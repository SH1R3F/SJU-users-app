import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { e as useAuthStore, h as storeToRefs, f as useLocalization, G as useSubscriberStore, u as useNuxtApp, a as useHead, d as useToast } from './server.mjs';
import { ref, resolveComponent, unref, withCtx, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderStyle } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "profile",
  __ssrInlineRender: true,
  setup(__props) {
    const { genders, countries, cities, qualifications, mobileCodes } = useSiteConfig();
    const authStore = useAuthStore();
    const { userData } = storeToRefs(authStore);
    const { dblocalize } = useLocalization();
    const profileData = ref({});
    const toast = useToast();
    const subscriberStore = useSubscriberStore();
    const updateSubscriber = async (body, node) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const { error } = await subscriberStore.updateSubscriber(body);
      if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) === 400) {
        node.setErrors((_c = error.value) == null ? void 0 : _c.data);
      } else if (((_e = (_d = error == null ? void 0 : error.value) == null ? void 0 : _d.response) == null ? void 0 : _e.status) === 422) {
        toast.error((_g = (_f = error.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message);
      }
    };
    const updatePassword = async (body, node) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const { error } = await subscriberStore.updatePassword(body);
      if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) === 400) {
        node.setErrors((_c = error.value) == null ? void 0 : _c.data);
      } else if (((_e = (_d = error == null ? void 0 : error.value) == null ? void 0 : _d.response) == null ? void 0 : _e.status) === 422) {
        toast.error((_g = (_f = error.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message);
      }
    };
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Edit profile");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="form"><div class="form-title font-semibold">${ssrInterpolate(_ctx.$translate("Edit profile"))}</div>`);
      if (Object.keys(unref(userData)).length) {
        _push(ssrRenderComponent(_component_FormKit, {
          type: "form",
          modelValue: profileData.value,
          "onUpdate:modelValue": ($event) => profileData.value = $event,
          actions: false,
          onSubmit: updateSubscriber
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
            if (_push2) {
              _push2(`<div class="flex flex-wrap gap-y-5 mb-8"${_scopeId}><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(_ctx.$translate("fname"))}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(dblocalize)(unref(userData), "fname"))}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(_ctx.$translate("sname"))}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(dblocalize)(unref(userData), "sname"))}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(_ctx.$translate("tname"))}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(dblocalize)(unref(userData), "tname"))}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(_ctx.$translate("lname"))}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(dblocalize)(unref(userData), "lname"))}</h4></div></div>`);
              {
                _push2(`<div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Gender"))}</label>`);
                _push2(ssrRenderComponent(_component_FormKit, {
                  "outer-class": "mb-3 w-full sm:w-10/12",
                  type: "myRadio",
                  name: "gender",
                  options: unref(genders),
                  "validation-label": _ctx.$translate("Gender"),
                  validation: "required",
                  classes: {
                    options: "flex items-center",
                    option: {
                      "formkit-option": false
                    },
                    inner: "m-3"
                  },
                  value: (_a = unref(userData)) == null ? void 0 : _a.gender
                }, null, _parent2, _scopeId));
                _push2(`</div>`);
              }
              _push2(`<div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Country"))}</label>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "select",
                classes: {
                  outer: "w-full sm:w-10/12",
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full": true
                  }
                },
                "sections-schema": {
                  selectIcon: { $el: null }
                },
                options: unref(countries),
                name: "country",
                "validation-label": _ctx.$translate("Country"),
                validation: "required",
                value: ((_b = unref(userData)) == null ? void 0 : _b.country) || 0
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
              if (profileData.value.country === 0) {
                _push2(`<div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("City"))}</label>`);
                _push2(ssrRenderComponent(_component_FormKit, {
                  type: "select",
                  classes: {
                    outer: "w-full sm:w-10/12",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(cities),
                  name: "city",
                  "validation-label": _ctx.$translate("City"),
                  validation: "required",
                  value: ((_c = unref(userData)) == null ? void 0 : _c.city) || 0
                }, null, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Nationality"))}</label><div class="w-full sm:w-10/12"${_scopeId}><h5 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(countries)[(_d = unref(userData)) == null ? void 0 : _d.nationality].label)}</h5></div></div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Email"))}</label><div class="w-full sm:w-10/12"${_scopeId}><h5 class="text-sju-50"${_scopeId}>${ssrInterpolate((_e = unref(userData)) == null ? void 0 : _e.email)}</h5></div></div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Qualification"))}</label>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "select",
                classes: {
                  outer: "w-full sm:w-10/12",
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full": true
                  }
                },
                "sections-schema": {
                  selectIcon: { $el: null }
                },
                options: unref(qualifications),
                name: "qualification",
                "validation-label": _ctx.$translate("Qualification"),
                validation: "required",
                value: ((_f = unref(userData)) == null ? void 0 : _f.qualification) || 0
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="formkit-outer flex flex-wrap mb-8" data-family="text"${_scopeId}><label for="mobile" class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Mobile"))}</label><div class="input-group [&amp;&gt;.formkit-outer]:mb-0 h-9 w-full sm:w-10/12" style="${ssrRenderStyle({ "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" })}"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "myTextInput",
                "outer-class": "w-full border border-y-0 m-0",
                id: "mobile",
                name: "mobile",
                placeholder: _ctx.$translate("Mobile"),
                validation: "required:trim|number",
                "validation-label": _ctx.$translate("Mobile"),
                value: ((_g = unref(userData)) == null ? void 0 : _g.mobile) || ""
              }, null, _parent2, _scopeId));
              _push2(`<span class="prepend"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "mySelect",
                name: "mobile_key",
                options: unref(mobileCodes),
                style: { "box-shadow": "none" },
                value: ((_h = unref(userData)) == null ? void 0 : _h.mobile_key) || 0
              }, null, _parent2, _scopeId));
              _push2(`</span></div></div><div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Save"))}</button></div>`);
            } else {
              return [
                createVNode("div", { class: "flex flex-wrap gap-y-5 mb-8" }, [
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(_ctx.$translate("fname")), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(dblocalize)(unref(userData), "fname")), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(_ctx.$translate("sname")), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(dblocalize)(unref(userData), "sname")), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(_ctx.$translate("tname")), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(dblocalize)(unref(userData), "tname")), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(_ctx.$translate("lname")), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(dblocalize)(unref(userData), "lname")), 1)
                  ])
                ]),
                (openBlock(), createBlock("div", {
                  key: 1,
                  class: "flex flex-wrap mb-8"
                }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Gender")), 1),
                  createVNode(_component_FormKit, {
                    "outer-class": "mb-3 w-full sm:w-10/12",
                    type: "myRadio",
                    name: "gender",
                    options: unref(genders),
                    "validation-label": _ctx.$translate("Gender"),
                    validation: "required",
                    classes: {
                      options: "flex items-center",
                      option: {
                        "formkit-option": false
                      },
                      inner: "m-3"
                    },
                    value: (_i = unref(userData)) == null ? void 0 : _i.gender
                  }, null, 8, ["options", "validation-label", "value"])
                ])),
                createVNode("div", { class: "flex flex-wrap mb-8" }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Country")), 1),
                  createVNode(_component_FormKit, {
                    type: "select",
                    classes: {
                      outer: "w-full sm:w-10/12",
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      }
                    },
                    "sections-schema": {
                      selectIcon: { $el: null }
                    },
                    options: unref(countries),
                    name: "country",
                    "validation-label": _ctx.$translate("Country"),
                    validation: "required",
                    value: ((_j = unref(userData)) == null ? void 0 : _j.country) || 0
                  }, null, 8, ["options", "validation-label", "value"])
                ]),
                profileData.value.country === 0 ? (openBlock(), createBlock("div", {
                  key: 2,
                  class: "flex flex-wrap mb-8"
                }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("City")), 1),
                  createVNode(_component_FormKit, {
                    type: "select",
                    classes: {
                      outer: "w-full sm:w-10/12",
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      }
                    },
                    "sections-schema": {
                      selectIcon: { $el: null }
                    },
                    options: unref(cities),
                    name: "city",
                    "validation-label": _ctx.$translate("City"),
                    validation: "required",
                    value: ((_k = unref(userData)) == null ? void 0 : _k.city) || 0
                  }, null, 8, ["options", "validation-label", "value"])
                ])) : createCommentVNode("", true),
                createVNode("div", { class: "flex flex-wrap mb-8" }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Nationality")), 1),
                  createVNode("div", { class: "w-full sm:w-10/12" }, [
                    createVNode("h5", { class: "text-sju-50" }, toDisplayString(unref(countries)[(_l = unref(userData)) == null ? void 0 : _l.nationality].label), 1)
                  ])
                ]),
                createVNode("div", { class: "flex flex-wrap mb-8" }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Email")), 1),
                  createVNode("div", { class: "w-full sm:w-10/12" }, [
                    createVNode("h5", { class: "text-sju-50" }, toDisplayString((_m = unref(userData)) == null ? void 0 : _m.email), 1)
                  ])
                ]),
                createVNode("div", { class: "flex flex-wrap mb-8" }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Qualification")), 1),
                  createVNode(_component_FormKit, {
                    type: "select",
                    classes: {
                      outer: "w-full sm:w-10/12",
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      }
                    },
                    "sections-schema": {
                      selectIcon: { $el: null }
                    },
                    options: unref(qualifications),
                    name: "qualification",
                    "validation-label": _ctx.$translate("Qualification"),
                    validation: "required",
                    value: ((_n = unref(userData)) == null ? void 0 : _n.qualification) || 0
                  }, null, 8, ["options", "validation-label", "value"])
                ]),
                createVNode("div", {
                  class: "formkit-outer flex flex-wrap mb-8",
                  "data-family": "text"
                }, [
                  createVNode("label", {
                    for: "mobile",
                    class: "w-full sm:w-2/12"
                  }, toDisplayString(_ctx.$translate("Mobile")), 1),
                  createVNode("div", {
                    class: "input-group [&>.formkit-outer]:mb-0 h-9 w-full sm:w-10/12",
                    style: { "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" }
                  }, [
                    createVNode(_component_FormKit, {
                      type: "myTextInput",
                      "outer-class": "w-full border border-y-0 m-0",
                      id: "mobile",
                      name: "mobile",
                      placeholder: _ctx.$translate("Mobile"),
                      validation: "required:trim|number",
                      "validation-label": _ctx.$translate("Mobile"),
                      value: ((_o = unref(userData)) == null ? void 0 : _o.mobile) || ""
                    }, null, 8, ["placeholder", "validation-label", "value"]),
                    createVNode("span", { class: "prepend" }, [
                      createVNode(_component_FormKit, {
                        type: "mySelect",
                        name: "mobile_key",
                        options: unref(mobileCodes),
                        style: { "box-shadow": "none" },
                        value: ((_p = unref(userData)) == null ? void 0 : _p.mobile_key) || 0
                      }, null, 8, ["options", "value"])
                    ])
                  ])
                ]),
                createVNode("div", { class: "text-end" }, [
                  createVNode("button", {
                    type: "submit",
                    class: "btn-primary"
                  }, toDisplayString(_ctx.$translate("Save")), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="form"><div class="form-title font-semibold">${ssrInterpolate(_ctx.$translate("Change password"))}</div>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: updatePassword
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-3/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Current password"))}</label>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                outer: "w-full sm:w-9/12",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("Current password"),
              id: "current_password",
              name: "current_password",
              "validation-label": _ctx.$translate("Current password"),
              validation: "required:trim|length:6"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-3/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("New password"))}</label>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                outer: "w-full sm:w-9/12",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("New password"),
              id: "new_password",
              name: "new_password",
              "validation-label": _ctx.$translate("New password"),
              validation: "required:trim|length:6"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-3/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Password confirmation"))}</label>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                outer: "w-full sm:w-9/12",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("Password confirmation"),
              id: "new_password_confirm",
              name: "new_password_confirm",
              "validation-label": _ctx.$translate("Password confirmation"),
              validation: "required:trim|length:6|confirm"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Save"))}</button></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-wrap mb-8" }, [
                createVNode("label", { class: "w-full sm:w-3/12" }, toDisplayString(_ctx.$translate("Current password")), 1),
                createVNode(_component_FormKit, {
                  classes: {
                    outer: "w-full sm:w-9/12",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("Current password"),
                  id: "current_password",
                  name: "current_password",
                  "validation-label": _ctx.$translate("Current password"),
                  validation: "required:trim|length:6"
                }, null, 8, ["placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "flex flex-wrap mb-8" }, [
                createVNode("label", { class: "w-full sm:w-3/12" }, toDisplayString(_ctx.$translate("New password")), 1),
                createVNode(_component_FormKit, {
                  classes: {
                    outer: "w-full sm:w-9/12",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("New password"),
                  id: "new_password",
                  name: "new_password",
                  "validation-label": _ctx.$translate("New password"),
                  validation: "required:trim|length:6"
                }, null, 8, ["placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "flex flex-wrap mb-8" }, [
                createVNode("label", { class: "w-full sm:w-3/12" }, toDisplayString(_ctx.$translate("Password confirmation")), 1),
                createVNode(_component_FormKit, {
                  classes: {
                    outer: "w-full sm:w-9/12",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("Password confirmation"),
                  id: "new_password_confirm",
                  name: "new_password_confirm",
                  "validation-label": _ctx.$translate("Password confirmation"),
                  validation: "required:trim|length:6|confirm"
                }, null, 8, ["placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  type: "submit",
                  class: "btn-primary"
                }, toDisplayString(_ctx.$translate("Save")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/subscribers/dashboard/profile.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=profile.2540d4e2.mjs.map
