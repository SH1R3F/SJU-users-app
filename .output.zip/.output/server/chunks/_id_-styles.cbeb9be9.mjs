const _id__vue_vue_type_style_index_0_lang = ".formkit-outer{margin-bottom:1px}[data-type=textarea] textarea{min-height:auto}";

const _id_Styles_cbeb9be9 = [_id__vue_vue_type_style_index_0_lang];

export { _id_Styles_cbeb9be9 as default };
//# sourceMappingURL=_id_-styles.cbeb9be9.mjs.map
