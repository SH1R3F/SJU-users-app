import { u as useNuxtApp, e as useAuthStore, a as useHead, p as useHomeStore, d as useToast } from './server.mjs';
import { ref, reactive, resolveComponent, mergeProps, withCtx, unref, createVNode, toDisplayString, createTextVNode, openBlock, createBlock, createCommentVNode, withDirectives, vShow, Fragment, renderList, withModifiers, useSSRContext, toRef, watch, createElementBlock, createElementVNode } from 'vue';
import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrRenderAttr, ssrInterpolate, ssrRenderStyle, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { getNode, createMessage } from '@formkit/core';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _hoisted_1 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M9 16.17L4.83 12l-1.42 1.41L9 19L21 7l-1.41-1.41L9 16.17z"
}, null, -1);
const _hoisted_3 = [
  _hoisted_2
];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, _hoisted_3);
}
const IcSharpCheck = { name: "ic-sharp-check", render };
const _sfc_main = {
  __name: "register",
  __ssrInlineRender: true,
  setup(__props) {
    const toast = useToast();
    const { $i18n } = useNuxtApp();
    const { branches, genders, nationalities, membershipTypes } = useSiteConfig();
    const memberData = ref({});
    const step = ref("registration");
    const steps = reactive({
      registration: {
        label: "Registration"
      },
      contactInfo: {
        label: "Contact info"
      },
      membershipTypes: {
        label: "Membership types"
      },
      memberInfo: {
        label: "Member info"
      },
      loginInfo: {
        label: "Login info"
      },
      review: {
        label: "Review"
      }
    });
    const visitedSteps = ref([]);
    const stepPlugin = (node) => {
      if (node.props.type == "group") {
        steps[node.name] = steps[node.name] || {};
        node.on("created", () => {
          steps[node.name].valid = toRef(node.context.state, "valid");
        });
        node.on("count:blocking", ({ payload: count }) => {
          steps[node.name].blockingCount = count;
        });
        node.on("count:errors", ({ payload: count }) => {
          steps[node.name].errorCount = count;
        });
        watch(step, (newStep, oldStep) => {
          if (oldStep && !visitedSteps.value.includes(oldStep)) {
            visitedSteps.value.push(oldStep);
          }
          visitedSteps.value.forEach((step2) => {
            const node2 = getNode(step2);
            node2.walk((n) => {
              n.store.set(
                createMessage({
                  key: "submitted",
                  value: true,
                  visible: false
                })
              );
            });
          });
        });
        return false;
      }
    };
    const checkStepValidity = (key) => {
      return (steps[key].errorCount > 0 || steps[key].blockingCount > 0) && visitedSteps.value.includes(key);
    };
    const authStore = useAuthStore();
    const registerMember = async (body, node) => {
      var _a, _b;
      node.clearErrors();
      useHomeStore().loading = true;
      const { error } = await authStore.registerMember(body);
      useHomeStore().loading = false;
      if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) == 400) {
        node.setErrors(error.value.data);
        toast.error($i18n.translate("Error in one or more fields"));
      } else if (error == null ? void 0 : error.value) {
        toast.error($i18n.translate("Error in registration"));
      }
    };
    const setStep = (n) => {
      const keys = Object.keys(steps);
      const to = keys[keys.indexOf(step.value) + n];
      if (to) {
        step.value = to;
      }
    };
    const dateChanged = (e) => {
      memberData.value.memberInfo[e.target.name] = e.target.value;
    };
    const title = $i18n.translate("Register new member");
    useHead({
      title,
      script: [
        {
          src: "/libs/datepicker/js/datepicker-hijri.js"
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "my-20" }, _attrs))}><div class="container"><div class="members-form form">`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        plugins: [stepPlugin],
        onSubmit: registerMember,
        actions: false,
        modelValue: memberData.value,
        "onUpdate:modelValue": ($event) => memberData.value = $event
      }, {
        default: withCtx(({ value }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<ul class="w-full border-b"${_scopeId}><!--[-->`);
            ssrRenderList(steps, (value2, key) => {
              _push2(`<li class="${ssrRenderClass([{ active: step.value == key }, "w-full text-center sm:w-auto sm:text-start cursor-pointer inline-block text-sju-50 text-sm px-5 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300"])}"${ssrRenderAttr("data-step-active", step.value == key)}${ssrRenderAttr("data-step-valid", value2.valid)}${_scopeId}>${ssrInterpolate(_ctx.$translate(value2 == null ? void 0 : value2.label))} `);
              if (checkStepValidity(key)) {
                _push2(`<span class="bg-red-600 text-white w-5 inline-block text-center rounded-full"${_scopeId}>${ssrInterpolate(value2.errorCount + value2.blockingCount)}</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</li>`);
            });
            _push2(`<!--]--></ul><div class="pt-10"${_scopeId}><section style="${ssrRenderStyle(step.value == "registration" ? null : { display: "none" })}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "group",
              id: "registration",
              name: "registration"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<h5 class="form-title"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Terms and policies"))}</h5><ol class="mb-5 [&amp;&gt;li]:flex [&amp;&gt;li]:gap-2 [&amp;&gt;li]:my-2 [&amp;&gt;li]:text-sju-200"${_scopeId2}><li${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(IcSharpCheck), null, null, _parent3, _scopeId2));
                  _push3(` ${ssrInterpolate(_ctx.$translate("member_rule1"))}</li><li${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(IcSharpCheck), null, null, _parent3, _scopeId2));
                  _push3(` ${ssrInterpolate(_ctx.$translate("member_rule2"))}</li><li${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(IcSharpCheck), null, null, _parent3, _scopeId2));
                  _push3(` ${ssrInterpolate(_ctx.$translate("member_rule3"))}</li><li${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(IcSharpCheck), null, null, _parent3, _scopeId2));
                  _push3(` ${ssrInterpolate(_ctx.$translate("member_rule4"))}</li><li${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(IcSharpCheck), null, null, _parent3, _scopeId2));
                  _push3(` ${ssrInterpolate(_ctx.$translate("member_rule5"))}</li><li${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(IcSharpCheck), null, null, _parent3, _scopeId2));
                  _push3(` ${ssrInterpolate(_ctx.$translate("member_rule6"))}</li></ol>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    type: "checkbox",
                    label: _ctx.$translate("TermsAgreement"),
                    "validation-label": _ctx.$translate("acceptance"),
                    validation: "required|accepted",
                    name: "terms_and_agreement",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full flex items-center": true
                      },
                      inner: "mx-1",
                      label: { "text-lg mx-2": true, "formkit-label": false }
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`<hr class="my-10"${_scopeId2}>`);
                  if (memberData.value.registration.terms_and_agreement) {
                    _push3(`<div${_scopeId2}>`);
                    _push3(ssrRenderComponent(_component_FormKit, {
                      label: _ctx.$translate("ID or residence number"),
                      type: "number",
                      name: "national_id",
                      id: "national_id",
                      classes: {
                        outer: "mb-3",
                        inner: "w-full md:w-6/12 mt-2",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex flex-col md:flex-row items-center": true
                        },
                        label: "w-full md:w-2/12"
                      },
                      placeholder: _ctx.$translate("National ID"),
                      validation: "required:trim|number|length:10,10",
                      "validation-label": _ctx.$translate("National ID")
                    }, null, _parent3, _scopeId2));
                    _push3(`</div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                } else {
                  return [
                    createVNode("h5", { class: "form-title" }, toDisplayString(_ctx.$translate("Terms and policies")), 1),
                    createVNode("ol", { class: "mb-5 [&>li]:flex [&>li]:gap-2 [&>li]:my-2 [&>li]:text-sju-200" }, [
                      createVNode("li", null, [
                        createVNode(unref(IcSharpCheck)),
                        createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule1")), 1)
                      ]),
                      createVNode("li", null, [
                        createVNode(unref(IcSharpCheck)),
                        createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule2")), 1)
                      ]),
                      createVNode("li", null, [
                        createVNode(unref(IcSharpCheck)),
                        createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule3")), 1)
                      ]),
                      createVNode("li", null, [
                        createVNode(unref(IcSharpCheck)),
                        createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule4")), 1)
                      ]),
                      createVNode("li", null, [
                        createVNode(unref(IcSharpCheck)),
                        createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule5")), 1)
                      ]),
                      createVNode("li", null, [
                        createVNode(unref(IcSharpCheck)),
                        createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule6")), 1)
                      ])
                    ]),
                    createVNode(_component_FormKit, {
                      type: "checkbox",
                      label: _ctx.$translate("TermsAgreement"),
                      "validation-label": _ctx.$translate("acceptance"),
                      validation: "required|accepted",
                      name: "terms_and_agreement",
                      classes: {
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex items-center": true
                        },
                        inner: "mx-1",
                        label: { "text-lg mx-2": true, "formkit-label": false }
                      }
                    }, null, 8, ["label", "validation-label"]),
                    createVNode("hr", { class: "my-10" }),
                    memberData.value.registration.terms_and_agreement ? (openBlock(), createBlock("div", { key: 0 }, [
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("ID or residence number"),
                        type: "number",
                        name: "national_id",
                        id: "national_id",
                        classes: {
                          outer: "mb-3",
                          inner: "w-full md:w-6/12 mt-2",
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full flex flex-col md:flex-row items-center": true
                          },
                          label: "w-full md:w-2/12"
                        },
                        placeholder: _ctx.$translate("National ID"),
                        validation: "required:trim|number|length:10,10",
                        "validation-label": _ctx.$translate("National ID")
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ])) : createCommentVNode("", true)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</section><section style="${ssrRenderStyle(step.value == "contactInfo" ? null : { display: "none" })}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              id: "contactInfo",
              type: "group",
              name: "contactInfo"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex flex-col md:flex-row items-center" data-family="text"${_scopeId2}><label for="mobile" class="formkit-label w-full md:w-2/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Mobile"))}</label><div class="input-group [&amp;&gt;.formkit-outer]:mb-0 h-9 w-full md:w-6/12" style="${ssrRenderStyle({ "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" })}"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    type: "myTextInput",
                    "outer-class": "w-full border border-y-0 m-0",
                    id: "mobile",
                    name: "mobile",
                    placeholder: _ctx.$translate("Mobile"),
                    validation: "required:trim|number|matches:/^(5)\\d{8}$/",
                    "validation-label": _ctx.$translate("Mobile"),
                    "validation-messages": {
                      matches: _ctx.$translate("Please enter a valid phone number. eg: 501234567")
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`<span class="prepend"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    type: "mySelect",
                    name: "mobile_key",
                    options: [{ label: "+966", value: "966" }],
                    style: { "box-shadow": "none" }
                  }, null, _parent3, _scopeId2));
                  _push3(`</span></div></div>`);
                } else {
                  return [
                    createVNode("div", {
                      class: "flex flex-col md:flex-row items-center",
                      "data-family": "text"
                    }, [
                      createVNode("label", {
                        for: "mobile",
                        class: "formkit-label w-full md:w-2/12"
                      }, toDisplayString(_ctx.$translate("Mobile")), 1),
                      createVNode("div", {
                        class: "input-group [&>.formkit-outer]:mb-0 h-9 w-full md:w-6/12",
                        style: { "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" }
                      }, [
                        createVNode(_component_FormKit, {
                          type: "myTextInput",
                          "outer-class": "w-full border border-y-0 m-0",
                          id: "mobile",
                          name: "mobile",
                          placeholder: _ctx.$translate("Mobile"),
                          validation: "required:trim|number|matches:/^(5)\\d{8}$/",
                          "validation-label": _ctx.$translate("Mobile"),
                          "validation-messages": {
                            matches: _ctx.$translate("Please enter a valid phone number. eg: 501234567")
                          }
                        }, null, 8, ["placeholder", "validation-label", "validation-messages"]),
                        createVNode("span", { class: "prepend" }, [
                          createVNode(_component_FormKit, {
                            type: "mySelect",
                            name: "mobile_key",
                            options: [{ label: "+966", value: "966" }],
                            style: { "box-shadow": "none" }
                          })
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</section><section style="${ssrRenderStyle(step.value == "membershipTypes" ? null : { display: "none" })}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              id: "membershipTypes",
              type: "group",
              name: "membershipTypes"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<table class="w-full text-gray-500 dark:text-gray-400 mb-6"${_scopeId2}><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"${_scopeId2}><tr class="md:text-lg"${_scopeId2}><th scope="col" class="py-3 px-6 text-start"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Choose the type that fits you"))}</th><th scope="col" class="py-3 px-6 text-start"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Amount"))}</th></tr></thead><tbody class="text-start"${_scopeId2}><tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId2}><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    "outer-class": "mb-3",
                    type: "myRadio",
                    name: "membership_type",
                    options: [
                      {
                        label: _ctx.$translate("fulltime_member"),
                        value: 1
                      }
                    ],
                    "validation-label": _ctx.$translate("fulltime_member"),
                    validation: "required",
                    classes: {
                      options: "flex items-center",
                      option: {
                        "formkit-option": false
                      },
                      wrapper: "m-0",
                      label: {
                        "formkit-label": false,
                        "md:text-2xl text-sju-200 font-bold": true
                      }
                    },
                    "validation-messages": {
                      required: _ctx.$translate("You have to choose member type")
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId2}><span class="md:text-xl text-sju-50 font-bold"${_scopeId2}>250 ${ssrInterpolate(_ctx.$translate("Riyal"))}\xA0 </span><span class="font-bold text-xs"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Annual"))}*</span></td></tr><tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId2}><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800" colspan="2"${_scopeId2}><ul class="text-sm md:text-base list-decimal md:mx-7"${_scopeId2}><li${_scopeId2}>${ssrInterpolate(_ctx.$translate("fulltime_member_desc1"))}</li><li${_scopeId2}>${ssrInterpolate(_ctx.$translate("fulltime_member_desc2"))}</li><li${_scopeId2}>${ssrInterpolate(_ctx.$translate("fulltime_member_desc3"))}</li></ul></td></tr><tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId2}><td class="py-4 px-6"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    "outer-class": "mb-3",
                    type: "myRadio",
                    name: "membership_type",
                    options: [
                      {
                        label: _ctx.$translate("parttime_member"),
                        value: 2
                      }
                    ],
                    "validation-label": _ctx.$translate("parttime_member"),
                    validation: "required",
                    classes: {
                      options: "flex items-center",
                      option: {
                        "formkit-option": false
                      },
                      wrapper: "m-0",
                      label: {
                        "formkit-label": false,
                        "md:text-2xl text-sju-200 font-bold": true
                      }
                    },
                    "validation-messages": {
                      required: _ctx.$translate("You have to choose member type")
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`</td><td class="py-4 px-6"${_scopeId2}><span class="md:text-xl text-sju-50 font-bold"${_scopeId2}>200 ${ssrInterpolate(_ctx.$translate("Riyal"))}\xA0 </span><span class="font-bold text-xs"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Annual"))}*</span></td></tr><tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId2}><td class="py-4 px-6" colspan="2"${_scopeId2}><ul class="text-sm md:text-base list-decimal md:mx-7"${_scopeId2}><li${_scopeId2}>${ssrInterpolate(_ctx.$translate("parttime_member_desc1"))}</li><li${_scopeId2}>${ssrInterpolate(_ctx.$translate("parttime_member_desc2"))}</li></ul></td></tr><tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId2}><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    "outer-class": "mb-3",
                    type: "myRadio",
                    name: "membership_type",
                    options: [
                      {
                        label: _ctx.$translate("affiliate_member"),
                        value: 3
                      }
                    ],
                    "validation-label": _ctx.$translate("affiliate_member"),
                    validation: "required",
                    classes: {
                      options: "flex items-center",
                      option: {
                        "formkit-option": false
                      },
                      wrapper: "m-0",
                      label: {
                        "formkit-label": false,
                        "md:text-2xl text-sju-200 font-bold": true
                      }
                    },
                    "validation-messages": {
                      required: _ctx.$translate("You have to choose member type")
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId2}><span class="md:text-xl text-sju-50 font-bold"${_scopeId2}>150 ${ssrInterpolate(_ctx.$translate("Riyal"))}\xA0 </span><span class="font-bold text-xs"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Annual"))}*</span></td></tr><tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId2}><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800" colspan="2"${_scopeId2}><ul class="text-sm md:text-base list-decimal md:mx-7"${_scopeId2}><li${_scopeId2}>${ssrInterpolate(_ctx.$translate("affiliate_member_desc1"))}</li></ul></td></tr></tbody></table>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Membership branch"),
                    type: "select",
                    name: "branch",
                    id: "branch",
                    classes: {
                      outer: "mb-3",
                      inner: "w-full md:w-6/12 mt-2",
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full flex flex-col md:flex-row items-center": true
                      },
                      label: "w-full md:w-2/12"
                    },
                    "sections-schema": {
                      selectIcon: { $el: null }
                    },
                    options: unref(branches),
                    placeholder: _ctx.$translate("Membership branch"),
                    validation: "required",
                    "validation-label": _ctx.$translate("Membership branch")
                  }, null, _parent3, _scopeId2));
                  if (memberData.value.membershipTypes.branch == 8) {
                    _push3(ssrRenderComponent(_component_FormKit, {
                      label: _ctx.$translate("Delivery method"),
                      help: _ctx.$translate(
                        "If you choose delivery, 30 riyals will be added to the invoice value."
                      ),
                      type: "select",
                      name: "delivery_method",
                      id: "delivery_method",
                      classes: {
                        outer: "mb-3",
                        inner: "w-full md:w-6/12 mt-2",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex flex-col md:flex-row items-center": true
                        },
                        label: "w-full md:w-2/12"
                      },
                      options: [
                        {
                          label: _ctx.$translate("Receipt from the branch"),
                          value: 1
                        },
                        {
                          label: _ctx.$translate("Delivery"),
                          value: 2
                        }
                      ],
                      "sections-schema": {
                        selectIcon: { $el: null }
                      },
                      placeholder: _ctx.$translate("Delivery method"),
                      validation: "required",
                      "validation-label": _ctx.$translate("Delivery method")
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  if (memberData.value.membershipTypes.branch == 8 && memberData.value.membershipTypes.delivery_method == 2) {
                    _push3(ssrRenderComponent(_component_FormKit, {
                      label: _ctx.$translate("Delivery Address"),
                      type: "text",
                      name: "delivery_address",
                      id: "delivery_address",
                      classes: {
                        outer: "mb-3",
                        inner: "w-full md:w-6/12 mt-2",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex flex-col md:flex-row items-center": true
                        },
                        label: "w-full md:w-2/12"
                      },
                      placeholder: _ctx.$translate("Delivery Address"),
                      validation: "required:trim",
                      "validation-label": _ctx.$translate("Delivery Address")
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                } else {
                  return [
                    createVNode("table", { class: "w-full text-gray-500 dark:text-gray-400 mb-6" }, [
                      createVNode("thead", { class: "text-xs text-gray-700 uppercase dark:text-gray-400" }, [
                        createVNode("tr", { class: "md:text-lg" }, [
                          createVNode("th", {
                            scope: "col",
                            class: "py-3 px-6 text-start"
                          }, toDisplayString(_ctx.$translate("Choose the type that fits you")), 1),
                          createVNode("th", {
                            scope: "col",
                            class: "py-3 px-6 text-start"
                          }, toDisplayString(_ctx.$translate("Amount")), 1)
                        ])
                      ]),
                      createVNode("tbody", { class: "text-start" }, [
                        createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                          createVNode("td", { class: "py-4 px-6 bg-gray-50 dark:bg-gray-800" }, [
                            createVNode(_component_FormKit, {
                              "outer-class": "mb-3",
                              type: "myRadio",
                              name: "membership_type",
                              options: [
                                {
                                  label: _ctx.$translate("fulltime_member"),
                                  value: 1
                                }
                              ],
                              "validation-label": _ctx.$translate("fulltime_member"),
                              validation: "required",
                              classes: {
                                options: "flex items-center",
                                option: {
                                  "formkit-option": false
                                },
                                wrapper: "m-0",
                                label: {
                                  "formkit-label": false,
                                  "md:text-2xl text-sju-200 font-bold": true
                                }
                              },
                              "validation-messages": {
                                required: _ctx.$translate("You have to choose member type")
                              }
                            }, null, 8, ["options", "validation-label", "validation-messages"])
                          ]),
                          createVNode("td", { class: "py-4 px-6 bg-gray-50 dark:bg-gray-800" }, [
                            createVNode("span", { class: "md:text-xl text-sju-50 font-bold" }, "250 " + toDisplayString(_ctx.$translate("Riyal")) + "\xA0 ", 1),
                            createVNode("span", { class: "font-bold text-xs" }, toDisplayString(_ctx.$translate("Annual")) + "*", 1)
                          ])
                        ]),
                        createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                          createVNode("td", {
                            class: "py-4 px-6 bg-gray-50 dark:bg-gray-800",
                            colspan: "2"
                          }, [
                            createVNode("ul", { class: "text-sm md:text-base list-decimal md:mx-7" }, [
                              createVNode("li", null, toDisplayString(_ctx.$translate("fulltime_member_desc1")), 1),
                              createVNode("li", null, toDisplayString(_ctx.$translate("fulltime_member_desc2")), 1),
                              createVNode("li", null, toDisplayString(_ctx.$translate("fulltime_member_desc3")), 1)
                            ])
                          ])
                        ]),
                        createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                          createVNode("td", { class: "py-4 px-6" }, [
                            createVNode(_component_FormKit, {
                              "outer-class": "mb-3",
                              type: "myRadio",
                              name: "membership_type",
                              options: [
                                {
                                  label: _ctx.$translate("parttime_member"),
                                  value: 2
                                }
                              ],
                              "validation-label": _ctx.$translate("parttime_member"),
                              validation: "required",
                              classes: {
                                options: "flex items-center",
                                option: {
                                  "formkit-option": false
                                },
                                wrapper: "m-0",
                                label: {
                                  "formkit-label": false,
                                  "md:text-2xl text-sju-200 font-bold": true
                                }
                              },
                              "validation-messages": {
                                required: _ctx.$translate("You have to choose member type")
                              }
                            }, null, 8, ["options", "validation-label", "validation-messages"])
                          ]),
                          createVNode("td", { class: "py-4 px-6" }, [
                            createVNode("span", { class: "md:text-xl text-sju-50 font-bold" }, "200 " + toDisplayString(_ctx.$translate("Riyal")) + "\xA0 ", 1),
                            createVNode("span", { class: "font-bold text-xs" }, toDisplayString(_ctx.$translate("Annual")) + "*", 1)
                          ])
                        ]),
                        createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                          createVNode("td", {
                            class: "py-4 px-6",
                            colspan: "2"
                          }, [
                            createVNode("ul", { class: "text-sm md:text-base list-decimal md:mx-7" }, [
                              createVNode("li", null, toDisplayString(_ctx.$translate("parttime_member_desc1")), 1),
                              createVNode("li", null, toDisplayString(_ctx.$translate("parttime_member_desc2")), 1)
                            ])
                          ])
                        ]),
                        createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                          createVNode("td", { class: "py-4 px-6 bg-gray-50 dark:bg-gray-800" }, [
                            createVNode(_component_FormKit, {
                              "outer-class": "mb-3",
                              type: "myRadio",
                              name: "membership_type",
                              options: [
                                {
                                  label: _ctx.$translate("affiliate_member"),
                                  value: 3
                                }
                              ],
                              "validation-label": _ctx.$translate("affiliate_member"),
                              validation: "required",
                              classes: {
                                options: "flex items-center",
                                option: {
                                  "formkit-option": false
                                },
                                wrapper: "m-0",
                                label: {
                                  "formkit-label": false,
                                  "md:text-2xl text-sju-200 font-bold": true
                                }
                              },
                              "validation-messages": {
                                required: _ctx.$translate("You have to choose member type")
                              }
                            }, null, 8, ["options", "validation-label", "validation-messages"])
                          ]),
                          createVNode("td", { class: "py-4 px-6 bg-gray-50 dark:bg-gray-800" }, [
                            createVNode("span", { class: "md:text-xl text-sju-50 font-bold" }, "150 " + toDisplayString(_ctx.$translate("Riyal")) + "\xA0 ", 1),
                            createVNode("span", { class: "font-bold text-xs" }, toDisplayString(_ctx.$translate("Annual")) + "*", 1)
                          ])
                        ]),
                        createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                          createVNode("td", {
                            class: "py-4 px-6 bg-gray-50 dark:bg-gray-800",
                            colspan: "2"
                          }, [
                            createVNode("ul", { class: "text-sm md:text-base list-decimal md:mx-7" }, [
                              createVNode("li", null, toDisplayString(_ctx.$translate("affiliate_member_desc1")), 1)
                            ])
                          ])
                        ])
                      ])
                    ]),
                    createVNode(_component_FormKit, {
                      label: _ctx.$translate("Membership branch"),
                      type: "select",
                      name: "branch",
                      id: "branch",
                      classes: {
                        outer: "mb-3",
                        inner: "w-full md:w-6/12 mt-2",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex flex-col md:flex-row items-center": true
                        },
                        label: "w-full md:w-2/12"
                      },
                      "sections-schema": {
                        selectIcon: { $el: null }
                      },
                      options: unref(branches),
                      placeholder: _ctx.$translate("Membership branch"),
                      validation: "required",
                      "validation-label": _ctx.$translate("Membership branch")
                    }, null, 8, ["label", "options", "placeholder", "validation-label"]),
                    memberData.value.membershipTypes.branch == 8 ? (openBlock(), createBlock(_component_FormKit, {
                      key: 0,
                      label: _ctx.$translate("Delivery method"),
                      help: _ctx.$translate(
                        "If you choose delivery, 30 riyals will be added to the invoice value."
                      ),
                      type: "select",
                      name: "delivery_method",
                      id: "delivery_method",
                      classes: {
                        outer: "mb-3",
                        inner: "w-full md:w-6/12 mt-2",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex flex-col md:flex-row items-center": true
                        },
                        label: "w-full md:w-2/12"
                      },
                      options: [
                        {
                          label: _ctx.$translate("Receipt from the branch"),
                          value: 1
                        },
                        {
                          label: _ctx.$translate("Delivery"),
                          value: 2
                        }
                      ],
                      "sections-schema": {
                        selectIcon: { $el: null }
                      },
                      placeholder: _ctx.$translate("Delivery method"),
                      validation: "required",
                      "validation-label": _ctx.$translate("Delivery method")
                    }, null, 8, ["label", "help", "options", "placeholder", "validation-label"])) : createCommentVNode("", true),
                    memberData.value.membershipTypes.branch == 8 && memberData.value.membershipTypes.delivery_method == 2 ? (openBlock(), createBlock(_component_FormKit, {
                      key: 1,
                      label: _ctx.$translate("Delivery Address"),
                      type: "text",
                      name: "delivery_address",
                      id: "delivery_address",
                      classes: {
                        outer: "mb-3",
                        inner: "w-full md:w-6/12 mt-2",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex flex-col md:flex-row items-center": true
                        },
                        label: "w-full md:w-2/12"
                      },
                      placeholder: _ctx.$translate("Delivery Address"),
                      validation: "required:trim",
                      "validation-label": _ctx.$translate("Delivery Address")
                    }, null, 8, ["label", "placeholder", "validation-label"])) : createCommentVNode("", true)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</section><section style="${ssrRenderStyle(step.value == "memberInfo" ? null : { display: "none" })}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              id: "memberInfo",
              type: "group",
              name: "memberInfo"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a, _b, _c, _d, _e, _f;
                if (_push3) {
                  _push3(`<div class="row-of-two mb-7"${_scopeId2}><div class="flex flex-col sm:flex-row items-center"${_scopeId2}><label class="font-bold w-full sm:w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("ID or residence number"))}</label><div class="w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center"${_scopeId2}>${ssrInterpolate((_a = memberData.value) == null ? void 0 : _a.registration.national_id)}</div></div><div class="flex flex-col sm:flex-row items-center"${_scopeId2}><label class="font-bold w-full sm:w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Mobile"))}</label><div class="w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" style="${ssrRenderStyle(((_b = memberData.value) == null ? void 0 : _b.contactInfo.mobile) ? null : { display: "none" })}"${_scopeId2}> 966${ssrInterpolate((_c = memberData.value) == null ? void 0 : _c.contactInfo.mobile)}</div></div></div><div class="row-of-two"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("ID source"),
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    type: "text",
                    placeholder: _ctx.$translate("ID source"),
                    name: "source",
                    "validation-label": _ctx.$translate("ID source"),
                    validation: "required:trim"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("ID date")} (${_ctx.$translate("Hijri")})`,
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    placeholder: _ctx.$translate("ID date"),
                    name: "date",
                    id: "date",
                    validation: "required",
                    "validation-label": _ctx.$translate("ID date"),
                    onChange: dateChanged
                  }, null, _parent3, _scopeId2));
                  _push3(`<datepicker-hijri reference="date" placement="bottom" date-format="iYYYY/iMM/iDD" selected-date="1441/02/01"${_scopeId2}></datepicker-hijri></div><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`,
                    type: "text",
                    name: "fname_ar",
                    id: "fname_ar",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    placeholder: _ctx.$translate("fname"),
                    validation: "required:trim|length:3,50",
                    "validation-label": _ctx.$translate("fname")
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`,
                    type: "text",
                    name: "sname_ar",
                    id: "sname_ar",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    placeholder: _ctx.$translate("sname"),
                    validation: "required:trim|length:3,50",
                    "validation-label": _ctx.$translate("sname")
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`,
                    type: "text",
                    name: "tname_ar",
                    id: "tname_ar",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    placeholder: _ctx.$translate("tname"),
                    validation: "required:trim|length:3,50",
                    "validation-label": _ctx.$translate("tname")
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`,
                    type: "text",
                    name: "lname_ar",
                    id: "lname_ar",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    placeholder: _ctx.$translate("lname"),
                    validation: "required:trim|length:3,50",
                    "validation-label": _ctx.$translate("lname")
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    type: "text",
                    label: `${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`,
                    name: "fname_en",
                    id: "fname_en",
                    placeholder: _ctx.$translate("fname"),
                    validation: "required:trim|length:3,50",
                    "validation-label": _ctx.$translate("fname")
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    type: "text",
                    label: `${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`,
                    name: "sname_en",
                    id: "sname_en",
                    placeholder: _ctx.$translate("sname"),
                    validation: "required:trim|length:3,50",
                    "validation-label": _ctx.$translate("sname")
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    type: "text",
                    label: `${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`,
                    name: "tname_en",
                    id: "tname_en",
                    placeholder: _ctx.$translate("tname"),
                    validation: "required:trim|length:3,50",
                    "validation-label": _ctx.$translate("tname")
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    type: "text",
                    label: `${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`,
                    name: "lname_en",
                    id: "lname_en",
                    placeholder: _ctx.$translate("lname"),
                    validation: "required:trim|length:3,50",
                    "validation-label": _ctx.$translate("lname")
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    "outer-class": "mb-3",
                    type: "myRadio",
                    name: "gender",
                    label: _ctx.$translate("Gender"),
                    options: unref(genders),
                    "validation-label": _ctx.$translate("Gender"),
                    validation: "required",
                    classes: {
                      options: "flex items-center",
                      option: {
                        "formkit-option": false
                      },
                      inner: "m-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`<div class="row-of-two"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("Birth date")} (${_ctx.$translate("Milady")})`,
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3",
                      input: "h-9 text-right"
                    },
                    placeholder: _ctx.$translate("Birth date"),
                    validation: "required",
                    type: "date",
                    name: "birthday_meladi",
                    "validation-label": _ctx.$translate("Birth date")
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("Birth date")} (${_ctx.$translate("Hijri")})`,
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    placeholder: _ctx.$translate("Birth date"),
                    name: "birthday_hijri",
                    id: "birthday_hijri",
                    validation: "required",
                    "validation-label": _ctx.$translate("Birth date"),
                    onChange: dateChanged
                  }, null, _parent3, _scopeId2));
                  _push3(`<datepicker-hijri reference="birthday_hijri" placement="bottom" date-format="iYYYY/iMM/iDD"${_scopeId2}></datepicker-hijri></div>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Nationality"),
                    type: "select",
                    "sections-schema": {
                      selectIcon: { $el: null }
                    },
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    options: unref(nationalities),
                    name: "nationality",
                    "validation-label": _ctx.$translate("Nationality"),
                    validation: "required"
                  }, null, _parent3, _scopeId2));
                  _push3(`<div class="row-of-two"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    "outer-class": "mb-3",
                    type: "text",
                    label: _ctx.$translate("Qualification"),
                    name: "qualification",
                    id: "qualification",
                    placeholder: _ctx.$translate("Qualification"),
                    validation: "required:trim",
                    "validation-label": _ctx.$translate("Qualification"),
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    "outer-class": "mb-3",
                    type: "text",
                    label: _ctx.$translate("Major"),
                    name: "major",
                    id: "major",
                    placeholder: _ctx.$translate("Major"),
                    validation: "required:trim",
                    "validation-label": _ctx.$translate("Major"),
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Journalist")})`,
                    type: "text",
                    placeholder: _ctx.$translate("Job title"),
                    name: "journalist_job_title",
                    "validation-label": _ctx.$translate("Job title"),
                    validation: "required:trim",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Employer"),
                    type: "text",
                    placeholder: _ctx.$translate("Employer"),
                    name: "journalist_employer",
                    "validation-label": _ctx.$translate("Employer"),
                    validation: "required:trim",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Newspaper type"),
                    type: "select",
                    "sections-schema": {
                      selectIcon: { $el: null }
                    },
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    },
                    options: [
                      {
                        label: _ctx.$translate("Printed newspaper"),
                        value: 1
                      },
                      {
                        label: _ctx.$translate("E-newspaper"),
                        value: 2
                      }
                    ],
                    name: "newspaper_type",
                    "validation-label": _ctx.$translate("Newspaper type"),
                    validation: "required"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="row-of-two"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Non-Journalist")})`,
                    type: "text",
                    placeholder: _ctx.$translate("Job title"),
                    name: "job_title",
                    "validation-label": _ctx.$translate("Job title"),
                    validation: "required:trim",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Employer"),
                    type: "text",
                    placeholder: _ctx.$translate("Employer"),
                    name: "employer",
                    "validation-label": _ctx.$translate("Employer"),
                    validation: "required:trim",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="row-of-two"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Work phone"),
                    type: "text",
                    placeholder: _ctx.$translate("Work phone"),
                    name: "worktel",
                    "validation-label": _ctx.$translate("Work phone"),
                    validation: "required:trim|number",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Ext"),
                    type: "text",
                    placeholder: _ctx.$translate("Ext"),
                    name: "worktel_ext",
                    "validation-label": _ctx.$translate("Ext"),
                    validation: "required:trim|number",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="row-of-two"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Fax"),
                    type: "text",
                    placeholder: _ctx.$translate("Fax"),
                    name: "fax",
                    "validation-label": _ctx.$translate("Fax"),
                    validation: "required:trim|number",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Ext"),
                    type: "text",
                    placeholder: _ctx.$translate("Ext"),
                    name: "fax_ext",
                    "validation-label": _ctx.$translate("Ext"),
                    validation: "required:trim|number",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Post box"),
                    type: "text",
                    placeholder: _ctx.$translate("Post box"),
                    name: "post_box",
                    "validation-label": _ctx.$translate("Post box"),
                    validation: "required:trim|number",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Post code"),
                    type: "text",
                    placeholder: _ctx.$translate("Post code"),
                    name: "post_code",
                    "validation-label": _ctx.$translate("Post code"),
                    validation: "required:trim|number",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("City"),
                    type: "text",
                    placeholder: _ctx.$translate("City"),
                    name: "city",
                    "validation-label": _ctx.$translate("City"),
                    validation: "required:trim",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      },
                      outer: "mb-3"
                    }
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Email"),
                    classes: {
                      outer: "mb-3",
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      }
                    },
                    type: "email",
                    placeholder: _ctx.$translate("Email"),
                    id: "email",
                    name: "email",
                    "validation-label": _ctx.$translate("Email"),
                    validation: "required:trim|email"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("div", { class: "row-of-two mb-7" }, [
                      createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                        createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("ID or residence number")), 1),
                        createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, toDisplayString((_d = memberData.value) == null ? void 0 : _d.registration.national_id), 1)
                      ]),
                      createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                        createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("Mobile")), 1),
                        withDirectives(createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, " 966" + toDisplayString((_e = memberData.value) == null ? void 0 : _e.contactInfo.mobile), 513), [
                          [vShow, (_f = memberData.value) == null ? void 0 : _f.contactInfo.mobile]
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "row-of-two" }, [
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("ID source"),
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        type: "text",
                        placeholder: _ctx.$translate("ID source"),
                        name: "source",
                        "validation-label": _ctx.$translate("ID source"),
                        validation: "required:trim"
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("ID date")} (${_ctx.$translate("Hijri")})`,
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        placeholder: _ctx.$translate("ID date"),
                        name: "date",
                        id: "date",
                        validation: "required",
                        "validation-label": _ctx.$translate("ID date"),
                        onChange: dateChanged
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode("datepicker-hijri", {
                        reference: "date",
                        placement: "bottom",
                        "date-format": "iYYYY/iMM/iDD",
                        "selected-date": "1441/02/01"
                      })
                    ]),
                    createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`,
                        type: "text",
                        name: "fname_ar",
                        id: "fname_ar",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        placeholder: _ctx.$translate("fname"),
                        validation: "required:trim|length:3,50",
                        "validation-label": _ctx.$translate("fname")
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`,
                        type: "text",
                        name: "sname_ar",
                        id: "sname_ar",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        placeholder: _ctx.$translate("sname"),
                        validation: "required:trim|length:3,50",
                        "validation-label": _ctx.$translate("sname")
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`,
                        type: "text",
                        name: "tname_ar",
                        id: "tname_ar",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        placeholder: _ctx.$translate("tname"),
                        validation: "required:trim|length:3,50",
                        "validation-label": _ctx.$translate("tname")
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`,
                        type: "text",
                        name: "lname_ar",
                        id: "lname_ar",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        placeholder: _ctx.$translate("lname"),
                        validation: "required:trim|length:3,50",
                        "validation-label": _ctx.$translate("lname")
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ]),
                    createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                      createVNode(_component_FormKit, {
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        type: "text",
                        label: `${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`,
                        name: "fname_en",
                        id: "fname_en",
                        placeholder: _ctx.$translate("fname"),
                        validation: "required:trim|length:3,50",
                        "validation-label": _ctx.$translate("fname")
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        type: "text",
                        label: `${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`,
                        name: "sname_en",
                        id: "sname_en",
                        placeholder: _ctx.$translate("sname"),
                        validation: "required:trim|length:3,50",
                        "validation-label": _ctx.$translate("sname")
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        type: "text",
                        label: `${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`,
                        name: "tname_en",
                        id: "tname_en",
                        placeholder: _ctx.$translate("tname"),
                        validation: "required:trim|length:3,50",
                        "validation-label": _ctx.$translate("tname")
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        type: "text",
                        label: `${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`,
                        name: "lname_en",
                        id: "lname_en",
                        placeholder: _ctx.$translate("lname"),
                        validation: "required:trim|length:3,50",
                        "validation-label": _ctx.$translate("lname")
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ]),
                    createVNode(_component_FormKit, {
                      "outer-class": "mb-3",
                      type: "myRadio",
                      name: "gender",
                      label: _ctx.$translate("Gender"),
                      options: unref(genders),
                      "validation-label": _ctx.$translate("Gender"),
                      validation: "required",
                      classes: {
                        options: "flex items-center",
                        option: {
                          "formkit-option": false
                        },
                        inner: "m-3"
                      }
                    }, null, 8, ["label", "options", "validation-label"]),
                    createVNode("div", { class: "row-of-two" }, [
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("Birth date")} (${_ctx.$translate("Milady")})`,
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3",
                          input: "h-9 text-right"
                        },
                        placeholder: _ctx.$translate("Birth date"),
                        validation: "required",
                        type: "date",
                        name: "birthday_meladi",
                        "validation-label": _ctx.$translate("Birth date")
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("Birth date")} (${_ctx.$translate("Hijri")})`,
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        placeholder: _ctx.$translate("Birth date"),
                        name: "birthday_hijri",
                        id: "birthday_hijri",
                        validation: "required",
                        "validation-label": _ctx.$translate("Birth date"),
                        onChange: dateChanged
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode("datepicker-hijri", {
                        reference: "birthday_hijri",
                        placement: "bottom",
                        "date-format": "iYYYY/iMM/iDD"
                      })
                    ]),
                    createVNode(_component_FormKit, {
                      label: _ctx.$translate("Nationality"),
                      type: "select",
                      "sections-schema": {
                        selectIcon: { $el: null }
                      },
                      classes: {
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full": true
                        },
                        outer: "mb-3"
                      },
                      options: unref(nationalities),
                      name: "nationality",
                      "validation-label": _ctx.$translate("Nationality"),
                      validation: "required"
                    }, null, 8, ["label", "options", "validation-label"]),
                    createVNode("div", { class: "row-of-two" }, [
                      createVNode(_component_FormKit, {
                        "outer-class": "mb-3",
                        type: "text",
                        label: _ctx.$translate("Qualification"),
                        name: "qualification",
                        id: "qualification",
                        placeholder: _ctx.$translate("Qualification"),
                        validation: "required:trim",
                        "validation-label": _ctx.$translate("Qualification"),
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        "outer-class": "mb-3",
                        type: "text",
                        label: _ctx.$translate("Major"),
                        name: "major",
                        id: "major",
                        placeholder: _ctx.$translate("Major"),
                        validation: "required:trim",
                        "validation-label": _ctx.$translate("Major"),
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ]),
                    createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4" }, [
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Journalist")})`,
                        type: "text",
                        placeholder: _ctx.$translate("Job title"),
                        name: "journalist_job_title",
                        "validation-label": _ctx.$translate("Job title"),
                        validation: "required:trim",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Employer"),
                        type: "text",
                        placeholder: _ctx.$translate("Employer"),
                        name: "journalist_employer",
                        "validation-label": _ctx.$translate("Employer"),
                        validation: "required:trim",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Newspaper type"),
                        type: "select",
                        "sections-schema": {
                          selectIcon: { $el: null }
                        },
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        },
                        options: [
                          {
                            label: _ctx.$translate("Printed newspaper"),
                            value: 1
                          },
                          {
                            label: _ctx.$translate("E-newspaper"),
                            value: 2
                          }
                        ],
                        name: "newspaper_type",
                        "validation-label": _ctx.$translate("Newspaper type"),
                        validation: "required"
                      }, null, 8, ["label", "options", "validation-label"])
                    ]),
                    createVNode("div", { class: "row-of-two" }, [
                      createVNode(_component_FormKit, {
                        label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Non-Journalist")})`,
                        type: "text",
                        placeholder: _ctx.$translate("Job title"),
                        name: "job_title",
                        "validation-label": _ctx.$translate("Job title"),
                        validation: "required:trim",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Employer"),
                        type: "text",
                        placeholder: _ctx.$translate("Employer"),
                        name: "employer",
                        "validation-label": _ctx.$translate("Employer"),
                        validation: "required:trim",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ]),
                    createVNode("div", { class: "row-of-two" }, [
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Work phone"),
                        type: "text",
                        placeholder: _ctx.$translate("Work phone"),
                        name: "worktel",
                        "validation-label": _ctx.$translate("Work phone"),
                        validation: "required:trim|number",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Ext"),
                        type: "text",
                        placeholder: _ctx.$translate("Ext"),
                        name: "worktel_ext",
                        "validation-label": _ctx.$translate("Ext"),
                        validation: "required:trim|number",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ]),
                    createVNode("div", { class: "row-of-two" }, [
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Fax"),
                        type: "text",
                        placeholder: _ctx.$translate("Fax"),
                        name: "fax",
                        "validation-label": _ctx.$translate("Fax"),
                        validation: "required:trim|number",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Ext"),
                        type: "text",
                        placeholder: _ctx.$translate("Ext"),
                        name: "fax_ext",
                        "validation-label": _ctx.$translate("Ext"),
                        validation: "required:trim|number",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ]),
                    createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4" }, [
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Post box"),
                        type: "text",
                        placeholder: _ctx.$translate("Post box"),
                        name: "post_box",
                        "validation-label": _ctx.$translate("Post box"),
                        validation: "required:trim|number",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Post code"),
                        type: "text",
                        placeholder: _ctx.$translate("Post code"),
                        name: "post_code",
                        "validation-label": _ctx.$translate("Post code"),
                        validation: "required:trim|number",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("City"),
                        type: "text",
                        placeholder: _ctx.$translate("City"),
                        name: "city",
                        "validation-label": _ctx.$translate("City"),
                        validation: "required:trim",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          },
                          outer: "mb-3"
                        }
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ]),
                    createVNode(_component_FormKit, {
                      label: _ctx.$translate("Email"),
                      classes: {
                        outer: "mb-3",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full": true
                        }
                      },
                      type: "email",
                      placeholder: _ctx.$translate("Email"),
                      id: "email",
                      name: "email",
                      "validation-label": _ctx.$translate("Email"),
                      validation: "required:trim|email"
                    }, null, 8, ["label", "placeholder", "validation-label"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</section><section style="${ssrRenderStyle(step.value == "loginInfo" ? null : { display: "none" })}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              id: "loginInfo",
              type: "group",
              name: "loginInfo"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex flex-col sm:flex-row items-center w-full md:w-1/2 mb-7"${_scopeId2}><label class="font-bold w-full sm:w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("ID or residence number"))}</label><div class="w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center"${_scopeId2}>${ssrInterpolate(memberData.value.registration.national_id)}</div></div><div class="row-of-two"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Password"),
                    classes: {
                      outer: "mb-3",
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      }
                    },
                    type: "password",
                    placeholder: _ctx.$translate("Password"),
                    id: "password",
                    name: "password",
                    "validation-label": _ctx.$translate("Password"),
                    validation: "required:trim|length:6"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_FormKit, {
                    label: _ctx.$translate("Password confirmation"),
                    classes: {
                      outer: "mb-3",
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full": true
                      }
                    },
                    type: "password",
                    placeholder: _ctx.$translate("Password confirmation"),
                    id: "password_confirm",
                    name: "password_confirm",
                    "validation-label": _ctx.$translate("Password confirmation"),
                    validation: "required:trim|confirm"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "flex flex-col sm:flex-row items-center w-full md:w-1/2 mb-7" }, [
                      createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("ID or residence number")), 1),
                      createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, toDisplayString(memberData.value.registration.national_id), 1)
                    ]),
                    createVNode("div", { class: "row-of-two" }, [
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Password"),
                        classes: {
                          outer: "mb-3",
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          }
                        },
                        type: "password",
                        placeholder: _ctx.$translate("Password"),
                        id: "password",
                        name: "password",
                        "validation-label": _ctx.$translate("Password"),
                        validation: "required:trim|length:6"
                      }, null, 8, ["label", "placeholder", "validation-label"]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Password confirmation"),
                        classes: {
                          outer: "mb-3",
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full": true
                          }
                        },
                        type: "password",
                        placeholder: _ctx.$translate("Password confirmation"),
                        id: "password_confirm",
                        name: "password_confirm",
                        "validation-label": _ctx.$translate("Password confirmation"),
                        validation: "required:trim|confirm"
                      }, null, 8, ["label", "placeholder", "validation-label"])
                    ])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</section><section style="${ssrRenderStyle(step.value == "review" ? null : { display: "none" })}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              id: "review",
              type: "group",
              name: "review"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a, _b, _c, _d, _e, _f, _g, _h;
                if (_push3) {
                  _push3(`<div class="row-of-two mb-7"${_scopeId2}><div class="flex flex-col sm:flex-row items-center"${_scopeId2}><label class="font-bold w-full sm:w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("ID or residence number"))}</label><div class="w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center"${_scopeId2}>${ssrInterpolate(memberData.value.registration.national_id)}</div></div><div class="flex flex-col sm:flex-row items-center"${_scopeId2}><label class="font-bold w-full sm:w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Mobile"))}</label><div class="w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" style="${ssrRenderStyle(memberData.value.contactInfo.mobile ? null : { display: "none" })}"${_scopeId2}> 966${ssrInterpolate(memberData.value.contactInfo.mobile)}</div></div></div><div class="row-of-two mb-7"${_scopeId2}><div class="flex flex-col sm:flex-row items-center"${_scopeId2}><label class="font-bold w-full sm:w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Membership type"))}</label><div class="w-full md:w-auto sm:mx-auto text-2xl text-end sm:text-center"${_scopeId2}>${ssrInterpolate(((_b = unref(membershipTypes)[(_a = memberData.value.membershipTypes) == null ? void 0 : _a.membership_type]) == null ? void 0 : _b.label) || "")}</div></div><div class="flex flex-col sm:flex-row items-center"${_scopeId2}><label class="font-bold w-full sm:w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Branch"))}</label><div class="w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center"${_scopeId2}>${ssrInterpolate((_c = unref(branches).find((b) => {
                    var _a2;
                    return b.__original == ((_a2 = memberData.value.membershipTypes) == null ? void 0 : _a2.branch);
                  })) == null ? void 0 : _c.label)}</div></div></div><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 my-4"${_scopeId2}><div${_scopeId2}><label${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`)}</label><h5${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.fname_ar)}</h5></div><div${_scopeId2}><label${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`)}</label><h5${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.sname_ar)}</h5></div><div${_scopeId2}><label${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`)}</label><h5${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.tname_ar)}</h5></div><div${_scopeId2}><label${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`)}</label><h5${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.lname_ar)}</h5></div></div><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 my-4"${_scopeId2}><div${_scopeId2}><label${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`)}</label><h5${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.fname_en)}</h5></div><div${_scopeId2}><label${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`)}</label><h5${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.sname_en)}</h5></div><div${_scopeId2}><label${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`)}</label><h5${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.tname_en)}</h5></div><div${_scopeId2}><label${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`)}</label><h5${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.lname_en)}</h5></div></div><div class="my-4"${_scopeId2}><label class="font-bold w-6/12 md:w-3/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Gender"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate((_d = unref(genders).find((gender) => gender.__original == memberData.value.memberInfo.gender)) == null ? void 0 : _d.label)}</h5></div><div class="row-of-two my-4"${_scopeId2}><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Hijri")})`)}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.birthday_meladi)}</h5></div><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Milady")})`)}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.birthday_meladi)}</h5></div></div><div class="my-4"${_scopeId2}><label class="font-bold w-6/12 md:w-3/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Nationality"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(unref(nationalities).find((c) => c.value == memberData.value.memberInfo.nationality).label)}</h5></div><div class="row-of-two my-4"${_scopeId2}><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Qualification"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.qualification)}</h5></div><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Major"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.major)}</h5></div></div><div class="row-of-two my-4"${_scopeId2}><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("Job title")} (${_ctx.$translate("Journalist")})`)}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.journalist_job_title)}</h5></div><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Employer"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.journalist_employer)}</h5></div></div><div class="row-of-two my-4"${_scopeId2}><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(`${_ctx.$translate("Job title")} (${_ctx.$translate("Non-Journalist")})`)}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.job_title)}</h5></div><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Employer"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.employer)}</h5></div></div><div class="row-of-two my-4"${_scopeId2}><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Work phone"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.worktel)}</h5></div><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Ext"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.worktel_ext)}</h5></div></div><div class="row-of-two my-4"${_scopeId2}><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Fax"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.fax)}</h5></div><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Ext"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.fax_ext)}</h5></div></div><div class="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4 my-4"${_scopeId2}><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Post box"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.post_box)}</h5></div><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Post code"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.post_code)}</h5></div><div${_scopeId2}><label class="font-bold w-6/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("City"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.city)}</h5></div></div><div class="my-4"${_scopeId2}><label class="font-bold w-6/12 md:w-3/12"${_scopeId2}>${ssrInterpolate(_ctx.$translate("Email"))}</label><h5 class="inline"${_scopeId2}>${ssrInterpolate(memberData.value.memberInfo.email)}</h5></div>`);
                  _push3(ssrRenderComponent(_component_FormKit, {
                    type: "checkbox",
                    label: _ctx.$translate("membership_agreement"),
                    "validation-label": _ctx.$translate("acceptance"),
                    validation: "required|accepted",
                    name: "terms_and_agreement",
                    classes: {
                      wrapper: {
                        "formkit-wrapper": false,
                        "w-full flex items-center": true
                      },
                      inner: "mx-1",
                      outer: "my-4"
                    }
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("div", { class: "row-of-two mb-7" }, [
                      createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                        createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("ID or residence number")), 1),
                        createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, toDisplayString(memberData.value.registration.national_id), 1)
                      ]),
                      createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                        createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("Mobile")), 1),
                        withDirectives(createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, " 966" + toDisplayString(memberData.value.contactInfo.mobile), 513), [
                          [vShow, memberData.value.contactInfo.mobile]
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "row-of-two mb-7" }, [
                      createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                        createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("Membership type")), 1),
                        createVNode("div", { class: "w-full md:w-auto sm:mx-auto text-2xl text-end sm:text-center" }, toDisplayString(((_f = unref(membershipTypes)[(_e = memberData.value.membershipTypes) == null ? void 0 : _e.membership_type]) == null ? void 0 : _f.label) || ""), 1)
                      ]),
                      createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                        createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("Branch")), 1),
                        createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, toDisplayString((_g = unref(branches).find((b) => {
                          var _a2;
                          return b.__original == ((_a2 = memberData.value.membershipTypes) == null ? void 0 : _a2.branch);
                        })) == null ? void 0 : _g.label), 1)
                      ])
                    ]),
                    createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", null, toDisplayString(`${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`), 1),
                        createVNode("h5", null, toDisplayString(memberData.value.memberInfo.fname_ar), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", null, toDisplayString(`${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`), 1),
                        createVNode("h5", null, toDisplayString(memberData.value.memberInfo.sname_ar), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", null, toDisplayString(`${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`), 1),
                        createVNode("h5", null, toDisplayString(memberData.value.memberInfo.tname_ar), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", null, toDisplayString(`${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`), 1),
                        createVNode("h5", null, toDisplayString(memberData.value.memberInfo.lname_ar), 1)
                      ])
                    ]),
                    createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", null, toDisplayString(`${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`), 1),
                        createVNode("h5", null, toDisplayString(memberData.value.memberInfo.fname_en), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", null, toDisplayString(`${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`), 1),
                        createVNode("h5", null, toDisplayString(memberData.value.memberInfo.sname_en), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", null, toDisplayString(`${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`), 1),
                        createVNode("h5", null, toDisplayString(memberData.value.memberInfo.tname_en), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", null, toDisplayString(`${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`), 1),
                        createVNode("h5", null, toDisplayString(memberData.value.memberInfo.lname_en), 1)
                      ])
                    ]),
                    createVNode("div", { class: "my-4" }, [
                      createVNode("label", { class: "font-bold w-6/12 md:w-3/12" }, toDisplayString(_ctx.$translate("Gender")), 1),
                      createVNode("h5", { class: "inline" }, toDisplayString((_h = unref(genders).find((gender) => gender.__original == memberData.value.memberInfo.gender)) == null ? void 0 : _h.label), 1)
                    ]),
                    createVNode("div", { class: "row-of-two my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Hijri")})`), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.birthday_meladi), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Milady")})`), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.birthday_meladi), 1)
                      ])
                    ]),
                    createVNode("div", { class: "my-4" }, [
                      createVNode("label", { class: "font-bold w-6/12 md:w-3/12" }, toDisplayString(_ctx.$translate("Nationality")), 1),
                      createVNode("h5", { class: "inline" }, toDisplayString(unref(nationalities).find((c) => c.value == memberData.value.memberInfo.nationality).label), 1)
                    ]),
                    createVNode("div", { class: "row-of-two my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Qualification")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.qualification), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Major")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.major), 1)
                      ])
                    ]),
                    createVNode("div", { class: "row-of-two my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(`${_ctx.$translate("Job title")} (${_ctx.$translate("Journalist")})`), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.journalist_job_title), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Employer")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.journalist_employer), 1)
                      ])
                    ]),
                    createVNode("div", { class: "row-of-two my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(`${_ctx.$translate("Job title")} (${_ctx.$translate("Non-Journalist")})`), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.job_title), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Employer")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.employer), 1)
                      ])
                    ]),
                    createVNode("div", { class: "row-of-two my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Work phone")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.worktel), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Ext")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.worktel_ext), 1)
                      ])
                    ]),
                    createVNode("div", { class: "row-of-two my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Fax")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.fax), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Ext")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.fax_ext), 1)
                      ])
                    ]),
                    createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4 my-4" }, [
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Post box")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.post_box), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Post code")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.post_code), 1)
                      ]),
                      createVNode("div", null, [
                        createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("City")), 1),
                        createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.city), 1)
                      ])
                    ]),
                    createVNode("div", { class: "my-4" }, [
                      createVNode("label", { class: "font-bold w-6/12 md:w-3/12" }, toDisplayString(_ctx.$translate("Email")), 1),
                      createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.email), 1)
                    ]),
                    createVNode(_component_FormKit, {
                      type: "checkbox",
                      label: _ctx.$translate("membership_agreement"),
                      "validation-label": _ctx.$translate("acceptance"),
                      validation: "required|accepted",
                      name: "terms_and_agreement",
                      classes: {
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex items-center": true
                        },
                        inner: "mx-1",
                        outer: "my-4"
                      }
                    }, null, 8, ["label", "validation-label"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</section><div class="flex justify-between items-center mt-10"${_scopeId}><button class="btn"${ssrIncludeBooleanAttr(step.value == "registration") ? " disabled" : ""}${_scopeId}>${ssrInterpolate(_ctx.$translate("Prev"))}</button>`);
            if (step.value !== "review") {
              _push2(`<button class="btn"${_scopeId}>${ssrInterpolate(_ctx.$translate("Next"))}</button>`);
            } else {
              _push2(`<!---->`);
            }
            if (step.value == "review") {
              _push2(`<button class="btn-primary" type="submit"${_scopeId}>${ssrInterpolate(_ctx.$translate("Register"))}</button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("ul", { class: "w-full border-b" }, [
                (openBlock(true), createBlock(Fragment, null, renderList(steps, (value2, key) => {
                  return openBlock(), createBlock("li", {
                    class: ["w-full text-center sm:w-auto sm:text-start cursor-pointer inline-block text-sju-50 text-sm px-5 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: step.value == key }],
                    onClick: ($event) => step.value = key,
                    "data-step-active": step.value == key,
                    "data-step-valid": value2.valid
                  }, [
                    createTextVNode(toDisplayString(_ctx.$translate(value2 == null ? void 0 : value2.label)) + " ", 1),
                    checkStepValidity(key) ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "bg-red-600 text-white w-5 inline-block text-center rounded-full"
                    }, toDisplayString(value2.errorCount + value2.blockingCount), 1)) : createCommentVNode("", true)
                  ], 10, ["onClick", "data-step-active", "data-step-valid"]);
                }), 256))
              ]),
              createVNode("div", { class: "pt-10" }, [
                withDirectives(createVNode("section", null, [
                  createVNode(_component_FormKit, {
                    type: "group",
                    id: "registration",
                    name: "registration"
                  }, {
                    default: withCtx(() => [
                      createVNode("h5", { class: "form-title" }, toDisplayString(_ctx.$translate("Terms and policies")), 1),
                      createVNode("ol", { class: "mb-5 [&>li]:flex [&>li]:gap-2 [&>li]:my-2 [&>li]:text-sju-200" }, [
                        createVNode("li", null, [
                          createVNode(unref(IcSharpCheck)),
                          createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule1")), 1)
                        ]),
                        createVNode("li", null, [
                          createVNode(unref(IcSharpCheck)),
                          createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule2")), 1)
                        ]),
                        createVNode("li", null, [
                          createVNode(unref(IcSharpCheck)),
                          createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule3")), 1)
                        ]),
                        createVNode("li", null, [
                          createVNode(unref(IcSharpCheck)),
                          createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule4")), 1)
                        ]),
                        createVNode("li", null, [
                          createVNode(unref(IcSharpCheck)),
                          createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule5")), 1)
                        ]),
                        createVNode("li", null, [
                          createVNode(unref(IcSharpCheck)),
                          createTextVNode(" " + toDisplayString(_ctx.$translate("member_rule6")), 1)
                        ])
                      ]),
                      createVNode(_component_FormKit, {
                        type: "checkbox",
                        label: _ctx.$translate("TermsAgreement"),
                        "validation-label": _ctx.$translate("acceptance"),
                        validation: "required|accepted",
                        name: "terms_and_agreement",
                        classes: {
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full flex items-center": true
                          },
                          inner: "mx-1",
                          label: { "text-lg mx-2": true, "formkit-label": false }
                        }
                      }, null, 8, ["label", "validation-label"]),
                      createVNode("hr", { class: "my-10" }),
                      memberData.value.registration.terms_and_agreement ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode(_component_FormKit, {
                          label: _ctx.$translate("ID or residence number"),
                          type: "number",
                          name: "national_id",
                          id: "national_id",
                          classes: {
                            outer: "mb-3",
                            inner: "w-full md:w-6/12 mt-2",
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full flex flex-col md:flex-row items-center": true
                            },
                            label: "w-full md:w-2/12"
                          },
                          placeholder: _ctx.$translate("National ID"),
                          validation: "required:trim|number|length:10,10",
                          "validation-label": _ctx.$translate("National ID")
                        }, null, 8, ["label", "placeholder", "validation-label"])
                      ])) : createCommentVNode("", true)
                    ]),
                    _: 1
                  })
                ], 512), [
                  [vShow, step.value == "registration"]
                ]),
                withDirectives(createVNode("section", null, [
                  createVNode(_component_FormKit, {
                    id: "contactInfo",
                    type: "group",
                    name: "contactInfo"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", {
                        class: "flex flex-col md:flex-row items-center",
                        "data-family": "text"
                      }, [
                        createVNode("label", {
                          for: "mobile",
                          class: "formkit-label w-full md:w-2/12"
                        }, toDisplayString(_ctx.$translate("Mobile")), 1),
                        createVNode("div", {
                          class: "input-group [&>.formkit-outer]:mb-0 h-9 w-full md:w-6/12",
                          style: { "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" }
                        }, [
                          createVNode(_component_FormKit, {
                            type: "myTextInput",
                            "outer-class": "w-full border border-y-0 m-0",
                            id: "mobile",
                            name: "mobile",
                            placeholder: _ctx.$translate("Mobile"),
                            validation: "required:trim|number|matches:/^(5)\\d{8}$/",
                            "validation-label": _ctx.$translate("Mobile"),
                            "validation-messages": {
                              matches: _ctx.$translate("Please enter a valid phone number. eg: 501234567")
                            }
                          }, null, 8, ["placeholder", "validation-label", "validation-messages"]),
                          createVNode("span", { class: "prepend" }, [
                            createVNode(_component_FormKit, {
                              type: "mySelect",
                              name: "mobile_key",
                              options: [{ label: "+966", value: "966" }],
                              style: { "box-shadow": "none" }
                            })
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  })
                ], 512), [
                  [vShow, step.value == "contactInfo"]
                ]),
                withDirectives(createVNode("section", null, [
                  createVNode(_component_FormKit, {
                    id: "membershipTypes",
                    type: "group",
                    name: "membershipTypes"
                  }, {
                    default: withCtx(() => [
                      createVNode("table", { class: "w-full text-gray-500 dark:text-gray-400 mb-6" }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase dark:text-gray-400" }, [
                          createVNode("tr", { class: "md:text-lg" }, [
                            createVNode("th", {
                              scope: "col",
                              class: "py-3 px-6 text-start"
                            }, toDisplayString(_ctx.$translate("Choose the type that fits you")), 1),
                            createVNode("th", {
                              scope: "col",
                              class: "py-3 px-6 text-start"
                            }, toDisplayString(_ctx.$translate("Amount")), 1)
                          ])
                        ]),
                        createVNode("tbody", { class: "text-start" }, [
                          createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                            createVNode("td", { class: "py-4 px-6 bg-gray-50 dark:bg-gray-800" }, [
                              createVNode(_component_FormKit, {
                                "outer-class": "mb-3",
                                type: "myRadio",
                                name: "membership_type",
                                options: [
                                  {
                                    label: _ctx.$translate("fulltime_member"),
                                    value: 1
                                  }
                                ],
                                "validation-label": _ctx.$translate("fulltime_member"),
                                validation: "required",
                                classes: {
                                  options: "flex items-center",
                                  option: {
                                    "formkit-option": false
                                  },
                                  wrapper: "m-0",
                                  label: {
                                    "formkit-label": false,
                                    "md:text-2xl text-sju-200 font-bold": true
                                  }
                                },
                                "validation-messages": {
                                  required: _ctx.$translate("You have to choose member type")
                                }
                              }, null, 8, ["options", "validation-label", "validation-messages"])
                            ]),
                            createVNode("td", { class: "py-4 px-6 bg-gray-50 dark:bg-gray-800" }, [
                              createVNode("span", { class: "md:text-xl text-sju-50 font-bold" }, "250 " + toDisplayString(_ctx.$translate("Riyal")) + "\xA0 ", 1),
                              createVNode("span", { class: "font-bold text-xs" }, toDisplayString(_ctx.$translate("Annual")) + "*", 1)
                            ])
                          ]),
                          createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                            createVNode("td", {
                              class: "py-4 px-6 bg-gray-50 dark:bg-gray-800",
                              colspan: "2"
                            }, [
                              createVNode("ul", { class: "text-sm md:text-base list-decimal md:mx-7" }, [
                                createVNode("li", null, toDisplayString(_ctx.$translate("fulltime_member_desc1")), 1),
                                createVNode("li", null, toDisplayString(_ctx.$translate("fulltime_member_desc2")), 1),
                                createVNode("li", null, toDisplayString(_ctx.$translate("fulltime_member_desc3")), 1)
                              ])
                            ])
                          ]),
                          createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                            createVNode("td", { class: "py-4 px-6" }, [
                              createVNode(_component_FormKit, {
                                "outer-class": "mb-3",
                                type: "myRadio",
                                name: "membership_type",
                                options: [
                                  {
                                    label: _ctx.$translate("parttime_member"),
                                    value: 2
                                  }
                                ],
                                "validation-label": _ctx.$translate("parttime_member"),
                                validation: "required",
                                classes: {
                                  options: "flex items-center",
                                  option: {
                                    "formkit-option": false
                                  },
                                  wrapper: "m-0",
                                  label: {
                                    "formkit-label": false,
                                    "md:text-2xl text-sju-200 font-bold": true
                                  }
                                },
                                "validation-messages": {
                                  required: _ctx.$translate("You have to choose member type")
                                }
                              }, null, 8, ["options", "validation-label", "validation-messages"])
                            ]),
                            createVNode("td", { class: "py-4 px-6" }, [
                              createVNode("span", { class: "md:text-xl text-sju-50 font-bold" }, "200 " + toDisplayString(_ctx.$translate("Riyal")) + "\xA0 ", 1),
                              createVNode("span", { class: "font-bold text-xs" }, toDisplayString(_ctx.$translate("Annual")) + "*", 1)
                            ])
                          ]),
                          createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                            createVNode("td", {
                              class: "py-4 px-6",
                              colspan: "2"
                            }, [
                              createVNode("ul", { class: "text-sm md:text-base list-decimal md:mx-7" }, [
                                createVNode("li", null, toDisplayString(_ctx.$translate("parttime_member_desc1")), 1),
                                createVNode("li", null, toDisplayString(_ctx.$translate("parttime_member_desc2")), 1)
                              ])
                            ])
                          ]),
                          createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                            createVNode("td", { class: "py-4 px-6 bg-gray-50 dark:bg-gray-800" }, [
                              createVNode(_component_FormKit, {
                                "outer-class": "mb-3",
                                type: "myRadio",
                                name: "membership_type",
                                options: [
                                  {
                                    label: _ctx.$translate("affiliate_member"),
                                    value: 3
                                  }
                                ],
                                "validation-label": _ctx.$translate("affiliate_member"),
                                validation: "required",
                                classes: {
                                  options: "flex items-center",
                                  option: {
                                    "formkit-option": false
                                  },
                                  wrapper: "m-0",
                                  label: {
                                    "formkit-label": false,
                                    "md:text-2xl text-sju-200 font-bold": true
                                  }
                                },
                                "validation-messages": {
                                  required: _ctx.$translate("You have to choose member type")
                                }
                              }, null, 8, ["options", "validation-label", "validation-messages"])
                            ]),
                            createVNode("td", { class: "py-4 px-6 bg-gray-50 dark:bg-gray-800" }, [
                              createVNode("span", { class: "md:text-xl text-sju-50 font-bold" }, "150 " + toDisplayString(_ctx.$translate("Riyal")) + "\xA0 ", 1),
                              createVNode("span", { class: "font-bold text-xs" }, toDisplayString(_ctx.$translate("Annual")) + "*", 1)
                            ])
                          ]),
                          createVNode("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                            createVNode("td", {
                              class: "py-4 px-6 bg-gray-50 dark:bg-gray-800",
                              colspan: "2"
                            }, [
                              createVNode("ul", { class: "text-sm md:text-base list-decimal md:mx-7" }, [
                                createVNode("li", null, toDisplayString(_ctx.$translate("affiliate_member_desc1")), 1)
                              ])
                            ])
                          ])
                        ])
                      ]),
                      createVNode(_component_FormKit, {
                        label: _ctx.$translate("Membership branch"),
                        type: "select",
                        name: "branch",
                        id: "branch",
                        classes: {
                          outer: "mb-3",
                          inner: "w-full md:w-6/12 mt-2",
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full flex flex-col md:flex-row items-center": true
                          },
                          label: "w-full md:w-2/12"
                        },
                        "sections-schema": {
                          selectIcon: { $el: null }
                        },
                        options: unref(branches),
                        placeholder: _ctx.$translate("Membership branch"),
                        validation: "required",
                        "validation-label": _ctx.$translate("Membership branch")
                      }, null, 8, ["label", "options", "placeholder", "validation-label"]),
                      memberData.value.membershipTypes.branch == 8 ? (openBlock(), createBlock(_component_FormKit, {
                        key: 0,
                        label: _ctx.$translate("Delivery method"),
                        help: _ctx.$translate(
                          "If you choose delivery, 30 riyals will be added to the invoice value."
                        ),
                        type: "select",
                        name: "delivery_method",
                        id: "delivery_method",
                        classes: {
                          outer: "mb-3",
                          inner: "w-full md:w-6/12 mt-2",
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full flex flex-col md:flex-row items-center": true
                          },
                          label: "w-full md:w-2/12"
                        },
                        options: [
                          {
                            label: _ctx.$translate("Receipt from the branch"),
                            value: 1
                          },
                          {
                            label: _ctx.$translate("Delivery"),
                            value: 2
                          }
                        ],
                        "sections-schema": {
                          selectIcon: { $el: null }
                        },
                        placeholder: _ctx.$translate("Delivery method"),
                        validation: "required",
                        "validation-label": _ctx.$translate("Delivery method")
                      }, null, 8, ["label", "help", "options", "placeholder", "validation-label"])) : createCommentVNode("", true),
                      memberData.value.membershipTypes.branch == 8 && memberData.value.membershipTypes.delivery_method == 2 ? (openBlock(), createBlock(_component_FormKit, {
                        key: 1,
                        label: _ctx.$translate("Delivery Address"),
                        type: "text",
                        name: "delivery_address",
                        id: "delivery_address",
                        classes: {
                          outer: "mb-3",
                          inner: "w-full md:w-6/12 mt-2",
                          wrapper: {
                            "formkit-wrapper": false,
                            "w-full flex flex-col md:flex-row items-center": true
                          },
                          label: "w-full md:w-2/12"
                        },
                        placeholder: _ctx.$translate("Delivery Address"),
                        validation: "required:trim",
                        "validation-label": _ctx.$translate("Delivery Address")
                      }, null, 8, ["label", "placeholder", "validation-label"])) : createCommentVNode("", true)
                    ]),
                    _: 1
                  })
                ], 512), [
                  [vShow, step.value == "membershipTypes"]
                ]),
                withDirectives(createVNode("section", null, [
                  createVNode(_component_FormKit, {
                    id: "memberInfo",
                    type: "group",
                    name: "memberInfo"
                  }, {
                    default: withCtx(() => {
                      var _a, _b, _c;
                      return [
                        createVNode("div", { class: "row-of-two mb-7" }, [
                          createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                            createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("ID or residence number")), 1),
                            createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, toDisplayString((_a = memberData.value) == null ? void 0 : _a.registration.national_id), 1)
                          ]),
                          createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                            createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("Mobile")), 1),
                            withDirectives(createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, " 966" + toDisplayString((_b = memberData.value) == null ? void 0 : _b.contactInfo.mobile), 513), [
                              [vShow, (_c = memberData.value) == null ? void 0 : _c.contactInfo.mobile]
                            ])
                          ])
                        ]),
                        createVNode("div", { class: "row-of-two" }, [
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("ID source"),
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            type: "text",
                            placeholder: _ctx.$translate("ID source"),
                            name: "source",
                            "validation-label": _ctx.$translate("ID source"),
                            validation: "required:trim"
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("ID date")} (${_ctx.$translate("Hijri")})`,
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            placeholder: _ctx.$translate("ID date"),
                            name: "date",
                            id: "date",
                            validation: "required",
                            "validation-label": _ctx.$translate("ID date"),
                            onChange: dateChanged
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode("datepicker-hijri", {
                            reference: "date",
                            placement: "bottom",
                            "date-format": "iYYYY/iMM/iDD",
                            "selected-date": "1441/02/01"
                          })
                        ]),
                        createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`,
                            type: "text",
                            name: "fname_ar",
                            id: "fname_ar",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            placeholder: _ctx.$translate("fname"),
                            validation: "required:trim|length:3,50",
                            "validation-label": _ctx.$translate("fname")
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`,
                            type: "text",
                            name: "sname_ar",
                            id: "sname_ar",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            placeholder: _ctx.$translate("sname"),
                            validation: "required:trim|length:3,50",
                            "validation-label": _ctx.$translate("sname")
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`,
                            type: "text",
                            name: "tname_ar",
                            id: "tname_ar",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            placeholder: _ctx.$translate("tname"),
                            validation: "required:trim|length:3,50",
                            "validation-label": _ctx.$translate("tname")
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`,
                            type: "text",
                            name: "lname_ar",
                            id: "lname_ar",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            placeholder: _ctx.$translate("lname"),
                            validation: "required:trim|length:3,50",
                            "validation-label": _ctx.$translate("lname")
                          }, null, 8, ["label", "placeholder", "validation-label"])
                        ]),
                        createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                          createVNode(_component_FormKit, {
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            type: "text",
                            label: `${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`,
                            name: "fname_en",
                            id: "fname_en",
                            placeholder: _ctx.$translate("fname"),
                            validation: "required:trim|length:3,50",
                            "validation-label": _ctx.$translate("fname")
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            type: "text",
                            label: `${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`,
                            name: "sname_en",
                            id: "sname_en",
                            placeholder: _ctx.$translate("sname"),
                            validation: "required:trim|length:3,50",
                            "validation-label": _ctx.$translate("sname")
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            type: "text",
                            label: `${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`,
                            name: "tname_en",
                            id: "tname_en",
                            placeholder: _ctx.$translate("tname"),
                            validation: "required:trim|length:3,50",
                            "validation-label": _ctx.$translate("tname")
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            type: "text",
                            label: `${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`,
                            name: "lname_en",
                            id: "lname_en",
                            placeholder: _ctx.$translate("lname"),
                            validation: "required:trim|length:3,50",
                            "validation-label": _ctx.$translate("lname")
                          }, null, 8, ["label", "placeholder", "validation-label"])
                        ]),
                        createVNode(_component_FormKit, {
                          "outer-class": "mb-3",
                          type: "myRadio",
                          name: "gender",
                          label: _ctx.$translate("Gender"),
                          options: unref(genders),
                          "validation-label": _ctx.$translate("Gender"),
                          validation: "required",
                          classes: {
                            options: "flex items-center",
                            option: {
                              "formkit-option": false
                            },
                            inner: "m-3"
                          }
                        }, null, 8, ["label", "options", "validation-label"]),
                        createVNode("div", { class: "row-of-two" }, [
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("Birth date")} (${_ctx.$translate("Milady")})`,
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3",
                              input: "h-9 text-right"
                            },
                            placeholder: _ctx.$translate("Birth date"),
                            validation: "required",
                            type: "date",
                            name: "birthday_meladi",
                            "validation-label": _ctx.$translate("Birth date")
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("Birth date")} (${_ctx.$translate("Hijri")})`,
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            placeholder: _ctx.$translate("Birth date"),
                            name: "birthday_hijri",
                            id: "birthday_hijri",
                            validation: "required",
                            "validation-label": _ctx.$translate("Birth date"),
                            onChange: dateChanged
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode("datepicker-hijri", {
                            reference: "birthday_hijri",
                            placement: "bottom",
                            "date-format": "iYYYY/iMM/iDD"
                          })
                        ]),
                        createVNode(_component_FormKit, {
                          label: _ctx.$translate("Nationality"),
                          type: "select",
                          "sections-schema": {
                            selectIcon: { $el: null }
                          },
                          classes: {
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full": true
                            },
                            outer: "mb-3"
                          },
                          options: unref(nationalities),
                          name: "nationality",
                          "validation-label": _ctx.$translate("Nationality"),
                          validation: "required"
                        }, null, 8, ["label", "options", "validation-label"]),
                        createVNode("div", { class: "row-of-two" }, [
                          createVNode(_component_FormKit, {
                            "outer-class": "mb-3",
                            type: "text",
                            label: _ctx.$translate("Qualification"),
                            name: "qualification",
                            id: "qualification",
                            placeholder: _ctx.$translate("Qualification"),
                            validation: "required:trim",
                            "validation-label": _ctx.$translate("Qualification"),
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            "outer-class": "mb-3",
                            type: "text",
                            label: _ctx.$translate("Major"),
                            name: "major",
                            id: "major",
                            placeholder: _ctx.$translate("Major"),
                            validation: "required:trim",
                            "validation-label": _ctx.$translate("Major"),
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"])
                        ]),
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4" }, [
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Journalist")})`,
                            type: "text",
                            placeholder: _ctx.$translate("Job title"),
                            name: "journalist_job_title",
                            "validation-label": _ctx.$translate("Job title"),
                            validation: "required:trim",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Employer"),
                            type: "text",
                            placeholder: _ctx.$translate("Employer"),
                            name: "journalist_employer",
                            "validation-label": _ctx.$translate("Employer"),
                            validation: "required:trim",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Newspaper type"),
                            type: "select",
                            "sections-schema": {
                              selectIcon: { $el: null }
                            },
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            },
                            options: [
                              {
                                label: _ctx.$translate("Printed newspaper"),
                                value: 1
                              },
                              {
                                label: _ctx.$translate("E-newspaper"),
                                value: 2
                              }
                            ],
                            name: "newspaper_type",
                            "validation-label": _ctx.$translate("Newspaper type"),
                            validation: "required"
                          }, null, 8, ["label", "options", "validation-label"])
                        ]),
                        createVNode("div", { class: "row-of-two" }, [
                          createVNode(_component_FormKit, {
                            label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Non-Journalist")})`,
                            type: "text",
                            placeholder: _ctx.$translate("Job title"),
                            name: "job_title",
                            "validation-label": _ctx.$translate("Job title"),
                            validation: "required:trim",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Employer"),
                            type: "text",
                            placeholder: _ctx.$translate("Employer"),
                            name: "employer",
                            "validation-label": _ctx.$translate("Employer"),
                            validation: "required:trim",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"])
                        ]),
                        createVNode("div", { class: "row-of-two" }, [
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Work phone"),
                            type: "text",
                            placeholder: _ctx.$translate("Work phone"),
                            name: "worktel",
                            "validation-label": _ctx.$translate("Work phone"),
                            validation: "required:trim|number",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Ext"),
                            type: "text",
                            placeholder: _ctx.$translate("Ext"),
                            name: "worktel_ext",
                            "validation-label": _ctx.$translate("Ext"),
                            validation: "required:trim|number",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"])
                        ]),
                        createVNode("div", { class: "row-of-two" }, [
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Fax"),
                            type: "text",
                            placeholder: _ctx.$translate("Fax"),
                            name: "fax",
                            "validation-label": _ctx.$translate("Fax"),
                            validation: "required:trim|number",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Ext"),
                            type: "text",
                            placeholder: _ctx.$translate("Ext"),
                            name: "fax_ext",
                            "validation-label": _ctx.$translate("Ext"),
                            validation: "required:trim|number",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"])
                        ]),
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4" }, [
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Post box"),
                            type: "text",
                            placeholder: _ctx.$translate("Post box"),
                            name: "post_box",
                            "validation-label": _ctx.$translate("Post box"),
                            validation: "required:trim|number",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("Post code"),
                            type: "text",
                            placeholder: _ctx.$translate("Post code"),
                            name: "post_code",
                            "validation-label": _ctx.$translate("Post code"),
                            validation: "required:trim|number",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"]),
                          createVNode(_component_FormKit, {
                            label: _ctx.$translate("City"),
                            type: "text",
                            placeholder: _ctx.$translate("City"),
                            name: "city",
                            "validation-label": _ctx.$translate("City"),
                            validation: "required:trim",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              },
                              outer: "mb-3"
                            }
                          }, null, 8, ["label", "placeholder", "validation-label"])
                        ]),
                        createVNode(_component_FormKit, {
                          label: _ctx.$translate("Email"),
                          classes: {
                            outer: "mb-3",
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full": true
                            }
                          },
                          type: "email",
                          placeholder: _ctx.$translate("Email"),
                          id: "email",
                          name: "email",
                          "validation-label": _ctx.$translate("Email"),
                          validation: "required:trim|email"
                        }, null, 8, ["label", "placeholder", "validation-label"])
                      ];
                    }),
                    _: 1
                  })
                ], 512), [
                  [vShow, step.value == "memberInfo"]
                ]),
                withDirectives(createVNode("section", null, [
                  createVNode(_component_FormKit, {
                    id: "loginInfo",
                    type: "group",
                    name: "loginInfo"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "flex flex-col sm:flex-row items-center w-full md:w-1/2 mb-7" }, [
                        createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("ID or residence number")), 1),
                        createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, toDisplayString(memberData.value.registration.national_id), 1)
                      ]),
                      createVNode("div", { class: "row-of-two" }, [
                        createVNode(_component_FormKit, {
                          label: _ctx.$translate("Password"),
                          classes: {
                            outer: "mb-3",
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full": true
                            }
                          },
                          type: "password",
                          placeholder: _ctx.$translate("Password"),
                          id: "password",
                          name: "password",
                          "validation-label": _ctx.$translate("Password"),
                          validation: "required:trim|length:6"
                        }, null, 8, ["label", "placeholder", "validation-label"]),
                        createVNode(_component_FormKit, {
                          label: _ctx.$translate("Password confirmation"),
                          classes: {
                            outer: "mb-3",
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full": true
                            }
                          },
                          type: "password",
                          placeholder: _ctx.$translate("Password confirmation"),
                          id: "password_confirm",
                          name: "password_confirm",
                          "validation-label": _ctx.$translate("Password confirmation"),
                          validation: "required:trim|confirm"
                        }, null, 8, ["label", "placeholder", "validation-label"])
                      ])
                    ]),
                    _: 1
                  })
                ], 512), [
                  [vShow, step.value == "loginInfo"]
                ]),
                withDirectives(createVNode("section", null, [
                  createVNode(_component_FormKit, {
                    id: "review",
                    type: "group",
                    name: "review"
                  }, {
                    default: withCtx(() => {
                      var _a, _b, _c, _d;
                      return [
                        createVNode("div", { class: "row-of-two mb-7" }, [
                          createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                            createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("ID or residence number")), 1),
                            createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, toDisplayString(memberData.value.registration.national_id), 1)
                          ]),
                          createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                            createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("Mobile")), 1),
                            withDirectives(createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, " 966" + toDisplayString(memberData.value.contactInfo.mobile), 513), [
                              [vShow, memberData.value.contactInfo.mobile]
                            ])
                          ])
                        ]),
                        createVNode("div", { class: "row-of-two mb-7" }, [
                          createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                            createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("Membership type")), 1),
                            createVNode("div", { class: "w-full md:w-auto sm:mx-auto text-2xl text-end sm:text-center" }, toDisplayString(((_b = unref(membershipTypes)[(_a = memberData.value.membershipTypes) == null ? void 0 : _a.membership_type]) == null ? void 0 : _b.label) || ""), 1)
                          ]),
                          createVNode("div", { class: "flex flex-col sm:flex-row items-center" }, [
                            createVNode("label", { class: "font-bold w-full sm:w-6/12" }, toDisplayString(_ctx.$translate("Branch")), 1),
                            createVNode("div", { class: "w-full md:w-auto sm:mx-20 text-2xl text-end sm:text-center" }, toDisplayString((_c = unref(branches).find((b) => {
                              var _a2;
                              return b.__original == ((_a2 = memberData.value.membershipTypes) == null ? void 0 : _a2.branch);
                            })) == null ? void 0 : _c.label), 1)
                          ])
                        ]),
                        createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", null, toDisplayString(`${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`), 1),
                            createVNode("h5", null, toDisplayString(memberData.value.memberInfo.fname_ar), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", null, toDisplayString(`${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`), 1),
                            createVNode("h5", null, toDisplayString(memberData.value.memberInfo.sname_ar), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", null, toDisplayString(`${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`), 1),
                            createVNode("h5", null, toDisplayString(memberData.value.memberInfo.tname_ar), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", null, toDisplayString(`${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`), 1),
                            createVNode("h5", null, toDisplayString(memberData.value.memberInfo.lname_ar), 1)
                          ])
                        ]),
                        createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", null, toDisplayString(`${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`), 1),
                            createVNode("h5", null, toDisplayString(memberData.value.memberInfo.fname_en), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", null, toDisplayString(`${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`), 1),
                            createVNode("h5", null, toDisplayString(memberData.value.memberInfo.sname_en), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", null, toDisplayString(`${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`), 1),
                            createVNode("h5", null, toDisplayString(memberData.value.memberInfo.tname_en), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", null, toDisplayString(`${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`), 1),
                            createVNode("h5", null, toDisplayString(memberData.value.memberInfo.lname_en), 1)
                          ])
                        ]),
                        createVNode("div", { class: "my-4" }, [
                          createVNode("label", { class: "font-bold w-6/12 md:w-3/12" }, toDisplayString(_ctx.$translate("Gender")), 1),
                          createVNode("h5", { class: "inline" }, toDisplayString((_d = unref(genders).find((gender) => gender.__original == memberData.value.memberInfo.gender)) == null ? void 0 : _d.label), 1)
                        ]),
                        createVNode("div", { class: "row-of-two my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Hijri")})`), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.birthday_meladi), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Milady")})`), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.birthday_meladi), 1)
                          ])
                        ]),
                        createVNode("div", { class: "my-4" }, [
                          createVNode("label", { class: "font-bold w-6/12 md:w-3/12" }, toDisplayString(_ctx.$translate("Nationality")), 1),
                          createVNode("h5", { class: "inline" }, toDisplayString(unref(nationalities).find((c) => c.value == memberData.value.memberInfo.nationality).label), 1)
                        ]),
                        createVNode("div", { class: "row-of-two my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Qualification")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.qualification), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Major")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.major), 1)
                          ])
                        ]),
                        createVNode("div", { class: "row-of-two my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(`${_ctx.$translate("Job title")} (${_ctx.$translate("Journalist")})`), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.journalist_job_title), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Employer")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.journalist_employer), 1)
                          ])
                        ]),
                        createVNode("div", { class: "row-of-two my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(`${_ctx.$translate("Job title")} (${_ctx.$translate("Non-Journalist")})`), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.job_title), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Employer")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.employer), 1)
                          ])
                        ]),
                        createVNode("div", { class: "row-of-two my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Work phone")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.worktel), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Ext")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.worktel_ext), 1)
                          ])
                        ]),
                        createVNode("div", { class: "row-of-two my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Fax")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.fax), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Ext")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.fax_ext), 1)
                          ])
                        ]),
                        createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4 my-4" }, [
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Post box")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.post_box), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("Post code")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.post_code), 1)
                          ]),
                          createVNode("div", null, [
                            createVNode("label", { class: "font-bold w-6/12" }, toDisplayString(_ctx.$translate("City")), 1),
                            createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.city), 1)
                          ])
                        ]),
                        createVNode("div", { class: "my-4" }, [
                          createVNode("label", { class: "font-bold w-6/12 md:w-3/12" }, toDisplayString(_ctx.$translate("Email")), 1),
                          createVNode("h5", { class: "inline" }, toDisplayString(memberData.value.memberInfo.email), 1)
                        ]),
                        createVNode(_component_FormKit, {
                          type: "checkbox",
                          label: _ctx.$translate("membership_agreement"),
                          "validation-label": _ctx.$translate("acceptance"),
                          validation: "required|accepted",
                          name: "terms_and_agreement",
                          classes: {
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full flex items-center": true
                            },
                            inner: "mx-1",
                            outer: "my-4"
                          }
                        }, null, 8, ["label", "validation-label"])
                      ];
                    }),
                    _: 2
                  }, 1024)
                ], 512), [
                  [vShow, step.value == "review"]
                ]),
                createVNode("div", { class: "flex justify-between items-center mt-10" }, [
                  createVNode("button", {
                    class: "btn",
                    disabled: step.value == "registration",
                    onClick: withModifiers(($event) => setStep(-1), ["prevent"])
                  }, toDisplayString(_ctx.$translate("Prev")), 9, ["disabled", "onClick"]),
                  step.value !== "review" ? (openBlock(), createBlock("button", {
                    key: 0,
                    class: "btn",
                    onClick: withModifiers(($event) => setStep(1), ["prevent"])
                  }, toDisplayString(_ctx.$translate("Next")), 9, ["onClick"])) : createCommentVNode("", true),
                  step.value == "review" ? (openBlock(), createBlock("button", {
                    key: 1,
                    class: "btn-primary",
                    type: "submit"
                  }, toDisplayString(_ctx.$translate("Register")), 1)) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/auth/register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=register.c6c11e06.mjs.map
