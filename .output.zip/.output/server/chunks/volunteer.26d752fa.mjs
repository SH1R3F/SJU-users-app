import { I as defineNuxtRouteMiddleware, e as useAuthStore, J as navigateTo } from './server.mjs';
import 'vue';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'vue/server-renderer';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const volunteer = defineNuxtRouteMiddleware((to, from) => {
  const authStore = useAuthStore();
  if (authStore.userType != "volunteer")
    return navigateTo("/volunteers/auth/login");
});

export { volunteer as default };
//# sourceMappingURL=volunteer.26d752fa.mjs.map
