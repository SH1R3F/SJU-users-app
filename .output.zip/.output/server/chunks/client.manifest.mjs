const client_manifest = {
  "assets/fonts/droidkufi/DroidKufi-Regular.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "DroidKufi-Regular.1fe42158.eot",
    "src": "assets/fonts/droidkufi/DroidKufi-Regular.eot"
  },
  "assets/fonts/droidkufi/DroidKufi-Bold.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "DroidKufi-Bold.827c40bb.eot",
    "src": "assets/fonts/droidkufi/DroidKufi-Bold.eot"
  },
  "assets/fonts/droidkufi/DroidKufi-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "DroidKufi-Regular.a7b09bb9.woff2",
    "src": "assets/fonts/droidkufi/DroidKufi-Regular.woff2"
  },
  "assets/fonts/droidkufi/DroidKufi-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "DroidKufi-Bold.31f02fb9.woff2",
    "src": "assets/fonts/droidkufi/DroidKufi-Bold.woff2"
  },
  "assets/fonts/droidkufi/DroidKufi-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "DroidKufi-Regular.1a4abb4b.woff",
    "src": "assets/fonts/droidkufi/DroidKufi-Regular.woff"
  },
  "assets/fonts/droidkufi/DroidKufi-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "DroidKufi-Bold.91862e14.woff",
    "src": "assets/fonts/droidkufi/DroidKufi-Bold.woff"
  },
  "assets/fonts/droidkufi/DroidKufi-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "DroidKufi-Regular.ae57aea1.ttf",
    "src": "assets/fonts/droidkufi/DroidKufi-Regular.ttf"
  },
  "assets/fonts/droidkufi/DroidKufi-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "DroidKufi-Bold.b9699e2c.ttf",
    "src": "assets/fonts/droidkufi/DroidKufi-Bold.ttf"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.1f559288.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "middleware/complete.js",
      "middleware/guest.js",
      "middleware/member.js",
      "middleware/redirect.js",
      "middleware/subscriber.js",
      "middleware/volunteer.js",
      "virtual:nuxt:C:/wamp64/www/Saudi Journalists V2/users-app/.nuxt/error-component.mjs",
      "layouts/default.vue",
      "node_modules/nuxt/dist/app/entry.mjs-css"
    ],
    "css": [],
    "assets": [
      "DroidKufi-Regular.1fe42158.eot",
      "DroidKufi-Regular.a7b09bb9.woff2",
      "DroidKufi-Regular.1a4abb4b.woff",
      "DroidKufi-Regular.ae57aea1.ttf",
      "DroidKufi-Bold.827c40bb.eot",
      "DroidKufi-Bold.31f02fb9.woff2",
      "DroidKufi-Bold.91862e14.woff",
      "DroidKufi-Bold.b9699e2c.ttf"
    ]
  },
  "entry.8bd16c5c.css": {
    "file": "entry.8bd16c5c.css",
    "resourceType": "style"
  },
  "DroidKufi-Regular.1fe42158.eot": {
    "file": "DroidKufi-Regular.1fe42158.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "DroidKufi-Regular.a7b09bb9.woff2": {
    "file": "DroidKufi-Regular.a7b09bb9.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "DroidKufi-Regular.1a4abb4b.woff": {
    "file": "DroidKufi-Regular.1a4abb4b.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "DroidKufi-Regular.ae57aea1.ttf": {
    "file": "DroidKufi-Regular.ae57aea1.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "DroidKufi-Bold.827c40bb.eot": {
    "file": "DroidKufi-Bold.827c40bb.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "DroidKufi-Bold.31f02fb9.woff2": {
    "file": "DroidKufi-Bold.31f02fb9.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "DroidKufi-Bold.91862e14.woff": {
    "file": "DroidKufi-Bold.91862e14.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "DroidKufi-Bold.b9699e2c.ttf": {
    "file": "DroidKufi-Bold.b9699e2c.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "virtual:nuxt:C:/wamp64/www/Saudi Journalists V2/users-app/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.5edb5df0.js",
    "src": "virtual:nuxt:C:/wamp64/www/Saudi Journalists V2/users-app/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/certval.vue": {
    "resourceType": "script",
    "module": true,
    "file": "certval.4315c4e9.js",
    "src": "pages/certval.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/events/[id]/attend.vue": {
    "resourceType": "script",
    "module": true,
    "file": "attend.b00372b8.js",
    "src": "pages/events/[id]/attend.vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.9624aa4e.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_EventPreview.7e9f10b9.js",
      "_useLocalization.787d362a.js",
      "_useFormating.1c2705e8.js"
    ]
  },
  "_PageHeader.9624aa4e.js": {
    "resourceType": "script",
    "module": true,
    "file": "PageHeader.9624aa4e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useFormating.1c2705e8.js"
    ]
  },
  "_EventPreview.7e9f10b9.js": {
    "resourceType": "script",
    "module": true,
    "file": "EventPreview.7e9f10b9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js"
    ]
  },
  "_useLocalization.787d362a.js": {
    "resourceType": "script",
    "module": true,
    "file": "useLocalization.787d362a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_useFormating.1c2705e8.js": {
    "resourceType": "script",
    "module": true,
    "file": "useFormating.1c2705e8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/events/[id]/register.vue": {
    "resourceType": "script",
    "module": true,
    "file": "register.10cc9c2c.js",
    "src": "pages/events/[id]/register.vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.9624aa4e.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_EventPreview.7e9f10b9.js",
      "_useLocalization.787d362a.js",
      "_useFormating.1c2705e8.js"
    ]
  },
  "pages/events/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.3a9ca8a3.js",
    "src": "pages/events/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.9624aa4e.js",
      "_EventPreview.7e9f10b9.js",
      "_SimplePagination.4c133b20.js",
      "_useLocalization.787d362a.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useFormating.1c2705e8.js"
    ]
  },
  "_SimplePagination.4c133b20.js": {
    "resourceType": "script",
    "module": true,
    "file": "SimplePagination.4c133b20.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b473ec12.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_PostPreview.e4f4a083.js",
      "_EventPreview.7e9f10b9.js",
      "_useLocalization.787d362a.js",
      "_linkedin.a172c36a.js"
    ],
    "css": []
  },
  "index.5675711f.css": {
    "file": "index.5675711f.css",
    "resourceType": "style"
  },
  "_PostPreview.e4f4a083.js": {
    "resourceType": "script",
    "module": true,
    "file": "PostPreview.e4f4a083.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js"
    ]
  },
  "_linkedin.a172c36a.js": {
    "resourceType": "script",
    "module": true,
    "file": "linkedin.a172c36a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/auth/forget_password.vue": {
    "resourceType": "script",
    "module": true,
    "file": "forget_password.c3405768.js",
    "src": "pages/members/auth/forget_password.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/auth/login.vue": {
    "resourceType": "script",
    "module": true,
    "file": "login.56d20194.js",
    "src": "pages/members/auth/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_user-edit.a800f117.js"
    ]
  },
  "_user-edit.a800f117.js": {
    "resourceType": "script",
    "module": true,
    "file": "user-edit.a800f117.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/auth/register.vue": {
    "resourceType": "script",
    "module": true,
    "file": "register.2bce0374.js",
    "src": "pages/members/auth/register.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js"
    ]
  },
  "_useSiteConfig.5b0eb25e.js": {
    "resourceType": "script",
    "module": true,
    "file": "useSiteConfig.5b0eb25e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/auth/reset_password.vue": {
    "resourceType": "script",
    "module": true,
    "file": "reset_password.4be23710.js",
    "src": "pages/members/auth/reset_password.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/auth/verify.vue": {
    "resourceType": "script",
    "module": true,
    "file": "verify.3b48ac4e.js",
    "src": "pages/members/auth/verify.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/dashboard/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b80c2fc7.js",
    "src": "pages/members/dashboard/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js",
      "_useFormating.1c2705e8.js",
      "_useSiteConfig.5b0eb25e.js",
      "_failed.4e971954.js"
    ]
  },
  "_failed.4e971954.js": {
    "resourceType": "script",
    "module": true,
    "file": "failed.4e971954.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/dashboard/membership/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.eb9e7b92.js",
    "src": "pages/members/dashboard/membership/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js"
    ],
    "css": []
  },
  "index.7c9900bb.css": {
    "file": "index.7c9900bb.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/membership/pay.vue": {
    "resourceType": "script",
    "module": true,
    "file": "pay.16a08227.js",
    "src": "pages/members/dashboard/membership/pay.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js"
    ],
    "css": []
  },
  "pay.ff871cf8.css": {
    "file": "pay.ff871cf8.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/notifications.vue": {
    "resourceType": "script",
    "module": true,
    "file": "notifications.0aed77cd.js",
    "src": "pages/members/dashboard/notifications.vue",
    "isDynamicEntry": true,
    "imports": [
      "_useFormating.1c2705e8.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/dashboard/profile/complete.vue": {
    "resourceType": "script",
    "module": true,
    "file": "complete.c2094803.js",
    "src": "pages/members/dashboard/profile/complete.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/dashboard/profile/contract.vue": {
    "resourceType": "script",
    "module": true,
    "file": "contract.edfb9910.js",
    "src": "pages/members/dashboard/profile/contract.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ProfileNav.4cb6613d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "contract.4a194e78.css": {
    "file": "contract.4a194e78.css",
    "resourceType": "style"
  },
  "_ProfileNav.4cb6613d.js": {
    "resourceType": "script",
    "module": true,
    "file": "ProfileNav.4cb6613d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/dashboard/profile/experiences.vue": {
    "resourceType": "script",
    "module": true,
    "file": "experiences.7740edfb.js",
    "src": "pages/members/dashboard/profile/experiences.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ProfileNav.4cb6613d.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js"
    ],
    "css": []
  },
  "experiences.4a194e78.css": {
    "file": "experiences.4a194e78.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/profile/identification.vue": {
    "resourceType": "script",
    "module": true,
    "file": "identification.f32ee588.js",
    "src": "pages/members/dashboard/profile/identification.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ProfileNav.4cb6613d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "identification.4a194e78.css": {
    "file": "identification.4a194e78.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/profile/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.54ee5974.js",
    "src": "pages/members/dashboard/profile/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ProfileNav.4cb6613d.js",
      "_useSiteConfig.5b0eb25e.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "index.4a194e78.css": {
    "file": "index.4a194e78.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/profile/license.vue": {
    "resourceType": "script",
    "module": true,
    "file": "license.0f155eb0.js",
    "src": "pages/members/dashboard/profile/license.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ProfileNav.4cb6613d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "license.4a194e78.css": {
    "file": "license.4a194e78.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/profile/password.vue": {
    "resourceType": "script",
    "module": true,
    "file": "password.dbf943e3.js",
    "src": "pages/members/dashboard/profile/password.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ProfileNav.4cb6613d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "password.4a194e78.css": {
    "file": "password.4a194e78.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/profile/picture.vue": {
    "resourceType": "script",
    "module": true,
    "file": "picture.88495c37.js",
    "src": "pages/members/dashboard/profile/picture.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ProfileNav.4cb6613d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "picture.4a194e78.css": {
    "file": "picture.4a194e78.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/profile/statement.vue": {
    "resourceType": "script",
    "module": true,
    "file": "statement.9622397f.js",
    "src": "pages/members/dashboard/profile/statement.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ProfileNav.4cb6613d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "statement.4a194e78.css": {
    "file": "statement.4a194e78.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/questionnaire/[eventId]/[questionnaireId].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_questionnaireId_.5b89a1bd.js",
    "src": "pages/members/dashboard/questionnaire/[eventId]/[questionnaireId].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js"
    ]
  },
  "pages/members/dashboard/support/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.cdd3bdfd.js",
    "src": "pages/members/dashboard/support/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "_id_.6ca94e3a.css": {
    "file": "_id_.6ca94e3a.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/support/create.vue": {
    "resourceType": "script",
    "module": true,
    "file": "create.acb98f5a.js",
    "src": "pages/members/dashboard/support/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/members/dashboard/support/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.06444339.js",
    "src": "pages/members/dashboard/support/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js",
      "_useFormating.1c2705e8.js"
    ]
  },
  "pages/members/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "file": "dashboard.2ee46947.js",
    "src": "pages/members/dashboard.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js"
    ]
  },
  "pages/members/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.c430fa60.js",
    "src": "pages/members/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/pages/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_slug_.3ee02fdb.js",
    "src": "pages/pages/[slug].vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.9624aa4e.js",
      "_useLocalization.787d362a.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useFormating.1c2705e8.js"
    ]
  },
  "pages/posts/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.bf87f90e.js",
    "src": "pages/posts/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.9624aa4e.js",
      "_PostPreview.e4f4a083.js",
      "_useLocalization.787d362a.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useFormating.1c2705e8.js"
    ]
  },
  "pages/posts/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.59b7a573.js",
    "src": "pages/posts/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.9624aa4e.js",
      "_PostPreview.e4f4a083.js",
      "_SimplePagination.4c133b20.js",
      "_useLocalization.787d362a.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useFormating.1c2705e8.js"
    ]
  },
  "pages/subscribers/auth/forget_password.vue": {
    "resourceType": "script",
    "module": true,
    "file": "forget_password.5ae2c555.js",
    "src": "pages/subscribers/auth/forget_password.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/subscribers/auth/login.vue": {
    "resourceType": "script",
    "module": true,
    "file": "login.8eacd67d.js",
    "src": "pages/subscribers/auth/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_user-edit.a800f117.js"
    ]
  },
  "pages/subscribers/auth/register.vue": {
    "resourceType": "script",
    "module": true,
    "file": "register.b2eee80d.js",
    "src": "pages/subscribers/auth/register.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js"
    ]
  },
  "pages/subscribers/auth/reset_password.vue": {
    "resourceType": "script",
    "module": true,
    "file": "reset_password.2efb1311.js",
    "src": "pages/subscribers/auth/reset_password.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/subscribers/dashboard/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.38afcdf9.js",
    "src": "pages/subscribers/dashboard/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js",
      "_useFormating.1c2705e8.js",
      "_useSiteConfig.5b0eb25e.js",
      "_failed.4e971954.js"
    ]
  },
  "pages/subscribers/dashboard/profile.vue": {
    "resourceType": "script",
    "module": true,
    "file": "profile.f1c28418.js",
    "src": "pages/subscribers/dashboard/profile.vue",
    "isDynamicEntry": true,
    "imports": [
      "_useSiteConfig.5b0eb25e.js",
      "_useLocalization.787d362a.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/subscribers/dashboard/questionnaire/[eventId]/[questionnaireId].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_questionnaireId_.a88d239f.js",
    "src": "pages/subscribers/dashboard/questionnaire/[eventId]/[questionnaireId].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js"
    ]
  },
  "pages/subscribers/dashboard/support/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.73748388.js",
    "src": "pages/subscribers/dashboard/support/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "pages/subscribers/dashboard/support/create.vue": {
    "resourceType": "script",
    "module": true,
    "file": "create.11420f72.js",
    "src": "pages/subscribers/dashboard/support/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/subscribers/dashboard/support/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.2a294fdd.js",
    "src": "pages/subscribers/dashboard/support/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js",
      "_useFormating.1c2705e8.js"
    ]
  },
  "pages/subscribers/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "file": "dashboard.cb5cf8af.js",
    "src": "pages/subscribers/dashboard.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js"
    ]
  },
  "pages/subscribers/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.9e06f5e5.js",
    "src": "pages/subscribers/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/auth/forget_password.vue": {
    "resourceType": "script",
    "module": true,
    "file": "forget_password.04ee232d.js",
    "src": "pages/volunteers/auth/forget_password.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/auth/login.vue": {
    "resourceType": "script",
    "module": true,
    "file": "login.9c573aec.js",
    "src": "pages/volunteers/auth/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_user-edit.a800f117.js"
    ]
  },
  "pages/volunteers/auth/register.vue": {
    "resourceType": "script",
    "module": true,
    "file": "register.2f1f0e75.js",
    "src": "pages/volunteers/auth/register.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js"
    ]
  },
  "pages/volunteers/auth/reset_password.vue": {
    "resourceType": "script",
    "module": true,
    "file": "reset_password.a8616d71.js",
    "src": "pages/volunteers/auth/reset_password.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/dashboard/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.08d18a36.js",
    "src": "pages/volunteers/dashboard/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js",
      "_useFormating.1c2705e8.js",
      "_useSiteConfig.5b0eb25e.js",
      "_failed.4e971954.js"
    ]
  },
  "pages/volunteers/dashboard/profile.vue": {
    "resourceType": "script",
    "module": true,
    "file": "profile.1e8fc463.js",
    "src": "pages/volunteers/dashboard/profile.vue",
    "isDynamicEntry": true,
    "imports": [
      "_useSiteConfig.5b0eb25e.js",
      "_useLocalization.787d362a.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/dashboard/questionnaire/[eventId]/[questionnaireId].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_questionnaireId_.65459ea2.js",
    "src": "pages/volunteers/dashboard/questionnaire/[eventId]/[questionnaireId].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js"
    ]
  },
  "pages/volunteers/dashboard/support/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.5c418886.js",
    "src": "pages/volunteers/dashboard/support/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "pages/volunteers/dashboard/support/create.vue": {
    "resourceType": "script",
    "module": true,
    "file": "create.5e05ada8.js",
    "src": "pages/volunteers/dashboard/support/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/dashboard/support/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.064de943.js",
    "src": "pages/volunteers/dashboard/support/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useSiteConfig.5b0eb25e.js",
      "_useFormating.1c2705e8.js"
    ]
  },
  "pages/volunteers/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "file": "dashboard.47a423de.js",
    "src": "pages/volunteers/dashboard.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.787d362a.js"
    ]
  },
  "pages/volunteers/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b2a2aefa.js",
    "src": "pages/volunteers/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "middleware/complete.js": {
    "resourceType": "script",
    "module": true,
    "file": "complete.b8aa0a1a.js",
    "src": "middleware/complete.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "middleware/guest.js": {
    "resourceType": "script",
    "module": true,
    "file": "guest.cbe071d4.js",
    "src": "middleware/guest.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "middleware/member.js": {
    "resourceType": "script",
    "module": true,
    "file": "member.60883dc1.js",
    "src": "middleware/member.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "middleware/redirect.js": {
    "resourceType": "script",
    "module": true,
    "file": "redirect.043d4d2c.js",
    "src": "middleware/redirect.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "middleware/subscriber.js": {
    "resourceType": "script",
    "module": true,
    "file": "subscriber.d455bd3e.js",
    "src": "middleware/subscriber.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "middleware/volunteer.js": {
    "resourceType": "script",
    "module": true,
    "file": "volunteer.42311885.js",
    "src": "middleware/volunteer.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.494eb5f5.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_linkedin.a172c36a.js",
      "_useLocalization.787d362a.js"
    ],
    "css": []
  },
  "default.58230321.css": {
    "file": "default.58230321.css",
    "resourceType": "style"
  },
  "pages/members/dashboard/profile/statement.css": {
    "resourceType": "style",
    "file": "statement.4a194e78.css",
    "src": "pages/members/dashboard/profile/statement.css"
  },
  "pages/members/dashboard/membership/index.css": {
    "resourceType": "style",
    "file": "index.7c9900bb.css",
    "src": "pages/members/dashboard/membership/index.css"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.5675711f.css",
    "src": "pages/index.css"
  },
  "pages/members/dashboard/profile/contract.css": {
    "resourceType": "style",
    "file": "contract.4a194e78.css",
    "src": "pages/members/dashboard/profile/contract.css"
  },
  "pages/members/dashboard/profile/identification.css": {
    "resourceType": "style",
    "file": "identification.4a194e78.css",
    "src": "pages/members/dashboard/profile/identification.css"
  },
  "pages/members/dashboard/profile/picture.css": {
    "resourceType": "style",
    "file": "picture.4a194e78.css",
    "src": "pages/members/dashboard/profile/picture.css"
  },
  "pages/members/dashboard/profile/experiences.css": {
    "resourceType": "style",
    "file": "experiences.4a194e78.css",
    "src": "pages/members/dashboard/profile/experiences.css"
  },
  "pages/volunteers/dashboard/support/[id].css": {
    "resourceType": "style",
    "file": "_id_.6ca94e3a.css",
    "src": "pages/volunteers/dashboard/support/[id].css"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.8bd16c5c.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.58230321.css",
    "src": "layouts/default.css"
  },
  "pages/members/dashboard/membership/pay.css": {
    "resourceType": "style",
    "file": "pay.ff871cf8.css",
    "src": "pages/members/dashboard/membership/pay.css"
  },
  "pages/members/dashboard/profile/password.css": {
    "resourceType": "style",
    "file": "password.4a194e78.css",
    "src": "pages/members/dashboard/profile/password.css"
  },
  "pages/members/dashboard/profile/license.css": {
    "resourceType": "style",
    "file": "license.4a194e78.css",
    "src": "pages/members/dashboard/profile/license.css"
  },
  "pages/members/dashboard/profile/index.css": {
    "resourceType": "style",
    "file": "index.4a194e78.css",
    "src": "pages/members/dashboard/profile/index.css"
  },
  "node_modules/nuxt/dist/app/entry.mjs-css": {
    "file": "",
    "css": [
      "entry.8bd16c5c.css"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
