import { u as useNuxtApp, e as useAuthStore, h as storeToRefs, z as useMemberStore, g as useRoute, a as useHead, d as useToast, k as __nuxt_component_0$1 } from './server.mjs';
import { withAsyncContext, mergeProps, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderStyle, ssrRenderAttr } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c;
    let __temp, __restore;
    const { $i18n } = useNuxtApp();
    const authStore = useAuthStore();
    [__temp, __restore] = withAsyncContext(() => authStore.initAuth()), await __temp, __restore();
    const { userData } = storeToRefs(authStore);
    useMemberStore();
    const { membershipTypes } = useSiteConfig();
    const route = useRoute();
    const toast = useToast();
    if (((_a = route.query) == null ? void 0 : _a.payment) == "success") {
      toast.success($i18n.translate("Successful payment"));
    } else if (((_b = route.query) == null ? void 0 : _b.payment) == "pending") {
      toast.warning($i18n.translate("Payment is pending"));
    } else if (((_c = route.query) == null ? void 0 : _c.payment) == "refused") {
      toast.error($i18n.translate("Payment refused"));
    }
    const title = $i18n.translate("Membership");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "form" }, _attrs))}><div class="form-title font-semibold">${ssrInterpolate(_ctx.$translate("Authority membership"))}</div><div class="overflow-x-auto relative shadow-md sm:rounded-lg"><table class="w-full text-sm text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase dark:text-gray-400 border-b"><tr><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Membership type"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Subscription start"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Subscription end"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Status"))}</th></tr></thead><tbody class="text-center"><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(unref(membershipTypes).find((c) => c.value == unref(userData).subscription.type).label)}</td><td class="py-4 px-6">${ssrInterpolate(unref(userData).subscription.start_date || "#")}</td><td class="py-4 px-6">${ssrInterpolate(unref(userData).subscription.end_date || "#")}</td><td class="py-4 px-6">`);
      if (unref(userData).approved == -2) {
        _push(`<!--[--><span class="underline cursor-pointer">${ssrInterpolate(_ctx.$translate("Refused"))}</span> \xA0 <button class="btn">${ssrInterpolate(_ctx.$translate("Resend"))}</button><!--]-->`);
      } else if (unref(userData).approved == null && !unref(userData).membership_number) {
        _push(`<button class="btn-primary">${ssrInterpolate(_ctx.$translate("Request membership"))}</button>`);
      } else if (unref(userData).active == -1 && unref(userData).approved == 0) {
        _push(`<!--[-->${ssrInterpolate(_ctx.$translate("Waiting branch approval"))}<!--]-->`);
      } else if (unref(userData).active == -1 && unref(userData).approved == 1) {
        _push(`<!--[-->${ssrInterpolate(_ctx.$translate("Waiting admin approval"))}<!--]-->`);
      } else if (unref(userData).active == 1 && unref(userData).approved == 1) {
        _push(`<!--[-->`);
        if (unref(userData).subscription.status == 1) {
          _push(`<!--[-->`);
          if (new Date(unref(userData).subscription.end_date) < new Date()) {
            _push(`<!--[-->${ssrInterpolate(_ctx.$translate("Subscription ended"))}<!--]-->`);
          } else {
            _push(`<!--[-->${ssrInterpolate(_ctx.$translate("Paid"))}<!--]-->`);
          }
          _push(`<!--]-->`);
        } else {
          _push(`<!--[-->${ssrInterpolate(_ctx.$translate("Waiting to pay"))}<!--]-->`);
        }
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</td></tr></tbody></table></div>`);
      if (unref(userData).active === 1 && unref(userData).approved === 1 && (unref(userData).subscription.status !== 1 || new Date(unref(userData).subscription.end_date) < new Date())) {
        _push(`<div class="bg-green-100 border-t-4 border-green-500 rounded-b text-green-900 px-4 py-5 shadow-md" role="alert"><div class="flex"><div class="p-2"><svg class="fill-current h-6 w-6 text-green-500 mr-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z"></path></svg></div><div class="w-full flex justify-between items-center"><div><h5 class="font-bold">${ssrInterpolate(_ctx.$translate("Complete payment process"))}</h5><p class="text-sm">${ssrInterpolate(_ctx.$translate("Subscribing to membership"))}: ${ssrInterpolate(unref(membershipTypes).find((c) => c.value == unref(userData).subscription.type).label)}</p></div>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/members/dashboard/membership/pay",
          class: "btn-primary"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Pay"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Pay")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(userData).active === 1 && unref(userData).approved === 1 && unref(userData).subscription.status === 1 && new Date(unref(userData).subscription.end_date) > new Date()) {
        _push(`<!--[--><hr class="my-10"><h5 class="form-title">${ssrInterpolate(_ctx.$translate("Membership card"))}</h5><div class="m-4"><div class="membership-cart"><div style="${ssrRenderStyle({ "position": "relative" })}"><div class="cart-header"><p class="m-0" style="${ssrRenderStyle({ "font-weight": "bolder", "color": "#fff", "font-size": "1.8em", "font-family": "'Markazi Text', serif !important" })}"> \u0647\u064A\u0626\u0640\u0640\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0640\u064A\u0646 </p><p class="m-0" style="${ssrRenderStyle({ "color": "#fff", "font-size": "1em", "font-family": "'Cairo', sans-serif" })}"> SAUDI JOURNALISTS ASSOCIATION </p></div><div class="cart-header-logo"><img style="${ssrRenderStyle({ "height": "100px" })}" src="https://sju.org.sa/assets/themes/main/images/logo.png"></div><div class="membership-id"><p class="m-0" style="${ssrRenderStyle({ "font-size": "1em", "font-weight": "bolder", "color": "#fff" })}"> \u0628\u0637\u0627\u0642\u0629 \u0639\u0636\u0648\u064A\u0629 \xA0\xA0\xA0\xA0 Membership ID </p></div><div class="membership-body"><img style="${ssrRenderStyle({ "height": "205px", "border": "1px solid #d9d8d8", "width": "200px", "object-fit": "cover", "border-radius": "3px", "margin-bottom": "5px", "margin": "auto" })}"${ssrRenderAttr("src", ((_a2 = unref(userData)) == null ? void 0 : _a2.avatar) || "/images/user.png")}><p class="m-1" style="${ssrRenderStyle({ "font-size": "1.25em", "font-weight": "bolder", "color": "#000" })}">${ssrInterpolate(unref(userData).fullName)}</p><p class="m-1" style="${ssrRenderStyle({ "font-family": "acumin-pro, sans-serif", "font-weight": "600", "color": "#000", "text-transform": "capitalize", "font-size": "18px" })}">${ssrInterpolate(unref(userData).fullName_en)}</p><p class="m-1 membership-number" style="${ssrRenderStyle({ "font-size": "1em", "font-weight": "bolder", "color": "#000", "direction": "ltr", "margin": "21px 0 !important" })}"> ID Number \xA0\xA0 ${ssrInterpolate(unref(userData).membership_number)} \xA0\xA0 \u0631\u0642\u0645 \u0627\u0644\u0639\u0636\u0648\u064A\u0629 </p><p class="m-0" style="${ssrRenderStyle({ "font-weight": "bolder", "color": "#fff", "background": "#95c049", "display": "block", "width": "100%", "direction": "ltr", "font-size": "1em", "padding": "3px 0" })}"> Expiry date \xA0\xA0\xA0\xA0 ${ssrInterpolate(unref(userData).subscription.end_date)} \xA0\xA0\xA0\xA0 \u0635\u0644\u0627\u062D\u064A\u0629 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 </p></div><div id="watermark" class="hidden"><p>\u0645\u0633\u0648\u062F\u0629</p></div></div></div></div><!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/dashboard/membership/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.7a19efd3.mjs.map
