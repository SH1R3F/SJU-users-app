import { C as useSupportStore, u as useNuxtApp, a as useHead } from './server.mjs';
import { resolveComponent, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "create",
  __ssrInlineRender: true,
  setup(__props) {
    const supportStore = useSupportStore();
    const createTicket = async (ticket, node) => {
      var _a, _b, _c, _d, _e, _f, _g, _h;
      const body = new FormData();
      Object.keys(ticket).forEach((key) => {
        let value = ticket[key];
        body.append(key, value);
      });
      body.append("image", ((_a = ticket.image[0]) == null ? void 0 : _a.file) || "");
      const { error } = await supportStore.submitTicket(body);
      if (((_c = (_b = error == null ? void 0 : error.value) == null ? void 0 : _b.response) == null ? void 0 : _c.status) === 400) {
        node.setErrors((_d = error.value) == null ? void 0 : _d.data);
      } else if (((_f = (_e = error == null ? void 0 : error.value) == null ? void 0 : _e.response) == null ? void 0 : _f.status) === 422) {
        toast.error((_h = (_g = error.value) == null ? void 0 : _g.data) == null ? void 0 : _h.message);
      }
    };
    const { $i18n } = useNuxtApp();
    const title = `${$i18n.translate("Technical support")} - ${$i18n.translate("New ticket")}`;
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="card"><h5 class="card-title">${ssrInterpolate(title)}</h5>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: createTicket,
        enctype: "multipart/form-data"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Ticket title"),
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              type: "text",
              placeholder: _ctx.$translate("Ticket title"),
              name: "title",
              "validation-label": _ctx.$translate("Ticket title"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Description"),
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              type: "textarea",
              rows: "20",
              placeholder: _ctx.$translate("Description"),
              name: "description",
              "validation-label": _ctx.$translate("Description"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "file",
              name: "image",
              label: _ctx.$translate("Attach image"),
              accept: "image/*",
              classes: {
                input: "block px-3 w-full",
                outer: "mb-5",
                wrapper: {
                  "formkit-wrapper": false
                }
              }
            }, null, _parent2, _scopeId));
            _push2(`<div class="text-end"${_scopeId}><button class="btn-primary" type="submit"${_scopeId}>${ssrInterpolate(_ctx.$translate("Create"))}</button></div>`);
          } else {
            return [
              createVNode(_component_FormKit, {
                label: _ctx.$translate("Ticket title"),
                classes: {
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full": true
                  },
                  outer: "mb-3"
                },
                type: "text",
                placeholder: _ctx.$translate("Ticket title"),
                name: "title",
                "validation-label": _ctx.$translate("Ticket title"),
                validation: "required:trim"
              }, null, 8, ["label", "placeholder", "validation-label"]),
              createVNode(_component_FormKit, {
                label: _ctx.$translate("Description"),
                classes: {
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full": true
                  },
                  outer: "mb-3"
                },
                type: "textarea",
                rows: "20",
                placeholder: _ctx.$translate("Description"),
                name: "description",
                "validation-label": _ctx.$translate("Description"),
                validation: "required:trim"
              }, null, 8, ["label", "placeholder", "validation-label"]),
              createVNode(_component_FormKit, {
                type: "file",
                name: "image",
                label: _ctx.$translate("Attach image"),
                accept: "image/*",
                classes: {
                  input: "block px-3 w-full",
                  outer: "mb-5",
                  wrapper: {
                    "formkit-wrapper": false
                  }
                }
              }, null, 8, ["label"]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  class: "btn-primary",
                  type: "submit"
                }, toDisplayString(_ctx.$translate("Create")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/subscribers/dashboard/support/create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create.ee07a594.mjs.map
