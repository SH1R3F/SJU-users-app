import { z as useMemberStore, u as useNuxtApp, a as useHead, B as _sfc_main$2, d as useToast } from './server.mjs';
import { resolveComponent, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "password",
  __ssrInlineRender: true,
  setup(__props) {
    const toast = useToast();
    const memberStore = useMemberStore();
    const updatePassword = async (body, node) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const { error } = await memberStore.updatePassword(body);
      if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) === 400) {
        node.setErrors((_c = error.value) == null ? void 0 : _c.data);
      } else if (((_e = (_d = error == null ? void 0 : error.value) == null ? void 0 : _d.response) == null ? void 0 : _e.status) === 422) {
        toast.error((_g = (_f = error.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message);
      }
    };
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Edit profile");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_members_profile_nav = _sfc_main$2;
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_members_profile_nav, { active: "password" }, null, _parent));
      _push(`<div class="form"><div class="form-title font-semibold">${ssrInterpolate(_ctx.$translate("Change password"))}</div>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: updatePassword
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-3/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Current password"))}</label>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                outer: "w-full sm:w-9/12",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("Current password"),
              id: "current_password",
              name: "current_password",
              "validation-label": _ctx.$translate("Current password"),
              validation: "required:trim|length:6"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-3/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("New password"))}</label>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                outer: "w-full sm:w-9/12",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("New password"),
              id: "new_password",
              name: "new_password",
              "validation-label": _ctx.$translate("New password"),
              validation: "required:trim|length:6"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-3/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Password confirmation"))}</label>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                outer: "w-full sm:w-9/12",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("Password confirmation"),
              id: "new_password_confirm",
              name: "new_password_confirm",
              "validation-label": _ctx.$translate("Password confirmation"),
              validation: "required:trim|length:6|confirm"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Save"))}</button></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-wrap mb-8" }, [
                createVNode("label", { class: "w-full sm:w-3/12" }, toDisplayString(_ctx.$translate("Current password")), 1),
                createVNode(_component_FormKit, {
                  classes: {
                    outer: "w-full sm:w-9/12",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("Current password"),
                  id: "current_password",
                  name: "current_password",
                  "validation-label": _ctx.$translate("Current password"),
                  validation: "required:trim|length:6"
                }, null, 8, ["placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "flex flex-wrap mb-8" }, [
                createVNode("label", { class: "w-full sm:w-3/12" }, toDisplayString(_ctx.$translate("New password")), 1),
                createVNode(_component_FormKit, {
                  classes: {
                    outer: "w-full sm:w-9/12",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("New password"),
                  id: "new_password",
                  name: "new_password",
                  "validation-label": _ctx.$translate("New password"),
                  validation: "required:trim|length:6"
                }, null, 8, ["placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "flex flex-wrap mb-8" }, [
                createVNode("label", { class: "w-full sm:w-3/12" }, toDisplayString(_ctx.$translate("Password confirmation")), 1),
                createVNode(_component_FormKit, {
                  classes: {
                    outer: "w-full sm:w-9/12",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("Password confirmation"),
                  id: "new_password_confirm",
                  name: "new_password_confirm",
                  "validation-label": _ctx.$translate("Password confirmation"),
                  validation: "required:trim|length:6|confirm"
                }, null, 8, ["placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  type: "submit",
                  class: "btn-primary"
                }, toDisplayString(_ctx.$translate("Save")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/dashboard/profile/password.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=password.0bccf63f.mjs.map
