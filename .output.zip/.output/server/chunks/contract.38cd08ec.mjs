import { z as useMemberStore, e as useAuthStore, h as storeToRefs, m as useRouter, u as useNuxtApp, a as useHead, B as _sfc_main$2, d as useToast } from './server.mjs';
import { resolveComponent, withCtx, unref, createVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "contract",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const toast = useToast();
    const memberStore = useMemberStore();
    const authStore = useAuthStore();
    const { userData } = storeToRefs(authStore);
    if (((_a = userData.value.subscription) == null ? void 0 : _a.type) !== 3) {
      useRouter().push("/members/dashboard/profile");
    }
    const updateContract = async (form, node) => {
      var _a2, _b, _c, _d, _e, _f, _g, _h;
      const body = new FormData();
      body.append("image", ((_a2 = form.image[0]) == null ? void 0 : _a2.file) || "");
      const { error } = await memberStore.updateContract(body);
      if (((_c = (_b = error == null ? void 0 : error.value) == null ? void 0 : _b.response) == null ? void 0 : _c.status) === 400) {
        node.setErrors((_d = error.value) == null ? void 0 : _d.data);
      } else if (((_f = (_e = error == null ? void 0 : error.value) == null ? void 0 : _e.response) == null ? void 0 : _f.status) === 422) {
        toast.error((_h = (_g = error.value) == null ? void 0 : _g.data) == null ? void 0 : _h.message);
      }
    };
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Edit profile");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_members_profile_nav = _sfc_main$2;
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_members_profile_nav, { active: "contract" }, null, _parent));
      _push(`<div class="form">`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: updateContract,
        enctype: "multipart/form-data"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b;
          if (_push2) {
            _push2(`<div class="flex flex-col md:flex-row justify-between mb-10"${_scopeId}><div${_scopeId}><div class="form-title font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$translate("Job contract"))}</div><ul class="pl-7 rtl:pr-7 rtl:pl-0 list-disc mb-7"${_scopeId}><li class="text-gray-600 text-sm mb-2"${_scopeId}>${ssrInterpolate(_ctx.$translate("Image must have a good quality"))}</li><li class="text-gray-600 text-sm mb-2"${_scopeId}>${ssrInterpolate(_ctx.$translate("Only .Jpg, .Gif, .Png images are accepted"))}</li><li class="text-gray-600 text-sm mb-2"${_scopeId}>${ssrInterpolate(_ctx.$translate("Image size must not exceed 2 MB"))}</li></ul>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "file",
              name: "image",
              accept: "image/*"
            }, null, _parent2, _scopeId));
            _push2(`</div><img${ssrRenderAttr("src", ((_a2 = unref(userData)) == null ? void 0 : _a2.job_contract) || "/images/letter.png")} class="mx-auto md:mx-0 mt-10 md:mt-0 h-32 lg:h-40 object-cover object-center"${_scopeId}></div><div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Save"))}</button></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col md:flex-row justify-between mb-10" }, [
                createVNode("div", null, [
                  createVNode("div", { class: "form-title font-semibold" }, toDisplayString(_ctx.$translate("Job contract")), 1),
                  createVNode("ul", { class: "pl-7 rtl:pr-7 rtl:pl-0 list-disc mb-7" }, [
                    createVNode("li", { class: "text-gray-600 text-sm mb-2" }, toDisplayString(_ctx.$translate("Image must have a good quality")), 1),
                    createVNode("li", { class: "text-gray-600 text-sm mb-2" }, toDisplayString(_ctx.$translate("Only .Jpg, .Gif, .Png images are accepted")), 1),
                    createVNode("li", { class: "text-gray-600 text-sm mb-2" }, toDisplayString(_ctx.$translate("Image size must not exceed 2 MB")), 1)
                  ]),
                  createVNode(_component_FormKit, {
                    type: "file",
                    name: "image",
                    accept: "image/*"
                  })
                ]),
                createVNode("img", {
                  src: ((_b = unref(userData)) == null ? void 0 : _b.job_contract) || "/images/letter.png",
                  class: "mx-auto md:mx-0 mt-10 md:mt-0 h-32 lg:h-40 object-cover object-center"
                }, null, 8, ["src"])
              ]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  type: "submit",
                  class: "btn-primary"
                }, toDisplayString(_ctx.$translate("Save")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/dashboard/profile/contract.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=contract.38cd08ec.mjs.map
