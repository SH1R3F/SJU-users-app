const index_vue_vue_type_style_index_0_lang = ".formkit-label{font-weight:400!important}";

const indexStyles_57a8fbfd = [index_vue_vue_type_style_index_0_lang];

export { indexStyles_57a8fbfd as default };
//# sourceMappingURL=index-styles.57a8fbfd.mjs.map
