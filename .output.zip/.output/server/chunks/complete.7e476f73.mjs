import { e as useAuthStore, h as storeToRefs, u as useNuxtApp, a as useHead, k as __nuxt_component_0$1 } from './server.mjs';
import { computed, ref, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle, ssrRenderClass, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "complete",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const authStore = useAuthStore();
    const { userData } = storeToRefs(authStore);
    const hasExperiences = computed(() => {
      var _a2, _b, _c, _d, _e, _f;
      return ((_b = (_a2 = userData.value.experiences_and_fields) == null ? void 0 : _a2.fields) == null ? void 0 : _b.length) && ((_d = (_c = userData.value.experiences_and_fields) == null ? void 0 : _c.experiences) == null ? void 0 : _d.length) && ((_f = (_e = userData.value.experiences_and_fields) == null ? void 0 : _e.languages) == null ? void 0 : _f.length);
    });
    const progress = ref(40);
    if (userData.value.newspaper_type != 2) {
      progress.value = progress.value + 10;
    }
    if (userData.value.subscription.type != 3) {
      progress.value = progress.value + 10;
    }
    progress.value += userData.value.avatar ? 10 : 0;
    progress.value += userData.value.national_image ? 10 : 0;
    progress.value += userData.value.employer_letter ? 10 : 0;
    if (((_a = userData.value.subscription) == null ? void 0 : _a.type) == 3) {
      progress.value += userData.value.job_contract ? 10 : 0;
    }
    if (userData.value.newspaper_type === 2) {
      progress.value += userData.value.newspaper_license ? 10 : 0;
    }
    progress.value += hasExperiences.value ? 10 : 0;
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Complete profile info");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="form"><div class="form-title font-semibold">${ssrInterpolate(_ctx.$translate("Complete profile info"))}</div><p class="text-gray-500 mb-7">${ssrInterpolate(_ctx.$translate("To apply for membership, you must complete the required information"))}</p><h5 class="mb-3">${ssrInterpolate(_ctx.$translate("Completion percentage"))}</h5><div class="w-full bg-gray-200 rounded-full dark:bg-gray-700"><div style="${ssrRenderStyle(`width: ${progress.value}%`)}" class="${ssrRenderClass([{
        "bg-sju-50": progress.value === 100,
        "bg-green-300": progress.value < 100
      }, "text-xs font-medium text-blue-100 text-center p-0.5 leading-none rounded-full"])}">${ssrInterpolate(progress.value)}% </div></div><table class="w-full text-sm text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"><tr><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Requirement"))}</th><th scope="col" class="py-3 px-6"></th></tr></thead><tbody class="text-center"><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6"><span class="${ssrRenderClass({
        "line-through text-sju-50": unref(userData).avatar
      })}">${ssrInterpolate(_ctx.$translate("Profile picture"))}</span></td><td class="py-4 px-6">`);
      if (!unref(userData).avatar) {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/members/dashboard/profile/picture",
          class: "btn-primary"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Upload"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Upload")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6"><span class="${ssrRenderClass({
        "line-through text-sju-50": unref(userData).national_image
      })}">${ssrInterpolate(_ctx.$translate("ID image"))}</span></td><td class="py-4 px-6">`);
      if (!unref(userData).national_image) {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/members/dashboard/profile/identification",
          class: "btn-primary"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Upload"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Upload")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6"><span class="${ssrRenderClass({
        "line-through text-sju-50": unref(userData).employer_letter
      })}">${ssrInterpolate(_ctx.$translate("Job letter"))}</span></td><td class="py-4 px-6">`);
      if (!unref(userData).employer_letter) {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/members/dashboard/profile/statement",
          class: "btn-primary"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Upload"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Upload")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</td></tr>`);
      if (((_a2 = unref(userData).subscription) == null ? void 0 : _a2.type) === 3) {
        _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6"><span class="${ssrRenderClass({
          "line-through text-sju-50": unref(userData).job_contract
        })}">${ssrInterpolate(_ctx.$translate("Job contract"))}</span></td><td class="py-4 px-6">`);
        if (!unref(userData).job_contract) {
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: "/members/dashboard/profile/contract",
            class: "btn-primary"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(_ctx.$translate("Upload"))}`);
              } else {
                return [
                  createTextVNode(toDisplayString(_ctx.$translate("Upload")), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</td></tr>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(userData).newspaper_type === 2) {
        _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6"><span class="${ssrRenderClass({
          "line-through text-sju-50": unref(userData).newspaper_license
        })}">${ssrInterpolate(_ctx.$translate("Newspaper license"))}</span></td><td class="py-4 px-6">`);
        if (!unref(userData).newspaper_license) {
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: "/members/dashboard/profile/license",
            class: "btn-primary"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(_ctx.$translate("Upload"))}`);
              } else {
                return [
                  createTextVNode(toDisplayString(_ctx.$translate("Upload")), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</td></tr>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6"><span class="${ssrRenderClass({
        "line-through text-sju-50": unref(hasExperiences)
      })}">${ssrInterpolate(_ctx.$translate("Exp. & fields"))}</span></td><td class="py-4 px-6">`);
      if (!unref(hasExperiences)) {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/members/dashboard/profile/experiences",
          class: "btn-primary"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Upload"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Upload")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</td></tr></tbody></table></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/dashboard/profile/complete.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=complete.7e476f73.mjs.map
