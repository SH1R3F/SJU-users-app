import { f as useLocalization, m as useRouter, g as useRoute, b as useEventStore, h as storeToRefs, u as useNuxtApp, a as useHead, j as _sfc_main$b, l as _sfc_main$a, n as _sfc_main$9 } from './server.mjs';
import { withAsyncContext, watch, ref, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useLocalization();
    const router = useRouter();
    const route = useRoute();
    const eventStore = useEventStore();
    const { events, getType, getPagination } = storeToRefs(eventStore);
    [__temp, __restore] = withAsyncContext(() => eventStore.fetchEvents()), await __temp, __restore();
    const setPage = (page) => {
      router.push({
        path: route.fullPath,
        query: {
          page,
          type: route.query.type
        }
      });
    };
    watch(
      () => route.query,
      async () => {
        eventStore.type = route.query.type;
        eventStore.pagination.current_page = route.query.page;
        await eventStore.fetchEvents();
      }
    );
    const { $i18n } = useNuxtApp();
    const meta = ref({
      title: $i18n.translate("Events list"),
      breadcrumb: [
        {
          link: "/",
          title: $i18n.translate("Home")
        }
      ]
    });
    useHead({
      title: meta.value.title
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_page_header = _sfc_main$b;
      const _component_event_preview = _sfc_main$a;
      const _component_simple_pagination = _sfc_main$9;
      _push(`<div${ssrRenderAttrs(mergeProps({ key: "something" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_page_header, {
        title: meta.value.title,
        breadcrumb: meta.value.breadcrumb
      }, null, _parent));
      _push(`<div class="page-content py-11 dark:bg-sjud-100"><div class="container"><ul class="w-full border-b"><li class="${ssrRenderClass([{ active: unref(getType)() === "upcoming" }, "cursor-pointer inline-block text-sju-50 text-sm px-5 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300"])}">${ssrInterpolate(_ctx.$translate("Upcoming events"))}</li><li class="${ssrRenderClass([{ active: unref(getType)() === "done" }, "cursor-pointer inline-block text-sju-50 text-sm px-5 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300"])}">${ssrInterpolate(_ctx.$translate("Events done"))}</li></ul>`);
      if ((_a = unref(events)) == null ? void 0 : _a.length) {
        _push(`<div class="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 my-10"><!--[-->`);
        ssrRenderList(unref(events), (event) => {
          _push(ssrRenderComponent(_component_event_preview, { event }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<div class="my-5 p-5 bg-sju-50 rounded-sm text-white">${ssrInterpolate(_ctx.$translate("No events found"))}</div>`);
      }
      if (unref(getPagination)().last_page) {
        _push(ssrRenderComponent(_component_simple_pagination, {
          pagination: unref(getPagination)(),
          onPaginate: setPage
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/events/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.1fc264dc.mjs.map
