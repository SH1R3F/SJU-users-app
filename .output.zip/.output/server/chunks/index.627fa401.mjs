import { e as useAuthStore, h as storeToRefs, z as useMemberStore, u as useNuxtApp, a as useHead, B as _sfc_main$2, d as useToast } from './server.mjs';
import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { ref, resolveComponent, unref, withCtx, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { genders, nationalities } = useSiteConfig();
    const authStore = useAuthStore();
    const { userData } = storeToRefs(authStore);
    const profileData = ref({});
    const toast = useToast();
    const memberStore = useMemberStore();
    const updateMember = async (body, node) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const { error } = await memberStore.updateMember(body);
      if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) === 400) {
        node.setErrors((_c = error.value) == null ? void 0 : _c.data);
      } else if (((_e = (_d = error == null ? void 0 : error.value) == null ? void 0 : _d.response) == null ? void 0 : _e.status) === 422) {
        toast.error((_g = (_f = error.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message);
      }
    };
    const dateChanged = (e) => {
      profileData.value[e.target.name] = e.target.value;
    };
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Edit profile");
    useHead({
      title,
      script: [
        {
          src: "/libs/datepicker/js/datepicker-hijri.js"
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_members_profile_nav = _sfc_main$2;
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_members_profile_nav, { active: "info" }, null, _parent));
      _push(`<div class="form"><div class="form-title font-semibold">${ssrInterpolate(_ctx.$translate("Edit profile"))}</div>`);
      if (Object.keys(unref(userData)).length) {
        _push(ssrRenderComponent(_component_FormKit, {
          type: "form",
          modelValue: profileData.value,
          "onUpdate:modelValue": ($event) => profileData.value = $event,
          actions: false,
          onSubmit: updateMember
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T;
            if (_push2) {
              _push2(`<div class="row-of-two mb-5"${_scopeId}><div${_scopeId}><label class="w-6/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("National ID"))}</label><h5 class="text-sju-50 font-bold inline-block"${_scopeId}>${ssrInterpolate(unref(userData).national_id)}</h5></div><div${_scopeId}><label class="w-6/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Mobile"))}</label><h5 class="text-sju-50 font-bold inline-block"${_scopeId}>${ssrInterpolate(unref(userData).mobile)}</h5></div></div><div class="row-of-two"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("ID source"),
                type: "text",
                name: "source",
                "validation-label": _ctx.$translate("ID source"),
                validation: "required",
                value: (_a = unref(userData)) == null ? void 0 : _a.source
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("ID date"),
                type: "text",
                name: "date",
                id: "date",
                "validation-label": _ctx.$translate("ID date"),
                validation: "required",
                value: (_b = unref(userData)) == null ? void 0 : _b.date,
                onChange: dateChanged
              }, null, _parent2, _scopeId));
              _push2(`<datepicker-hijri reference="date" placement="bottom" date-format="iYYYY/iMM/iDD"${ssrRenderAttr("selected-date", (_c = unref(userData)) == null ? void 0 : _c.date)}${_scopeId}></datepicker-hijri></div><div class="flex flex-wrap gap-y-5 mb-8"${_scopeId}><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(_ctx.$translate("fname"))}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(userData).fname_ar)}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(_ctx.$translate("sname"))}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(userData).sname_ar)}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(_ctx.$translate("tname"))}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(userData).tname_ar)}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(_ctx.$translate("lname"))}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(userData).lname_ar)}</h4></div></div><div class="flex flex-wrap gap-y-5 mb-8"${_scopeId}><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(`${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`)}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(userData).fname_en)}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(`${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`)}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(userData).sname_en)}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(`${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`)}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(userData).tname_en)}</h4></div><div class="w-6/12 sm:w-3/12"${_scopeId}><label${_scopeId}>${ssrInterpolate(`${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`)}</label><h4 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(userData).lname_en)}</h4></div></div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Gender"))}</label><div class="w-full sm:w-10/12"${_scopeId}><h5 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(genders)[(_d = unref(userData)) == null ? void 0 : _d.gender].label)}</h5></div></div><div class="row-of-two mb-5"${_scopeId}><div${_scopeId}><label class="w-6/12"${_scopeId}>${ssrInterpolate(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Hijri")})`)}</label><h5 class="text-sju-50 inline-block"${_scopeId}>${ssrInterpolate(unref(userData).birthday_hijri)}</h5></div><div${_scopeId}><label class="w-6/12"${_scopeId}>${ssrInterpolate(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Milady")})`)}</label><h5 class="text-sju-50 inline-block"${_scopeId}>${ssrInterpolate(unref(userData).birthday_meladi)}</h5></div></div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Nationality"))}</label><div class="w-full sm:w-10/12"${_scopeId}><h5 class="text-sju-50"${_scopeId}>${ssrInterpolate(unref(nationalities).find((c) => c.value === unref(userData).nationality).label)}</h5></div></div><div class="row-of-two"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Qualification"),
                type: "text",
                name: "qualification",
                "validation-label": _ctx.$translate("Qualification"),
                validation: "required",
                value: (_e = unref(userData)) == null ? void 0 : _e.qualification
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Major"),
                type: "text",
                name: "major",
                "validation-label": _ctx.$translate("Major"),
                validation: "required",
                value: (_f = unref(userData)) == null ? void 0 : _f.major
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="flex flex-wrap gap-y-5 mb-8"${_scopeId}><div class="w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Journalist")})`,
                type: "text",
                name: "journalist_job_title",
                "validation-label": _ctx.$translate("Job title"),
                validation: "required",
                value: (_g = unref(userData)) == null ? void 0 : _g.journalist_job_title
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Employer"),
                type: "text",
                name: "journalist_employer",
                "validation-label": _ctx.$translate("Employer"),
                validation: "required",
                value: (_h = unref(userData)) == null ? void 0 : _h.journalist_employer
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "select",
                classes: {
                  outer: "w-full"
                },
                "sections-schema": {
                  selectIcon: { $el: null }
                },
                options: [
                  {
                    label: _ctx.$translate("Printed newspaper"),
                    value: 1
                  },
                  {
                    label: _ctx.$translate("E-newspaper"),
                    value: 2
                  }
                ],
                name: "newspaper_type",
                label: _ctx.$translate("Newspaper type"),
                "validation-label": _ctx.$translate("Newspaper type"),
                validation: "required",
                value: (_i = unref(userData)) == null ? void 0 : _i.newspaper_type
              }, null, _parent2, _scopeId));
              _push2(`</div></div><div class="row-of-two"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Non-Journalist")})`,
                type: "text",
                name: "job_title",
                "validation-label": _ctx.$translate("Job title"),
                validation: "required",
                value: (_j = unref(userData)) == null ? void 0 : _j.job_title
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Employer"),
                type: "text",
                name: "employer",
                "validation-label": _ctx.$translate("Employer"),
                validation: "required",
                value: (_k = unref(userData)) == null ? void 0 : _k.employer
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="row-of-two"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Work phone"),
                type: "text",
                name: "worktel",
                "validation-label": _ctx.$translate("Work phone"),
                validation: "required",
                value: (_l = unref(userData)) == null ? void 0 : _l.worktel
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Ext"),
                type: "text",
                name: "worktel_ext",
                "validation-label": _ctx.$translate("Ext"),
                validation: "required",
                value: (_m = unref(userData)) == null ? void 0 : _m.worktel_ext
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="row-of-two"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Fax"),
                type: "text",
                name: "fax",
                "validation-label": _ctx.$translate("Fax"),
                validation: "required",
                value: (_n = unref(userData)) == null ? void 0 : _n.fax
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Ext"),
                type: "text",
                name: "fax_ext",
                "validation-label": _ctx.$translate("Ext"),
                validation: "required",
                value: (_o = unref(userData)) == null ? void 0 : _o.fax_ext
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="flex flex-wrap gap-y-5 mb-8"${_scopeId}><div class="w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Post box"),
                type: "text",
                name: "post_box",
                "validation-label": _ctx.$translate("Post box"),
                validation: "required",
                value: (_p = unref(userData)) == null ? void 0 : _p.post_box
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("Post code"),
                type: "text",
                name: "post_code",
                "validation-label": _ctx.$translate("Post code"),
                validation: "required",
                value: (_q = unref(userData)) == null ? void 0 : _q.post_code
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("City"),
                type: "text",
                name: "city",
                "validation-label": _ctx.$translate("City"),
                validation: "required",
                value: (_r = unref(userData)) == null ? void 0 : _r.city
              }, null, _parent2, _scopeId));
              _push2(`</div></div><div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Email"))}</label><div class="w-full sm:w-10/12"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "email",
                name: "email",
                "validation-label": _ctx.$translate("Email"),
                validation: "required",
                value: (_s = unref(userData)) == null ? void 0 : _s.email
              }, null, _parent2, _scopeId));
              _push2(`</div></div>`);
              if (((_t = unref(userData)) == null ? void 0 : _t.branch) === 8) {
                _push2(`<div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Delivery method"))}</label><div class="w-full sm:w-10/12"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_FormKit, {
                  help: _ctx.$translate("If you choose delivery, 30 riyals will be added to the invoice value."),
                  type: "select",
                  name: "delivery_method",
                  id: "delivery_method",
                  classes: {
                    outer: "mb-3",
                    inner: "w-full md:w-6/12 mt-2",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full flex flex-col md:flex-row items-center": true
                    },
                    label: "w-full md:w-2/12"
                  },
                  options: [
                    {
                      label: _ctx.$translate("Receipt from the branch"),
                      value: 1
                    },
                    {
                      label: _ctx.$translate("Delivery"),
                      value: 2
                    }
                  ],
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  placeholder: _ctx.$translate("Delivery method"),
                  validation: "required",
                  "validation-label": _ctx.$translate("Delivery method"),
                  value: (_u = unref(userData)) == null ? void 0 : _u.delivery_method
                }, null, _parent2, _scopeId));
                _push2(`</div></div>`);
              } else {
                _push2(`<!---->`);
              }
              if (((_v = unref(userData)) == null ? void 0 : _v.branch) === 8 && profileData.value.delivery_method === 2) {
                _push2(`<div class="flex flex-wrap mb-8"${_scopeId}><label class="w-full sm:w-2/12"${_scopeId}>${ssrInterpolate(_ctx.$translate("Delivery method"))}</label><div class="w-full sm:w-10/12"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_FormKit, {
                  type: "text",
                  name: "delivery_address",
                  id: "delivery_address",
                  classes: {
                    outer: "mb-3",
                    inner: "w-full md:w-6/12 mt-2",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full flex flex-col md:flex-row items-center": true
                    },
                    label: "w-full md:w-2/12"
                  },
                  placeholder: _ctx.$translate("Delivery Address"),
                  validation: "required:trim",
                  "validation-label": _ctx.$translate("Delivery Address"),
                  value: (_w = unref(userData)) == null ? void 0 : _w.delivery_address
                }, null, _parent2, _scopeId));
                _push2(`</div></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Save"))}</button></div>`);
            } else {
              return [
                createVNode("div", { class: "row-of-two mb-5" }, [
                  createVNode("div", null, [
                    createVNode("label", { class: "w-6/12" }, toDisplayString(_ctx.$translate("National ID")), 1),
                    createVNode("h5", { class: "text-sju-50 font-bold inline-block" }, toDisplayString(unref(userData).national_id), 1)
                  ]),
                  createVNode("div", null, [
                    createVNode("label", { class: "w-6/12" }, toDisplayString(_ctx.$translate("Mobile")), 1),
                    createVNode("h5", { class: "text-sju-50 font-bold inline-block" }, toDisplayString(unref(userData).mobile), 1)
                  ])
                ]),
                createVNode("div", { class: "row-of-two" }, [
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("ID source"),
                    type: "text",
                    name: "source",
                    "validation-label": _ctx.$translate("ID source"),
                    validation: "required",
                    value: (_x = unref(userData)) == null ? void 0 : _x.source
                  }, null, 8, ["label", "validation-label", "value"]),
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("ID date"),
                    type: "text",
                    name: "date",
                    id: "date",
                    "validation-label": _ctx.$translate("ID date"),
                    validation: "required",
                    value: (_y = unref(userData)) == null ? void 0 : _y.date,
                    onChange: dateChanged
                  }, null, 8, ["label", "validation-label", "value"]),
                  createVNode("datepicker-hijri", {
                    reference: "date",
                    placement: "bottom",
                    "date-format": "iYYYY/iMM/iDD",
                    "selected-date": (_z = unref(userData)) == null ? void 0 : _z.date
                  }, null, 8, ["selected-date"])
                ]),
                createVNode("div", { class: "flex flex-wrap gap-y-5 mb-8" }, [
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(_ctx.$translate("fname")), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(userData).fname_ar), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(_ctx.$translate("sname")), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(userData).sname_ar), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(_ctx.$translate("tname")), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(userData).tname_ar), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(_ctx.$translate("lname")), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(userData).lname_ar), 1)
                  ])
                ]),
                createVNode("div", { class: "flex flex-wrap gap-y-5 mb-8" }, [
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(`${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(userData).fname_en), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(`${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(userData).sname_en), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(`${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(userData).tname_en), 1)
                  ]),
                  createVNode("div", { class: "w-6/12 sm:w-3/12" }, [
                    createVNode("label", null, toDisplayString(`${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`), 1),
                    createVNode("h4", { class: "text-sju-50" }, toDisplayString(unref(userData).lname_en), 1)
                  ])
                ]),
                createVNode("div", { class: "flex flex-wrap mb-8" }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Gender")), 1),
                  createVNode("div", { class: "w-full sm:w-10/12" }, [
                    createVNode("h5", { class: "text-sju-50" }, toDisplayString(unref(genders)[(_A = unref(userData)) == null ? void 0 : _A.gender].label), 1)
                  ])
                ]),
                createVNode("div", { class: "row-of-two mb-5" }, [
                  createVNode("div", null, [
                    createVNode("label", { class: "w-6/12" }, toDisplayString(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Hijri")})`), 1),
                    createVNode("h5", { class: "text-sju-50 inline-block" }, toDisplayString(unref(userData).birthday_hijri), 1)
                  ]),
                  createVNode("div", null, [
                    createVNode("label", { class: "w-6/12" }, toDisplayString(`${_ctx.$translate("Birth date")} (${_ctx.$translate("Milady")})`), 1),
                    createVNode("h5", { class: "text-sju-50 inline-block" }, toDisplayString(unref(userData).birthday_meladi), 1)
                  ])
                ]),
                createVNode("div", { class: "flex flex-wrap mb-8" }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Nationality")), 1),
                  createVNode("div", { class: "w-full sm:w-10/12" }, [
                    createVNode("h5", { class: "text-sju-50" }, toDisplayString(unref(nationalities).find((c) => c.value === unref(userData).nationality).label), 1)
                  ])
                ]),
                createVNode("div", { class: "row-of-two" }, [
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("Qualification"),
                    type: "text",
                    name: "qualification",
                    "validation-label": _ctx.$translate("Qualification"),
                    validation: "required",
                    value: (_B = unref(userData)) == null ? void 0 : _B.qualification
                  }, null, 8, ["label", "validation-label", "value"]),
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("Major"),
                    type: "text",
                    name: "major",
                    "validation-label": _ctx.$translate("Major"),
                    validation: "required",
                    value: (_C = unref(userData)) == null ? void 0 : _C.major
                  }, null, 8, ["label", "validation-label", "value"])
                ]),
                createVNode("div", { class: "flex flex-wrap gap-y-5 mb-8" }, [
                  createVNode("div", { class: "w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0" }, [
                    createVNode(_component_FormKit, {
                      label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Journalist")})`,
                      type: "text",
                      name: "journalist_job_title",
                      "validation-label": _ctx.$translate("Job title"),
                      validation: "required",
                      value: (_D = unref(userData)) == null ? void 0 : _D.journalist_job_title
                    }, null, 8, ["label", "validation-label", "value"])
                  ]),
                  createVNode("div", { class: "w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0" }, [
                    createVNode(_component_FormKit, {
                      label: _ctx.$translate("Employer"),
                      type: "text",
                      name: "journalist_employer",
                      "validation-label": _ctx.$translate("Employer"),
                      validation: "required",
                      value: (_E = unref(userData)) == null ? void 0 : _E.journalist_employer
                    }, null, 8, ["label", "validation-label", "value"])
                  ]),
                  createVNode("div", { class: "w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0" }, [
                    createVNode(_component_FormKit, {
                      type: "select",
                      classes: {
                        outer: "w-full"
                      },
                      "sections-schema": {
                        selectIcon: { $el: null }
                      },
                      options: [
                        {
                          label: _ctx.$translate("Printed newspaper"),
                          value: 1
                        },
                        {
                          label: _ctx.$translate("E-newspaper"),
                          value: 2
                        }
                      ],
                      name: "newspaper_type",
                      label: _ctx.$translate("Newspaper type"),
                      "validation-label": _ctx.$translate("Newspaper type"),
                      validation: "required",
                      value: (_F = unref(userData)) == null ? void 0 : _F.newspaper_type
                    }, null, 8, ["options", "label", "validation-label", "value"])
                  ])
                ]),
                createVNode("div", { class: "row-of-two" }, [
                  createVNode(_component_FormKit, {
                    label: `${_ctx.$translate("Job title")} (${_ctx.$translate("Non-Journalist")})`,
                    type: "text",
                    name: "job_title",
                    "validation-label": _ctx.$translate("Job title"),
                    validation: "required",
                    value: (_G = unref(userData)) == null ? void 0 : _G.job_title
                  }, null, 8, ["label", "validation-label", "value"]),
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("Employer"),
                    type: "text",
                    name: "employer",
                    "validation-label": _ctx.$translate("Employer"),
                    validation: "required",
                    value: (_H = unref(userData)) == null ? void 0 : _H.employer
                  }, null, 8, ["label", "validation-label", "value"])
                ]),
                createVNode("div", { class: "row-of-two" }, [
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("Work phone"),
                    type: "text",
                    name: "worktel",
                    "validation-label": _ctx.$translate("Work phone"),
                    validation: "required",
                    value: (_I = unref(userData)) == null ? void 0 : _I.worktel
                  }, null, 8, ["label", "validation-label", "value"]),
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("Ext"),
                    type: "text",
                    name: "worktel_ext",
                    "validation-label": _ctx.$translate("Ext"),
                    validation: "required",
                    value: (_J = unref(userData)) == null ? void 0 : _J.worktel_ext
                  }, null, 8, ["label", "validation-label", "value"])
                ]),
                createVNode("div", { class: "row-of-two" }, [
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("Fax"),
                    type: "text",
                    name: "fax",
                    "validation-label": _ctx.$translate("Fax"),
                    validation: "required",
                    value: (_K = unref(userData)) == null ? void 0 : _K.fax
                  }, null, 8, ["label", "validation-label", "value"]),
                  createVNode(_component_FormKit, {
                    label: _ctx.$translate("Ext"),
                    type: "text",
                    name: "fax_ext",
                    "validation-label": _ctx.$translate("Ext"),
                    validation: "required",
                    value: (_L = unref(userData)) == null ? void 0 : _L.fax_ext
                  }, null, 8, ["label", "validation-label", "value"])
                ]),
                createVNode("div", { class: "flex flex-wrap gap-y-5 mb-8" }, [
                  createVNode("div", { class: "w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0" }, [
                    createVNode(_component_FormKit, {
                      label: _ctx.$translate("Post box"),
                      type: "text",
                      name: "post_box",
                      "validation-label": _ctx.$translate("Post box"),
                      validation: "required",
                      value: (_M = unref(userData)) == null ? void 0 : _M.post_box
                    }, null, 8, ["label", "validation-label", "value"])
                  ]),
                  createVNode("div", { class: "w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0" }, [
                    createVNode(_component_FormKit, {
                      label: _ctx.$translate("Post code"),
                      type: "text",
                      name: "post_code",
                      "validation-label": _ctx.$translate("Post code"),
                      validation: "required",
                      value: (_N = unref(userData)) == null ? void 0 : _N.post_code
                    }, null, 8, ["label", "validation-label", "value"])
                  ]),
                  createVNode("div", { class: "w-full sm:w-4/12 pr-5 rtl:pl-5 rtl:pr-0" }, [
                    createVNode(_component_FormKit, {
                      label: _ctx.$translate("City"),
                      type: "text",
                      name: "city",
                      "validation-label": _ctx.$translate("City"),
                      validation: "required",
                      value: (_O = unref(userData)) == null ? void 0 : _O.city
                    }, null, 8, ["label", "validation-label", "value"])
                  ])
                ]),
                createVNode("div", { class: "flex flex-wrap mb-8" }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Email")), 1),
                  createVNode("div", { class: "w-full sm:w-10/12" }, [
                    createVNode(_component_FormKit, {
                      type: "email",
                      name: "email",
                      "validation-label": _ctx.$translate("Email"),
                      validation: "required",
                      value: (_P = unref(userData)) == null ? void 0 : _P.email
                    }, null, 8, ["validation-label", "value"])
                  ])
                ]),
                ((_Q = unref(userData)) == null ? void 0 : _Q.branch) === 8 ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "flex flex-wrap mb-8"
                }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Delivery method")), 1),
                  createVNode("div", { class: "w-full sm:w-10/12" }, [
                    createVNode(_component_FormKit, {
                      help: _ctx.$translate("If you choose delivery, 30 riyals will be added to the invoice value."),
                      type: "select",
                      name: "delivery_method",
                      id: "delivery_method",
                      classes: {
                        outer: "mb-3",
                        inner: "w-full md:w-6/12 mt-2",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex flex-col md:flex-row items-center": true
                        },
                        label: "w-full md:w-2/12"
                      },
                      options: [
                        {
                          label: _ctx.$translate("Receipt from the branch"),
                          value: 1
                        },
                        {
                          label: _ctx.$translate("Delivery"),
                          value: 2
                        }
                      ],
                      "sections-schema": {
                        selectIcon: { $el: null }
                      },
                      placeholder: _ctx.$translate("Delivery method"),
                      validation: "required",
                      "validation-label": _ctx.$translate("Delivery method"),
                      value: (_R = unref(userData)) == null ? void 0 : _R.delivery_method
                    }, null, 8, ["help", "options", "placeholder", "validation-label", "value"])
                  ])
                ])) : createCommentVNode("", true),
                ((_S = unref(userData)) == null ? void 0 : _S.branch) === 8 && profileData.value.delivery_method === 2 ? (openBlock(), createBlock("div", {
                  key: 1,
                  class: "flex flex-wrap mb-8"
                }, [
                  createVNode("label", { class: "w-full sm:w-2/12" }, toDisplayString(_ctx.$translate("Delivery method")), 1),
                  createVNode("div", { class: "w-full sm:w-10/12" }, [
                    createVNode(_component_FormKit, {
                      type: "text",
                      name: "delivery_address",
                      id: "delivery_address",
                      classes: {
                        outer: "mb-3",
                        inner: "w-full md:w-6/12 mt-2",
                        wrapper: {
                          "formkit-wrapper": false,
                          "w-full flex flex-col md:flex-row items-center": true
                        },
                        label: "w-full md:w-2/12"
                      },
                      placeholder: _ctx.$translate("Delivery Address"),
                      validation: "required:trim",
                      "validation-label": _ctx.$translate("Delivery Address"),
                      value: (_T = unref(userData)) == null ? void 0 : _T.delivery_address
                    }, null, 8, ["placeholder", "validation-label", "value"])
                  ])
                ])) : createCommentVNode("", true),
                createVNode("div", { class: "text-end" }, [
                  createVNode("button", {
                    type: "submit",
                    class: "btn-primary"
                  }, toDisplayString(_ctx.$translate("Save")), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/dashboard/profile/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.627fa401.mjs.map
