const Footer_vue_vue_type_style_index_0_scoped_aba42310_lang = ".twitter-white[data-v-aba42310]{fill:#fff}";

const FooterStyles_7b4ef09b = [Footer_vue_vue_type_style_index_0_scoped_aba42310_lang];

export { FooterStyles_7b4ef09b as default };
//# sourceMappingURL=Footer-styles.7b4ef09b.mjs.map
