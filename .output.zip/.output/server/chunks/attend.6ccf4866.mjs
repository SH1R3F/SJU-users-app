import { e as useAuthStore, f as useLocalization, g as useRoute, b as useEventStore, h as storeToRefs, i as useFormating, u as useNuxtApp, a as useHead, j as _sfc_main$b, k as __nuxt_component_0$1, l as _sfc_main$a } from './server.mjs';
import { withAsyncContext, ref, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "attend",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const authStore = useAuthStore();
    const { dblocalize } = useLocalization();
    const route = useRoute();
    const eventStore = useEventStore();
    const { event, pivot, upcomingEvents } = storeToRefs(eventStore);
    const { formattedDate, formattedTime } = useFormating();
    [__temp, __restore] = withAsyncContext(() => eventStore.fetchEvent(route.params.id)), await __temp, __restore();
    const { $i18n } = useNuxtApp();
    const meta = ref({
      title: dblocalize(event.value, "name"),
      breadcrumb: [
        {
          link: "/",
          title: $i18n.translate("Home")
        },
        {
          link: "/events",
          title: $i18n.translate("Events list")
        }
      ]
    });
    useHead({
      title: meta.value.title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_page_header = _sfc_main$b;
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_event_preview = _sfc_main$a;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_page_header, {
        title: meta.value.title,
        breadcrumb: meta.value.breadcrumb,
        date: unref(event).date_from
      }, null, _parent));
      _push(`<div class="page-content py-11 dark:bg-sjud-100"><div class="container"><div class="flex flex-col md:flex-row gap-6"><div class="md:w-8/12 text-gray-600"><div class="card"><h5 class="card-title">${ssrInterpolate(_ctx.$translate("Additional info"))}</h5><div class="overflow-x-auto relative shadow-md sm:rounded-lg mb-8"><table class="w-full text-sm text-gray-500 dark:text-gray-400"><tbody class="text-center"><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(_ctx.$translate("Event name"))}</td><td class="py-4 px-6">${ssrInterpolate(unref(dblocalize)(unref(event), "name"))}</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Event date"))}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(unref(formattedDate)(unref(event).date_from))} ${ssrInterpolate(_ctx.$translate("to"))} ${ssrInterpolate(unref(formattedDate)(unref(event).date_to))}</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(_ctx.$translate("Event time"))}</td><td class="py-4 px-6">${ssrInterpolate(`${unref(formattedTime)(unref(event).time_from)} ${_ctx.$translate(
        "to"
      )} ${unref(formattedTime)(unref(event).time_to)}`)}</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Event type"))}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(unref(event).type)}</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(_ctx.$translate("Event category"))}</td><td class="py-4 px-6">${ssrInterpolate(unref(event).category)}</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Event gender"))}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(unref(event).gender)}</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(_ctx.$translate("Event location"))}</td><td class="py-4 px-6">${ssrInterpolate(unref(event).location)}</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Additional info"))}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(unref(event).summary)}</td></tr></tbody></table></div><h5 class="card-title">${ssrInterpolate(_ctx.$translate("User info"))}</h5><div class="overflow-x-auto relative shadow-md sm:rounded-lg"><table class="w-full text-sm text-gray-500 dark:text-gray-400"><tbody class="text-center"><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(_ctx.$translate("User name"))}</td><td class="py-4 px-6 text-start">`);
      if (unref(authStore).authenticated) {
        _push(`<div>${ssrInterpolate(unref(dblocalize)(unref(authStore).userData, "fullName"))}</div>`);
      } else {
        _push(`<div><button class="btn-primary" data-modal-toggle="loginModal">${ssrInterpolate(_ctx.$translate("login"))}</button></div>`);
      }
      _push(`</td></tr>`);
      if (unref(authStore).authenticated) {
        _push(`<tr class="border-b border-gray-200 dark:border-gray-700">`);
        if (!unref(event).registered) {
          _push(`<td class="py-4 px-6 bg-gray-50 dark:bg-gray-800" colspan="2"><b class="text-sju-50">${ssrInterpolate(_ctx.$translate("Not registered in event"))}</b>`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            class: "mx-2 hover:underline transition-all",
            to: `/events/${unref(event).id}/register`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(_ctx.$translate("Register"))}`);
              } else {
                return [
                  createTextVNode(toDisplayString(_ctx.$translate("Register")), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</td>`);
        } else {
          _push(`<td class="py-4 px-6 bg-sju-500 dark:bg-gray-800" colspan="2"><button type="submit" class="btn-primary">${ssrInterpolate(_ctx.$translate("Attend"))}</button></td>`);
        }
        _push(`</tr>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</tbody></table></div></div></div><div class="md:w-4/12"><h3 class="mb-3 text-sju-50">${ssrInterpolate(_ctx.$translate("Upcoming events"))}</h3><!--[-->`);
      ssrRenderList(unref(upcomingEvents), (event2) => {
        _push(ssrRenderComponent(_component_event_preview, { event: event2 }, null, _parent));
      });
      _push(`<!--]--></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/events/[id]/attend.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=attend.6ccf4866.mjs.map
