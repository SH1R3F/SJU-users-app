import { defineComponent, h, ref, computed, unref, useSSRContext, mergeProps, withCtx, createVNode, openBlock, createBlock, toDisplayString, withAsyncContext, createTextVNode, createElementBlock, createElementVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot, ssrInterpolate, ssrRenderAttr, ssrRenderStyle, ssrRenderList } from 'vue/server-renderer';
import { u as useNuxtApp, g as useRoute, p as useHomeStore, a as useHead, d as useToast, o as _export_sfc, K as GgFacebook, M as MdiTwitter, L as MdiLinkedin, e as useAuthStore, q as useApiFetch, f as useLocalization, k as __nuxt_component_0$1 } from './server.mjs';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _imports_0 = "" + globalThis.__publicAssetsURL("images/logo.png");
const _sfc_main$6 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed inset-0 bg-gray-100 transition-opacity z-30 flex items-center justify-center" }, _attrs))}><div class="text-center"><img${ssrRenderAttr("src", _imports_0)} alt="\u0647\u064A\u0626\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646" class="h-20 mx-auto"><span class="mt-1 text-sm text-gray-500">${ssrInterpolate(_ctx.$translate("Loading"))}...</span></div></div>`);
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/layout/Loading.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$5 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "form-loading" }, _attrs))}>Loading\u2026</div>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FormLoading.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender]]);
const __nuxt_component_2 = defineComponent({
  name: "NuxtLoadingIndicator",
  props: {
    throttle: {
      type: Number,
      default: 200
    },
    duration: {
      type: Number,
      default: 2e3
    },
    height: {
      type: Number,
      default: 3
    },
    color: {
      type: String,
      default: "repeating-linear-gradient(to right,#00dc82 0%,#34cdfe 50%,#0047e1 100%)"
    }
  },
  setup(props) {
    const indicator = useLoadingIndicator({
      duration: props.duration,
      throttle: props.throttle
    });
    const nuxtApp = useNuxtApp();
    nuxtApp.hook("page:start", indicator.start);
    nuxtApp.hook("page:finish", indicator.finish);
    return () => h("div", {
      class: "nuxt-loading-indicator",
      style: {
        position: "fixed",
        top: 0,
        right: 0,
        left: 0,
        pointerEvents: "none",
        width: `${indicator.progress.value}%`,
        height: `${props.height}px`,
        opacity: indicator.isLoading.value ? 1 : 0,
        background: props.color,
        backgroundSize: `${100 / indicator.progress.value * 100}% auto`,
        transition: "width 0.1s, height 0.4s, opacity 0.4s",
        zIndex: 999999
      }
    });
  }
});
function useLoadingIndicator(opts) {
  const progress = ref(0);
  const isLoading = ref(false);
  computed(() => 1e4 / opts.duration);
  let _timer = null;
  let _throttle = null;
  function start() {
    clear();
    progress.value = 0;
    isLoading.value = true;
    if (opts.throttle)
      ;
  }
  function finish() {
    progress.value = 100;
    _hide();
  }
  function clear() {
    clearInterval(_timer);
    clearTimeout(_throttle);
    _timer = null;
    _throttle = null;
  }
  function _hide() {
    clear();
  }
  return {
    progress,
    isLoading,
    start,
    finish,
    clear
  };
}
const _hoisted_1$1 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$1 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M11.38 2.019a7.5 7.5 0 1 0 10.6 10.6C21.662 17.854 17.316 22 12.001 22C6.477 22 2 17.523 2 12c0-5.315 4.146-9.661 9.38-9.981z"
}, null, -1);
const _hoisted_3$1 = [
  _hoisted_2$1
];
function render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$1, _hoisted_3$1);
}
const RiMoonFill = { name: "ri-moon-fill", render: render$1 };
const _hoisted_1 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M11 5V1h2v4Zm6.65 2.75l-1.375-1.375l2.8-2.875l1.4 1.425ZM19 13v-2h4v2Zm-8 10v-4h2v4ZM6.35 7.7L3.5 4.925l1.425-1.4L7.75 6.35Zm12.7 12.8l-2.775-2.875l1.35-1.35l2.85 2.75ZM1 13v-2h4v2Zm3.925 7.5l-1.4-1.425l2.8-2.8l.725.675l.725.7ZM12 18q-2.5 0-4.25-1.75T6 12q0-2.5 1.75-4.25T12 6q2.5 0 4.25 1.75T18 12q0 2.5-1.75 4.25T12 18Zm0-2q1.65 0 2.825-1.175Q16 13.65 16 12q0-1.65-1.175-2.825Q13.65 8 12 8q-1.65 0-2.825 1.175Q8 10.35 8 12q0 1.65 1.175 2.825Q10.35 16 12 16Zm0-4Z"
}, null, -1);
const _hoisted_3 = [
  _hoisted_2
];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, _hoisted_3);
}
const MaterialSymbolsSunnyOutline = { name: "material-symbols-sunny-outline", render };
const _sfc_main$4 = {
  __name: "Minibar",
  __ssrInlineRender: true,
  setup(__props) {
    const homeStore = useHomeStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-sju-50 py-1" }, _attrs))}><div class="container"><ul class="flex justify-end items-center text-white text-sm"><li class="mx-1 hover:text-sju-100 transition cursor-pointer">`);
      if (unref(homeStore).darkMode) {
        _push(ssrRenderComponent(unref(MaterialSymbolsSunnyOutline), null, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(RiMoonFill), null, null, _parent));
      }
      _push(`</li><li class="mx-1 hover:text-sju-100 transition"><a href="#">`);
      _push(ssrRenderComponent(unref(GgFacebook), null, null, _parent));
      _push(`</a></li><li class="mx-1 hover:text-sju-100 transition"><a href="https://twitter.com/sju_ksa" target="_blank">`);
      _push(ssrRenderComponent(unref(MdiTwitter), null, null, _parent));
      _push(`</a></li><li class="mx-1 hover:text-sju-100 transition"><a href="#">`);
      _push(ssrRenderComponent(unref(MdiLinkedin), null, null, _parent));
      _push(`</a></li><li class="mx-2"><span class="flex items-center cursor-pointer" data-dropdown-toggle="dropdown" id="dropperdown">${ssrInterpolate(_ctx.$i18n.locale === "ar" ? "\u0627\u0644\u0639\u0631\u0628\u064A\u0629" : "English")} <svg class="mx-2 w-4 h-4" aria-hidden="true" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></span><ul id="dropdown" class="hidden z-10 text-black w-44 bg-white rounded-md shadow dark:bg-sjud-500 dark:text-gray-200"><li class="cursor-pointer py-1 px-3 hover:bg-sju-100 hover:text-white [&amp;.active]:bg-sju-100 [&amp;.active]:text-white"><a>\u0627\u0644\u0639\u0631\u0628\u064A\u0629</a></li><li class="cursor-pointer py-1 px-3 hover:bg-sju-100 hover:text-white [&amp;.active]:bg-sju-100 [&amp;.active]:text-white"><a>English</a></li></ul></li></ul></div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/layout/Minibar.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    const authStore = useAuthStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-32 py-2"><div class="container"><div class="flex justify-between items-center px-2">`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="\u0647\u064A\u0626\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646" class="h-28"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "\u0647\u064A\u0626\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646",
                class: "h-28"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div style="${ssrRenderStyle(!unref(authStore).authenticated ? null : { display: "none" })}" class="flex flex-col justify-center bg-sju-100 h-24 px-9 cursor-pointer" data-modal-toggle="loginModal"><svg xmlns="http://www.w3.org/2000/svg" width="45.485" height="39.798" viewBox="0 0 45.485 39.798" class="mx-auto mb-1"><g id="user_6_" data-name="user (6)" transform="translate(0 -0.008)"><path id="Path_3" data-name="Path 3" d="M94.808,18.959a9.476,9.476,0,1,1,9.476-9.475A9.486,9.486,0,0,1,94.808,18.959Zm0-16.109a6.633,6.633,0,1,0,6.633,6.633A6.64,6.64,0,0,0,94.808,2.851Zm0,0" transform="translate(-77.752)" fill="#fff"></path><path id="Path_4" data-name="Path 4" d="M32.691,273.064H1.421A1.422,1.422,0,0,1,0,271.643V265.01a9.012,9.012,0,0,1,9-9H25.111a9.012,9.012,0,0,1,9,9v6.633A1.422,1.422,0,0,1,32.691,273.064ZM2.843,270.221H31.27V265.01a6.166,6.166,0,0,0-6.159-6.159H9a6.166,6.166,0,0,0-6.159,6.159Zm0,0" transform="translate(0 -233.258)" fill="#fff"></path><path id="Path_5" data-name="Path 5" d="M316.2,189.518H300.089a1.421,1.421,0,1,1,0-2.843H316.2a1.421,1.421,0,1,1,0,2.843Zm0,0" transform="translate(-272.136 -170.085)" fill="#fff"></path><path id="Path_6" data-name="Path 6" d="M396.093,119.312a1.422,1.422,0,0,1-1-2.428l6.576-6.576-6.576-6.576a1.422,1.422,0,1,1,2.011-2.011l7.581,7.58a1.422,1.422,0,0,1,0,2.011l-7.581,7.58A1.413,1.413,0,0,1,396.093,119.312Zm0,0" transform="translate(-359.611 -92.298)" fill="#fff"></path></g></svg><span class="font-bold text-white">${ssrInterpolate(_ctx.$translate("login"))}</span></div>`);
      if (unref(authStore).authenticated) {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: `/${unref(authStore).userType}s/`,
          class: "flex flex-col justify-center bg-sju-100 h-24 px-9 cursor-pointer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<svg xmlns="http://www.w3.org/2000/svg" width="45.485" height="39.798" viewBox="0 0 45.485 39.798" class="mx-auto mb-1"${_scopeId}><g id="user_6_" data-name="user (6)" transform="translate(0 -0.008)"${_scopeId}><path id="Path_3" data-name="Path 3" d="M94.808,18.959a9.476,9.476,0,1,1,9.476-9.475A9.486,9.486,0,0,1,94.808,18.959Zm0-16.109a6.633,6.633,0,1,0,6.633,6.633A6.64,6.64,0,0,0,94.808,2.851Zm0,0" transform="translate(-77.752)" fill="#fff"${_scopeId}></path><path id="Path_4" data-name="Path 4" d="M32.691,273.064H1.421A1.422,1.422,0,0,1,0,271.643V265.01a9.012,9.012,0,0,1,9-9H25.111a9.012,9.012,0,0,1,9,9v6.633A1.422,1.422,0,0,1,32.691,273.064ZM2.843,270.221H31.27V265.01a6.166,6.166,0,0,0-6.159-6.159H9a6.166,6.166,0,0,0-6.159,6.159Zm0,0" transform="translate(0 -233.258)" fill="#fff"${_scopeId}></path></g></svg><span class="font-bold text-white"${_scopeId}>${ssrInterpolate(_ctx.$translate("Profile"))}</span>`);
            } else {
              return [
                (openBlock(), createBlock("svg", {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "45.485",
                  height: "39.798",
                  viewBox: "0 0 45.485 39.798",
                  class: "mx-auto mb-1"
                }, [
                  createVNode("g", {
                    id: "user_6_",
                    "data-name": "user (6)",
                    transform: "translate(0 -0.008)"
                  }, [
                    createVNode("path", {
                      id: "Path_3",
                      "data-name": "Path 3",
                      d: "M94.808,18.959a9.476,9.476,0,1,1,9.476-9.475A9.486,9.486,0,0,1,94.808,18.959Zm0-16.109a6.633,6.633,0,1,0,6.633,6.633A6.64,6.64,0,0,0,94.808,2.851Zm0,0",
                      transform: "translate(-77.752)",
                      fill: "#fff"
                    }),
                    createVNode("path", {
                      id: "Path_4",
                      "data-name": "Path 4",
                      d: "M32.691,273.064H1.421A1.422,1.422,0,0,1,0,271.643V265.01a9.012,9.012,0,0,1,9-9H25.111a9.012,9.012,0,0,1,9,9v6.633A1.422,1.422,0,0,1,32.691,273.064ZM2.843,270.221H31.27V265.01a6.166,6.166,0,0,0-6.159-6.159H9a6.166,6.166,0,0,0-6.159,6.159Zm0,0",
                      transform: "translate(0 -233.258)",
                      fill: "#fff"
                    })
                  ])
                ])),
                createVNode("span", { class: "font-bold text-white" }, toDisplayString(_ctx.$translate("Profile")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><div id="loginModal" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 w-full md:inset-0 h-modal md:h-full" tabindex="-1"><div class="relative p-4 w-full max-w-2xl h-full md:h-auto"><div class="modal-box relative bg-white rounded-lg shadow dark:bg-sjud-100"><div class="flex justify-between items-start p-4 rounded-t border-b dark:border-sjud-500"><h3 class="text-xl font-medium text-gray-900 dark:text-gray-200">${ssrInterpolate(_ctx.$translate("Login to sju"))}</h3><button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 inline-flex items-center dark:hover:bg-sjud-200" data-modal-toggle="loginModal"><svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg><span class="sr-only">${ssrInterpolate(_ctx.$translate("Close modal"))}</span></button></div><div class="flex flex-col md:flex-row justify-center space-x-3 rtl:space-x-reverse px-3 py-7"><div class="flex-1 py-16 text-center border rounded-md dark:border-sjud-200 dark:text-gray-300"><div class="text-2xl pb-8">${ssrInterpolate(_ctx.$translate("Subscribers"))}</div>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "block px-4 mb-2",
        to: "/subscribers/auth/login",
        "data-modal-toggle": "loginModal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="bg-sju-200 text-white w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl hover:bg-sju-50 transition-all"${_scopeId}>${ssrInterpolate(_ctx.$translate("Login"))}</button>`);
          } else {
            return [
              createVNode("button", { class: "bg-sju-200 text-white w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl hover:bg-sju-50 transition-all" }, toDisplayString(_ctx.$translate("Login")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "block px-4",
        to: "/subscribers/auth/register",
        "data-modal-toggle": "loginModal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="bg-white text-sju-200 w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl dark:bg-sjud-200 transition-all" data-modal-toggle="loginModal"${_scopeId}>${ssrInterpolate(_ctx.$translate("Register"))}</button>`);
          } else {
            return [
              createVNode("button", {
                class: "bg-white text-sju-200 w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl dark:bg-sjud-200 transition-all",
                "data-modal-toggle": "loginModal"
              }, toDisplayString(_ctx.$translate("Register")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex-1 py-16 text-center border rounded-md dark:border-sjud-200 dark:text-gray-300 bg-sju-300 dark:bg-sju-50 transition-all"><div class="text-2xl pb-8 text-white">${ssrInterpolate(_ctx.$translate("Members"))}</div>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "block px-4 mb-2",
        to: "/members/auth/login",
        "data-modal-toggle": "loginModal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="bg-sju-200 text-white w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl hover:bg-sju-50 transition-all"${_scopeId}>${ssrInterpolate(_ctx.$translate("Login"))}</button>`);
          } else {
            return [
              createVNode("button", { class: "bg-sju-200 text-white w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl hover:bg-sju-50 transition-all" }, toDisplayString(_ctx.$translate("Login")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "block px-4 transition-all",
        to: "/members/auth/register",
        "data-modal-toggle": "loginModal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="bg-white text-sju-200 w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl transition-all"${_scopeId}>${ssrInterpolate(_ctx.$translate("Register"))}</button>`);
          } else {
            return [
              createVNode("button", { class: "bg-white text-sju-200 w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl transition-all" }, toDisplayString(_ctx.$translate("Register")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex-1 py-16 text-center border rounded-md dark:border-sjud-200 dark:text-gray-300"><div class="text-2xl pb-8">${ssrInterpolate(_ctx.$translate("Volunteers"))}</div>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "block px-4 mb-2",
        to: "/volunteers/auth/login",
        "data-modal-toggle": "loginModal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="bg-sju-200 text-white w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl hover:bg-sju-50"${_scopeId}>${ssrInterpolate(_ctx.$translate("Login"))}</button>`);
          } else {
            return [
              createVNode("button", { class: "bg-sju-200 text-white w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl hover:bg-sju-50" }, toDisplayString(_ctx.$translate("Login")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "block px-4",
        to: "/volunteers/auth/register",
        "data-modal-toggle": "loginModal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="bg-white text-sju-200 w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl dark:bg-sjud-200"${_scopeId}>${ssrInterpolate(_ctx.$translate("Register"))}</button>`);
          } else {
            return [
              createVNode("button", { class: "bg-white text-sju-200 w-full py-2 m-0 rounded-md shadow-lg hover:shadow-xl dark:bg-sjud-200" }, toDisplayString(_ctx.$translate("Register")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="flex items-center justify-end p-3 rounded-b border-t border-gray-200 dark:border-sjud-500"><button data-modal-toggle="loginModal" type="button" class="text-gray-500 bg-white hover:bg-gray-100 hover:shadow-md rounded-md border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 dark:bg-sjud-200 dark:text-gray-300 dark:border-sjud-500">${ssrInterpolate(_ctx.$translate("Close"))}</button></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/layout/Header.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "Navbar",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { useMyFetch } = useApiFetch();
    const { data } = ([__temp, __restore] = withAsyncContext(() => useMyFetch("/menus", {
      key: "menus"
    })), __temp = await __temp, __restore(), __temp);
    const { menus } = data.value;
    const { dblocalize } = useLocalization();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<nav${ssrRenderAttrs(mergeProps({ class: "bg-gradient-to-r from-sju-50 to-sju-400 sm:px-4 py-1" }, _attrs))}><div class="container flex flex-wrap justify-end items-center mx-auto"><button data-collapse-toggle="navbar-default" type="button" class="inline-flex items-center p-2 ml-3 text-sm text-gray-500 rounded-lg lg:hidden" aria-controls="navbar-default" aria-expanded="false"><span class="sr-only">Open main menu</span><svg class="w-6 h-6 text-white" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path></svg></button><div class="hidden w-full lg:block" id="navbar-default"><ul class="flex flex-col justify-between overflow-hidden p-4 lg:flex-row lg:space-x-8 rtl:space-x-reverse lg:mt-0 lg:text-sm lg:font-medium lg:border-0"><!--[-->`);
      ssrRenderList(unref(menus), (menu) => {
        _push(`<li>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: menu.link,
          class: "block py-2 pr-4 pl-3 text-white lg:p-0 hover:text-sju-400",
          target: menu.open_in_same_page ? "_self" : "_blank"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(unref(dblocalize)(menu, "title"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(dblocalize)(menu, "title")), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div></div></nav>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/layout/Navbar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-aba42310><footer class="bg-sju-600 py-8 text-white dark:bg-sjud-50" data-v-aba42310><div class="container px-2" data-v-aba42310><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8" data-v-aba42310><div data-v-aba42310><h5 class="text-xl mb-3" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Important Links"))}</h5><ul data-v-aba42310><li data-v-aba42310><a href="http://www.media.gov.sa/" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Ministry of Information"))}</a></li><li data-v-aba42310><a href="http://www.gcam.gov.sa/ar/Pages/default.aspx" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Audiovisual organization"))}</a></li><li data-v-aba42310><a href="http://www.spa.gov.sa/" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Saudi press agency"))}</a></li><li data-v-aba42310><a href="http://www.spa.gov.sa/" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Radio & TV organization"))}</a></li></ul></div><div data-v-aba42310><h5 class="text-xl mb-3" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Contact us"))}</h5><ul data-v-aba42310><li class="flex gap-3 mb-3" data-v-aba42310><svg xmlns="http://www.w3.org/2000/svg" width="22.351" height="22.351" viewBox="0 0 22.351 22.351" data-v-aba42310><g id="email_1_" data-name="email (1)" transform="translate(-0.001 -0.004)" data-v-aba42310><g id="Group_52" data-name="Group 52" transform="translate(0.001 0.004)" data-v-aba42310><g id="Group_51" data-name="Group 51" transform="translate(0)" data-v-aba42310><path id="Path_65" data-name="Path 65" d="M22.348,8.549a.352.352,0,0,0-.015-.076.373.373,0,0,0-.021-.064.334.334,0,0,0-.037-.057.351.351,0,0,0-.05-.058c-.006-.005-.009-.012-.015-.018L18.627,5.495V2.611a1.118,1.118,0,0,0-1.118-1.118H13.472L11.855.238a1.1,1.1,0,0,0-1.359,0L8.88,1.493H4.843A1.118,1.118,0,0,0,3.725,2.611V5.495L.144,8.277c-.006.005-.009.012-.015.018a.349.349,0,0,0-.05.058.333.333,0,0,0-.037.057.368.368,0,0,0-.021.064.353.353,0,0,0-.015.075c0,.008,0,.015,0,.022V21.238A1.105,1.105,0,0,0,.22,21.9s0,.007.005.01l.012.01a1.112,1.112,0,0,0,.881.439H21.235a1.112,1.112,0,0,0,.884-.441s.007,0,.01-.009,0-.007.005-.01a1.105,1.105,0,0,0,.219-.658V8.571C22.352,8.564,22.348,8.557,22.348,8.549ZM10.952.826a.357.357,0,0,1,.444,0l.859.667H10.1ZM1.211,21.61l9.741-7.567a.358.358,0,0,1,.444,0l9.744,7.567Zm20.4-.581-9.752-7.574a1.105,1.105,0,0,0-1.359,0L.745,21.029V9.139l6.1,4.741a.373.373,0,0,0,.457-.589L1.1,8.475,3.725,6.438V9.316a.373.373,0,1,0,.745,0V2.611a.373.373,0,0,1,.373-.373H17.509a.373.373,0,0,1,.373.373V9.316a.373.373,0,1,0,.745,0V6.438l2.621,2.037L15.035,13.3a.373.373,0,1,0,.457.589l6.116-4.749V21.029Z" transform="translate(-0.001 -0.004)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_66" data-name="Path 66" d="M162.515,74.2v-1.49a4.47,4.47,0,1,0-4.47,4.47.373.373,0,1,0,0-.745,3.725,3.725,0,1,1,3.725-3.725V74.2a.745.745,0,1,1-1.49,0v-1.49a.373.373,0,1,0-.745,0,1.49,1.49,0,1,1-1.49-1.49.373.373,0,1,0,0-.745,2.235,2.235,0,1,0,1.506,3.882,1.486,1.486,0,0,0,2.964-.157Z" transform="translate(-146.869 -65.258)" fill="#FFFFFF" data-v-aba42310></path></g></g></g></svg><a href="mailto:info@sju.org.sa" data-v-aba42310>info@sju.org.sa</a></li><li class="flex gap-3 mb-3" data-v-aba42310><svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="22.351" height="22.35" viewBox="0 0 22.35 18.33" data-v-aba42310><defs data-v-aba42310></defs><path class="twitter-white" d="M427.82,294.88a9,9,0,0,1-2,2.26.34.34,0,0,0-.15.3,13.26,13.26,0,0,1-2.8,8.26,12.19,12.19,0,0,1-6.59,4.43,13.39,13.39,0,0,1-4.63.42,12.88,12.88,0,0,1-5.86-2,1.73,1.73,0,0,1-.28-.26V308a.62.62,0,0,1,.63-.27,8.48,8.48,0,0,0,4.57-.81l.57-.31-.34-.12a4.82,4.82,0,0,1-3-3.07c-.1-.3.05-.51.44-.6l-.16-.15a4.8,4.8,0,0,1-1.84-3.74c0-.47.29-.66.71-.45l.22.1c-.16-.29-.32-.54-.44-.81a4.82,4.82,0,0,1,.17-4.46.45.45,0,0,1,.77-.07c.6.61,1.21,1.22,1.83,1.8.24.23.54.4.8.61a.36.36,0,0,1,.15.46.46.46,0,0,1-.77.16,12.61,12.61,0,0,1-2.12-1.81l-.14-.2a3.79,3.79,0,0,0-.27,1.52,3.9,3.9,0,0,0,1.62,3.13l.16.12a.43.43,0,0,1,.14.49.38.38,0,0,1-.42.28c-.42-.05-.83-.13-1.25-.19a2.19,2.19,0,0,0-.23-.07,3.91,3.91,0,0,0,.73,1.71,4,4,0,0,0,2.31,1.51c.29.07.43.22.43.44s-.15.39-.45.44-.82.12-1.25.18a3,3,0,0,0,.65.89,4.07,4.07,0,0,0,2.71,1.19.42.42,0,0,1,.44.32.47.47,0,0,1-.22.52,9.45,9.45,0,0,1-4.31,1.82l-.28,0a.62.62,0,0,0-.27.09c.38.14.76.3,1.15.43a11.83,11.83,0,0,0,5.25.51,11.56,11.56,0,0,0,9.35-6.67,11.82,11.82,0,0,0,1.23-5.79.65.65,0,0,1,.28-.56c.34-.27.68-.56,1-.85l0-.05-.84.15-.24,0a.42.42,0,0,1-.48-.28.43.43,0,0,1,.2-.53,3.89,3.89,0,0,0,1.14-1.05l-.38.13c-.4.11-.8.21-1.19.34a.56.56,0,0,1-.63-.18,4,4,0,0,0-1.51-1,4,4,0,0,0-5.2,3.17,7.09,7.09,0,0,0,0,1.38c.05.45-.12.69-.57.63-.84-.11-1.67-.25-2.5-.39a.45.45,0,0,1-.42-.57c.06-.25.29-.36.63-.29l1.73.33h.17v-.57a4.8,4.8,0,0,1,3.76-4.66,4.66,4.66,0,0,1,4.2,1,.48.48,0,0,0,.51.12,8.48,8.48,0,0,0,1.9-.76l.25-.13a.42.42,0,0,1,.51,0,.39.39,0,0,1,.11.51c-.19.42-.41.83-.62,1.24a1.4,1.4,0,0,1-.16.23l.65-.25c.39-.15.51-.13.77.19Zm-9.51,12.33a10,10,0,0,0,2.14-1.68,7.2,7.2,0,0,0,.64-.71.42.42,0,0,0,0-.62.43.43,0,0,0-.61,0,1.1,1.1,0,0,0-.15.16,9.84,9.84,0,0,1-2.33,2,1.61,1.61,0,0,0-.3.21.4.4,0,0,0-.1.48.43.43,0,0,0,.46.26Zm-6.42-10.66a.44.44,0,1,0,0,.88.43.43,0,0,0,.43-.42A.47.47,0,0,0,411.89,296.55Zm9.8,6.27a.41.41,0,0,0-.43.42.45.45,0,0,0,.43.45.43.43,0,0,0,.42-.44A.41.41,0,0,0,421.69,302.82Z" transform="translate(-405.47 -292.27)" data-v-aba42310></path></svg><a href="https://twitter.com/sju_ksa" target="_blank" data-v-aba42310>sju_ksa</a></li><li class="flex gap-3 mb-3" data-v-aba42310><svg xmlns="http://www.w3.org/2000/svg" width="22.351" height="22.35" viewBox="0 0 22.351 22.35" data-v-aba42310><g id="call" transform="translate(-1 -1.018)" data-v-aba42310><g id="Group_54" data-name="Group 54" transform="translate(1 1.018)" data-v-aba42310><g id="Group_53" data-name="Group 53" transform="translate(0 0)" data-v-aba42310><path id="Path_67" data-name="Path 67" d="M22.765,18.26l-4.524-3.017a1.32,1.32,0,0,0-1.768.287l-1.318,1.694a.563.563,0,0,1-.722.152l-.251-.138a15.149,15.149,0,0,1-3.948-3.1,15.211,15.211,0,0,1-3.1-3.948L7,9.939a.564.564,0,0,1,.149-.725L8.838,7.9a1.321,1.321,0,0,0,.288-1.768L6.108,1.6a1.314,1.314,0,0,0-1.771-.4L2.446,2.342A2.669,2.669,0,0,0,1.229,3.921C.548,6.4,1.06,10.687,7.371,17c5.02,5.019,8.757,6.369,11.325,6.369a6.6,6.6,0,0,0,1.751-.229,2.666,2.666,0,0,0,1.579-1.217l1.138-1.891A1.314,1.314,0,0,0,22.765,18.26Zm-.244,1.389-1.135,1.892a1.925,1.925,0,0,1-1.136.881c-2.291.629-6.295.108-12.353-5.95S1.319,6.41,1.948,4.119a1.928,1.928,0,0,1,.882-1.138L4.721,1.846a.57.57,0,0,1,.768.173l1.639,2.46L8.5,6.543a.573.573,0,0,1-.124.767L6.686,8.627A1.3,1.3,0,0,0,6.341,10.3l.134.244A15.8,15.8,0,0,0,9.7,14.664a15.817,15.817,0,0,0,4.119,3.228l.245.135a1.3,1.3,0,0,0,1.673-.345l1.317-1.694a.574.574,0,0,1,.767-.124l4.524,3.017A.569.569,0,0,1,22.521,19.649Z" transform="translate(-1 -1.018)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_68" data-name="Path 68" d="M283,70.069a6.339,6.339,0,0,1,6.332,6.332.372.372,0,1,0,.745,0A7.085,7.085,0,0,0,283,69.324a.372.372,0,1,0,0,.745Z" transform="translate(-270.335 -66.343)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_69" data-name="Path 69" d="M283,121.269a4.1,4.1,0,0,1,4.1,4.1.372.372,0,0,0,.745,0A4.848,4.848,0,0,0,283,120.524a.372.372,0,1,0,0,.745Z" transform="translate(-270.335 -115.308)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_70" data-name="Path 70" d="M283,172.469a1.865,1.865,0,0,1,1.862,1.862.372.372,0,1,0,.745,0A2.61,2.61,0,0,0,283,171.724a.372.372,0,0,0,0,.745Z" transform="translate(-270.335 -164.273)" fill="#FFFFFF" data-v-aba42310></path></g></g></g></svg> 0114878555 \u2013 0114878855 </li><li class="flex gap-3 mb-3" data-v-aba42310><svg id="fax" xmlns="http://www.w3.org/2000/svg" width="22.351" height="22.351" viewBox="0 0 22.351 22.351" data-v-aba42310><path id="Path_71" data-name="Path 71" d="M22.023,13.778a.328.328,0,0,0,.328-.328v-7a1.642,1.642,0,0,0-1.64-1.64h-.263V.328A.328.328,0,0,0,20.12,0H9.423A.328.328,0,0,0,9.1.328V4.81H7.848V4.666a1.2,1.2,0,0,0-1.2-1.2H3.88a1.2,1.2,0,0,0-1.2,1.2V4.81H1.64A1.642,1.642,0,0,0,0,6.45v9.362a.328.328,0,1,0,.656,0V6.45a.985.985,0,0,1,.984-.984H2.677V20.348H1.64a.985.985,0,0,1-.984-.984V17.125a.328.328,0,1,0-.656,0v2.239A1.642,1.642,0,0,0,1.64,21H2.677v.144a1.2,1.2,0,0,0,1.2,1.2H6.645a1.2,1.2,0,0,0,1.2-1.2V21H20.711a1.642,1.642,0,0,0,1.64-1.64v-4.6a.328.328,0,1,0-.656,0v4.6a.985.985,0,0,1-.984.984H7.848V11.131a.328.328,0,0,0-.656,0V21.148a.547.547,0,0,1-.547.547H3.88a.547.547,0,0,1-.547-.547V4.666a.547.547,0,0,1,.547-.547H6.645a.547.547,0,0,1,.547.547V9.819a.328.328,0,1,0,.656,0V5.466H20.711a.985.985,0,0,1,.984.984v7a.328.328,0,0,0,.328.328ZM9.751.656H19.792V4.81H9.751Z" fill="#FFFFFF" data-v-aba42310></path><path id="Path_72" data-name="Path 72" d="M247.162,158.7v-1.932A.766.766,0,0,0,246.4,156H239.5a.766.766,0,0,0-.765.765V158.7a.766.766,0,0,0,.765.765H246.4A.766.766,0,0,0,247.162,158.7Zm-.656,0a.109.109,0,0,1-.109.109H239.5a.109.109,0,0,1-.109-.109v-1.932a.109.109,0,0,1,.109-.109H246.4a.109.109,0,0,1,.109.109Z" transform="translate(-228.316 -149.188)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_73" data-name="Path 73" d="M247.938,273.486h-1.274a.328.328,0,0,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-235.582 -261.547)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_74" data-name="Path 74" d="M314.72,273.528h-1.274a.328.328,0,0,0,0,.656h1.274a.328.328,0,1,0,0-.656Z" transform="translate(-299.449 -261.587)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_75" data-name="Path 75" d="M381.5,273.486h-1.274a.328.328,0,0,0,0,.656H381.5a.328.328,0,0,0,0-.656Z" transform="translate(-363.317 -261.547)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_76" data-name="Path 76" d="M247.938,315.609h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-235.582 -301.831)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_77" data-name="Path 77" d="M314.72,315.651h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-299.449 -301.871)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_78" data-name="Path 78" d="M381.5,315.609h-1.274a.328.328,0,1,0,0,.656H381.5a.328.328,0,1,0,0-.656Z" transform="translate(-363.317 -301.831)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_79" data-name="Path 79" d="M247.938,357.732h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-235.582 -342.115)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_80" data-name="Path 80" d="M314.72,357.773h-1.274a.328.328,0,0,0,0,.656h1.274a.328.328,0,1,0,0-.656Z" transform="translate(-299.449 -342.155)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_81" data-name="Path 81" d="M381.5,357.732h-1.274a.328.328,0,0,0,0,.656H381.5a.328.328,0,1,0,0-.656Z" transform="translate(-363.317 -342.115)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_82" data-name="Path 82" d="M247.938,399.854h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-235.582 -382.399)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_83" data-name="Path 83" d="M314.72,399.895h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,1,0,0-.656Z" transform="translate(-299.449 -382.438)" fill="#FFFFFF" data-v-aba42310></path><path id="Path_84" data-name="Path 84" d="M381.5,399.854h-1.274a.328.328,0,1,0,0,.656H381.5a.328.328,0,0,0,0-.656Z" transform="translate(-363.317 -382.399)" fill="#FFFFFF" data-v-aba42310></path></svg> 0114878444 </li></ul></div><div data-v-aba42310><h5 class="text-xl mb-3" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Our location"))}:</h5><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1023.7624475266713!2d46.631574088726786!3d24.794504080179525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ee39d45930e57%3A0xb06fc0fbbbe7d2f3!2z2YfZitim2Kkg2KfZhNi12K3ZgdmK2YrZhiDYp9mE2LPYudmI2K_ZitmK2YY!5e0!3m2!1sar!2ssa!4v1542227466291" frameborder="0" style="${ssrRenderStyle({ "border": "0" })}" class="w-full" data-v-aba42310></iframe></div><div data-v-aba42310><h5 class="text-xl mb-3" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Follow us"))}</h5><div class="mb-4" data-v-aba42310>`);
      _push(ssrRenderComponent(_component_nuxt_link, { class: "text-3xl mr-3 rtl:ml-3 rtl:mr-0" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(GgFacebook), { class: "inline" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(GgFacebook), { class: "inline" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "https://twitter.com/sju_ksa",
        target: "_blank",
        class: "text-3xl mr-3 rtl:ml-3 rtl:mr-0"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(MdiTwitter), { class: "inline" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(MdiTwitter), { class: "inline" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, { class: "text-3xl mr-3 rtl:ml-3 rtl:mr-0" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(MdiLinkedin), { class: "inline" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(MdiLinkedin), { class: "inline" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><a href="http://vision2030.gov.sa/" target="_blank" style="${ssrRenderStyle({ "padding": "0" })}" data-v-aba42310><img src="https://sju.org.sa/assets/themes/new/images/logo2030.svg" width="100" alt="" data-v-aba42310></a></div></div></div></footer><div class="bg-sju-500 py-2 text-gray-600 dark:bg-sjud-100 dark:text-gray-400" data-v-aba42310><div class="container" data-v-aba42310><div class="flex justify-between items-center" data-v-aba42310><div data-v-aba42310><ul class="flex gap-3 mb-1.5" data-v-aba42310><li class="text-xs" data-v-aba42310><a href="https://sju.org.sa/page-faq.html" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Terms of service"))}</a></li><li class="text-xs" data-v-aba42310><a href="https://sju.org.sa/sitemap.html" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Privacy policy"))}</a></li><li class="text-xs" data-v-aba42310><a href="https://sju.org.sa/contact-us.html" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Call us"))}</a></li></ul><span class="text-xs block mb-1.5" data-v-aba42310>${ssrInterpolate(_ctx.$translate("All rights reserved to Saudi Journalists Association"))}</span><div class="text-xs mb-1.5" data-v-aba42310>${ssrInterpolate(_ctx.$translate("Made with \u2764 by:"))} `);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "https://github.com/sh1r3f" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Sh1r3f`);
          } else {
            return [
              createTextVNode("Sh1r3f")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div data-v-aba42310><img src="https://sju.org.sa/assets/themes/new/images/logo.png"${ssrRenderAttr("alt", _ctx.$translate("All rights reserved to Saudi Journalists Association"))} class="max-h-20" data-v-aba42310></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/layout/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-aba42310"]]);
const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const { $i18n } = useNuxtApp();
    const loading = ref(true);
    const route = useRoute();
    const toast = useToast();
    if (((_a = route.query) == null ? void 0 : _a.verified) == 1) {
      toast.success($i18n.translate("Email has been verified successfully"));
    }
    const locale = $i18n.locale;
    const darkmode = useHomeStore().darkMode;
    useHead({
      titleTemplate: (title) => title ? `${title} - ${$i18n.translate("Saudi journalists association")}` : $i18n.translate("Saudi journalists association"),
      meta: [
        {
          name: "keywords",
          content: $i18n.translate("Saudi journalists association")
        },
        {
          name: "description",
          content: $i18n.translate("Saudi journalists association")
        }
      ],
      htmlAttrs: {
        dir: locale == "ar" ? "rtl" : "ltr",
        lang: locale
      },
      bodyAttrs: {
        class: `${locale == "ar" ? "rtl" : "ltr"} ${darkmode ? "dark" : ""} [&.dark]:bg-sjud-500`
      },
      meta: [
        {
          name: "author",
          content: "sju.org.sa"
        }
      ],
      link: [
        {
          rel: "shortcut icon",
          href: "/icons/favicon.ico",
          type: "image/x-icon"
        },
        {
          rel: "apple-touch-icon",
          href: "/icons/favicon.ico"
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_layout_loading = __nuxt_component_0;
      const _component_form_loading = __nuxt_component_1;
      const _component_NuxtLoadingIndicator = __nuxt_component_2;
      const _component_layout_minibar = _sfc_main$4;
      const _component_layout_header = _sfc_main$3;
      const _component_layout_navbar = _sfc_main$2;
      const _component_layout_footer = __nuxt_component_6;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_layout_loading, {
        style: loading.value ? null : { display: "none" }
      }, null, _parent));
      _push(ssrRenderComponent(_component_form_loading, {
        style: unref(useHomeStore)().loading ? null : { display: "none" }
      }, null, _parent));
      _push(ssrRenderComponent(_component_NuxtLoadingIndicator, null, null, _parent));
      _push(ssrRenderComponent(_component_layout_minibar, null, null, _parent));
      _push(ssrRenderComponent(_component_layout_header, null, null, _parent));
      _push(ssrRenderComponent(_component_layout_navbar, null, null, _parent));
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(ssrRenderComponent(_component_layout_footer, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default.eddf521c.mjs.map
