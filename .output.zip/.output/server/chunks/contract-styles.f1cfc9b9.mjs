const contract_vue_vue_type_style_index_0_lang = ".formkit-label{font-weight:400!important}";

const contractStyles_f1cfc9b9 = [contract_vue_vue_type_style_index_0_lang];

export { contractStyles_f1cfc9b9 as default };
//# sourceMappingURL=contract-styles.f1cfc9b9.mjs.map
