const index_vue_vue_type_style_index_0_scoped_85d17637_lang = ".twitter-green[data-v-85d17637]{fill:#007d41}";

const indexStyles_b02edbd7 = [index_vue_vue_type_style_index_0_scoped_85d17637_lang];

export { indexStyles_b02edbd7 as default };
//# sourceMappingURL=index-styles.b02edbd7.mjs.map
