const _id__vue_vue_type_style_index_0_lang = ".formkit-outer{margin-bottom:1px}[data-type=textarea] textarea{min-height:auto}";

const _id_Styles_fc0226ac = [_id__vue_vue_type_style_index_0_lang];

export { _id_Styles_fc0226ac as default };
//# sourceMappingURL=_id_-styles.fc0226ac.mjs.map
