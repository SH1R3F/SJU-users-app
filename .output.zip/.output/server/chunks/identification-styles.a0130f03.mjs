const identification_vue_vue_type_style_index_0_lang = ".formkit-label{font-weight:400!important}";

const identificationStyles_a0130f03 = [identification_vue_vue_type_style_index_0_lang];

export { identificationStyles_a0130f03 as default };
//# sourceMappingURL=identification-styles.a0130f03.mjs.map
