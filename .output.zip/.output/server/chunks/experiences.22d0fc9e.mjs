import { z as useMemberStore, e as useAuthStore, h as storeToRefs, u as useNuxtApp, a as useHead, B as _sfc_main$2, d as useToast } from './server.mjs';
import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { ref, resolveComponent, withCtx, unref, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, withModifiers, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "experiences",
  __ssrInlineRender: true,
  setup(__props) {
    const toast = useToast();
    const memberStore = useMemberStore();
    const authStore = useAuthStore();
    const { userData } = storeToRefs(authStore);
    const { levels } = useSiteConfig();
    const updateExperiences = async (body, node) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const { error } = await memberStore.updateExperiences(experiences.value, fields.value, languages.value);
      if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) === 400) {
        node.setErrors((_c = error.value) == null ? void 0 : _c.data);
      } else if (((_e = (_d = error == null ? void 0 : error.value) == null ? void 0 : _d.response) == null ? void 0 : _e.status) === 422) {
        toast.error((_g = (_f = error.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message);
      }
    };
    const experiences = ref(userData.value.experiences_and_fields.experiences);
    const addExperience = () => {
      var _a, _b;
      if (experiences.value.length === 0 || ((_a = experiences.value[experiences.value.length - 1]) == null ? void 0 : _a.name) != "" && ((_b = experiences.value[experiences.value.length - 1]) == null ? void 0 : _b.years) != null) {
        experiences.value.push({
          name: "",
          years: null
        });
      }
    };
    const removeExperience = (i) => {
      if (experiences.value.length > 1) {
        experiences.value.splice(i, 1);
      }
    };
    const fields = ref(userData.value.experiences_and_fields.fields);
    const addField = () => {
      var _a;
      if (((_a = fields.value[fields.value.length - 1]) == null ? void 0 : _a.name) != "") {
        fields.value.push({
          name: ""
        });
      }
    };
    const removeField = (i) => {
      if (fields.value.length > 1) {
        fields.value.splice(i, 1);
      }
    };
    const languages = ref(userData.value.experiences_and_fields.languages);
    const addLanguage = () => {
      var _a, _b;
      if (languages.value.length === 0 || ((_a = languages.value[languages.value.length - 1]) == null ? void 0 : _a.name) != "" && ((_b = languages.value[languages.value.length - 1]) == null ? void 0 : _b.level) != null) {
        languages.value.push({
          name: "",
          level: null
        });
      }
    };
    const removeLanguage = (i) => {
      if (languages.value.length > 1) {
        languages.value.splice(i, 1);
      }
    };
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Edit profile");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_members_profile_nav = _sfc_main$2;
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_members_profile_nav, { active: "experiences" }, null, _parent));
      _push(`<div class="form"><div class="form-title font-semibold">${ssrInterpolate(_ctx.$translate("Experiences"))}</div>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: updateExperiences
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<table class="w-full text-sm text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId}>${ssrInterpolate(_ctx.$translate("Experiences"))}</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId}>${ssrInterpolate(_ctx.$translate("Years"))}</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId}></th></tr></thead><tbody class="text-start"${_scopeId}><!--[-->`);
            ssrRenderList(experiences.value, (experience, i) => {
              _push2(`<tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId}><td class="py-2 px-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "text",
                placeholder: _ctx.$translate("Experiences"),
                "validation-label": _ctx.$translate("Experiences"),
                validation: "required:trim",
                classes: {
                  outer: {
                    "formkit-outer": false,
                    "w-full": true
                  },
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full": true
                  }
                },
                modelValue: experience.name,
                "onUpdate:modelValue": ($event) => experience.name = $event
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="py-2 px-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "text",
                placeholder: _ctx.$translate("Years"),
                "validation-label": _ctx.$translate("Years"),
                validation: "required",
                classes: {
                  outer: {
                    "formkit-outer": false
                  },
                  wrapper: {
                    "formkit-wrapper": false,
                    "max-w-[100px] mx-auto": true
                  }
                },
                modelValue: experience.years,
                "onUpdate:modelValue": ($event) => experience.years = $event
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="py-2 px-6 font-bold cursor-pointer"${_scopeId}>X</td></tr>`);
            });
            _push2(`<!--]--></tbody></table><div class="text-end"${_scopeId}><button class="btn"${_scopeId}>${ssrInterpolate(_ctx.$translate("Add"))}</button></div><div class="form-title font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$translate("Fields you want to contribute to"))}</div><table class="w-full text-sm text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId}>${ssrInterpolate(_ctx.$translate("Fields"))}</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId}></th></tr></thead><tbody class="text-start"${_scopeId}><!--[-->`);
            ssrRenderList(fields.value, (field, i) => {
              _push2(`<tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId}><td class="py-2 px-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "text",
                placeholder: _ctx.$translate("Experiences"),
                "validation-label": _ctx.$translate("Experiences"),
                validation: "required:trim",
                classes: {
                  outer: {
                    "formkit-outer": false,
                    "w-full": true
                  },
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full": true
                  }
                },
                modelValue: field.name,
                "onUpdate:modelValue": ($event) => field.name = $event
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="py-2 px-6 font-bold cursor-pointer"${_scopeId}>X</td></tr>`);
            });
            _push2(`<!--]--></tbody></table><div class="text-end"${_scopeId}><button class="btn"${_scopeId}>${ssrInterpolate(_ctx.$translate("Add"))}</button></div><div class="form-title font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$translate("Languages you good at"))}</div><table class="w-full text-sm text-gray-500 dark:text-gray-400"${_scopeId}><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId}>${ssrInterpolate(_ctx.$translate("Languages"))}</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId}>${ssrInterpolate(_ctx.$translate("Level"))}</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"${_scopeId}></th></tr></thead><tbody class="text-start"${_scopeId}><!--[-->`);
            ssrRenderList(languages.value, (language, i) => {
              _push2(`<tr class="border-b border-gray-200 dark:border-gray-700"${_scopeId}><td class="py-2 px-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "text",
                placeholder: _ctx.$translate("Experiences"),
                "validation-label": _ctx.$translate("Experiences"),
                validation: "required:trim",
                classes: {
                  outer: {
                    "formkit-outer": false,
                    "w-full": true
                  },
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full": true
                  }
                },
                modelValue: language.name,
                "onUpdate:modelValue": ($event) => language.name = $event
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="py-2 px-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "select",
                classes: {
                  outer: {
                    "formkit-outer": false
                  },
                  wrapper: {
                    "formkit-wrapper": false,
                    "max-w-[100px] mx-auto": true
                  }
                },
                "sections-schema": {
                  selectIcon: { $el: null }
                },
                options: unref(levels),
                name: "level",
                "validation-label": _ctx.$translate("Years"),
                validation: "required",
                modelValue: language.level,
                "onUpdate:modelValue": ($event) => language.level = $event
              }, null, _parent2, _scopeId));
              _push2(`</td><td class="py-2 px-6 font-bold cursor-pointer"${_scopeId}>X</td></tr>`);
            });
            _push2(`<!--]--></tbody></table><div class="text-end"${_scopeId}><button class="btn"${_scopeId}>${ssrInterpolate(_ctx.$translate("Add"))}</button></div><div class="text-end mt-10"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Save"))}</button></div>`);
          } else {
            return [
              createVNode("table", { class: "w-full text-sm text-gray-500 dark:text-gray-400" }, [
                createVNode("thead", { class: "text-xs text-gray-700 uppercase dark:text-gray-400" }, [
                  createVNode("tr", null, [
                    createVNode("th", {
                      scope: "col",
                      class: "py-3 px-6 bg-gray-50 dark:bg-gray-800"
                    }, toDisplayString(_ctx.$translate("Experiences")), 1),
                    createVNode("th", {
                      scope: "col",
                      class: "py-3 px-6 bg-gray-50 dark:bg-gray-800"
                    }, toDisplayString(_ctx.$translate("Years")), 1),
                    createVNode("th", {
                      scope: "col",
                      class: "py-3 px-6 bg-gray-50 dark:bg-gray-800"
                    })
                  ])
                ]),
                createVNode("tbody", { class: "text-start" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(experiences.value, (experience, i) => {
                    return openBlock(), createBlock("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                      createVNode("td", { class: "py-2 px-6" }, [
                        createVNode(_component_FormKit, {
                          type: "text",
                          placeholder: _ctx.$translate("Experiences"),
                          "validation-label": _ctx.$translate("Experiences"),
                          validation: "required:trim",
                          classes: {
                            outer: {
                              "formkit-outer": false,
                              "w-full": true
                            },
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full": true
                            }
                          },
                          modelValue: experience.name,
                          "onUpdate:modelValue": ($event) => experience.name = $event
                        }, null, 8, ["placeholder", "validation-label", "modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "py-2 px-6" }, [
                        createVNode(_component_FormKit, {
                          type: "text",
                          placeholder: _ctx.$translate("Years"),
                          "validation-label": _ctx.$translate("Years"),
                          validation: "required",
                          classes: {
                            outer: {
                              "formkit-outer": false
                            },
                            wrapper: {
                              "formkit-wrapper": false,
                              "max-w-[100px] mx-auto": true
                            }
                          },
                          modelValue: experience.years,
                          "onUpdate:modelValue": ($event) => experience.years = $event
                        }, null, 8, ["placeholder", "validation-label", "modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", {
                        class: "py-2 px-6 font-bold cursor-pointer",
                        onClick: ($event) => removeExperience(i)
                      }, "X", 8, ["onClick"])
                    ]);
                  }), 256))
                ])
              ]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  class: "btn",
                  onClick: withModifiers(addExperience, ["prevent"])
                }, toDisplayString(_ctx.$translate("Add")), 9, ["onClick"])
              ]),
              createVNode("div", { class: "form-title font-semibold" }, toDisplayString(_ctx.$translate("Fields you want to contribute to")), 1),
              createVNode("table", { class: "w-full text-sm text-gray-500 dark:text-gray-400" }, [
                createVNode("thead", { class: "text-xs text-gray-700 uppercase dark:text-gray-400" }, [
                  createVNode("tr", null, [
                    createVNode("th", {
                      scope: "col",
                      class: "py-3 px-6 bg-gray-50 dark:bg-gray-800"
                    }, toDisplayString(_ctx.$translate("Fields")), 1),
                    createVNode("th", {
                      scope: "col",
                      class: "py-3 px-6 bg-gray-50 dark:bg-gray-800"
                    })
                  ])
                ]),
                createVNode("tbody", { class: "text-start" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(fields.value, (field, i) => {
                    return openBlock(), createBlock("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                      createVNode("td", { class: "py-2 px-6" }, [
                        createVNode(_component_FormKit, {
                          type: "text",
                          placeholder: _ctx.$translate("Experiences"),
                          "validation-label": _ctx.$translate("Experiences"),
                          validation: "required:trim",
                          classes: {
                            outer: {
                              "formkit-outer": false,
                              "w-full": true
                            },
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full": true
                            }
                          },
                          modelValue: field.name,
                          "onUpdate:modelValue": ($event) => field.name = $event
                        }, null, 8, ["placeholder", "validation-label", "modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", {
                        class: "py-2 px-6 font-bold cursor-pointer",
                        onClick: ($event) => removeField(i)
                      }, "X", 8, ["onClick"])
                    ]);
                  }), 256))
                ])
              ]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  class: "btn",
                  onClick: withModifiers(addField, ["prevent"])
                }, toDisplayString(_ctx.$translate("Add")), 9, ["onClick"])
              ]),
              createVNode("div", { class: "form-title font-semibold" }, toDisplayString(_ctx.$translate("Languages you good at")), 1),
              createVNode("table", { class: "w-full text-sm text-gray-500 dark:text-gray-400" }, [
                createVNode("thead", { class: "text-xs text-gray-700 uppercase dark:text-gray-400" }, [
                  createVNode("tr", null, [
                    createVNode("th", {
                      scope: "col",
                      class: "py-3 px-6 bg-gray-50 dark:bg-gray-800"
                    }, toDisplayString(_ctx.$translate("Languages")), 1),
                    createVNode("th", {
                      scope: "col",
                      class: "py-3 px-6 bg-gray-50 dark:bg-gray-800"
                    }, toDisplayString(_ctx.$translate("Level")), 1),
                    createVNode("th", {
                      scope: "col",
                      class: "py-3 px-6 bg-gray-50 dark:bg-gray-800"
                    })
                  ])
                ]),
                createVNode("tbody", { class: "text-start" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(languages.value, (language, i) => {
                    return openBlock(), createBlock("tr", { class: "border-b border-gray-200 dark:border-gray-700" }, [
                      createVNode("td", { class: "py-2 px-6" }, [
                        createVNode(_component_FormKit, {
                          type: "text",
                          placeholder: _ctx.$translate("Experiences"),
                          "validation-label": _ctx.$translate("Experiences"),
                          validation: "required:trim",
                          classes: {
                            outer: {
                              "formkit-outer": false,
                              "w-full": true
                            },
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full": true
                            }
                          },
                          modelValue: language.name,
                          "onUpdate:modelValue": ($event) => language.name = $event
                        }, null, 8, ["placeholder", "validation-label", "modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", { class: "py-2 px-6" }, [
                        createVNode(_component_FormKit, {
                          type: "select",
                          classes: {
                            outer: {
                              "formkit-outer": false
                            },
                            wrapper: {
                              "formkit-wrapper": false,
                              "max-w-[100px] mx-auto": true
                            }
                          },
                          "sections-schema": {
                            selectIcon: { $el: null }
                          },
                          options: unref(levels),
                          name: "level",
                          "validation-label": _ctx.$translate("Years"),
                          validation: "required",
                          modelValue: language.level,
                          "onUpdate:modelValue": ($event) => language.level = $event
                        }, null, 8, ["options", "validation-label", "modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("td", {
                        class: "py-2 px-6 font-bold cursor-pointer",
                        onClick: ($event) => removeLanguage(i)
                      }, "X", 8, ["onClick"])
                    ]);
                  }), 256))
                ])
              ]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  class: "btn",
                  onClick: withModifiers(addLanguage, ["prevent"])
                }, toDisplayString(_ctx.$translate("Add")), 9, ["onClick"])
              ]),
              createVNode("div", { class: "text-end mt-10" }, [
                createVNode("button", {
                  type: "submit",
                  class: "btn-primary"
                }, toDisplayString(_ctx.$translate("Save")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/dashboard/profile/experiences.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=experiences.22d0fc9e.mjs.map
