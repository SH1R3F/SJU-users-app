import { f as useLocalization, b as useEventStore, g as useRoute, h as storeToRefs, k as __nuxt_component_0$1 } from './server.mjs';
import { withAsyncContext, ref, resolveComponent, unref, withCtx, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, withDirectives, withModifiers, vShow, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrRenderStyle } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "[questionnaireId]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { dblocalize } = useLocalization();
    const eventStore = useEventStore();
    const route = useRoute();
    const { eventId, questionnaireId } = route.params;
    [__temp, __restore] = withAsyncContext(() => eventStore.getQuestionnaire(eventId, questionnaireId)), await __temp, __restore();
    const { questionnaire, questions } = storeToRefs(eventStore);
    const steps = questions.value.map((q) => `question-${q.id}`);
    const step = ref(steps[0]);
    const questionnaireData = ref({});
    const submitQuestion = async (i) => {
      if (steps[i + 1]) {
        step.value = steps[i + 1];
      } else {
        await eventStore.submitQuestionnaire(eventId, questionnaireId, questionnaireData.value);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      if (unref(questionnaire).id) {
        _push(`<div class="bg-blue-50 border-l-4 rtl:border-l-0 rtl:border-r-4 border-blue-400 text-blue-600 p-4 mb-3" role="alert"><p>${ssrInterpolate(_ctx.$translate("Fill the survey first"))}.</p></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(questionnaire).id) {
        _push(`<div class="card"><h4 class="card-title">${ssrInterpolate(unref(dblocalize)(unref(questionnaire), "name"))}</h4>`);
        _push(ssrRenderComponent(_component_FormKit, {
          type: "form",
          actions: false,
          modelValue: questionnaireData.value,
          "onUpdate:modelValue": ($event) => questionnaireData.value = $event
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<!--[-->`);
              ssrRenderList(unref(questions), (question, i) => {
                _push2(`<section style="${ssrRenderStyle(step.value == `question-${question.id}` ? null : { display: "none" })}"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_FormKit, {
                  type: "group",
                  id: `question-${question.id}`,
                  name: `question-${question.id}`
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<h5 class="mb-2"${_scopeId2}>${ssrInterpolate(question.question)}</h5>`);
                      if (question.type == 1) {
                        _push3(`<div${_scopeId2}>`);
                        _push3(ssrRenderComponent(_component_FormKit, {
                          type: "radio",
                          options: [
                            {
                              value: 1,
                              label: question.answer1
                            },
                            {
                              value: 2,
                              label: question.answer2
                            },
                            {
                              value: 3,
                              label: question.answer3
                            },
                            {
                              value: 4,
                              label: question.answer4
                            }
                          ],
                          classes: {
                            fieldset: {
                              "formkit-fieldset": false,
                              "w-full": true
                            },
                            wrapper: `border-2 border-gray-200 p-2`,
                            inner: "mx-3"
                          }
                        }, null, _parent3, _scopeId2));
                        _push3(`</div>`);
                      } else {
                        _push3(`<div${_scopeId2}>`);
                        _push3(ssrRenderComponent(_component_FormKit, {
                          type: "textarea",
                          validation: "required",
                          classes: {
                            wrapper: {
                              "formkit-wrapper": false,
                              "w-full": true
                            }
                          }
                        }, null, _parent3, _scopeId2));
                        _push3(`</div>`);
                      }
                    } else {
                      return [
                        createVNode("h5", { class: "mb-2" }, toDisplayString(question.question), 1),
                        question.type == 1 ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode(_component_FormKit, {
                            type: "radio",
                            options: [
                              {
                                value: 1,
                                label: question.answer1
                              },
                              {
                                value: 2,
                                label: question.answer2
                              },
                              {
                                value: 3,
                                label: question.answer3
                              },
                              {
                                value: 4,
                                label: question.answer4
                              }
                            ],
                            classes: {
                              fieldset: {
                                "formkit-fieldset": false,
                                "w-full": true
                              },
                              wrapper: `border-2 border-gray-200 p-2`,
                              inner: "mx-3"
                            }
                          }, null, 8, ["options"])
                        ])) : (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode(_component_FormKit, {
                            type: "textarea",
                            validation: "required",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              }
                            }
                          })
                        ]))
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`<div class="text-end"${_scopeId}><button class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Next"))}</button></div></section>`);
              });
              _push2(`<!--]-->`);
            } else {
              return [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(questions), (question, i) => {
                  return withDirectives((openBlock(), createBlock("section", null, [
                    createVNode(_component_FormKit, {
                      type: "group",
                      id: `question-${question.id}`,
                      name: `question-${question.id}`
                    }, {
                      default: withCtx(() => [
                        createVNode("h5", { class: "mb-2" }, toDisplayString(question.question), 1),
                        question.type == 1 ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode(_component_FormKit, {
                            type: "radio",
                            options: [
                              {
                                value: 1,
                                label: question.answer1
                              },
                              {
                                value: 2,
                                label: question.answer2
                              },
                              {
                                value: 3,
                                label: question.answer3
                              },
                              {
                                value: 4,
                                label: question.answer4
                              }
                            ],
                            classes: {
                              fieldset: {
                                "formkit-fieldset": false,
                                "w-full": true
                              },
                              wrapper: `border-2 border-gray-200 p-2`,
                              inner: "mx-3"
                            }
                          }, null, 8, ["options"])
                        ])) : (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode(_component_FormKit, {
                            type: "textarea",
                            validation: "required",
                            classes: {
                              wrapper: {
                                "formkit-wrapper": false,
                                "w-full": true
                              }
                            }
                          })
                        ]))
                      ]),
                      _: 2
                    }, 1032, ["id", "name"]),
                    createVNode("div", { class: "text-end" }, [
                      createVNode("button", {
                        class: "btn-primary",
                        onClick: withModifiers(($event) => submitQuestion(i), ["prevent"])
                      }, toDisplayString(_ctx.$translate("Next")), 9, ["onClick"])
                    ])
                  ], 512)), [
                    [vShow, step.value == `question-${question.id}`]
                  ]);
                }), 256))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<div class="card text-center">`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          class: "btn-primary",
          to: "/volunteers/dashboard"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Back to events"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Back to events")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/volunteers/dashboard/questionnaire/[eventId]/[questionnaireId].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_questionnaireId_.590cf3e4.mjs.map
