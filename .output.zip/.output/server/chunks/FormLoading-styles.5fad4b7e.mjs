const FormLoading_vue_vue_type_style_index_0_lang = '.form-loading{bottom:0;height:2em;left:0;margin:auto;overflow:visible;position:fixed;right:0;top:0;width:2em;z-index:999}.form-loading:before{background-color:rgba(0,0,0,.3);content:"";display:block;height:100%;left:0;position:fixed;top:0;width:100%}.form-loading:not(:required){background-color:transparent;border:0;color:transparent;font:0/0 a;text-shadow:none}.form-loading:not(:required):after{animation:spinner 1.5s linear infinite;border-radius:.5em;box-shadow:1.5em 0 0 0 rgba(0,0,0,.75),1.1em 1.1em 0 0 rgba(0,0,0,.75),0 1.5em 0 0 rgba(0,0,0,.75),-1.1em 1.1em 0 0 rgba(0,0,0,.75),-1.5em 0 0 0 rgba(0,0,0,.75),-1.1em -1.1em 0 0 rgba(0,0,0,.75),0 -1.5em 0 0 rgba(0,0,0,.75),1.1em -1.1em 0 0 rgba(0,0,0,.75);content:"";display:block;font-size:10px;height:1em;margin-top:-.5em;width:1em}@keyframes spinner{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}';

const FormLoadingStyles_5fad4b7e = [FormLoading_vue_vue_type_style_index_0_lang];

export { FormLoadingStyles_5fad4b7e as default };
//# sourceMappingURL=FormLoading-styles.5fad4b7e.mjs.map
