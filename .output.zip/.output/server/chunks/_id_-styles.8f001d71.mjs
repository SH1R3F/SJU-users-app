const _id__vue_vue_type_style_index_0_lang = ".formkit-outer{margin-bottom:1px}[data-type=textarea] textarea{min-height:auto}";

const _id_Styles_8f001d71 = [_id__vue_vue_type_style_index_0_lang];

export { _id_Styles_8f001d71 as default };
//# sourceMappingURL=_id_-styles.8f001d71.mjs.map
