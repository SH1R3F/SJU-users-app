const experiences_vue_vue_type_style_index_0_lang = ".formkit-label{font-weight:400!important}";

const experiencesStyles_54bba59c = [experiences_vue_vue_type_style_index_0_lang];

export { experiencesStyles_54bba59c as default };
//# sourceMappingURL=experiences-styles.54bba59c.mjs.map
