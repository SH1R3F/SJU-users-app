import { ref, resolveComponent, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useNuxtApp, e as useAuthStore, a as useHead } from './server.mjs';
import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "register",
  __ssrInlineRender: true,
  setup(__props) {
    const { $i18n } = useNuxtApp();
    const { genders, countries, nationalities, cities, branches, qualifications, howKnewUs, mobileCodes } = useSiteConfig();
    const volunteerData = ref({});
    const authStore = useAuthStore();
    const createVolunteer = async (volunteer, node) => {
      var _a, _b, _c, _d;
      const body = new FormData();
      Object.keys(volunteer).forEach((key) => {
        let value = volunteer[key];
        body.append(key, value);
      });
      body.append("image", ((_a = volunteer.image[0]) == null ? void 0 : _a.file) || "");
      const { error } = await authStore.registerVolunteer(body);
      if (((_c = (_b = error == null ? void 0 : error.value) == null ? void 0 : _b.response) == null ? void 0 : _c.status) === 400) {
        node.setErrors((_d = error.value) == null ? void 0 : _d.data);
      }
    };
    const title = $i18n.translate("Register new volunteer");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "my-20" }, _attrs))}><div class="container"><div class="form"><h5 class="form-title">${ssrInterpolate(unref(title))}</h5>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: createVolunteer,
        modelValue: volunteerData.value,
        "onUpdate:modelValue": ($event) => volunteerData.value = $event,
        enctype: "multipart/form-data"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "file",
              name: "image",
              label: _ctx.$translate("Profile picture"),
              accept: "image/*",
              classes: {
                input: "block px-3 w-full",
                outer: "mb-5",
                wrapper: {
                  "formkit-wrapper": false
                }
              }
            }, null, _parent2, _scopeId));
            _push2(`<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: `${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`,
              type: "text",
              name: "fname_ar",
              id: "fname_ar",
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              placeholder: _ctx.$translate("fname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("fname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: `${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`,
              type: "text",
              name: "sname_ar",
              id: "sname_ar",
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              placeholder: _ctx.$translate("sname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("sname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: `${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`,
              type: "text",
              name: "tname_ar",
              id: "tname_ar",
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              placeholder: _ctx.$translate("tname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("tname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: `${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`,
              type: "text",
              name: "lname_ar",
              id: "lname_ar",
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              placeholder: _ctx.$translate("lname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("lname")
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              type: "text",
              label: `${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`,
              name: "fname_en",
              id: "fname_en",
              placeholder: _ctx.$translate("fname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("fname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              type: "text",
              label: `${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`,
              name: "sname_en",
              id: "sname_en",
              placeholder: _ctx.$translate("sname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("sname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              type: "text",
              label: `${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`,
              name: "tname_en",
              id: "tname_en",
              placeholder: _ctx.$translate("tname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("tname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              type: "text",
              label: `${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`,
              name: "lname_en",
              id: "lname_en",
              placeholder: _ctx.$translate("lname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("lname")
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              "outer-class": "mb-3",
              type: "myRadio",
              name: "gender",
              label: _ctx.$translate("Gender"),
              options: unref(genders),
              "validation-label": _ctx.$translate("Gender"),
              validation: "required",
              classes: {
                options: "flex items-center",
                option: {
                  "formkit-option": false
                },
                inner: "m-3"
              }
            }, null, _parent2, _scopeId));
            _push2(`<div class="${ssrRenderClass([{
              "md:grid-cols-4": volunteerData.value.country === 0,
              "md:grid-cols-3": volunteerData.value.country !== 0
            }, "grid grid-cols-1 gap-2 md:gap-4"])}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Country"),
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              options: unref(countries),
              name: "country",
              "validation-label": _ctx.$translate("Country"),
              validation: "required",
              "outer-class": "mb-3"
            }, null, _parent2, _scopeId));
            if (volunteerData.value.country === 0) {
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("City"),
                type: "select",
                "sections-schema": {
                  selectIcon: { $el: null }
                },
                options: unref(cities),
                name: "city",
                "validation-label": _ctx.$translate("City"),
                validation: "required",
                "outer-class": "mb-3"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Nationality"),
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              "outer-class": "mb-3",
              options: unref(nationalities),
              name: "nationality",
              "validation-label": _ctx.$translate("Nationality"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Qualification"),
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              "outer-class": "mb-3",
              options: unref(qualifications),
              name: "qualification",
              "validation-label": _ctx.$translate("Qualification"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("National ID"),
              "outer-class": "mb-3",
              type: "number",
              placeholder: _ctx.$translate("National ID"),
              name: "national_id",
              "validation-label": _ctx.$translate("National ID"),
              validation: "required:trim|number|length:10"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Martial status"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Martial status"),
              name: "marital_status",
              "validation-label": _ctx.$translate("Martial status"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Adminstrative area"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Adminstrative area"),
              name: "adminstrative_area",
              "validation-label": _ctx.$translate("Adminstrative area"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Governorate"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Governorate"),
              name: "governorate",
              "validation-label": _ctx.$translate("Governorate"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("National address"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("National address"),
              name: "national_address",
              id: "national_address",
              "validation-label": _ctx.$translate("National address"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Job title"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Job title"),
              name: "job_title",
              "validation-label": _ctx.$translate("Job title"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Address"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Address"),
              name: "address",
              "validation-label": _ctx.$translate("Address"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                outer: "my-4",
                options: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4",
                option: {
                  "formkit-option": false
                },
                fieldset: { "formkit-fieldset": false },
                wrapper: "flex justify-between items-center p-2 border-l border-b"
              },
              name: "fields",
              type: "checkbox",
              label: _ctx.$translate("Volunteering fields"),
              options: [
                {
                  label: _ctx.$translate("Photography"),
                  value: 1
                },
                {
                  label: _ctx.$translate("Videography"),
                  value: 2
                },
                {
                  label: _ctx.$translate("Cinematography"),
                  value: 3
                },
                {
                  label: _ctx.$translate("Editing - Media Platforms - Documentation"),
                  value: 4
                },
                {
                  label: _ctx.$translate("Coverings"),
                  value: 5
                },
                {
                  label: _ctx.$translate("Presentation"),
                  value: 6
                },
                {
                  label: _ctx.$translate("Digital content industry"),
                  value: 7
                },
                {
                  label: _ctx.$translate("Montage"),
                  value: 8
                },
                {
                  label: _ctx.$translate("Social media"),
                  value: 9
                },
                {
                  label: _ctx.$translate("Media marketing"),
                  value: 10
                },
                {
                  label: _ctx.$translate("Editorial management"),
                  value: 11
                },
                {
                  label: _ctx.$translate("Field Editorial Leadership"),
                  value: 12
                },
                {
                  label: _ctx.$translate("Management of meetings and seminars"),
                  value: 13
                },
                {
                  label: _ctx.$translate("Media training"),
                  value: 14
                }
              ],
              "validation-label": _ctx.$translate("Volunteering fields"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(`<div class="row-of-two"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Educational level"),
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              type: "text",
              placeholder: _ctx.$translate("Educational level"),
              name: "education",
              "validation-label": _ctx.$translate("Educational level"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "text",
              placeholder: _ctx.$translate("Volunteering experiences"),
              name: "experiences",
              label: _ctx.$translate("Volunteering experiences"),
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              "validation-label": _ctx.$translate("Volunteering experiences"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="row-of-two"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Branch"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              options: unref(branches),
              name: "branch",
              "validation-label": _ctx.$translate("Branch"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("How do you know the authority?"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              options: unref(howKnewUs),
              name: "hearabout",
              "validation-label": _ctx.$translate("How do you know the authority?"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="row-of-two"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Email"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "email",
              placeholder: _ctx.$translate("Email"),
              id: "email",
              name: "email",
              "validation-label": _ctx.$translate("Email"),
              validation: "required:trim|email"
            }, null, _parent2, _scopeId));
            _push2(`<div class="formkit-outer mb-3" data-family="text"${_scopeId}><label for="mobile" class="formkit-label"${_scopeId}>${ssrInterpolate(_ctx.$translate("Mobile"))}</label><div class="input-group [&amp;&gt;.formkit-outer]:mb-0 h-9" style="${ssrRenderStyle({ "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" })}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "myTextInput",
              "outer-class": "w-full border border-y-0 m-0",
              id: "mobile",
              name: "mobile",
              placeholder: _ctx.$translate("Mobile"),
              validation: "required:trim|number",
              "validation-label": _ctx.$translate("Mobile")
            }, null, _parent2, _scopeId));
            _push2(`<span class="prepend"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "mySelect",
              name: "mobile_key",
              options: unref(mobileCodes),
              style: { "box-shadow": "none" }
            }, null, _parent2, _scopeId));
            _push2(`</span></div></div></div><div class="row-of-two"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Password"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("Password"),
              id: "password",
              name: "password",
              "validation-label": _ctx.$translate("Password"),
              validation: "required:trim|length:6"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Password confirmation"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("Password confirmation"),
              id: "password_confirm",
              name: "password_confirm",
              "validation-label": _ctx.$translate("Password confirmation"),
              validation: "required:trim|confirm"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mb-7"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "checkbox",
              label: _ctx.$translate("TermsAcceptance"),
              "validation-label": _ctx.$translate("acceptance"),
              validation: "required|accepted",
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full flex items-center": true
                },
                inner: "mx-3"
              }
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Register"))}</button></div>`);
          } else {
            return [
              createVNode(_component_FormKit, {
                type: "file",
                name: "image",
                label: _ctx.$translate("Profile picture"),
                accept: "image/*",
                classes: {
                  input: "block px-3 w-full",
                  outer: "mb-5",
                  wrapper: {
                    "formkit-wrapper": false
                  }
                }
              }, null, 8, ["label"]),
              createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                createVNode(_component_FormKit, {
                  label: `${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`,
                  type: "text",
                  name: "fname_ar",
                  id: "fname_ar",
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  placeholder: _ctx.$translate("fname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("fname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: `${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`,
                  type: "text",
                  name: "sname_ar",
                  id: "sname_ar",
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  placeholder: _ctx.$translate("sname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("sname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: `${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`,
                  type: "text",
                  name: "tname_ar",
                  id: "tname_ar",
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  placeholder: _ctx.$translate("tname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("tname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: `${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`,
                  type: "text",
                  name: "lname_ar",
                  id: "lname_ar",
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  placeholder: _ctx.$translate("lname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("lname")
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                createVNode(_component_FormKit, {
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  type: "text",
                  label: `${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`,
                  name: "fname_en",
                  id: "fname_en",
                  placeholder: _ctx.$translate("fname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("fname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  type: "text",
                  label: `${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`,
                  name: "sname_en",
                  id: "sname_en",
                  placeholder: _ctx.$translate("sname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("sname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  type: "text",
                  label: `${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`,
                  name: "tname_en",
                  id: "tname_en",
                  placeholder: _ctx.$translate("tname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("tname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  type: "text",
                  label: `${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`,
                  name: "lname_en",
                  id: "lname_en",
                  placeholder: _ctx.$translate("lname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("lname")
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode(_component_FormKit, {
                "outer-class": "mb-3",
                type: "myRadio",
                name: "gender",
                label: _ctx.$translate("Gender"),
                options: unref(genders),
                "validation-label": _ctx.$translate("Gender"),
                validation: "required",
                classes: {
                  options: "flex items-center",
                  option: {
                    "formkit-option": false
                  },
                  inner: "m-3"
                }
              }, null, 8, ["label", "options", "validation-label"]),
              createVNode("div", {
                class: ["grid grid-cols-1 gap-2 md:gap-4", {
                  "md:grid-cols-4": volunteerData.value.country === 0,
                  "md:grid-cols-3": volunteerData.value.country !== 0
                }]
              }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Country"),
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(countries),
                  name: "country",
                  "validation-label": _ctx.$translate("Country"),
                  validation: "required",
                  "outer-class": "mb-3"
                }, null, 8, ["label", "options", "validation-label"]),
                volunteerData.value.country === 0 ? (openBlock(), createBlock(_component_FormKit, {
                  key: 0,
                  label: _ctx.$translate("City"),
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(cities),
                  name: "city",
                  "validation-label": _ctx.$translate("City"),
                  validation: "required",
                  "outer-class": "mb-3"
                }, null, 8, ["label", "options", "validation-label"])) : createCommentVNode("", true),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Nationality"),
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  "outer-class": "mb-3",
                  options: unref(nationalities),
                  name: "nationality",
                  "validation-label": _ctx.$translate("Nationality"),
                  validation: "required"
                }, null, 8, ["label", "options", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Qualification"),
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  "outer-class": "mb-3",
                  options: unref(qualifications),
                  name: "qualification",
                  "validation-label": _ctx.$translate("Qualification"),
                  validation: "required"
                }, null, 8, ["label", "options", "validation-label"])
              ], 2),
              createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("National ID"),
                  "outer-class": "mb-3",
                  type: "number",
                  placeholder: _ctx.$translate("National ID"),
                  name: "national_id",
                  "validation-label": _ctx.$translate("National ID"),
                  validation: "required:trim|number|length:10"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Martial status"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Martial status"),
                  name: "marital_status",
                  "validation-label": _ctx.$translate("Martial status"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Adminstrative area"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Adminstrative area"),
                  name: "adminstrative_area",
                  "validation-label": _ctx.$translate("Adminstrative area"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Governorate"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Governorate"),
                  name: "governorate",
                  "validation-label": _ctx.$translate("Governorate"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("National address"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("National address"),
                  name: "national_address",
                  id: "national_address",
                  "validation-label": _ctx.$translate("National address"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Job title"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Job title"),
                  name: "job_title",
                  "validation-label": _ctx.$translate("Job title"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Address"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Address"),
                  name: "address",
                  "validation-label": _ctx.$translate("Address"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode(_component_FormKit, {
                classes: {
                  outer: "my-4",
                  options: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4",
                  option: {
                    "formkit-option": false
                  },
                  fieldset: { "formkit-fieldset": false },
                  wrapper: "flex justify-between items-center p-2 border-l border-b"
                },
                name: "fields",
                type: "checkbox",
                label: _ctx.$translate("Volunteering fields"),
                options: [
                  {
                    label: _ctx.$translate("Photography"),
                    value: 1
                  },
                  {
                    label: _ctx.$translate("Videography"),
                    value: 2
                  },
                  {
                    label: _ctx.$translate("Cinematography"),
                    value: 3
                  },
                  {
                    label: _ctx.$translate("Editing - Media Platforms - Documentation"),
                    value: 4
                  },
                  {
                    label: _ctx.$translate("Coverings"),
                    value: 5
                  },
                  {
                    label: _ctx.$translate("Presentation"),
                    value: 6
                  },
                  {
                    label: _ctx.$translate("Digital content industry"),
                    value: 7
                  },
                  {
                    label: _ctx.$translate("Montage"),
                    value: 8
                  },
                  {
                    label: _ctx.$translate("Social media"),
                    value: 9
                  },
                  {
                    label: _ctx.$translate("Media marketing"),
                    value: 10
                  },
                  {
                    label: _ctx.$translate("Editorial management"),
                    value: 11
                  },
                  {
                    label: _ctx.$translate("Field Editorial Leadership"),
                    value: 12
                  },
                  {
                    label: _ctx.$translate("Management of meetings and seminars"),
                    value: 13
                  },
                  {
                    label: _ctx.$translate("Media training"),
                    value: 14
                  }
                ],
                "validation-label": _ctx.$translate("Volunteering fields"),
                validation: "required"
              }, null, 8, ["label", "options", "validation-label"]),
              createVNode("div", { class: "row-of-two" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Educational level"),
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  type: "text",
                  placeholder: _ctx.$translate("Educational level"),
                  name: "education",
                  "validation-label": _ctx.$translate("Educational level"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  type: "text",
                  placeholder: _ctx.$translate("Volunteering experiences"),
                  name: "experiences",
                  label: _ctx.$translate("Volunteering experiences"),
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  "validation-label": _ctx.$translate("Volunteering experiences"),
                  validation: "required:trim"
                }, null, 8, ["placeholder", "label", "validation-label"])
              ]),
              createVNode("div", { class: "row-of-two" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Branch"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(branches),
                  name: "branch",
                  "validation-label": _ctx.$translate("Branch"),
                  validation: "required"
                }, null, 8, ["label", "options", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("How do you know the authority?"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(howKnewUs),
                  name: "hearabout",
                  "validation-label": _ctx.$translate("How do you know the authority?"),
                  validation: "required"
                }, null, 8, ["label", "options", "validation-label"])
              ]),
              createVNode("div", { class: "row-of-two" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Email"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "email",
                  placeholder: _ctx.$translate("Email"),
                  id: "email",
                  name: "email",
                  "validation-label": _ctx.$translate("Email"),
                  validation: "required:trim|email"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode("div", {
                  class: "formkit-outer mb-3",
                  "data-family": "text"
                }, [
                  createVNode("label", {
                    for: "mobile",
                    class: "formkit-label"
                  }, toDisplayString(_ctx.$translate("Mobile")), 1),
                  createVNode("div", {
                    class: "input-group [&>.formkit-outer]:mb-0 h-9",
                    style: { "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" }
                  }, [
                    createVNode(_component_FormKit, {
                      type: "myTextInput",
                      "outer-class": "w-full border border-y-0 m-0",
                      id: "mobile",
                      name: "mobile",
                      placeholder: _ctx.$translate("Mobile"),
                      validation: "required:trim|number",
                      "validation-label": _ctx.$translate("Mobile")
                    }, null, 8, ["placeholder", "validation-label"]),
                    createVNode("span", { class: "prepend" }, [
                      createVNode(_component_FormKit, {
                        type: "mySelect",
                        name: "mobile_key",
                        options: unref(mobileCodes),
                        style: { "box-shadow": "none" }
                      }, null, 8, ["options"])
                    ])
                  ])
                ])
              ]),
              createVNode("div", { class: "row-of-two" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Password"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("Password"),
                  id: "password",
                  name: "password",
                  "validation-label": _ctx.$translate("Password"),
                  validation: "required:trim|length:6"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Password confirmation"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("Password confirmation"),
                  id: "password_confirm",
                  name: "password_confirm",
                  "validation-label": _ctx.$translate("Password confirmation"),
                  validation: "required:trim|confirm"
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "mb-7" }, [
                createVNode(_component_FormKit, {
                  type: "checkbox",
                  label: _ctx.$translate("TermsAcceptance"),
                  "validation-label": _ctx.$translate("acceptance"),
                  validation: "required|accepted",
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full flex items-center": true
                    },
                    inner: "mx-3"
                  }
                }, null, 8, ["label", "validation-label"])
              ]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  type: "submit",
                  class: "btn-primary"
                }, toDisplayString(_ctx.$translate("Register")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/volunteers/auth/register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=register.67a03d2f.mjs.map
