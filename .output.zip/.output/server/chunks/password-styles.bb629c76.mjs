const password_vue_vue_type_style_index_0_lang = ".formkit-label{font-weight:400!important}";

const passwordStyles_bb629c76 = [password_vue_vue_type_style_index_0_lang];

export { passwordStyles_bb629c76 as default };
//# sourceMappingURL=password-styles.bb629c76.mjs.map
