import { openBlock, createElementBlock, createElementVNode } from 'vue';

const _hoisted_1$3 = {
  viewBox: "0 0 32 32",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$3 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "m6.115 18.172l-.36-.016H2.522l4.312-4.312l-.016-.36a1.096 1.096 0 0 0-1.063-1.063l-.359-.015H.005l.021.359c.041.584.468 1.027 1.056 1.063l.36.016h3.24L.363 18.156l.016.36a1.105 1.105 0 0 0 1.063 1.063l.36.015h5.391l-.016-.359c-.047-.589-.469-1.021-1.063-1.057zm4.317-5.765h-.005c-4.791.005-4.787 7.187 0 7.187c4.792 0 4.792-7.181.005-7.187zm1.521 5.12a2.155 2.155 0 0 1-3.089.036a2.16 2.16 0 0 1 .037-3.089c2.036-1.932 4.984 1.016 3.052 3.053zm17.162-5.12c-.823 0-1.604.353-2.151.973a2.878 2.878 0 0 0-3.77-.478c-.276-.313-.907-.495-1.261-.495v7.187l.36-.015c.599-.043 1.036-.464 1.057-1.063l.02-.36V15.64l.016-.359c.016-.271.052-.511.177-.719a1.438 1.438 0 0 1 1.964-.527c.219.125.395.308.52.521s.161.453.177.724l.021.359v2.516l.015.36c.037.583.469 1.02 1.063 1.063l.36.015V15.64l.015-.359c.011-.265.052-.516.177-.724a1.435 1.435 0 0 1 2.489.006c.12.208.157.453.172.719l.021.359v2.516l.016.36a1.108 1.108 0 0 0 1.063 1.063l.359.015v-4.312a2.879 2.879 0 0 0-2.88-2.875zm-13.678 1.052a3.591 3.591 0 0 0-.068 5.145a3.592 3.592 0 0 0 5.147-.063c3.224-3.385-1.693-8.301-5.079-5.083zm4.063 4.068a2.157 2.157 0 1 1-3.047-3.053c2.031-1.979 5.031 1.016 3.047 3.053z"
}, null, -1);
const _hoisted_3$3 = [
  _hoisted_2$3
];
function render$3(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$3, _hoisted_3$3);
}
const CibZoom = { name: "cib-zoom", render: render$3 };
const _hoisted_1$2 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$2 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M12.006 19.012h-.02c-.062 0-6.265-.012-7.83-.437a2.5 2.5 0 0 1-1.764-1.765A26.494 26.494 0 0 1 1.986 12a26.646 26.646 0 0 1 .417-4.817A2.564 2.564 0 0 1 4.169 5.4c1.522-.4 7.554-.4 7.81-.4H12c.063 0 6.282.012 7.831.437c.859.233 1.53.904 1.762 1.763c.29 1.594.427 3.211.407 4.831a26.568 26.568 0 0 1-.418 4.811a2.51 2.51 0 0 1-1.767 1.763c-1.52.403-7.553.407-7.809.407Zm-2-10.007l-.005 6l5.212-3l-5.207-3Z"
}, null, -1);
const _hoisted_3$2 = [
  _hoisted_2$2
];
function render$2(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$2, _hoisted_3$2);
}
const CiYoutube = { name: "ci-youtube", render: render$2 };
const _hoisted_1$1 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$1 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M4 3c-1.11 0-2 .89-2 2v10a2 2 0 0 0 2 2h8v5l3-3l3 3v-5h2a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H4m8 2l3 2l3-2v3.5l3 1.5l-3 1.5V15l-3-2l-3 2v-3.5L9 10l3-1.5V5M4 5h5v2H4V5m0 4h3v2H4V9m0 4h5v2H4v-2Z"
}, null, -1);
const _hoisted_3$1 = [
  _hoisted_2$1
];
function render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$1, _hoisted_3$1);
}
const MdiCertificate = { name: "mdi-certificate", render: render$1 };
const _hoisted_1 = {
  viewBox: "0 0 1024 1024",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "m557.248 608l135.744-135.744l-45.248-45.248l-135.68 135.744l-135.808-135.68l-45.248 45.184L466.752 608l-135.68 135.68l45.184 45.312L512 653.248l135.744 135.744l45.248-45.248L557.312 608zM704 192h160v736H160V192h160v64h384v-64zm-320 0V96h256v96H384z"
}, null, -1);
const _hoisted_3 = [
  _hoisted_2
];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, _hoisted_3);
}
const EpFailed = { name: "ep-failed", render };

export { CibZoom as C, EpFailed as E, MdiCertificate as M, CiYoutube as a };
//# sourceMappingURL=failed.8c4cb9b5.mjs.map
