const statement_vue_vue_type_style_index_0_lang = ".formkit-label{font-weight:400!important}";

const statementStyles_380b1eb4 = [statement_vue_vue_type_style_index_0_lang];

export { statementStyles_380b1eb4 as default };
//# sourceMappingURL=statement-styles.380b1eb4.mjs.map
