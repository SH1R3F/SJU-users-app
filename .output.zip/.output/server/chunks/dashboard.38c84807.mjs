import { e as useAuthStore, h as storeToRefs, f as useLocalization, k as __nuxt_component_0$1 } from './server.mjs';
import { resolveComponent, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    const authStore = useAuthStore();
    const { userData } = storeToRefs(authStore);
    const { dblocalize } = useLocalization();
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_NuxtChild = resolveComponent("NuxtChild");
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="dashboard my-16"><div class="container"><div class="flex gap-5 flex-col sm:flex-row"><div class="w-full sm:w-3/12"><img${ssrRenderAttr("src", ((_a = unref(userData)) == null ? void 0 : _a.avatar) || "/images/user.png")} class="rounded-full mx-auto mb-5 h-40 w-40 lg:h-52 lg:w-52 object-cover object-top shadow-lg"><h6 class="text-sju-50 text-center font-bold">${ssrInterpolate(unref(dblocalize)(unref(userData), "fullName"))}</h6><ul class="mt-4">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard",
        class: "block p-2 hover:bg-sju-500 transition-all [&.router-link-exact-active]:text-sju-50 [&.router-link-exact-active]:font-bold [&.router-link-exact-active]:bg-sju-500 dark:[&.router-link-exact-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Events"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Events")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/notifications",
        class: "block p-2 hover:bg-sju-500 transition-all [&.router-link-exact-active]:text-sju-50 [&.router-link-exact-active]:font-bold [&.router-link-exact-active]:bg-sju-500 dark:[&.router-link-exact-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Notifications"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Notifications")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/membership",
        class: "block p-2 hover:bg-sju-500 transition-all [&.router-link-exact-active]:text-sju-50 [&.router-link-exact-active]:font-bold [&.router-link-exact-active]:bg-sju-500 dark:[&.router-link-exact-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Membership"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Membership")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/profile",
        class: "block p-2 hover:bg-sju-500 transition-all [&.router-link-exact-active]:text-sju-50 [&.router-link-exact-active]:font-bold [&.router-link-exact-active]:bg-sju-500 dark:[&.router-link-exact-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Profile"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Profile")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "block p-2 hover:bg-sju-500 transition-all [&.router-link-exact-active]:text-sju-50 [&.router-link-exact-active]:font-bold [&.router-link-exact-active]:bg-sju-500 dark:[&.router-link-exact-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400",
        to: "/members/dashboard/support"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Technical support"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Technical support")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<a class="cursor-pointer block p-2 hover:bg-sju-500 transition-all [&amp;.router-link-exact-active]:text-sju-50 [&amp;.router-link-exact-active]:font-bold [&amp;.router-link-exact-active]:bg-sju-500 dark:[&amp;.router-link-exact-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400">${ssrInterpolate(_ctx.$translate("logout"))}</a></ul></div><div class="w-full sm:w-9/12">`);
      _push(ssrRenderComponent(_component_NuxtChild, null, null, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=dashboard.38c84807.mjs.map
