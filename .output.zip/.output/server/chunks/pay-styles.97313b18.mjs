const pay_vue_vue_type_style_index_0_lang = ".wpwl-control{direction:ltr!important}.wpwl-button{background:green!important}";

const payStyles_97313b18 = [pay_vue_vue_type_style_index_0_lang];

export { payStyles_97313b18 as default };
//# sourceMappingURL=pay-styles.97313b18.mjs.map
