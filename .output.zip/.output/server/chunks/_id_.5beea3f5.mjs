import { e as useAuthStore, C as useSupportStore, h as storeToRefs, g as useRoute, u as useNuxtApp, a as useHead, k as __nuxt_component_0$1 } from './server.mjs';
import { ref, resolveComponent, unref, withCtx, createVNode, openBlock, createBlock, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    const authStore = useAuthStore();
    const message = ref({});
    const supportStore = useSupportStore();
    const { chat, getMessages } = storeToRefs(supportStore);
    const id = useRoute().params.id;
    supportStore.fetchChat(id);
    const sendMessage = async (msg, node) => {
      var _a, _b, _c, _d, _e, _f, _g, _h;
      const body = new FormData();
      Object.keys(msg).forEach((key) => {
        let value = msg[key] || "";
        body.append(key, value);
      });
      body.append("image", ((_a = msg.image[0]) == null ? void 0 : _a.file) || "");
      const { error } = await supportStore.sendMessage(id, body);
      if (((_c = (_b = error == null ? void 0 : error.value) == null ? void 0 : _b.response) == null ? void 0 : _c.status) === 400) {
        node.setErrors((_d = error.value) == null ? void 0 : _d.data);
      } else if (((_f = (_e = error == null ? void 0 : error.value) == null ? void 0 : _e.response) == null ? void 0 : _f.status) === 422) {
        toast.error((_h = (_g = error.value) == null ? void 0 : _g.data) == null ? void 0 : _h.message);
      } else if (!(error == null ? void 0 : error.value)) {
        message.value = {};
      }
    };
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Technical support");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="card bg-zinc-50" style="${ssrRenderStyle({ "padding-bottom": "30px" })}"><h5 class="card-title mb-0">${ssrInterpolate(unref(chat).title)}</h5><div class="chat"><div class="w-full px-5 flex flex-col justify-between max-h-[70vh] overflow-hidden"><div class="messages flex flex-col mt-5 overflow-x-auto mb-3"><!--[-->`);
      ssrRenderList(unref(getMessages), (msgGroup) => {
        _push(`<div class="${ssrRenderClass([{
          "justify-end": msgGroup[0].sender === 1,
          "justify-start": msgGroup === 2
        }, "flex mb-4"])}">`);
        if (msgGroup[0].sender === 2) {
          _push(`<img${ssrRenderAttr(
            "src",
            msgGroup[0].sender === 1 ? "/images/support.png" : unref(authStore).userData.avatar || "/images/user.png"
          )} class="object-cover h-8 w-8 rounded-full">`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div><!--[-->`);
        ssrRenderList(msgGroup, (msg) => {
          _push(`<div class="${ssrRenderClass([{
            "bubble-other": msgGroup[0].sender === 1,
            "bubble-me": msgGroup[0].sender === 2
          }, "mt-1"])}">`);
          if (msg.message) {
            _push(`<span>${ssrInterpolate(msg.message)}</span>`);
          } else {
            _push(`<!---->`);
          }
          if (msg.attachment) {
            _push(ssrRenderComponent(_component_nuxt_link, {
              to: msg.attachment,
              target: "_blank"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`<img${ssrRenderAttr("src", msg.attachment)} class="max-w-xs"${_scopeId}>`);
                } else {
                  return [
                    createVNode("img", {
                      src: msg.attachment,
                      class: "max-w-xs"
                    }, null, 8, ["src"])
                  ];
                }
              }),
              _: 2
            }, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
        if (msgGroup[0].sender === 1) {
          _push(`<img${ssrRenderAttr(
            "src",
            msgGroup[0].sender === 1 ? "/images/support.png" : unref(authStore).userData.avatar || "/images/user.png"
          )} class="object-cover h-8 w-8 rounded-full">`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        enctype: "multipart/form-data",
        "form-class": "flex items-center",
        modelValue: message.value,
        "onUpdate:modelValue": ($event) => message.value = $event,
        actions: false,
        onSubmit: sendMessage
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "w-full"
              },
              type: "textarea",
              rows: "1",
              placeholder: _ctx.$translate("Message"),
              name: "body",
              "validation-label": _ctx.$translate("Message"),
              validation: "trim"
            }, null, _parent2, _scopeId));
            _push2(`<label class="${ssrRenderClass([{
              "text-sju-50": (_b = (_a = message.value) == null ? void 0 : _a.image) == null ? void 0 : _b.length
            }, "mr-1 cursor-pointer rounded"])}" style="${ssrRenderStyle({ "padding": "3px" })}" for="attachment"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "file",
              name: "image",
              id: "attachment",
              accept: "image/*",
              "outer-class": "hidden"
            }, null, _parent2, _scopeId));
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" width="17px" height="17px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-upload"${_scopeId}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"${_scopeId}></path><polyline points="17 8 12 3 7 8"${_scopeId}></polyline><line x1="12" y1="3" x2="12" y2="15"${_scopeId}></line></svg></label><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Send"))}</button>`);
          } else {
            return [
              createVNode(_component_FormKit, {
                classes: {
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full": true
                  },
                  outer: "w-full"
                },
                type: "textarea",
                rows: "1",
                placeholder: _ctx.$translate("Message"),
                name: "body",
                "validation-label": _ctx.$translate("Message"),
                validation: "trim"
              }, null, 8, ["placeholder", "validation-label"]),
              createVNode("label", {
                class: ["mr-1 cursor-pointer rounded", {
                  "text-sju-50": (_d = (_c = message.value) == null ? void 0 : _c.image) == null ? void 0 : _d.length
                }],
                style: { "padding": "3px" },
                for: "attachment"
              }, [
                createVNode(_component_FormKit, {
                  type: "file",
                  name: "image",
                  id: "attachment",
                  accept: "image/*",
                  "outer-class": "hidden"
                }),
                (openBlock(), createBlock("svg", {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "17px",
                  height: "17px",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  "stroke-width": "2",
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  class: "feather feather-upload"
                }, [
                  createVNode("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }),
                  createVNode("polyline", { points: "17 8 12 3 7 8" }),
                  createVNode("line", {
                    x1: "12",
                    y1: "3",
                    x2: "12",
                    y2: "15"
                  })
                ]))
              ], 2),
              createVNode("button", {
                type: "submit",
                class: "btn-primary"
              }, toDisplayString(_ctx.$translate("Send")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/subscribers/dashboard/support/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_.5beea3f5.mjs.map
