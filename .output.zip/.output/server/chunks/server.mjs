import { getCurrentInstance, inject, computed, defineComponent, provide, h, Suspense, Transition, reactive, toRaw, isRef, isReactive, toRef, mergeProps, withCtx, createTextVNode, toDisplayString, unref, openBlock, createBlock, createVNode, useSSRContext, ref, watch, watchEffect, onUnmounted, defineAsyncComponent, resolveComponent, markRaw, createElementBlock, shallowRef, createApp, effectScope, onErrorCaptured, onServerPrefetch, createElementVNode, nextTick, triggerRef, toRefs } from 'vue';
import { $fetch as $fetch$1 } from 'ohmyfetch';
import { hasProtocol, parseURL, joinURL, isEqual } from 'ufo';
import { createHooks } from 'hookable';
import { getContext, executeAsync } from 'unctx';
import { RouterView, createMemoryHistory, createRouter } from 'vue-router';
import destr from 'destr';
import { createError as createError$1, sendRedirect, appendHeader } from 'h3';
import defu, { defuFn } from 'defu';
import { isFunction } from '@vue/shared';
import { ssrRenderAttrs, ssrRenderList, ssrRenderComponent, ssrInterpolate, ssrRenderSlot, ssrRenderClass, ssrRenderStyle, ssrRenderSuspense } from 'vue/server-renderer';
import { parse, serialize } from 'cookie-es';
import { isEqual as isEqual$1 } from 'ohash';
import { error, createNode, createMessage, resetCount, warn, getNode, watchRegistry, isNode, createConfig, clearErrors, setErrors, submitForm, reset, createClasses, generateClassList, sugar, isDOM, isComponent, isConditional, compile } from '@formkit/core';
import { cloneAny, extend, camel, kebab, nodeProps, only, except, slugify, isObject, has, isPojo, empty, eq, shallowClone, undefine } from '@formkit/utils';
import { outer, textInput, messages, message, selectInput, $if, optionSlot, option, options, selects, defaultIcon, boxWrapper, inner, prefix, box, decorator, icon, suffix, boxLabel, wrapper, legend, help, boxOptions, boxOption, $extend, boxHelp, radios, createLibraryPlugin, inputs } from '@formkit/inputs';
import * as defaultRules from '@formkit/rules';
import { createValidationPlugin } from '@formkit/validation';
import { createI18nPlugin, en as en$1, ar as ar$1 } from '@formkit/i18n';
import { createIconHandler, createThemePlugin } from '@formkit/themes';
import { createObserver } from '@formkit/observer';
import { a as useRuntimeConfig$1 } from './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const appConfig = useRuntimeConfig$1().app;
const baseURL = () => appConfig.baseURL;
const buildAssetsDir = () => appConfig.buildAssetsDir;
const buildAssetsURL = (...path) => joinURL(publicAssetsURL(), buildAssetsDir(), ...path);
const publicAssetsURL = (...path) => {
  const publicBase = appConfig.cdnURL || appConfig.baseURL;
  return path.length ? joinURL(publicBase, ...path) : publicBase;
};
globalThis.__buildAssetsURL = buildAssetsURL;
globalThis.__publicAssetsURL = publicAssetsURL;
const nuxtAppCtx = getContext("nuxt-app");
const NuxtPluginIndicator = "__nuxt_plugin";
function createNuxtApp(options2) {
  const nuxtApp = {
    provide: void 0,
    globalName: "nuxt",
    payload: reactive({
      data: {},
      state: {},
      _errors: {},
      ...{ serverRendered: true }
    }),
    isHydrating: false,
    _asyncDataPromises: {},
    _asyncData: {},
    ...options2
  };
  nuxtApp.hooks = createHooks();
  nuxtApp.hook = nuxtApp.hooks.hook;
  nuxtApp.callHook = nuxtApp.hooks.callHook;
  nuxtApp.provide = (name, value) => {
    const $name = "$" + name;
    defineGetter(nuxtApp, $name, value);
    defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
  };
  defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
  defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
  {
    if (nuxtApp.ssrContext) {
      nuxtApp.ssrContext.nuxt = nuxtApp;
    }
    nuxtApp.ssrContext = nuxtApp.ssrContext || {};
    if (nuxtApp.ssrContext.payload) {
      Object.assign(nuxtApp.payload, nuxtApp.ssrContext.payload);
    }
    nuxtApp.ssrContext.payload = nuxtApp.payload;
    nuxtApp.payload.config = {
      public: options2.ssrContext.runtimeConfig.public,
      app: options2.ssrContext.runtimeConfig.app
    };
  }
  const runtimeConfig = options2.ssrContext.runtimeConfig;
  const compatibilityConfig = new Proxy(runtimeConfig, {
    get(target, prop) {
      var _a;
      if (prop === "public") {
        return target.public;
      }
      return (_a = target[prop]) != null ? _a : target.public[prop];
    },
    set(target, prop, value) {
      {
        return false;
      }
    }
  });
  nuxtApp.provide("config", compatibilityConfig);
  return nuxtApp;
}
async function applyPlugin(nuxtApp, plugin2) {
  if (typeof plugin2 !== "function") {
    return;
  }
  const { provide: provide2 } = await callWithNuxt(nuxtApp, plugin2, [nuxtApp]) || {};
  if (provide2 && typeof provide2 === "object") {
    for (const key in provide2) {
      nuxtApp.provide(key, provide2[key]);
    }
  }
}
async function applyPlugins(nuxtApp, plugins2) {
  for (const plugin2 of plugins2) {
    await applyPlugin(nuxtApp, plugin2);
  }
}
function normalizePlugins(_plugins2) {
  const plugins2 = _plugins2.map((plugin2) => {
    if (typeof plugin2 !== "function") {
      return null;
    }
    if (plugin2.length > 1) {
      return (nuxtApp) => plugin2(nuxtApp, nuxtApp.provide);
    }
    return plugin2;
  }).filter(Boolean);
  return plugins2;
}
function defineNuxtPlugin(plugin2) {
  plugin2[NuxtPluginIndicator] = true;
  return plugin2;
}
function callWithNuxt(nuxt, setup, args) {
  const fn = () => args ? setup(...args) : setup();
  {
    return nuxtAppCtx.callAsync(nuxt, fn);
  }
}
function useNuxtApp() {
  const nuxtAppInstance = nuxtAppCtx.tryUse();
  if (!nuxtAppInstance) {
    const vm = getCurrentInstance();
    if (!vm) {
      throw new Error("nuxt instance unavailable");
    }
    return vm.appContext.app.$nuxt;
  }
  return nuxtAppInstance;
}
function useRuntimeConfig() {
  return useNuxtApp().$config;
}
function defineGetter(obj, key, val) {
  Object.defineProperty(obj, key, { get: () => val });
}
function defineAppConfig(config2) {
  return config2;
}
const getDefault = () => null;
function useAsyncData(...args) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  let [key, handler, options2 = {}] = args;
  if (typeof key !== "string") {
    throw new TypeError("[nuxt] [asyncData] key must be a string.");
  }
  if (typeof handler !== "function") {
    throw new TypeError("[nuxt] [asyncData] handler must be a function.");
  }
  options2.server = (_a = options2.server) != null ? _a : true;
  options2.default = (_b = options2.default) != null ? _b : getDefault;
  if (options2.defer) {
    console.warn("[useAsyncData] `defer` has been renamed to `lazy`. Support for `defer` will be removed in RC.");
  }
  options2.lazy = (_d = (_c = options2.lazy) != null ? _c : options2.defer) != null ? _d : false;
  options2.initialCache = (_e = options2.initialCache) != null ? _e : true;
  options2.immediate = (_f = options2.immediate) != null ? _f : true;
  const nuxt = useNuxtApp();
  const useInitialCache = () => (nuxt.isHydrating || options2.initialCache) && nuxt.payload.data[key] !== void 0;
  if (!nuxt._asyncData[key]) {
    nuxt._asyncData[key] = {
      data: ref(useInitialCache() ? nuxt.payload.data[key] : (_h = (_g = options2.default) == null ? void 0 : _g.call(options2)) != null ? _h : null),
      pending: ref(!useInitialCache()),
      error: ref((_i = nuxt.payload._errors[key]) != null ? _i : null)
    };
  }
  const asyncData = { ...nuxt._asyncData[key] };
  asyncData.refresh = asyncData.execute = (opts = {}) => {
    if (nuxt._asyncDataPromises[key]) {
      return nuxt._asyncDataPromises[key];
    }
    if (opts._initial && useInitialCache()) {
      return nuxt.payload.data[key];
    }
    asyncData.pending.value = true;
    nuxt._asyncDataPromises[key] = new Promise(
      (resolve, reject) => {
        try {
          resolve(handler(nuxt));
        } catch (err) {
          reject(err);
        }
      }
    ).then((result) => {
      if (options2.transform) {
        result = options2.transform(result);
      }
      if (options2.pick) {
        result = pick(result, options2.pick);
      }
      asyncData.data.value = result;
      asyncData.error.value = null;
    }).catch((error2) => {
      var _a2, _b2;
      asyncData.error.value = error2;
      asyncData.data.value = unref((_b2 = (_a2 = options2.default) == null ? void 0 : _a2.call(options2)) != null ? _b2 : null);
    }).finally(() => {
      asyncData.pending.value = false;
      nuxt.payload.data[key] = asyncData.data.value;
      if (asyncData.error.value) {
        nuxt.payload._errors[key] = true;
      }
      delete nuxt._asyncDataPromises[key];
    });
    return nuxt._asyncDataPromises[key];
  };
  const initialFetch = () => asyncData.refresh({ _initial: true });
  const fetchOnServer = options2.server !== false && nuxt.payload.serverRendered;
  if (fetchOnServer && options2.immediate) {
    const promise = initialFetch();
    onServerPrefetch(() => promise);
  }
  const asyncDataPromise = Promise.resolve(nuxt._asyncDataPromises[key]).then(() => asyncData);
  Object.assign(asyncDataPromise, asyncData);
  return asyncDataPromise;
}
function pick(obj, keys) {
  const newObj = {};
  for (const key of keys) {
    newObj[key] = obj[key];
  }
  return newObj;
}
function useState(...args) {
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  const [_key, init] = args;
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useState] key must be a string: " + _key);
  }
  if (init !== void 0 && typeof init !== "function") {
    throw new Error("[nuxt] [useState] init must be a function: " + init);
  }
  const key = "$s" + _key;
  const nuxt = useNuxtApp();
  const state = toRef(nuxt.payload.state, key);
  if (state.value === void 0 && init) {
    const initialValue = init();
    if (isRef(initialValue)) {
      nuxt.payload.state[key] = initialValue;
      return initialValue;
    }
    state.value = initialValue;
  }
  return state;
}
const useError = () => toRef(useNuxtApp().payload, "error");
const showError = (_err) => {
  const err = createError(_err);
  try {
    const nuxtApp = useNuxtApp();
    nuxtApp.callHook("app:error", err);
    const error2 = useError();
    error2.value = error2.value || err;
  } catch {
    throw err;
  }
  return err;
};
const clearError = async (options2 = {}) => {
  const nuxtApp = useNuxtApp();
  const error2 = useError();
  nuxtApp.callHook("app:error:cleared", options2);
  if (options2.redirect) {
    await nuxtApp.$router.replace(options2.redirect);
  }
  error2.value = null;
};
const createError = (err) => {
  const _err = createError$1(err);
  _err.__nuxt_error = true;
  return _err;
};
function useFetch(request, arg1, arg2) {
  const [opts = {}, autoKey] = typeof arg1 === "string" ? [{}, arg1] : [arg1, arg2];
  const _key = opts.key || autoKey;
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useFetch] key must be a string: " + _key);
  }
  if (!request) {
    throw new Error("[nuxt] [useFetch] request is missing.");
  }
  const key = "$f" + _key;
  const _request = computed(() => {
    let r = request;
    if (typeof r === "function") {
      r = r();
    }
    return isRef(r) ? r.value : r;
  });
  const {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    watch: watch2,
    initialCache,
    ...fetchOptions
  } = opts;
  const _fetchOptions = {
    ...fetchOptions,
    cache: typeof opts.cache === "boolean" ? void 0 : opts.cache
  };
  const _asyncDataOptions = {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    initialCache,
    watch: [
      _request,
      ...watch2 || []
    ]
  };
  const asyncData = useAsyncData(key, () => {
    return $fetch(_request.value, _fetchOptions);
  }, _asyncDataOptions);
  return asyncData;
}
function useRequestEvent(nuxtApp = useNuxtApp()) {
  var _a;
  return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
}
const CookieDefaults = {
  path: "/",
  decode: (val) => destr(decodeURIComponent(val)),
  encode: (val) => encodeURIComponent(typeof val === "string" ? val : JSON.stringify(val))
};
function useCookie(name, _opts) {
  var _a, _b;
  const opts = { ...CookieDefaults, ..._opts };
  const cookies = readRawCookies(opts) || {};
  const cookie = ref((_b = cookies[name]) != null ? _b : (_a = opts.default) == null ? void 0 : _a.call(opts));
  {
    const nuxtApp = useNuxtApp();
    const writeFinalCookieValue = () => {
      if (!isEqual$1(cookie.value, cookies[name])) {
        writeServerCookie(useRequestEvent(nuxtApp), name, cookie.value, opts);
      }
    };
    const unhook = nuxtApp.hooks.hookOnce("app:rendered", writeFinalCookieValue);
    nuxtApp.hooks.hookOnce("app:redirected", () => {
      unhook();
      return writeFinalCookieValue();
    });
  }
  return cookie;
}
function readRawCookies(opts = {}) {
  var _a;
  {
    return parse(((_a = useRequestEvent()) == null ? void 0 : _a.req.headers.cookie) || "", opts);
  }
}
function serializeCookie(name, value, opts = {}) {
  if (value === null || value === void 0) {
    return serialize(name, value, { ...opts, maxAge: -1 });
  }
  return serialize(name, value, opts);
}
function writeServerCookie(event, name, value, opts = {}) {
  if (event) {
    appendHeader(event, "Set-Cookie", serializeCookie(name, value, opts));
  }
}
const useRouter = () => {
  var _a;
  return (_a = useNuxtApp()) == null ? void 0 : _a.$router;
};
const useRoute = () => {
  if (getCurrentInstance()) {
    return inject("_route", useNuxtApp()._route);
  }
  return useNuxtApp()._route;
};
const defineNuxtRouteMiddleware = (middleware) => middleware;
const isProcessingMiddleware = () => {
  try {
    if (useNuxtApp()._processingMiddleware) {
      return true;
    }
  } catch {
    return true;
  }
  return false;
};
const navigateTo = (to2, options2) => {
  if (!to2) {
    to2 = "/";
  }
  const toPath = typeof to2 === "string" ? to2 : to2.path || "/";
  const isExternal = hasProtocol(toPath, true);
  if (isExternal && !(options2 == null ? void 0 : options2.external)) {
    throw new Error("Navigating to external URL is not allowed by default. Use `nagivateTo (url, { external: true })`.");
  }
  if (isExternal && parseURL(toPath).protocol === "script:") {
    throw new Error("Cannot navigate to an URL with script protocol.");
  }
  const router = useRouter();
  {
    const nuxtApp = useNuxtApp();
    if (nuxtApp.ssrContext && nuxtApp.ssrContext.event) {
      const redirectLocation = isExternal ? toPath : joinURL(useRuntimeConfig().app.baseURL, router.resolve(to2).fullPath || "/");
      return nuxtApp.callHook("app:redirected").then(() => sendRedirect(nuxtApp.ssrContext.event, redirectLocation, (options2 == null ? void 0 : options2.redirectCode) || 302));
    }
  }
  if (isExternal) {
    if (options2 == null ? void 0 : options2.replace) {
      location.replace(toPath);
    } else {
      location.href = toPath;
    }
    return Promise.resolve();
  }
  return (options2 == null ? void 0 : options2.replace) ? router.replace(to2) : router.push(to2);
};
const setPageLayout = (layout) => {
  {
    useState("_layout").value = layout;
  }
  useNuxtApp();
  const inMiddleware = isProcessingMiddleware();
  if (inMiddleware || true) {
    const unsubscribe = useRouter().beforeResolve((to2) => {
      to2.meta.layout = layout;
      unsubscribe();
    });
  }
  if (!inMiddleware) {
    useRoute().meta.layout = layout;
  }
};
const firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
const DEFAULT_EXTERNAL_REL_ATTRIBUTE = "noopener noreferrer";
function defineNuxtLink(options2) {
  const componentName = options2.componentName || "NuxtLink";
  return defineComponent({
    name: componentName,
    props: {
      to: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      href: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      target: {
        type: String,
        default: void 0,
        required: false
      },
      rel: {
        type: String,
        default: void 0,
        required: false
      },
      noRel: {
        type: Boolean,
        default: void 0,
        required: false
      },
      prefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      noPrefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      activeClass: {
        type: String,
        default: void 0,
        required: false
      },
      exactActiveClass: {
        type: String,
        default: void 0,
        required: false
      },
      prefetchedClass: {
        type: String,
        default: void 0,
        required: false
      },
      replace: {
        type: Boolean,
        default: void 0,
        required: false
      },
      ariaCurrentValue: {
        type: String,
        default: void 0,
        required: false
      },
      external: {
        type: Boolean,
        default: void 0,
        required: false
      },
      custom: {
        type: Boolean,
        default: void 0,
        required: false
      }
    },
    setup(props2, { slots }) {
      const router = useRouter();
      const to2 = computed(() => {
        return props2.to || props2.href || "";
      });
      const isExternal = computed(() => {
        if (props2.external) {
          return true;
        }
        if (props2.target && props2.target !== "_self") {
          return true;
        }
        if (typeof to2.value === "object") {
          return false;
        }
        return to2.value === "" || hasProtocol(to2.value, true);
      });
      const prefetched = ref(false);
      return () => {
        var _a, _b, _c;
        if (!isExternal.value) {
          return h(
            resolveComponent("RouterLink"),
            {
              ref: void 0,
              to: to2.value,
              ...prefetched.value && !props2.custom ? { class: props2.prefetchedClass || options2.prefetchedClass } : {},
              activeClass: props2.activeClass || options2.activeClass,
              exactActiveClass: props2.exactActiveClass || options2.exactActiveClass,
              replace: props2.replace,
              ariaCurrentValue: props2.ariaCurrentValue,
              custom: props2.custom
            },
            slots.default
          );
        }
        const href = typeof to2.value === "object" ? (_b = (_a = router.resolve(to2.value)) == null ? void 0 : _a.href) != null ? _b : null : to2.value || null;
        const target = props2.target || null;
        const rel = props2.noRel ? null : firstNonUndefined(props2.rel, options2.externalRelAttribute, href ? DEFAULT_EXTERNAL_REL_ATTRIBUTE : "") || null;
        const navigate = () => navigateTo(href, { replace: props2.replace });
        if (props2.custom) {
          if (!slots.default) {
            return null;
          }
          return slots.default({
            href,
            navigate,
            route: router.resolve(href),
            rel,
            target,
            isActive: false,
            isExactActive: false
          });
        }
        return h("a", { href, rel, target }, (_c = slots.default) == null ? void 0 : _c.call(slots));
      };
    }
  });
}
const __nuxt_component_0$1 = defineNuxtLink({ componentName: "NuxtLink" });
const cfg0 = defineAppConfig({
  title: "Saudi journalists association"
});
const inlineConfig = {};
defuFn(cfg0, inlineConfig);
function useHead(meta2) {
  const resolvedMeta = isFunction(meta2) ? computed(meta2) : meta2;
  useNuxtApp()._useHead(resolvedMeta);
}
const components = {};
const _nuxt_components_plugin_mjs_KR1HBZs4kY = defineNuxtPlugin((nuxtApp) => {
  for (const name in components) {
    nuxtApp.vueApp.component(name, components[name]);
    nuxtApp.vueApp.component("Lazy" + name, components[name]);
  }
});
var PROVIDE_KEY = `usehead`;
var HEAD_COUNT_KEY = `head:count`;
var HEAD_ATTRS_KEY = `data-head-attrs`;
var SELF_CLOSING_TAGS = ["meta", "link", "base"];
var BODY_TAG_ATTR_NAME = `data-meta-body`;
var createElement = (tag, attrs, document2) => {
  const el = document2.createElement(tag);
  for (const key of Object.keys(attrs)) {
    if (key === "body" && attrs.body === true) {
      el.setAttribute(BODY_TAG_ATTR_NAME, "true");
    } else {
      let value = attrs[key];
      if (key === "renderPriority" || key === "key" || value === false) {
        continue;
      }
      if (key === "children") {
        el.textContent = value;
      } else {
        el.setAttribute(key, value);
      }
    }
  }
  return el;
};
var stringifyAttrName = (str) => str.replace(/[\s"'><\/=]/g, "").replace(/[^a-zA-Z0-9_-]/g, "");
var stringifyAttrValue = (str) => str.replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
var stringifyAttrs = (attributes) => {
  const handledAttributes = [];
  for (let [key, value] of Object.entries(attributes)) {
    if (key === "children" || key === "key") {
      continue;
    }
    if (value === false || value == null) {
      continue;
    }
    let attribute = stringifyAttrName(key);
    if (value !== true) {
      attribute += `="${stringifyAttrValue(String(value))}"`;
    }
    handledAttributes.push(attribute);
  }
  return handledAttributes.length > 0 ? " " + handledAttributes.join(" ") : "";
};
function isEqualNode(oldTag, newTag) {
  if (oldTag instanceof HTMLElement && newTag instanceof HTMLElement) {
    const nonce = newTag.getAttribute("nonce");
    if (nonce && !oldTag.getAttribute("nonce")) {
      const cloneTag = newTag.cloneNode(true);
      cloneTag.setAttribute("nonce", "");
      cloneTag.nonce = nonce;
      return nonce === oldTag.nonce && oldTag.isEqualNode(cloneTag);
    }
  }
  return oldTag.isEqualNode(newTag);
}
var tagDedupeKey = (tag) => {
  if (!["meta", "base", "script", "link"].includes(tag.tag)) {
    return false;
  }
  const { props: props2, tag: tagName } = tag;
  if (tagName === "base") {
    return "base";
  }
  if (tagName === "link" && props2.rel === "canonical") {
    return "canonical";
  }
  if (props2.charset) {
    return "charset";
  }
  const name = ["key", "id", "name", "property", "http-equiv"];
  for (const n of name) {
    let value = void 0;
    if (typeof props2.getAttribute === "function" && props2.hasAttribute(n)) {
      value = props2.getAttribute(n);
    } else {
      value = props2[n];
    }
    if (value !== void 0) {
      return `${tagName}-${n}-${value}`;
    }
  }
  return false;
};
var acceptFields = [
  "title",
  "meta",
  "link",
  "base",
  "style",
  "script",
  "noscript",
  "htmlAttrs",
  "bodyAttrs"
];
var renderTemplate = (template, title) => {
  if (template == null)
    return "";
  if (typeof template === "string") {
    return template.replace("%s", title != null ? title : "");
  }
  return template(unref(title));
};
var headObjToTags = (obj) => {
  const tags = [];
  const keys = Object.keys(obj);
  for (const key of keys) {
    if (obj[key] == null)
      continue;
    switch (key) {
      case "title":
        tags.push({ tag: key, props: { children: obj[key] } });
        break;
      case "titleTemplate":
        break;
      case "base":
        tags.push({ tag: key, props: { key: "default", ...obj[key] } });
        break;
      default:
        if (acceptFields.includes(key)) {
          const value = obj[key];
          if (Array.isArray(value)) {
            value.forEach((item) => {
              tags.push({ tag: key, props: unref(item) });
            });
          } else if (value) {
            tags.push({ tag: key, props: value });
          }
        }
        break;
    }
  }
  return tags;
};
var setAttrs = (el, attrs) => {
  const existingAttrs = el.getAttribute(HEAD_ATTRS_KEY);
  if (existingAttrs) {
    for (const key of existingAttrs.split(",")) {
      if (!(key in attrs)) {
        el.removeAttribute(key);
      }
    }
  }
  const keys = [];
  for (const key in attrs) {
    const value = attrs[key];
    if (value == null)
      continue;
    if (value === false) {
      el.removeAttribute(key);
    } else {
      el.setAttribute(key, value);
    }
    keys.push(key);
  }
  if (keys.length) {
    el.setAttribute(HEAD_ATTRS_KEY, keys.join(","));
  } else {
    el.removeAttribute(HEAD_ATTRS_KEY);
  }
};
var updateElements = (document2 = window.document, type, tags) => {
  var _a, _b;
  const head = document2.head;
  const body = document2.body;
  let headCountEl = head.querySelector(`meta[name="${HEAD_COUNT_KEY}"]`);
  let bodyMetaElements = body.querySelectorAll(`[${BODY_TAG_ATTR_NAME}]`);
  const headCount = headCountEl ? Number(headCountEl.getAttribute("content")) : 0;
  const oldHeadElements = [];
  const oldBodyElements = [];
  if (bodyMetaElements) {
    for (let i2 = 0; i2 < bodyMetaElements.length; i2++) {
      if (bodyMetaElements[i2] && ((_a = bodyMetaElements[i2].tagName) == null ? void 0 : _a.toLowerCase()) === type) {
        oldBodyElements.push(bodyMetaElements[i2]);
      }
    }
  }
  if (headCountEl) {
    for (let i2 = 0, j = headCountEl.previousElementSibling; i2 < headCount; i2++, j = (j == null ? void 0 : j.previousElementSibling) || null) {
      if (((_b = j == null ? void 0 : j.tagName) == null ? void 0 : _b.toLowerCase()) === type) {
        oldHeadElements.push(j);
      }
    }
  } else {
    headCountEl = document2.createElement("meta");
    headCountEl.setAttribute("name", HEAD_COUNT_KEY);
    headCountEl.setAttribute("content", "0");
    head.append(headCountEl);
  }
  let newElements = tags.map((tag) => {
    var _a2;
    return {
      element: createElement(tag.tag, tag.props, document2),
      body: (_a2 = tag.props.body) != null ? _a2 : false
    };
  });
  newElements = newElements.filter((newEl) => {
    for (let i2 = 0; i2 < oldHeadElements.length; i2++) {
      const oldEl = oldHeadElements[i2];
      if (isEqualNode(oldEl, newEl.element)) {
        oldHeadElements.splice(i2, 1);
        return false;
      }
    }
    for (let i2 = 0; i2 < oldBodyElements.length; i2++) {
      const oldEl = oldBodyElements[i2];
      if (isEqualNode(oldEl, newEl.element)) {
        oldBodyElements.splice(i2, 1);
        return false;
      }
    }
    return true;
  });
  oldBodyElements.forEach((t) => {
    var _a2;
    return (_a2 = t.parentNode) == null ? void 0 : _a2.removeChild(t);
  });
  oldHeadElements.forEach((t) => {
    var _a2;
    return (_a2 = t.parentNode) == null ? void 0 : _a2.removeChild(t);
  });
  newElements.forEach((t) => {
    if (t.body === true) {
      body.insertAdjacentElement("beforeend", t.element);
    } else {
      head.insertBefore(t.element, headCountEl);
    }
  });
  headCountEl.setAttribute(
    "content",
    "" + (headCount - oldHeadElements.length + newElements.filter((t) => !t.body).length)
  );
};
var createHead = (initHeadObject) => {
  let allHeadObjs = [];
  let previousTags = /* @__PURE__ */ new Set();
  if (initHeadObject) {
    allHeadObjs.push(shallowRef(initHeadObject));
  }
  const head = {
    install(app) {
      app.config.globalProperties.$head = head;
      app.provide(PROVIDE_KEY, head);
    },
    get headTags() {
      const deduped = [];
      const deduping = {};
      const titleTemplate = allHeadObjs.map((i2) => unref(i2).titleTemplate).reverse().find((i2) => i2 != null);
      allHeadObjs.forEach((objs, headObjectIdx) => {
        const tags = headObjToTags(unref(objs));
        tags.forEach((tag, tagIdx) => {
          tag._position = headObjectIdx * 1e4 + tagIdx;
          if (titleTemplate && tag.tag === "title") {
            tag.props.children = renderTemplate(
              titleTemplate,
              tag.props.children
            );
          }
          const dedupeKey = tagDedupeKey(tag);
          if (dedupeKey) {
            deduping[dedupeKey] = tag;
          } else {
            deduped.push(tag);
          }
        });
      });
      deduped.push(...Object.values(deduping));
      return deduped.sort((a, b) => a._position - b._position);
    },
    addHeadObjs(objs) {
      allHeadObjs.push(objs);
    },
    removeHeadObjs(objs) {
      allHeadObjs = allHeadObjs.filter((_objs) => _objs !== objs);
    },
    updateDOM(document2 = window.document) {
      let title;
      let htmlAttrs = {};
      let bodyAttrs = {};
      const actualTags = {};
      for (const tag of head.headTags.sort(sortTags)) {
        if (tag.tag === "title") {
          title = tag.props.children;
          continue;
        }
        if (tag.tag === "htmlAttrs") {
          Object.assign(htmlAttrs, tag.props);
          continue;
        }
        if (tag.tag === "bodyAttrs") {
          Object.assign(bodyAttrs, tag.props);
          continue;
        }
        actualTags[tag.tag] = actualTags[tag.tag] || [];
        actualTags[tag.tag].push(tag);
      }
      if (title !== void 0) {
        document2.title = title;
      }
      setAttrs(document2.documentElement, htmlAttrs);
      setAttrs(document2.body, bodyAttrs);
      const tags = /* @__PURE__ */ new Set([...Object.keys(actualTags), ...previousTags]);
      for (const tag of tags) {
        updateElements(document2, tag, actualTags[tag] || []);
      }
      previousTags.clear();
      Object.keys(actualTags).forEach((i2) => previousTags.add(i2));
    }
  };
  return head;
};
var tagToString = (tag) => {
  let isBodyTag = false;
  if (tag.props.body) {
    isBodyTag = true;
    delete tag.props.body;
  }
  if (tag.props.renderPriority) {
    delete tag.props.renderPriority;
  }
  let attrs = stringifyAttrs(tag.props);
  if (SELF_CLOSING_TAGS.includes(tag.tag)) {
    return `<${tag.tag}${attrs}${isBodyTag ? `  ${BODY_TAG_ATTR_NAME}="true"` : ""}>`;
  }
  return `<${tag.tag}${attrs}${isBodyTag ? ` ${BODY_TAG_ATTR_NAME}="true"` : ""}>${tag.props.children || ""}</${tag.tag}>`;
};
var sortTags = (aTag, bTag) => {
  const tagWeight = (tag) => {
    if (tag.props.renderPriority) {
      return tag.props.renderPriority;
    }
    switch (tag.tag) {
      case "base":
        return -1;
      case "meta":
        if (tag.props.charset) {
          return -2;
        }
        if (tag.props["http-equiv"] === "content-security-policy") {
          return 0;
        }
        return 10;
      default:
        return 10;
    }
  };
  return tagWeight(aTag) - tagWeight(bTag);
};
var renderHeadToString = (head) => {
  const tags = [];
  let titleTag = "";
  let htmlAttrs = {};
  let bodyAttrs = {};
  let bodyTags = [];
  for (const tag of head.headTags.sort(sortTags)) {
    if (tag.tag === "title") {
      titleTag = tagToString(tag);
    } else if (tag.tag === "htmlAttrs") {
      Object.assign(htmlAttrs, tag.props);
    } else if (tag.tag === "bodyAttrs") {
      Object.assign(bodyAttrs, tag.props);
    } else if (tag.props.body) {
      bodyTags.push(tagToString(tag));
    } else {
      tags.push(tagToString(tag));
    }
  }
  tags.push(`<meta name="${HEAD_COUNT_KEY}" content="${tags.length}">`);
  return {
    get headTags() {
      return titleTag + tags.join("");
    },
    get htmlAttrs() {
      return stringifyAttrs({
        ...htmlAttrs,
        [HEAD_ATTRS_KEY]: Object.keys(htmlAttrs).join(",")
      });
    },
    get bodyAttrs() {
      return stringifyAttrs({
        ...bodyAttrs,
        [HEAD_ATTRS_KEY]: Object.keys(bodyAttrs).join(",")
      });
    },
    get bodyTags() {
      return bodyTags.join("");
    }
  };
};
const node_modules_nuxt_dist_head_runtime_lib_vueuse_head_plugin_mjs_D7WGfuP1A0 = defineNuxtPlugin((nuxtApp) => {
  const head = createHead();
  nuxtApp.vueApp.use(head);
  nuxtApp.hooks.hookOnce("app:mounted", () => {
    watchEffect(() => {
      head.updateDOM();
    });
  });
  nuxtApp._useHead = (_meta) => {
    const meta2 = ref(_meta);
    const headObj = computed(() => {
      const overrides = { meta: [] };
      if (meta2.value.charset) {
        overrides.meta.push({ key: "charset", charset: meta2.value.charset });
      }
      if (meta2.value.viewport) {
        overrides.meta.push({ name: "viewport", content: meta2.value.viewport });
      }
      return defu(overrides, meta2.value);
    });
    head.addHeadObjs(headObj);
    {
      return;
    }
  };
  {
    nuxtApp.ssrContext.renderMeta = () => {
      const meta2 = renderHeadToString(head);
      return {
        ...meta2,
        bodyScripts: meta2.bodyTags
      };
    };
  }
});
const removeUndefinedProps = (props2) => Object.fromEntries(Object.entries(props2).filter(([, value]) => value !== void 0));
const setupForUseMeta = (metaFactory, renderChild) => (props2, ctx) => {
  useHead(() => metaFactory({ ...removeUndefinedProps(props2), ...ctx.attrs }, ctx));
  return () => {
    var _a, _b;
    return renderChild ? (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a) : null;
  };
};
const globalProps = {
  accesskey: String,
  autocapitalize: String,
  autofocus: {
    type: Boolean,
    default: void 0
  },
  class: String,
  contenteditable: {
    type: Boolean,
    default: void 0
  },
  contextmenu: String,
  dir: String,
  draggable: {
    type: Boolean,
    default: void 0
  },
  enterkeyhint: String,
  exportparts: String,
  hidden: {
    type: Boolean,
    default: void 0
  },
  id: String,
  inputmode: String,
  is: String,
  itemid: String,
  itemprop: String,
  itemref: String,
  itemscope: String,
  itemtype: String,
  lang: String,
  nonce: String,
  part: String,
  slot: String,
  spellcheck: {
    type: Boolean,
    default: void 0
  },
  style: String,
  tabindex: String,
  title: String,
  translate: String
};
const Script = defineComponent({
  name: "Script",
  inheritAttrs: false,
  props: {
    ...globalProps,
    async: Boolean,
    crossorigin: {
      type: [Boolean, String],
      default: void 0
    },
    defer: Boolean,
    fetchpriority: String,
    integrity: String,
    nomodule: Boolean,
    nonce: String,
    referrerpolicy: String,
    src: String,
    type: String,
    charset: String,
    language: String
  },
  setup: setupForUseMeta((script) => ({
    script: [script]
  }))
});
const NoScript = defineComponent({
  name: "NoScript",
  inheritAttrs: false,
  props: {
    ...globalProps,
    title: String
  },
  setup: setupForUseMeta((props2, { slots }) => {
    var _a;
    const noscript = { ...props2 };
    const textContent = (((_a = slots.default) == null ? void 0 : _a.call(slots)) || []).filter(({ children }) => children).map(({ children }) => children).join("");
    if (textContent) {
      noscript.children = textContent;
    }
    return {
      noscript: [noscript]
    };
  })
});
const Link = defineComponent({
  name: "Link",
  inheritAttrs: false,
  props: {
    ...globalProps,
    as: String,
    crossorigin: String,
    disabled: Boolean,
    fetchpriority: String,
    href: String,
    hreflang: String,
    imagesizes: String,
    imagesrcset: String,
    integrity: String,
    media: String,
    prefetch: {
      type: Boolean,
      default: void 0
    },
    referrerpolicy: String,
    rel: String,
    sizes: String,
    title: String,
    type: String,
    methods: String,
    target: String
  },
  setup: setupForUseMeta((link) => ({
    link: [link]
  }))
});
const Base = defineComponent({
  name: "Base",
  inheritAttrs: false,
  props: {
    ...globalProps,
    href: String,
    target: String
  },
  setup: setupForUseMeta((base) => ({
    base
  }))
});
const Title = defineComponent({
  name: "Title",
  inheritAttrs: false,
  setup: setupForUseMeta((_, { slots }) => {
    var _a, _b, _c;
    const title = ((_c = (_b = (_a = slots.default) == null ? void 0 : _a.call(slots)) == null ? void 0 : _b[0]) == null ? void 0 : _c.children) || null;
    return {
      title
    };
  })
});
const Meta = defineComponent({
  name: "Meta",
  inheritAttrs: false,
  props: {
    ...globalProps,
    charset: String,
    content: String,
    httpEquiv: String,
    name: String
  },
  setup: setupForUseMeta((props2) => {
    const meta2 = { ...props2 };
    if (meta2.httpEquiv) {
      meta2["http-equiv"] = meta2.httpEquiv;
      delete meta2.httpEquiv;
    }
    return {
      meta: [meta2]
    };
  })
});
const Style = defineComponent({
  name: "Style",
  inheritAttrs: false,
  props: {
    ...globalProps,
    type: String,
    media: String,
    nonce: String,
    title: String,
    scoped: {
      type: Boolean,
      default: void 0
    }
  },
  setup: setupForUseMeta((props2, { slots }) => {
    var _a, _b, _c;
    const style = { ...props2 };
    const textContent = (_c = (_b = (_a = slots.default) == null ? void 0 : _a.call(slots)) == null ? void 0 : _b[0]) == null ? void 0 : _c.children;
    if (textContent) {
      style.children = textContent;
    }
    return {
      style: [style]
    };
  })
});
const Head = defineComponent({
  name: "Head",
  inheritAttrs: false,
  setup: (_props, ctx) => () => {
    var _a, _b;
    return (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a);
  }
});
const Html = defineComponent({
  name: "Html",
  inheritAttrs: false,
  props: {
    ...globalProps,
    manifest: String,
    version: String,
    xmlns: String
  },
  setup: setupForUseMeta((htmlAttrs) => ({ htmlAttrs }), true)
});
const Body = defineComponent({
  name: "Body",
  inheritAttrs: false,
  props: globalProps,
  setup: setupForUseMeta((bodyAttrs) => ({ bodyAttrs }), true)
});
const Components = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Script,
  NoScript,
  Link,
  Base,
  Title,
  Meta,
  Style,
  Head,
  Html,
  Body
}, Symbol.toStringTag, { value: "Module" }));
const appHead = { "meta": [], "link": [], "style": [], "script": [], "noscript": [], "charset": "utf-8", "viewport": "width=device-width, initial-scale=1" };
const appLayoutTransition = { "name": "layout", "mode": "out-in" };
const appPageTransition = { "name": "page", "mode": "out-in" };
const appKeepalive = false;
const metaMixin = {
  created() {
    const instance = getCurrentInstance();
    if (!instance) {
      return;
    }
    const options2 = instance.type;
    if (!options2 || !("head" in options2)) {
      return;
    }
    const nuxtApp = useNuxtApp();
    const source = typeof options2.head === "function" ? computed(() => options2.head(nuxtApp)) : options2.head;
    useHead(source);
  }
};
const node_modules_nuxt_dist_head_runtime_plugin_mjs_1QO0gqa6n2 = defineNuxtPlugin((nuxtApp) => {
  useHead(markRaw({ title: "", ...appHead }));
  nuxtApp.vueApp.mixin(metaMixin);
  for (const name in Components) {
    nuxtApp.vueApp.component(name, Components[name]);
  }
});
const interpolatePath = (route, match) => {
  return match.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
    var _a;
    return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
  });
};
const generateRouteKey = (override, routeProps) => {
  var _a;
  const matchedRoute = routeProps.route.matched.find((m) => {
    var _a2;
    return ((_a2 = m.components) == null ? void 0 : _a2.default) === routeProps.Component.type;
  });
  const source = (_a = override != null ? override : matchedRoute == null ? void 0 : matchedRoute.meta.key) != null ? _a : matchedRoute && interpolatePath(routeProps.route, matchedRoute);
  return typeof source === "function" ? source(routeProps.route) : source;
};
const wrapInKeepAlive = (props2, children) => {
  return { default: () => children };
};
const Fragment = defineComponent({
  setup(_props, { slots }) {
    return () => {
      var _a;
      return (_a = slots.default) == null ? void 0 : _a.call(slots);
    };
  }
});
const _wrapIf = (component, props2, slots) => {
  return { default: () => props2 ? h(component, props2 === true ? {} : props2, slots) : h(Fragment, {}, slots) };
};
const isNestedKey = Symbol("isNested");
const NuxtPage = defineComponent({
  name: "NuxtPage",
  inheritAttrs: false,
  props: {
    name: {
      type: String
    },
    transition: {
      type: [Boolean, Object],
      default: void 0
    },
    keepalive: {
      type: [Boolean, Object],
      default: void 0
    },
    route: {
      type: Object
    },
    pageKey: {
      type: [Function, String],
      default: null
    }
  },
  setup(props2, { attrs }) {
    const nuxtApp = useNuxtApp();
    const isNested = inject(isNestedKey, false);
    provide(isNestedKey, true);
    return () => {
      return h(RouterView, { name: props2.name, route: props2.route, ...attrs }, {
        default: (routeProps) => {
          var _a, _b, _c, _d;
          if (!routeProps.Component) {
            return;
          }
          const key = generateRouteKey(props2.pageKey, routeProps);
          const transitionProps = (_b = (_a = props2.transition) != null ? _a : routeProps.route.meta.pageTransition) != null ? _b : appPageTransition;
          return _wrapIf(
            Transition,
            transitionProps,
            wrapInKeepAlive(
              (_d = (_c = props2.keepalive) != null ? _c : routeProps.route.meta.keepalive) != null ? _d : appKeepalive,
              isNested && nuxtApp.isHydrating ? h(Component, { key, routeProps, pageKey: key, hasTransition: !!transitionProps }) : h(Suspense, {
                onPending: () => nuxtApp.callHook("page:start", routeProps.Component),
                onResolve: () => nuxtApp.callHook("page:finish", routeProps.Component)
              }, { default: () => h(Component, { key, routeProps, pageKey: key, hasTransition: !!transitionProps }) })
            )
          ).default();
        }
      });
    };
  }
});
const Component = defineComponent({
  props: ["routeProps", "pageKey", "hasTransition"],
  setup(props2) {
    const previousKey = props2.pageKey;
    const previousRoute = props2.routeProps.route;
    const route = {};
    for (const key in props2.routeProps.route) {
      route[key] = computed(() => previousKey === props2.pageKey ? props2.routeProps.route[key] : previousRoute[key]);
    }
    provide("_route", reactive(route));
    return () => {
      return h(props2.routeProps.Component);
    };
  }
});
const useToast = () => {
  return {
    success: () => {
    },
    error: () => {
    },
    info: () => {
    },
    warning: () => {
    }
  };
};
const isVue2 = false;
/*!
  * pinia v2.0.23
  * (c) 2022 Eduardo San Martin Morote
  * @license MIT
  */
let activePinia;
const setActivePinia = (pinia) => activePinia = pinia;
const piniaSymbol = Symbol();
function isPlainObject(o) {
  return o && typeof o === "object" && Object.prototype.toString.call(o) === "[object Object]" && typeof o.toJSON !== "function";
}
var MutationType;
(function(MutationType2) {
  MutationType2["direct"] = "direct";
  MutationType2["patchObject"] = "patch object";
  MutationType2["patchFunction"] = "patch function";
})(MutationType || (MutationType = {}));
function createPinia() {
  const scope = effectScope(true);
  const state = scope.run(() => ref({}));
  let _p = [];
  let toBeInstalled = [];
  const pinia = markRaw({
    install(app) {
      setActivePinia(pinia);
      {
        pinia._a = app;
        app.provide(piniaSymbol, pinia);
        app.config.globalProperties.$pinia = pinia;
        toBeInstalled.forEach((plugin2) => _p.push(plugin2));
        toBeInstalled = [];
      }
    },
    use(plugin2) {
      if (!this._a && !isVue2) {
        toBeInstalled.push(plugin2);
      } else {
        _p.push(plugin2);
      }
      return this;
    },
    _p,
    _a: null,
    _e: scope,
    _s: /* @__PURE__ */ new Map(),
    state
  });
  return pinia;
}
const noop = () => {
};
function addSubscription(subscriptions, callback, detached, onCleanup = noop) {
  subscriptions.push(callback);
  const removeSubscription = () => {
    const idx = subscriptions.indexOf(callback);
    if (idx > -1) {
      subscriptions.splice(idx, 1);
      onCleanup();
    }
  };
  if (!detached && getCurrentInstance()) {
    onUnmounted(removeSubscription);
  }
  return removeSubscription;
}
function triggerSubscriptions(subscriptions, ...args) {
  subscriptions.slice().forEach((callback) => {
    callback(...args);
  });
}
function mergeReactiveObjects(target, patchToApply) {
  if (target instanceof Map && patchToApply instanceof Map) {
    patchToApply.forEach((value, key) => target.set(key, value));
  }
  if (target instanceof Set && patchToApply instanceof Set) {
    patchToApply.forEach(target.add, target);
  }
  for (const key in patchToApply) {
    if (!patchToApply.hasOwnProperty(key))
      continue;
    const subPatch = patchToApply[key];
    const targetValue = target[key];
    if (isPlainObject(targetValue) && isPlainObject(subPatch) && target.hasOwnProperty(key) && !isRef(subPatch) && !isReactive(subPatch)) {
      target[key] = mergeReactiveObjects(targetValue, subPatch);
    } else {
      target[key] = subPatch;
    }
  }
  return target;
}
const skipHydrateSymbol = Symbol();
function shouldHydrate(obj) {
  return !isPlainObject(obj) || !obj.hasOwnProperty(skipHydrateSymbol);
}
const { assign } = Object;
function isComputed(o) {
  return !!(isRef(o) && o.effect);
}
function createOptionsStore(id, options2, pinia, hot) {
  const { state, actions, getters } = options2;
  const initialState = pinia.state.value[id];
  let store;
  function setup() {
    if (!initialState && (!("production" !== "production") )) {
      {
        pinia.state.value[id] = state ? state() : {};
      }
    }
    const localState = toRefs(pinia.state.value[id]);
    return assign(localState, actions, Object.keys(getters || {}).reduce((computedGetters, name) => {
      computedGetters[name] = markRaw(computed(() => {
        setActivePinia(pinia);
        const store2 = pinia._s.get(id);
        return getters[name].call(store2, store2);
      }));
      return computedGetters;
    }, {}));
  }
  store = createSetupStore(id, setup, options2, pinia, hot, true);
  store.$reset = function $reset() {
    const newState = state ? state() : {};
    this.$patch(($state) => {
      assign($state, newState);
    });
  };
  return store;
}
function createSetupStore($id, setup, options2 = {}, pinia, hot, isOptionsStore) {
  let scope;
  const optionsForPlugin = assign({ actions: {} }, options2);
  const $subscribeOptions = {
    deep: true
  };
  let isListening;
  let isSyncListening;
  let subscriptions = markRaw([]);
  let actionSubscriptions = markRaw([]);
  let debuggerEvents;
  const initialState = pinia.state.value[$id];
  if (!isOptionsStore && !initialState && (!("production" !== "production") )) {
    {
      pinia.state.value[$id] = {};
    }
  }
  ref({});
  let activeListener;
  function $patch(partialStateOrMutator) {
    let subscriptionMutation;
    isListening = isSyncListening = false;
    if (typeof partialStateOrMutator === "function") {
      partialStateOrMutator(pinia.state.value[$id]);
      subscriptionMutation = {
        type: MutationType.patchFunction,
        storeId: $id,
        events: debuggerEvents
      };
    } else {
      mergeReactiveObjects(pinia.state.value[$id], partialStateOrMutator);
      subscriptionMutation = {
        type: MutationType.patchObject,
        payload: partialStateOrMutator,
        storeId: $id,
        events: debuggerEvents
      };
    }
    const myListenerId = activeListener = Symbol();
    nextTick().then(() => {
      if (activeListener === myListenerId) {
        isListening = true;
      }
    });
    isSyncListening = true;
    triggerSubscriptions(subscriptions, subscriptionMutation, pinia.state.value[$id]);
  }
  const $reset = noop;
  function $dispose() {
    scope.stop();
    subscriptions = [];
    actionSubscriptions = [];
    pinia._s.delete($id);
  }
  function wrapAction(name, action) {
    return function() {
      setActivePinia(pinia);
      const args = Array.from(arguments);
      const afterCallbackList = [];
      const onErrorCallbackList = [];
      function after(callback) {
        afterCallbackList.push(callback);
      }
      function onError(callback) {
        onErrorCallbackList.push(callback);
      }
      triggerSubscriptions(actionSubscriptions, {
        args,
        name,
        store,
        after,
        onError
      });
      let ret;
      try {
        ret = action.apply(this && this.$id === $id ? this : store, args);
      } catch (error2) {
        triggerSubscriptions(onErrorCallbackList, error2);
        throw error2;
      }
      if (ret instanceof Promise) {
        return ret.then((value) => {
          triggerSubscriptions(afterCallbackList, value);
          return value;
        }).catch((error2) => {
          triggerSubscriptions(onErrorCallbackList, error2);
          return Promise.reject(error2);
        });
      }
      triggerSubscriptions(afterCallbackList, ret);
      return ret;
    };
  }
  const partialStore = {
    _p: pinia,
    $id,
    $onAction: addSubscription.bind(null, actionSubscriptions),
    $patch,
    $reset,
    $subscribe(callback, options3 = {}) {
      const removeSubscription = addSubscription(subscriptions, callback, options3.detached, () => stopWatcher());
      const stopWatcher = scope.run(() => watch(() => pinia.state.value[$id], (state) => {
        if (options3.flush === "sync" ? isSyncListening : isListening) {
          callback({
            storeId: $id,
            type: MutationType.direct,
            events: debuggerEvents
          }, state);
        }
      }, assign({}, $subscribeOptions, options3)));
      return removeSubscription;
    },
    $dispose
  };
  const store = reactive(partialStore);
  pinia._s.set($id, store);
  const setupStore = pinia._e.run(() => {
    scope = effectScope();
    return scope.run(() => setup());
  });
  for (const key in setupStore) {
    const prop = setupStore[key];
    if (isRef(prop) && !isComputed(prop) || isReactive(prop)) {
      if (!isOptionsStore) {
        if (initialState && shouldHydrate(prop)) {
          if (isRef(prop)) {
            prop.value = initialState[key];
          } else {
            mergeReactiveObjects(prop, initialState[key]);
          }
        }
        {
          pinia.state.value[$id][key] = prop;
        }
      }
    } else if (typeof prop === "function") {
      const actionValue = wrapAction(key, prop);
      {
        setupStore[key] = actionValue;
      }
      optionsForPlugin.actions[key] = prop;
    } else ;
  }
  {
    assign(store, setupStore);
    assign(toRaw(store), setupStore);
  }
  Object.defineProperty(store, "$state", {
    get: () => pinia.state.value[$id],
    set: (state) => {
      $patch(($state) => {
        assign($state, state);
      });
    }
  });
  pinia._p.forEach((extender) => {
    {
      assign(store, scope.run(() => extender({
        store,
        app: pinia._a,
        pinia,
        options: optionsForPlugin
      })));
    }
  });
  if (initialState && isOptionsStore && options2.hydrate) {
    options2.hydrate(store.$state, initialState);
  }
  isListening = true;
  isSyncListening = true;
  return store;
}
function defineStore(idOrOptions, setup, setupOptions) {
  let id;
  let options2;
  const isSetupStore = typeof setup === "function";
  if (typeof idOrOptions === "string") {
    id = idOrOptions;
    options2 = isSetupStore ? setupOptions : setup;
  } else {
    options2 = idOrOptions;
    id = idOrOptions.id;
  }
  function useStore(pinia, hot) {
    const currentInstance = getCurrentInstance();
    pinia = (pinia) || currentInstance && inject(piniaSymbol);
    if (pinia)
      setActivePinia(pinia);
    pinia = activePinia;
    if (!pinia._s.has(id)) {
      if (isSetupStore) {
        createSetupStore(id, setup, options2, pinia);
      } else {
        createOptionsStore(id, options2, pinia);
      }
    }
    const store = pinia._s.get(id);
    return store;
  }
  useStore.$id = id;
  return useStore;
}
function storeToRefs(store) {
  {
    store = toRaw(store);
    const refs = {};
    for (const key in store) {
      const value = store[key];
      if (isRef(value) || isReactive(value)) {
        refs[key] = toRef(store, key);
      }
    }
    return refs;
  }
}
const useAuthStore = defineStore("authStore", {
  state: () => ({
    authenticated: false,
    userData: {},
    userType: null,
    accessToken: null
  }),
  actions: {
    async initAuth() {
      const config2 = useRuntimeConfig();
      try {
        const token = useCookie("access-token").value || null;
        if (token) {
          this.accessToken = token;
          const res = await $fetch("/auth/user", {
            baseURL: config2.public.baseURL,
            headers: {
              Authorization: `Bearer ${token}`
            }
          });
          if (res) {
            this.userData = res.user;
            this.userType = res.type;
            this.authenticated = true;
          }
        }
        return true;
      } catch (e) {
        useCookie("access-token").value = null;
      }
    },
    async registerVolunteer(volunteer) {
      const { useMyFetch } = useApiFetch();
      const router = useRouter();
      const { data, error: error2 } = await useMyFetch("/volunteers/register", {
        key: "register-volunteer",
        method: "POST",
        body: volunteer
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        const { $i18n } = useNuxtApp();
        toast.success(data == null ? void 0 : data.value.message);
        toast.success($i18n.translate("Please verify your email"));
        router.push("/volunteers/auth/login");
      }
      return { error: error2 };
    },
    async loginVolunteer(volunteer) {
      const { useMyFetch } = useApiFetch();
      const router = useRouter();
      const redirectTo = `/volunteers/`;
      const { data, error: error2 } = await useMyFetch("/volunteers/login", {
        key: "login-volunteer",
        method: "POST",
        body: volunteer
      });
      if (data == null ? void 0 : data.value) {
        this.authenticated = true;
        this.userData = data.value.userData;
        this.userType = "volunteer";
        this.accessToken = data.value.accessToken;
        useCookie("access-token").value = data.value.accessToken;
        router.push(redirectTo);
      }
      return { error: error2 };
    },
    async registerSubscriber(subscriber) {
      const { useMyFetch } = useApiFetch();
      const router = useRouter();
      const { data, error: error2 } = await useMyFetch("/subscribers/register", {
        key: "register-subscriber",
        method: "POST",
        body: subscriber
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        const { $i18n } = useNuxtApp();
        toast.success(data == null ? void 0 : data.value.message);
        toast.success($i18n.translate("Please verify your email"));
        router.push("/subscribers/auth/login");
      }
      return { error: error2 };
    },
    async loginSubscriber(subscriber) {
      const { useMyFetch } = useApiFetch();
      const router = useRouter();
      const redirectTo = `/subscribers/`;
      const { data, error: error2 } = await useMyFetch("/subscribers/login", {
        key: "login-subscriber",
        method: "POST",
        body: subscriber
      });
      if (data == null ? void 0 : data.value) {
        this.authenticated = true;
        this.userData = data.value.userData;
        this.userType = "subscriber";
        this.accessToken = data.value.accessToken;
        useCookie("access-token").value = data.value.accessToken;
        router.push(redirectTo);
      }
      return { error: error2 };
    },
    async registerMember(member) {
      const { useMyFetch } = useApiFetch();
      const router = useRouter();
      const { data, error: error2 } = await useMyFetch("/members/register", {
        key: "register-member",
        method: "POST",
        body: member
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        const { $i18n } = useNuxtApp();
        toast.success(data == null ? void 0 : data.value.message);
        toast.success($i18n.translate("Please verify your mobile"));
        router.push(`/members/auth/verify?mobile=${member.contactInfo.mobile}`);
      }
      return { error: error2 };
    },
    async loginMember(member) {
      const { useMyFetch } = useApiFetch();
      const router = useRouter();
      const redirectTo = `/members/`;
      const { data, error: error2 } = await useMyFetch("/members/login", {
        key: "login-member",
        method: "POST",
        body: member
      });
      if (data == null ? void 0 : data.value) {
        this.authenticated = true;
        this.userData = data.value.userData;
        this.userType = "member";
        this.accessToken = data.value.accessToken;
        useCookie("access-token").value = data.value.accessToken;
        router.push(redirectTo);
      }
      return { error: error2 };
    },
    async resendVerification(resend_url) {
      if (resend_url) {
        const { useMyFetch } = useApiFetch();
        const { data, error: error2 } = await useMyFetch(resend_url, {
          key: "resend-verification",
          method: "POST"
        });
        if (data == null ? void 0 : data.value) {
          const toast = useToast();
          toast.success(data == null ? void 0 : data.value.message);
        }
        return { error: error2 };
      }
    },
    async resendMobileVerification(mobile) {
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch(`/members/resend/${mobile}`, {
        key: "resend-mobile-verification",
        method: "POST"
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success(data == null ? void 0 : data.value.message);
      }
      return { error: error2 };
    },
    async verifyMobile(mobile, code) {
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch(`/members/verify/${mobile}/${code}`, {
        key: "verify-mobile",
        method: "POST"
      });
      const toast = useToast();
      const router = useRouter();
      if (data == null ? void 0 : data.value) {
        toast.success(data == null ? void 0 : data.value.message);
        router.push("/members/auth/login");
      }
      return { error: error2 };
    },
    async logout() {
      const { useMyFetch } = useApiFetch();
      const router = useRouter();
      const redirectTo = this.userType ? `/${this.userType}s/auth/login` : "/";
      await useMyFetch("/auth/logout", {
        key: "logout",
        method: "POST"
      });
      useCookie("access-token").value = null;
      this.userData = {};
      this.userType = null;
      this.accessToken = null;
      this.authenticated = false;
      router.push(redirectTo);
    },
    async sendForgotPasswordLink(body) {
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch(`/forgot-password/${body.userType}`, {
        key: "forgot-password",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success(data == null ? void 0 : data.value.message);
      }
      return { error: error2 };
    },
    async resetPassword(body) {
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch(`/reset-password/${body.userType}`, {
        key: "forgot-password",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        const router = useRouter();
        toast.success(data == null ? void 0 : data.value.message);
        router.push(`/${body.userType}s/auth/login`);
      }
      return { error: error2 };
    }
  }
});
const useHomeStore = defineStore("homeStore", {
  state: () => ({
    darkMode: useCookie("darkMode").value || false,
    mediacenter: [],
    studio: [],
    events: [],
    stats: [],
    loading: false
  }),
  actions: {
    async fetchHomeData() {
      const { useMyFetch } = useApiFetch();
      const { data } = await useMyFetch("/home", {
        key: "home-data"
      });
      const { mediacenter, studio, events, stats } = (data == null ? void 0 : data.value) || {};
      this.mediacenter = mediacenter;
      this.studio = studio;
      this.events = events;
      this.stats = stats;
    },
    toggleDarkMode() {
      this.darkMode = !this.darkMode;
      useCookie("darkMode").value = this.darkMode;
      const locale = useCookie("locale").value || "ar";
      useHead({
        bodyAttrs: {
          class: `${locale == "ar" ? "rtl" : "ltr"} ${this.darkMode ? "dark" : ""} [&.dark]:bg-sjud-500`
        }
      });
    }
  }
});
const useApiFetch = () => {
  const { $i18n } = useNuxtApp();
  const toast = useToast();
  const config2 = useRuntimeConfig();
  const useMyFetch = async (url, options2 = {}) => {
    useHomeStore().loading = true;
    const authStore = useAuthStore();
    const fetched = await useFetch(url, {
      baseURL: config2.public.baseURL,
      headers: {
        "Accept-Language": $i18n.locale,
        Accept: "application/json",
        "Cache-Control": "no-cache",
        Authorization: `Bearer ${authStore.accessToken}`
      },
      initialCache: false,
      credentials: "include",
      async onResponseError({ request, response, options: options3 }) {
        if (response.status == 403) {
          toast.error($i18n.translate("Error occured. Refresh the page and if problem resists contact us!"));
        }
      },
      ...options2
    }, "$5hFx8z1oTU");
    useHomeStore().loading = false;
    return fetched;
  };
  const useFetchCookies = async () => {
    await $fetch(`${config2.public.homeBase}/sanctum/csrf-cookie`, {
      credentials: "include"
    });
  };
  return {
    useMyFetch,
    useFetchCookies
  };
};
const useEventStore = defineStore("eventStore", {
  state: () => ({
    events: [],
    type: "upcoming",
    pagination: {
      current_page: 1,
      perPage: 18
    },
    event: {},
    upcomingEvents: [],
    questionnaire: {},
    questions: []
  }),
  getters: {
    getType: (state) => {
      return () => useRoute().query.type || state.type;
    },
    getPagination: (state) => {
      return () => {
        const current_page = useRoute().query.page || 1;
        const pagination = {
          ...state.pagination,
          current_page
        };
        return pagination;
      };
    }
  },
  actions: {
    async fetchEvents() {
      var _a, _b, _c, _d, _e, _f;
      this.pagination = {
        current_page: 1,
        perPage: 18
      };
      const { useMyFetch } = useApiFetch();
      const { data, error: error2, refresh } = await useMyFetch(
        `/events?page=${this.getPagination().current_page}&perPage=${this.pagination.perPage}&type=${this.getType()}`,
        {
          key: "events"
        }
      );
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.events = data.value.data;
      this.pagination = { ...this.pagination, ...data.value.meta };
    },
    async fetchEvent(id) {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const {
        data = {},
        error: error2,
        refresh
      } = await useMyFetch(`/events/${id}`, {
        key: "event"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.event = data.value.event;
      this.upcomingEvents = data.value.events;
    },
    async enrollEvent(id) {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const {
        data = {},
        error: error2,
        refresh
      } = await useMyFetch(`/events/${id}`, {
        method: "POST",
        key: "event"
      });
      const toast = useToast();
      if ((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message) {
        toast.success((_b = data == null ? void 0 : data.value) == null ? void 0 : _b.message);
        const router = useRouter();
        const authStore = useAuthStore();
        router.push(`/${authStore.userType}s/dashboard`);
      }
      if (((_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status) === 422) {
        toast.error((_f = (_e = error2.value) == null ? void 0 : _e.data) == null ? void 0 : _f.message);
      }
    },
    async attendEvent(id) {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const {
        data = {},
        error: error2,
        refresh
      } = await useMyFetch(`/events/${id}/attend`, {
        method: "POST",
        key: "event"
      });
      const toast = useToast();
      if ((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message) {
        const toast2 = useToast();
        toast2.success((_b = data == null ? void 0 : data.value) == null ? void 0 : _b.message);
        const router = useRouter();
        const authStore = useAuthStore();
        router.push(`/${authStore.userType}s/dashboard`);
      }
      if (((_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status) === 422) {
        toast.error((_f = (_e = error2.value) == null ? void 0 : _e.data) == null ? void 0 : _f.message);
      }
    },
    async getCertificate(eventId) {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const {
        data = {},
        error: error2,
        refresh
      } = await useMyFetch(`/events/${eventId}/certificate`, {
        key: "event-certificate"
      });
      const toast = useToast();
      const router = useRouter();
      const authStore = useAuthStore();
      if (data == null ? void 0 : data.value) {
        const { type } = data.value;
        if (type === "questionnaire") {
          router.push(`/${authStore.userType}s/dashboard/questionnaire/${eventId}/${data.value.id}`);
        } else if (type === "certificate") {
          window.location = data.value.certificate;
        }
      }
      if (error2 == null ? void 0 : error2.value) {
        toast.error((_b = (_a = error2.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message);
      }
    },
    async getQuestionnaire(eventId, questionnaireId) {
      var _a, _b, _c, _d;
      const { useMyFetch } = useApiFetch();
      const {
        data = {},
        error: error2,
        refresh
      } = await useMyFetch(`/questionnaires/${eventId}/${questionnaireId}`, {
        key: "event-questionnaire"
      });
      const toast = useToast();
      if (data == null ? void 0 : data.value) {
        this.questionnaire = data.value.questionnaire;
        this.questions = data.value.questionnaire.questions;
      }
      if ((_b = (_a = error2.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) {
        toast.error((_d = (_c = error2.value) == null ? void 0 : _c.data) == null ? void 0 : _d.message);
      }
    },
    async submitQuestionnaire(eventId, questionnaireId, questionnaire) {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const router = useRouter();
      const authStore = useAuthStore();
      const {
        data = {},
        error: error2,
        refresh
      } = await useMyFetch(`/questionnaires/${eventId}/${questionnaireId}`, {
        key: "post-questionnaire",
        method: "POST",
        body: {
          questionnaire
        }
      });
      const toast = useToast();
      if ((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message) {
        toast.success((_b = data == null ? void 0 : data.value) == null ? void 0 : _b.message);
        router.push(`/${authStore.userType}s/dashboard`);
      }
      if ((_d = (_c = error2.value) == null ? void 0 : _c.data) == null ? void 0 : _d.message) {
        toast.error((_f = (_e = error2.value) == null ? void 0 : _e.data) == null ? void 0 : _f.message);
      }
    },
    async validateCertificate(code) {
      var _a, _b, _c, _d;
      const { useMyFetch } = useApiFetch();
      useRouter();
      useAuthStore();
      const {
        data = {},
        error: error2,
        refresh
      } = await useMyFetch(`/certificate/${code}`, {
        key: "validate-certificate"
      });
      const toast = useToast();
      if (data == null ? void 0 : data.value) {
        const { type } = data.value;
        if (type === "certificate") {
          window.location = data.value.certificate;
        }
      }
      if ((_b = (_a = error2.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) {
        toast.error((_d = (_c = error2.value) == null ? void 0 : _c.data) == null ? void 0 : _d.message);
      }
    }
  }
});
const meta$T = void 0;
const useFormating = () => {
  const { $i18n } = useNuxtApp();
  return {
    formattedDate: (date) => {
      const itemDate = new Date(date);
      const day = itemDate.toLocaleDateString($i18n.locale, { weekday: "long" });
      return `${day} ${itemDate.toLocaleDateString("ar-US")}`;
    },
    formattedTime: (timeString) => {
      const [hourString, minute] = timeString.split(":");
      const hour = +hourString % 24;
      return (hour % 12 || 12) + ":" + minute + (hour < 12 ? " \u0635\u0628\u0627\u062D\u064B\u0627" : " \u0645\u0633\u0627\u0621\u064B");
    }
  };
};
const _sfc_main$b = {
  __name: "PageHeader",
  __ssrInlineRender: true,
  props: {
    title: String,
    breadcrumb: Array,
    date: String
  },
  setup(__props) {
    const route = useRoute();
    useNuxtApp();
    const { formattedDate } = useFormating();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-sju-50 text-white py-8" }, _attrs))}><div class="container"><nav aria-label="breadcrumb"><ul class="breadcrumb py-3 px-3 mb-4"><!--[-->`);
      ssrRenderList(__props.breadcrumb, (page) => {
        _push(`<li class="inline-block pl-2 rtl:pl-0 rtl:pr-2 before:content-[&#39;/&#39;] first:before:content-[&#39;&#39;] before:pr-2 rtl:before:pr-0 rtl:before:pl-2">`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: page.link
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(page.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(page.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></nav><h3>${ssrInterpolate(__props.title)}</h3><div class="flex gap-3 mt-5 text-sm">`);
      if (__props.date) {
        _push(`<span class="date">${ssrInterpolate(unref(formattedDate)(__props.date))}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: unref(route).fullPath,
        target: "_blank"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg id="share" xmlns="http://www.w3.org/2000/svg" width="16.412" height="16.412" viewBox="0 0 16.412 16.412"${_scopeId}><path id="Path_97" data-name="Path 97" d="M162.223,0h-4.261a.427.427,0,1,0,0,.855H161.2l-8.313,8.393a.427.427,0,0,0,.607.6l8.3-8.383V4.689a.427.427,0,1,0,.855,0V.427A.427.427,0,0,0,162.223,0Zm0,0" transform="translate(-146.238)" fill="#fff"${_scopeId}></path><path id="Path_98" data-name="Path 98" d="M13.853,56.9a.427.427,0,0,0-.427.427v4.68a1.284,1.284,0,0,1-1.282,1.282H2.137A1.284,1.284,0,0,1,.855,62.007V52a1.284,1.284,0,0,1,1.282-1.282h4.68a.427.427,0,1,0,0-.855H2.137A2.139,2.139,0,0,0,0,52V62.007a2.139,2.139,0,0,0,2.137,2.137H12.144a2.139,2.139,0,0,0,2.137-2.137v-4.68A.427.427,0,0,0,13.853,56.9Zm0,0" transform="translate(0 -47.732)" fill="#fff"${_scopeId}></path></svg>`);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                id: "share",
                xmlns: "http://www.w3.org/2000/svg",
                width: "16.412",
                height: "16.412",
                viewBox: "0 0 16.412 16.412"
              }, [
                createVNode("path", {
                  id: "Path_97",
                  "data-name": "Path 97",
                  d: "M162.223,0h-4.261a.427.427,0,1,0,0,.855H161.2l-8.313,8.393a.427.427,0,0,0,.607.6l8.3-8.383V4.689a.427.427,0,1,0,.855,0V.427A.427.427,0,0,0,162.223,0Zm0,0",
                  transform: "translate(-146.238)",
                  fill: "#fff"
                }),
                createVNode("path", {
                  id: "Path_98",
                  "data-name": "Path 98",
                  d: "M13.853,56.9a.427.427,0,0,0-.427.427v4.68a1.284,1.284,0,0,1-1.282,1.282H2.137A1.284,1.284,0,0,1,.855,62.007V52a1.284,1.284,0,0,1,1.282-1.282h4.68a.427.427,0,1,0,0-.855H2.137A2.139,2.139,0,0,0,0,52V62.007a2.139,2.139,0,0,0,2.137,2.137H12.144a2.139,2.139,0,0,0,2.137-2.137v-4.68A.427.427,0,0,0,13.853,56.9Zm0,0",
                  transform: "translate(0 -47.732)",
                  fill: "#fff"
                })
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div><svg xmlns="http://www.w3.org/2000/svg" width="15.465" height="16.412" viewBox="0 0 15.465 16.412"><g id="pdf" transform="translate(0)"><g id="Group_59" data-name="Group 59" transform="translate(0)"><g id="Group_58" data-name="Group 58"><path id="Path_85" data-name="Path 85" d="M30.146,4.441,25.965.1a.316.316,0,0,0-.227-.1H19.506a1.266,1.266,0,0,0-1.265,1.264V5.681H15.715a.947.947,0,0,0-.946.946v4.736a.947.947,0,0,0,.946.946h2.525V15.15a1.265,1.265,0,0,0,1.265,1.262h9.464a1.265,1.265,0,0,0,1.265-1.261V4.66A.316.316,0,0,0,30.146,4.441ZM25.816.852l3.432,3.567H25.816Zm-10.1,10.826a.315.315,0,0,1-.315-.315V6.627a.315.315,0,0,1,.315-.315h8.523a.315.315,0,0,1,.315.315v4.736a.315.315,0,0,1-.315.315ZM29.6,15.151a.633.633,0,0,1-.634.63H19.506a.633.633,0,0,1-.634-.631V12.309h5.366a.947.947,0,0,0,.946-.946V6.627a.947.947,0,0,0-.946-.946H18.872V1.264a.634.634,0,0,1,.634-.633h5.679v4.1a.316.316,0,0,0,.316.316h4.1Z" transform="translate(-14.769)" fill="#fff"></path></g></g><g id="Group_61" data-name="Group 61" transform="translate(1.853 7.704)"><g id="Group_60" data-name="Group 60"><path id="Path_86" data-name="Path 86" d="M74.516,240.652a.711.711,0,0,0-.39-.265,3.185,3.185,0,0,0-.651-.041H72.6v2.711h.547v-1.023H73.5a3.123,3.123,0,0,0,.568-.039.793.793,0,0,0,.284-.129.743.743,0,0,0,.23-.267.884.884,0,0,0,.091-.42A.842.842,0,0,0,74.516,240.652Zm-.469.746a.359.359,0,0,1-.171.133,1.415,1.415,0,0,1-.433.043h-.3V240.8h.264a2.625,2.625,0,0,1,.394.019.378.378,0,0,1,.22.12.35.35,0,0,1,.087.244A.364.364,0,0,1,74.047,241.4Z" transform="translate(-72.596 -240.346)" fill="#fff"></path></g></g><g id="Group_63" data-name="Group 63" transform="translate(4.378 7.704)"><g id="Group_62" data-name="Group 62"><path id="Path_87" data-name="Path 87" d="M153.53,241.087a1.185,1.185,0,0,0-.259-.439.907.907,0,0,0-.409-.25,1.954,1.954,0,0,0-.516-.052h-1v2.711h1.03a1.655,1.655,0,0,0,.485-.057.962.962,0,0,0,.385-.216,1.2,1.2,0,0,0,.29-.479,1.782,1.782,0,0,0,.083-.577A2,2,0,0,0,153.53,241.087ZM153,242.2a.574.574,0,0,1-.143.262.505.505,0,0,1-.221.113,1.491,1.491,0,0,1-.331.026h-.409v-1.8h.246a2.48,2.48,0,0,1,.449.026.521.521,0,0,1,.253.128.62.62,0,0,1,.155.263,1.619,1.619,0,0,1,.055.483A1.769,1.769,0,0,1,153,242.2Z" transform="translate(-151.346 -240.346)" fill="#fff"></path></g></g><g id="Group_65" data-name="Group 65" transform="translate(7.118 7.704)"><g id="Group_64" data-name="Group 64"><path id="Path_88" data-name="Path 88" d="M238.7,240.8v-.459h-1.859v2.711h.547V241.9h1.132v-.459h-1.132V240.8Z" transform="translate(-236.846 -240.346)" fill="#fff"></path></g></g></g></svg></div><a href="#" onclick="window.print();"><svg xmlns="http://www.w3.org/2000/svg" width="16.412" height="16.412" viewBox="0 0 16.412 16.412"><g id="printer" transform="translate(0)"><path id="Path_89" data-name="Path 89" d="M14.7,14.206H12.651a.342.342,0,0,1,0-.684H14.7A1.027,1.027,0,0,0,15.728,12.5V7.71A1.027,1.027,0,0,0,14.7,6.684H1.71A1.027,1.027,0,0,0,.684,7.71V12.5A1.027,1.027,0,0,0,1.71,13.522H3.761a.342.342,0,0,1,0,.684H1.71A1.712,1.712,0,0,1,0,12.5V7.71A1.712,1.712,0,0,1,1.71,6H14.7a1.712,1.712,0,0,1,1.71,1.71V12.5A1.712,1.712,0,0,1,14.7,14.206Z" transform="translate(0 -1.897)" fill="#fff"></path><path id="Path_90" data-name="Path 90" d="M12.445,20.684h-4.1a.342.342,0,0,1,0-.684h4.1a.342.342,0,1,1,0,.684Z" transform="translate(-2.529 -6.323)" fill="#fff"></path><path id="Path_91" data-name="Path 91" d="M12.445,18.684h-4.1a.342.342,0,0,1,0-.684h4.1a.342.342,0,1,1,0,.684Z" transform="translate(-2.529 -5.691)" fill="#fff"></path><path id="Path_92" data-name="Path 92" d="M9.71,16.684H8.342a.342.342,0,0,1,0-.684H9.71a.342.342,0,1,1,0,.684Z" transform="translate(-2.529 -5.059)" fill="#fff"></path><path id="Path_93" data-name="Path 93" d="M14.232,4.787a.342.342,0,0,1-.342-.342V1.71A1.027,1.027,0,0,0,12.864.684H6.71A1.027,1.027,0,0,0,5.684,1.71V4.445a.342.342,0,1,1-.684,0V1.71A1.712,1.712,0,0,1,6.71,0h6.155a1.712,1.712,0,0,1,1.71,1.71V4.445A.342.342,0,0,1,14.232,4.787Z" transform="translate(-1.581)" fill="#fff"></path><path id="Path_94" data-name="Path 94" d="M12.864,20.522H6.71A1.712,1.712,0,0,1,5,18.813V13.342A.342.342,0,0,1,5.342,13h8.89a.342.342,0,0,1,.342.342v5.471A1.712,1.712,0,0,1,12.864,20.522Zm-7.18-6.838v5.129A1.027,1.027,0,0,0,6.71,19.838h6.155a1.027,1.027,0,0,0,1.026-1.026V13.684Z" transform="translate(-1.581 -4.11)" fill="#fff"></path></g></svg></a></div>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/PageHeader.vue");
  return _sfc_setup$b ? _sfc_setup$b(props2, ctx) : void 0;
};
const useLocalization = () => {
  const { $i18n } = useNuxtApp();
  const dblocalize = (obj, col) => {
    const locale = $i18n.locale;
    if (!obj)
      return false;
    if (locale === "en" && !obj[`${col}_${locale}`]) {
      return resolveAr(obj, col);
    }
    if (locale === "ar") {
      return resolveAr(obj, col);
    }
    return obj[`${col}_${locale}`];
  };
  const resolveAr = (obj, col) => {
    if (!obj.hasOwnProperty(`${col}_ar`)) {
      return obj[col];
    }
    return obj[`${col}_ar`];
  };
  return {
    dblocalize
  };
};
const _sfc_main$a = {
  __name: "EventPreview",
  __ssrInlineRender: true,
  props: ["event"],
  setup(__props) {
    const { dblocalize } = useLocalization();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex mb-4" }, _attrs))}><div class="bg-sju-50 text-white text-center flex-grow-0 py-5 px-10 w-28 flex justify-center items-center flex-col"><span class="font-bold text-4xl block">${ssrInterpolate(new Date(__props.event.date).getDate())}</span> ${ssrInterpolate(_ctx.$translate(new Date(__props.event.date).toLocaleString("default", { month: "long" })))}</div><h6 class="text-sju-50 bg-sju-500 flex-grow p-4 flex items-center dark:bg-sjud-100">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: `/events/${__props.event.id}/register`
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(dblocalize)(__props.event, "name"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(dblocalize)(__props.event, "name")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</h6></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/EventPreview.vue");
  return _sfc_setup$a ? _sfc_setup$a(props2, ctx) : void 0;
};
const meta$S = {
  key: (route) => route.fullPath,
  validate: async (route) => {
    return /^\d+$/.test(route.params.id);
  }
};
const meta$R = {
  key: (route) => route.fullPath,
  validate: async (route) => {
    return /^\d+$/.test(route.params.id);
  }
};
const _sfc_main$9 = {
  __name: "SimplePagination",
  __ssrInlineRender: true,
  props: ["pagination"],
  setup(__props) {
    const {
      pagination: { last_page, current_page }
    } = __props;
    const start = ref(null);
    const end = ref(null);
    const currentPage = ref(parseInt(current_page));
    if (last_page < 11) {
      start.value = 0;
      end.value = last_page;
    } else if (currentPage.value <= 6) {
      start.value = 0;
      end.value = 11;
    } else if (currentPage.value > 6 && currentPage.value < last_page - 6) {
      start.value = currentPage.value - 5;
      end.value = currentPage.value + 5;
    } else if (currentPage.value > 6 && currentPage.value >= last_page - 6) {
      start.value = last_page - 11;
      end.value = last_page;
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-sju-500 py-5 p-7 rounded-sm flex justify-end" }, _attrs))}><ul><!--[-->`);
      ssrRenderList(end.value - start.value, (page) => {
        _push(`<li class="${ssrRenderClass([{ active: currentPage.value == start.value + page }, "inline-block bg-white text-sju-50 py-1 px-2.5 mx-0.5 border transition hover:bg-sju-500 [&.active]:bg-sju-50 [&.active]:text-white cursor-pointer"])}">${ssrInterpolate(start.value + page)}</li>`);
      });
      _push(`<!--]--></ul></div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SimplePagination.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props2, ctx) : void 0;
};
const meta$Q = {
  key: (route) => route.fullPath
};
const _sfc_main$8 = {
  __name: "PostPreview",
  __ssrInlineRender: true,
  props: ["post"],
  setup(__props) {
    const { dblocalize } = useLocalization();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "h-64 w-full flex flex-col justify-between overflow-hidden",
        style: `background: linear-gradient(to bottom, transparent, rgba(0, 0, 0, 0.7)), url('${__props.post.photos[0] || "/images/noimage.jpg"}'); background-size: 100% 100%;`
      }, _attrs))}>`);
      if (__props.post.category) {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          class: "text-white bg-sju-50 text-xs py-2 px-3",
          to: `/posts?category=${__props.post.category.id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(unref(dblocalize)(__props.post.category, "title"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(unref(dblocalize)(__props.post.category, "title")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<div></div>`);
      }
      _push(`<div class="text-white px-2.5 pb-4">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: `/posts/${__props.post.id}`,
        class: "mb-1.5 block"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(dblocalize)(__props.post, "title"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(dblocalize)(__props.post, "title")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<span class="text-xs">${ssrInterpolate(__props.post.post_date)}</span></div></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/PostPreview.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props2, ctx) : void 0;
};
const _sfc_main$7 = {
  __name: "MediaCenter",
  __ssrInlineRender: true,
  props: ["posts"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_post_preview = _sfc_main$8;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "py-20 bg-sju-500 dark:bg-sjud-100" }, _attrs))}><div class="container"><div class="flex justify-between items-center"><h2 class="text-sju-50 text-3xl py-4 mb-2">${ssrInterpolate(_ctx.$translate("Media center"))}</h2>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/posts",
        class: "text-sju-50 text-sm"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("More"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("More")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-1 md:grid-cols-3 mt-3 gap-6 md:gap-8"><!--[-->`);
      ssrRenderList(__props.posts, (post) => {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_post_preview, { post }, null, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div></section>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/home/MediaCenter.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props2, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "Regulations",
  __ssrInlineRender: true,
  props: ["events"],
  setup(__props) {
    useLocalization();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_event_preview = _sfc_main$a;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "py-20" }, _attrs))}><div class="container px-2"><div class="flex flex-col md:flex-row md:space-x-8 rtl:space-x-reverse"><div class="md:w-7/12"><div class="flex justify-between items-center"><h2 class="text-sju-50 text-3xl py-4 mb-2">${ssrInterpolate(_ctx.$translate("Regulations and events"))}</h2><a href="#" class="text-sju-50 text-sm">${ssrInterpolate(_ctx.$translate("More"))}</a></div><div class="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8"><!--[-->`);
      ssrRenderList(3, (i2) => {
        _push(`<div class="bg-sju-500 py-9 px-4 text-center dark:bg-sjud-100"><svg xmlns="http://www.w3.org/2000/svg" width="84.001" height="83.183" viewBox="0 0 84.001 83.183" class="mx-auto"><g id="paper_1_" data-name="paper (1)" transform="translate(0 -2.493)"><path id="Path_7" data-name="Path 7" d="M83.309,12.686,73.392,3.229a2.012,2.012,0,0,0-1.5-.736H32.173a2.107,2.107,0,0,0-2.1,2.1v6.461l-14,2.4a2.074,2.074,0,0,0-1.682,2.392l.711,4.143c-4.551,1.531-9.223,3.11-13.733,4.73A2.083,2.083,0,0,0,.119,27.37l8.972,24.94a1.231,1.231,0,1,0,2.316-.833L2.568,26.906c4.249-1.521,8.65-3.01,12.95-4.458L19.746,47.1l4.865,28.388A2.084,2.084,0,0,0,27,77.173L40.18,74.912l10.3-1.765L34.991,78.713,22.779,83.1l-9.484-26.38a1.23,1.23,0,1,0-2.316.833L20.6,84.312a2.078,2.078,0,0,0,1.947,1.364,2.036,2.036,0,0,0,.7-.124l12.579-4.523L64.386,70.763l5.457-.935H81.9A2.109,2.109,0,0,0,84,67.719V14.072a1.77,1.77,0,0,0-.691-1.387Zm-3.26.291h-6.31c-.295,0-.985.007-1.16-.167a.693.693,0,0,1-.088-.424l-.014-6.631ZM81.54,67.366H32.53V43.386a1.23,1.23,0,0,0-2.461,0V67.719a2.109,2.109,0,0,0,2.1,2.109h23.1L39.764,72.486l-12.794,2.2-4.8-28L16.877,15.816l13.192-2.261V37.676a1.23,1.23,0,1,0,2.461,0V4.954H70.015l.016,7.436a2.93,2.93,0,0,0,.815,2.167,3.763,3.763,0,0,0,2.734.882H81.54Z" transform="translate(0)" fill="#85c72e"></path><path id="Path_8" data-name="Path 8" d="M234.43,112.679a1.231,1.231,0,0,0,1.23,1.23h35.181a1.23,1.23,0,1,0,0-2.461H235.66A1.231,1.231,0,0,0,234.43,112.679Z" transform="translate(-195.969 -91.08)" fill="#85c72e"></path><path id="Path_9" data-name="Path 9" d="M270.842,164.731H235.66a1.23,1.23,0,1,0,0,2.461h35.181a1.23,1.23,0,1,0,0-2.461Z" transform="translate(-195.969 -135.621)" fill="#85c72e"></path><path id="Path_10" data-name="Path 10" d="M270.842,218.013H235.66a1.23,1.23,0,1,0,0,2.461h35.181a1.23,1.23,0,1,0,0-2.461Z" transform="translate(-195.969 -180.161)" fill="#85c72e"></path><path id="Path_11" data-name="Path 11" d="M270.842,271.3H235.66a1.23,1.23,0,1,0,0,2.461h35.181a1.23,1.23,0,1,0,0-2.461Z" transform="translate(-195.969 -224.701)" fill="#85c72e"></path><path id="Path_12" data-name="Path 12" d="M270.842,324.578H235.66a1.23,1.23,0,1,0,0,2.461h35.181a1.23,1.23,0,1,0,0-2.461Z" transform="translate(-195.969 -269.242)" fill="#85c72e"></path></g></svg><a href="#" class="text-sju-50 pt-3 font-bold block text-sm">${ssrInterpolate(_ctx.$translate("The basic bylaw of the Saudi Journalists Association"))}</a><span class="text-xs mt-2 text-sju-50" dir="auto">${ssrInterpolate(_ctx.$translate("1.5 Miga bytes"))}</span></div>`);
      });
      _push(`<!--]--></div></div><div class="md:w-5/12"><div class="flex justify-between items-center"><h2 class="text-sju-50 text-3xl py-4 mb-2">${ssrInterpolate(_ctx.$translate("Events"))}</h2>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/events",
        class: "text-sju-50 text-sm"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("More"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("More")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex flex-col space-y-5"><!--[-->`);
      ssrRenderList(__props.events, (event) => {
        _push(ssrRenderComponent(_component_event_preview, { event }, null, _parent));
      });
      _push(`<!--]--></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/home/Regulations.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props2, ctx) : void 0;
};
const _export_sfc = (sfc, props2) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props2) {
    target[key] = val;
  }
  return target;
};
const _sfc_main$5 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "py-20 bg-gradient-to-r from-sju-50 to-sju-400 sm:px-4 text-white" }, _attrs))}><div class="container px-2"><h2 class="text-4xl mb-10">${ssrInterpolate(_ctx.$translate("Authority membership"))}</h2><div class="flex flex-col md:flex-row gap-12 md:gap-8"><div class="w-full md:w-5/12"><p class="font-bold mb-4">${ssrInterpolate(_ctx.$translate("membership_desc"))}</p><a href="https://sju.org.sa/members/register"><button class="border border-white py-3 px-8 transition hover:bg-white hover:text-sju-50">${ssrInterpolate(_ctx.$translate("membership_btn"))}</button></a></div><div class="w-full md:w-7/12"><h4 class="mb-4">${ssrInterpolate(_ctx.$translate("membership_conditions"))}</h4><ol class="list-decimal pr-6" id="accordion-collapse" data-accordion="collapse"><li class="mb-4"><div class="flex justify-between cursor-pointer" id="accordion-collapse-heading-1"><div style="${ssrRenderStyle({ "color": "#fff", "background": "none" })}" class="font-bold transition" data-accordion-target="#accordion-collapse-body-1" aria-expanded="true" aria-controls="accordion-collapse-body-1">${ssrInterpolate(_ctx.$translate("fulltime_member"))}</div><i class="fas fa-caret-down"></i></div><ol class="list-decimal pt-3 pb-4 overflow-hidden transition px-9 hidden" id="accordion-collapse-body-1" aria-labelledby="accordion-collapse-heading-1"><li>${ssrInterpolate(_ctx.$translate("fulltime_member_desc1"))}</li><li>${ssrInterpolate(_ctx.$translate("fulltime_member_desc2"))}</li><li>${ssrInterpolate(_ctx.$translate("fulltime_member_desc3"))}</li></ol></li><li class="mb-4"><div class="flex justify-between cursor-pointer" id="accordion-collapse-heading-2"><div style="${ssrRenderStyle({ "color": "#fff", "background": "none" })}" class="font-bold transition" data-accordion-target="#accordion-collapse-body-2" aria-controls="accordion-collapse-body-2">${ssrInterpolate(_ctx.$translate("parttime_member"))}</div><i class="fas fa-caret-up"></i></div><ol class="list-decimal pt-3 pb-4 overflow-hidden transition px-9 hidden" id="accordion-collapse-body-2" aria-labelledby="accordion-collapse-heading-2"><li>${ssrInterpolate(_ctx.$translate("parttime_member_desc1"))}</li><li>${ssrInterpolate(_ctx.$translate("parttime_member_desc2"))}</li></ol></li><li class="mb-4"><div class="flex justify-between cursor-pointer" id="accordion-collapse-heading-3"><div style="${ssrRenderStyle({ "color": "#fff", "background": "none" })}" class="font-bold transition" data-accordion-target="#accordion-collapse-body-3" aria-controls="accordion-collapse-body-3">${ssrInterpolate(_ctx.$translate("affiliate_member"))}</div><i class="fas fa-caret-down"></i></div><ol class="list-decimal pt-3 pb-4 overflow-hidden transition px-9 hidden" id="accordion-collapse-body-3" aria-labelledby="accordion-collapse-heading-3"><li>${ssrInterpolate(_ctx.$translate("affiliate_member_desc1"))}</li></ol></li></ol></div></div></div></section>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/home/MembershipDetails.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props2, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$4 = {
  __name: "Stats",
  __ssrInlineRender: true,
  props: ["stats"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "py-20" }, _attrs))}><div class="container px-2"><h2 class="text-sju-50 text-3xl py-4 mb-4">${ssrInterpolate(_ctx.$translate("Statistics"))}</h2><div class="grid grid-cols-2 md:grid-cols-4 gap-y-12"><div class="text-center"><svg id="group_3_" class="mx-auto" data-name="group (3)" xmlns="http://www.w3.org/2000/svg" width="90" height="90" viewBox="0 0 90 90"><g id="Group_22" data-name="Group 22" transform="translate(34.5)"><g id="Group_21" data-name="Group 21"><path id="Path_25" data-name="Path 25" d="M194.5,0A10.5,10.5,0,1,0,205,10.5,10.5,10.5,0,0,0,194.5,0Zm0,18a7.5,7.5,0,1,1,7.5-7.5A7.5,7.5,0,0,1,194.5,18Z" transform="translate(-184)" fill="#85c72e"></path></g></g><g id="Group_24" data-name="Group 24" transform="translate(27 22.5)"><g id="Group_23" data-name="Group 23"><path id="Path_26" data-name="Path 26" d="M166.5,120h-9A13.515,13.515,0,0,0,144,133.5V159h6v28.5h3V153h-3v3h-3V133.5A10.512,10.512,0,0,1,157.5,123h9A10.512,10.512,0,0,1,177,133.5V156h-3v-3h-3v34.5h3V159h6V133.5A13.515,13.515,0,0,0,166.5,120Z" transform="translate(-144 -120)" fill="#85c72e"></path></g></g><g id="Group_26" data-name="Group 26" transform="translate(43.5 61.5)"><g id="Group_25" data-name="Group 25"><rect id="Rectangle_20" data-name="Rectangle 20" width="3" height="28" transform="translate(0.5 0.5)" fill="#85c72e"></rect></g></g><g id="Group_28" data-name="Group 28" transform="translate(66 15)"><g id="Group_27" data-name="Group 27"><path id="Path_27" data-name="Path 27" d="M361,80a9,9,0,1,0,9,9A9,9,0,0,0,361,80Zm0,15a6,6,0,1,1,6-6A6,6,0,0,1,361,95Z" transform="translate(-352 -80)" fill="#85c72e"></path></g></g><g id="Group_30" data-name="Group 30" transform="translate(66 34.5)"><g id="Group_29" data-name="Group 29"><path id="Path_28" data-name="Path 28" d="M365.5,184H352v3h13.5a7.509,7.509,0,0,1,7.5,7.5V214h-3v-3h-3v28.5h3V217h6V194.5A10.512,10.512,0,0,0,365.5,184Z" transform="translate(-352 -184)" fill="#85c72e"></path></g></g><g id="Group_32" data-name="Group 32" transform="translate(60 61.5)"><g id="Group_31" data-name="Group 31"><path id="Path_29" data-name="Path 29" d="M326,328v3h-6v3h6v22.5h3V328Z" transform="translate(-320 -328)" fill="#85c72e"></path></g></g><g id="Group_34" data-name="Group 34" transform="translate(73.5 67.5)"><g id="Group_33" data-name="Group 33"><rect id="Rectangle_21" data-name="Rectangle 21" width="3" height="22" transform="translate(0.5 0.5)" fill="#85c72e"></rect></g></g><g id="Group_36" data-name="Group 36" transform="translate(6 15)"><g id="Group_35" data-name="Group 35"><path id="Path_30" data-name="Path 30" d="M41,80a9,9,0,1,0,9,9A9,9,0,0,0,41,80Zm0,15a6,6,0,1,1,6-6A6,6,0,0,1,41,95Z" transform="translate(-32 -80)" fill="#85c72e"></path></g></g><g id="Group_38" data-name="Group 38" transform="translate(0 34.5)"><g id="Group_37" data-name="Group 37"><path id="Path_31" data-name="Path 31" d="M10.5,184A10.512,10.512,0,0,0,0,194.5V217H6v22.5H9V211H6v3H3V194.5a7.509,7.509,0,0,1,7.5-7.5H24v-3Z" transform="translate(0 -184)" fill="#85c72e"></path></g></g><g id="Group_40" data-name="Group 40" transform="translate(21 61.5)"><g id="Group_39" data-name="Group 39"><path id="Path_32" data-name="Path 32" d="M115,331v-3h-3v28.5h3V334h6v-3Z" transform="translate(-112 -328)" fill="#85c72e"></path></g></g><g id="Group_42" data-name="Group 42" transform="translate(13.5 67.5)"><g id="Group_41" data-name="Group 41"><rect id="Rectangle_22" data-name="Rectangle 22" width="3" height="22" transform="translate(0.5 0.5)" fill="#85c72e"></rect></g></g></svg><h3 class="text-sju-50 font-bold text-3xl mt-1">${ssrInterpolate(__props.stats.members)}</h3><span class="text-sju-50">${ssrInterpolate(_ctx.$translate("Of members"))}</span></div><div class="text-center"><svg xmlns="http://www.w3.org/2000/svg" class="mx-auto" width="88.864" height="89.844" viewBox="0 0 88.864 89.844"><g id="certificate_1_" data-name="certificate (1)" transform="translate(-2.794)"><g id="Group_20" data-name="Group 20" transform="translate(2.794 0)"><path id="Path_16" data-name="Path 16" d="M94.295,181.506H60.606a1.316,1.316,0,1,0,0,2.632H94.295a1.316,1.316,0,1,0,0-2.632Z" transform="translate(-49.376 -149.656)" fill="#85c72e"></path><path id="Path_17" data-name="Path 17" d="M94.295,234.2H60.606a1.316,1.316,0,0,0,0,2.632H94.295a1.316,1.316,0,1,0,0-2.632Z" transform="translate(-49.376 -193.105)" fill="#85c72e"></path><path id="Path_18" data-name="Path 18" d="M94.295,286.9H60.606a1.316,1.316,0,1,0,0,2.632H94.295a1.316,1.316,0,1,0,0-2.632Z" transform="translate(-49.376 -236.553)" fill="#85c72e"></path><path id="Path_19" data-name="Path 19" d="M95.611,340.91a1.316,1.316,0,0,0-1.316-1.316H60.606a1.316,1.316,0,1,0,0,2.632H94.295A1.316,1.316,0,0,0,95.611,340.91Z" transform="translate(-49.376 -280.003)" fill="#85c72e"></path><path id="Path_20" data-name="Path 20" d="M60.606,416.821a1.316,1.316,0,1,0,0,2.632H77.493a1.316,1.316,0,1,0,0-2.632Z" transform="translate(-49.376 -343.678)" fill="#85c72e"></path><path id="Path_21" data-name="Path 21" d="M190.522,58.927v-4.27a2.953,2.953,0,0,0-2.95-2.95H160.554a2.953,2.953,0,0,0-2.95,2.95v4.27a2.953,2.953,0,0,0,2.95,2.95h2.282a1.316,1.316,0,1,0,0-2.632h-2.282a.318.318,0,0,1-.318-.318v-4.27a.319.319,0,0,1,.318-.318h27.018a.318.318,0,0,1,.318.318v4.27a.318.318,0,0,1-.318.318H168.988a1.316,1.316,0,0,0,0,2.632h18.584A2.953,2.953,0,0,0,190.522,58.927Z" transform="translate(-130.438 -42.634)" fill="#85c72e"></path><path id="Path_22" data-name="Path 22" d="M72.717,80.245A1.316,1.316,0,0,0,71.4,81.561v1.772a3.884,3.884,0,0,1-3.879,3.879H9.305a3.884,3.884,0,0,1-3.879-3.879V20.079a3.906,3.906,0,0,1,.093-.836H17.5a4.542,4.542,0,0,0,4.537-4.537V2.725a3.9,3.9,0,0,1,.836-.093H67.522A3.884,3.884,0,0,1,71.4,6.511v17.52a1.316,1.316,0,1,0,2.632,0V6.511A6.518,6.518,0,0,0,67.522,0H22.873a6.469,6.469,0,0,0-4.6,1.907L4.7,15.475a6.468,6.468,0,0,0-1.907,4.6V83.333a6.518,6.518,0,0,0,6.511,6.511H67.522a6.519,6.519,0,0,0,6.511-6.511V81.561a1.316,1.316,0,0,0-1.316-1.316ZM19.406,4.493V14.707a1.907,1.907,0,0,1-1.9,1.9H7.287Z" transform="translate(-2.794 0)" fill="#85c72e"></path><path id="Path_23" data-name="Path 23" d="M330.295,182.667a5.262,5.262,0,0,0-2.572-7.915,2.615,2.615,0,0,1-1.741-2.4,5.262,5.262,0,0,0-6.733-4.892,2.615,2.615,0,0,1-2.817-.915,5.262,5.262,0,0,0-8.323,0,2.615,2.615,0,0,1-2.816.915,5.262,5.262,0,0,0-6.733,4.892,2.615,2.615,0,0,1-1.741,2.4,5.262,5.262,0,0,0-2.572,7.915,2.615,2.615,0,0,1,0,2.962,5.262,5.262,0,0,0,2.572,7.916,2.615,2.615,0,0,1,1.741,2.4,5.262,5.262,0,0,0,4.544,5.054v11.981a2.793,2.793,0,0,0,4.257,2.378l4.826-2.971a.138.138,0,0,1,.169,0l4.826,2.971a2.793,2.793,0,0,0,4.257-2.379V200.994a5.261,5.261,0,0,0,4.544-5.054,2.615,2.615,0,0,1,1.741-2.4,5.262,5.262,0,0,0,2.572-7.916,2.613,2.613,0,0,1,0-2.961Zm-11.734,30.445-4.826-2.971a2.793,2.793,0,0,0-2.928,0l-4.826,2.971a.16.16,0,0,1-.245-.137V200.744a2.611,2.611,0,0,1,2.374,1,5.262,5.262,0,0,0,8.323,0,2.611,2.611,0,0,1,2.375-1v12.231A.16.16,0,0,1,318.561,213.113Zm9.559-26a2.63,2.63,0,0,1-1.286,3.956,5.232,5.232,0,0,0-3.483,4.794,2.594,2.594,0,0,1-.947,1.943,2.62,2.62,0,0,1-2.418.5,5.233,5.233,0,0,0-5.636,1.831,2.63,2.63,0,0,1-4.16,0,5.228,5.228,0,0,0-4.145-2.045,5.313,5.313,0,0,0-1.49.214,2.619,2.619,0,0,1-2.419-.5,2.592,2.592,0,0,1-.947-1.942,5.232,5.232,0,0,0-3.483-4.794,2.63,2.63,0,0,1-1.285-3.956,5.232,5.232,0,0,0,0-5.925,2.63,2.63,0,0,1,1.285-3.956,5.232,5.232,0,0,0,3.483-4.794,2.63,2.63,0,0,1,3.365-2.445,5.232,5.232,0,0,0,5.635-1.831,2.63,2.63,0,0,1,4.16,0,5.232,5.232,0,0,0,5.635,1.831,2.63,2.63,0,0,1,3.365,2.445,5.232,5.232,0,0,0,3.483,4.794,2.63,2.63,0,0,1,1.286,3.956,5.232,5.232,0,0,0,0,5.926Z" transform="translate(-242.348 -135.64)" fill="#85c72e"></path><path id="Path_24" data-name="Path 24" d="M349.443,213.583a11.029,11.029,0,1,0,11.029,11.029A11.042,11.042,0,0,0,349.443,213.583Zm0,19.427a8.4,8.4,0,1,1,8.4-8.4A8.407,8.407,0,0,1,349.443,233.01Z" transform="translate(-279.52 -176.104)" fill="#85c72e"></path></g></g></svg><h3 class="text-sju-50 font-bold text-3xl mt-1">${ssrInterpolate(__props.stats.memberships)}</h3><span class="text-sju-50">${ssrInterpolate(_ctx.$translate("Of memberships"))}</span></div><div class="text-center"><svg class="mx-auto" id="conference" xmlns="http://www.w3.org/2000/svg" width="89.844" height="89.844" viewBox="0 0 89.844 89.844"><g id="Group_44" data-name="Group 44" transform="translate(43.663 41.983)"><g id="Group_43" data-name="Group 43" transform="translate(0 0)"><rect id="Rectangle_23" data-name="Rectangle 23" width="2" height="3" transform="translate(0.182 0.017)" fill="#85c72e"></rect></g></g><g id="Group_46" data-name="Group 46" transform="translate(40.304 47.861)"><g id="Group_45" data-name="Group 45" transform="translate(0 0)"><rect id="Rectangle_24" data-name="Rectangle 24" width="10" height="3" transform="translate(-0.46 0.139)" fill="#85c72e"></rect></g></g><g id="Group_48" data-name="Group 48" transform="translate(4.492 67.376)"><g id="Group_47" data-name="Group 47"><path id="Path_33" data-name="Path 33" d="M95.953,367.452a8.942,8.942,0,0,0-1.688.153,8.971,8.971,0,0,0-17.744,0,8.559,8.559,0,0,0-3.219,0,8.971,8.971,0,0,0-17.744,0,8.559,8.559,0,0,0-3.219,0,8.971,8.971,0,0,0-17.744,0A8.947,8.947,0,0,0,24,376.439v4.492a1.5,1.5,0,0,0,1.5,1.5H40.471a1.5,1.5,0,0,0,1.5-1.5v-4.492a8.986,8.986,0,0,0-.135-1.5H45.1a8.986,8.986,0,0,0-.135,1.5v4.492a1.5,1.5,0,0,0,1.5,1.5H61.435a1.5,1.5,0,0,0,1.5-1.5v-4.492a8.986,8.986,0,0,0-.135-1.5h3.264a8.986,8.986,0,0,0-.135,1.5v4.492a1.5,1.5,0,0,0,1.5,1.5H82.4a1.5,1.5,0,0,0,1.5-1.5v-4.492a8.986,8.986,0,0,0-.135-1.5h3.264a8.985,8.985,0,0,0-.135,1.5v4.492a1.5,1.5,0,0,0,1.5,1.5h14.974a1.5,1.5,0,0,0,1.5-1.5v-4.492A8.947,8.947,0,0,0,95.953,367.452Zm-56.98,11.982H26.994v-2.995a5.99,5.99,0,1,1,11.979,0Zm7.206-7.487H40.753a9.029,9.029,0,0,0-3.249-3.26,5.967,5.967,0,0,1,11.925,0A9.029,9.029,0,0,0,46.179,371.947Zm13.758,7.487H47.958v-2.995a5.99,5.99,0,1,1,11.979,0Zm7.206-7.487H61.716a9.029,9.029,0,0,0-3.249-3.26,5.967,5.967,0,0,1,11.925,0A9.029,9.029,0,0,0,67.143,371.947ZM80.9,379.434H68.922v-2.995a5.99,5.99,0,1,1,11.979,0Zm7.206-7.487H82.68a9.029,9.029,0,0,0-3.249-3.26,5.967,5.967,0,0,1,11.925,0A9.029,9.029,0,0,0,88.107,371.947Zm13.758,7.487H89.885v-2.995a5.99,5.99,0,1,1,11.979,0Z" transform="translate(-24 -359.96)" fill="#85c72e"></path></g></g><g id="Group_50" data-name="Group 50"><g id="Group_49" data-name="Group 49"><path id="Path_34" data-name="Path 34" d="M88.347,0H1.5A1.5,1.5,0,0,0,0,1.5v5.99a1.5,1.5,0,0,0,1.5,1.5H4.492v40.43a1.5,1.5,0,0,0,1.5,1.5H33.5l.69,4.492H32.943a1.5,1.5,0,0,0-1.5,1.5v5.99a1.5,1.5,0,0,0,1.5,1.5H56.9a1.5,1.5,0,0,0,1.5-1.5V56.9a1.5,1.5,0,0,0-1.5-1.5H55.653l.69-4.492H83.855a1.5,1.5,0,0,0,1.5-1.5V8.984h2.995a1.5,1.5,0,0,0,1.5-1.5V1.5A1.5,1.5,0,0,0,88.347,0ZM55.4,61.394H34.44V58.4H55.4ZM34.689,38.932H55.155L52.622,55.4h-15.4ZM29.62,35.938l-.749-2.995h32.1l-.749,2.995ZM82.357,47.917H56.8l1.382-8.984h3.207A1.5,1.5,0,0,0,62.846,37.8l1.5-5.99a1.5,1.5,0,0,0-1.452-1.86H59.9V25.456a1.5,1.5,0,0,0-.439-1.059L56.452,21.39a4.419,4.419,0,0,0,.449-1.924,4.492,4.492,0,1,0-4.492,4.492,4.419,4.419,0,0,0,1.924-.449L56.9,26.076v3.872H32.943V26.076l2.568-2.567a4.419,4.419,0,0,0,1.924.449,4.492,4.492,0,1,0-4.492-4.492,4.419,4.419,0,0,0,.449,1.924L30.385,24.4a1.5,1.5,0,0,0-.437,1.059v4.492H26.953a1.5,1.5,0,0,0-1.452,1.86L27,37.8a1.5,1.5,0,0,0,1.452,1.135h3.207l1.382,8.984H7.487V8.984h74.87ZM53.907,19.466a1.5,1.5,0,1,1-1.5-1.5A1.5,1.5,0,0,1,53.907,19.466Zm-17.969,0a1.5,1.5,0,1,1,1.5,1.5A1.5,1.5,0,0,1,35.938,19.466ZM86.849,5.99H2.995V2.995H86.849Z" fill="#85c72e"></path></g></g></svg><h3 class="text-sju-50 font-bold text-3xl mt-1">${ssrInterpolate(__props.stats.events)}</h3><span class="text-sju-50">${ssrInterpolate(_ctx.$translate("Of events"))}</span></div><div class="text-center"><svg class="mx-auto" xmlns="http://www.w3.org/2000/svg" width="89.844" height="89.844" viewBox="0 0 89.844 89.844"><g id="online-conference" transform="translate(-1 -1)"><path id="Path_35" data-name="Path 35" d="M15.449,29.982H64.718a1.449,1.449,0,0,0,1.449-1.449V2.449A1.449,1.449,0,0,0,64.718,1H15.449A1.449,1.449,0,0,0,14,2.449V28.533A1.449,1.449,0,0,0,15.449,29.982Zm31.88-2.9H45.88v-2.9h-2.9v2.9h-5.8v-2.9h-2.9v2.9H32.838V22.736a1.451,1.451,0,0,1,1.449-1.449H45.88a1.451,1.451,0,0,1,1.449,1.449ZM16.9,3.9H63.269V27.084H50.227V22.736a4.353,4.353,0,0,0-4.347-4.347H34.287a4.353,4.353,0,0,0-4.347,4.347v4.347H16.9Z" transform="translate(5.838 0)" fill="#85c72e"></path><path id="Path_36" data-name="Path 36" d="M1.636,35.529a1.453,1.453,0,0,0,1.351.146l14.491-5.8a1.451,1.451,0,0,0,.911-1.346V2.449A1.449,1.449,0,0,0,16.4,1.1L1.911,6.9A1.451,1.451,0,0,0,1,8.246V34.329a1.451,1.451,0,0,0,.636,1.2ZM3.9,9.227,15.491,4.59V27.552L3.9,32.189Z" transform="translate(0 0)" fill="#85c72e"></path><path id="Path_37" data-name="Path 37" d="M67.478,6.9,52.987,1.1A1.449,1.449,0,0,0,51,2.449V28.533a1.451,1.451,0,0,0,.911,1.346l14.491,5.8a1.453,1.453,0,0,0,1.351-.146,1.451,1.451,0,0,0,.636-1.2V8.245A1.451,1.451,0,0,0,67.478,6.9Zm-1.987,25.29L53.9,27.552V4.589L65.491,9.227Z" transform="translate(22.454 0)" fill="#85c72e"></path><path id="Path_38" data-name="Path 38" d="M28,8.8v2.9a5.8,5.8,0,1,0,11.593,0V8.8A5.8,5.8,0,1,0,28,8.8Zm2.9,0a2.9,2.9,0,1,1,5.8,0v2.9a2.9,2.9,0,1,1-5.8,0Z" transform="translate(12.125 0.898)" fill="#85c72e"></path><path id="Path_39" data-name="Path 39" d="M42.78,48.58a8.654,8.654,0,0,0,2.405-5.988v-2.9a8.695,8.695,0,1,0-17.389,0v2.9A8.654,8.654,0,0,0,30.2,48.58,10.158,10.158,0,0,0,22,58.533v5.8a1.448,1.448,0,0,0,1.449,1.449H49.533a1.448,1.448,0,0,0,1.449-1.449v-5.8A10.158,10.158,0,0,0,42.78,48.58ZM30.695,39.695a5.8,5.8,0,1,1,11.593,0v2.9a5.8,5.8,0,1,1-11.593,0ZM48.084,62.88h-2.9v-5.8h-2.9v5.8H30.695v-5.8H27.8v5.8H24.9V58.533a7.254,7.254,0,0,1,7.245-7.245h8.695a7.254,7.254,0,0,1,7.245,7.245Z" transform="translate(9.431 13.473)" fill="#85c72e"></path><path id="Path_40" data-name="Path 40" d="M63.78,56.58a8.654,8.654,0,0,0,2.405-5.988v-2.9a8.695,8.695,0,1,0-17.389,0v2.9A8.654,8.654,0,0,0,51.2,56.58,10.158,10.158,0,0,0,43,66.533v5.8a1.448,1.448,0,0,0,1.449,1.449H70.533a1.448,1.448,0,0,0,1.449-1.449v-5.8A10.158,10.158,0,0,0,63.78,56.58ZM51.695,47.695a5.8,5.8,0,1,1,11.593,0v2.9a5.8,5.8,0,1,1-11.593,0ZM69.084,70.88h-2.9v-5.8h-2.9v5.8H51.695v-5.8H48.8v5.8H45.9V66.533a7.254,7.254,0,0,1,7.245-7.245h8.695a7.254,7.254,0,0,1,7.245,7.245Z" transform="translate(18.862 17.066)" fill="#85c72e"></path><path id="Path_41" data-name="Path 41" d="M21.78,56.58a8.654,8.654,0,0,0,2.405-5.988v-2.9a8.695,8.695,0,1,0-17.389,0v2.9A8.654,8.654,0,0,0,9.2,56.58,10.158,10.158,0,0,0,1,66.533v5.8a1.448,1.448,0,0,0,1.449,1.449H28.533a1.448,1.448,0,0,0,1.449-1.449v-5.8A10.158,10.158,0,0,0,21.78,56.58ZM9.695,47.695a5.8,5.8,0,1,1,11.593,0v2.9a5.8,5.8,0,0,1-11.593,0ZM27.084,70.88h-2.9v-5.8h-2.9v5.8H9.695v-5.8H6.8v5.8H3.9V66.533a7.254,7.254,0,0,1,7.245-7.245h8.695a7.254,7.254,0,0,1,7.245,7.245Z" transform="translate(0 17.066)" fill="#85c72e"></path><path id="Path_42" data-name="Path 42" d="M14,27h2.9v2.9H14Z" transform="translate(5.838 11.677)" fill="#85c72e"></path><path id="Path_43" data-name="Path 43" d="M17,27h2.9v2.9H17Z" transform="translate(7.185 11.677)" fill="#85c72e"></path><path id="Path_44" data-name="Path 44" d="M20,27h2.9v2.9H20Z" transform="translate(8.533 11.677)" fill="#85c72e"></path><path id="Path_45" data-name="Path 45" d="M27.389,37.491h1.449a4.353,4.353,0,0,0,4.347-4.347v-5.8A4.353,4.353,0,0,0,28.838,23H14.347A4.353,4.353,0,0,0,10,27.347v5.8a4.353,4.353,0,0,0,4.347,4.347h5.314l5.409,4.057a1.442,1.442,0,0,0,.869.29,1.447,1.447,0,0,0,1.449-1.449Zm-1.449-2.9a1.449,1.449,0,0,0-1.449,1.449v1.449l-3.478-2.608a1.445,1.445,0,0,0-.869-.29h-5.8A1.451,1.451,0,0,1,12.9,33.144v-5.8A1.451,1.451,0,0,1,14.347,25.9H28.838a1.451,1.451,0,0,1,1.449,1.449v5.8a1.451,1.451,0,0,1-1.449,1.449Z" transform="translate(4.042 9.88)" fill="#85c72e"></path><path id="Path_46" data-name="Path 46" d="M48,30h2.9v2.9H48Z" transform="translate(21.107 13.024)" fill="#85c72e"></path><path id="Path_47" data-name="Path 47" d="M45,30h2.9v2.9H45Z" transform="translate(19.76 13.024)" fill="#85c72e"></path><path id="Path_48" data-name="Path 48" d="M42,30h2.9v2.9H42Z" transform="translate(18.413 13.024)" fill="#85c72e"></path><path id="Path_49" data-name="Path 49" d="M46.115,23.29A1.449,1.449,0,0,0,43.8,24.449v2.9H42.347A4.353,4.353,0,0,0,38,31.695v5.8a4.353,4.353,0,0,0,4.347,4.347H56.838a4.353,4.353,0,0,0,4.347-4.347v-5.8a4.353,4.353,0,0,0-4.347-4.347H51.524Zm12.172,8.4v5.8a1.45,1.45,0,0,1-1.449,1.449H42.347A1.45,1.45,0,0,1,40.9,37.491v-5.8a1.451,1.451,0,0,1,1.449-1.449h2.9A1.449,1.449,0,0,0,46.695,28.8V27.348l3.478,2.608a1.445,1.445,0,0,0,.869.29h5.8A1.451,1.451,0,0,1,58.287,31.695Z" transform="translate(16.616 9.88)" fill="#85c72e"></path></g></svg><h3 class="text-sju-50 font-bold text-3xl mt-1">${ssrInterpolate(__props.stats.workshops)}</h3><span class="text-sju-50">${ssrInterpolate(_ctx.$translate("Of workshops"))}</span></div></div></div></section>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/home/Stats.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props2, ctx) : void 0;
};
const _hoisted_1$2 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$2 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M9.198 21.5h4v-8.01h3.604l.396-3.98h-4V7.5a1 1 0 0 1 1-1h3v-4h-3a5 5 0 0 0-5 5v2.01h-2l-.396 3.98h2.396v8.01Z"
}, null, -1);
const _hoisted_3$2 = [
  _hoisted_2$2
];
function render$2(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$2, _hoisted_3$2);
}
const GgFacebook = { name: "gg-facebook", render: render$2 };
const _hoisted_1$1 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2$1 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M22.46 6c-.77.35-1.6.58-2.46.69c.88-.53 1.56-1.37 1.88-2.38c-.83.5-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29c0 .34.04.67.11.98C8.28 9.09 5.11 7.38 3 4.79c-.37.63-.58 1.37-.58 2.15c0 1.49.75 2.81 1.91 3.56c-.71 0-1.37-.2-1.95-.5v.03c0 2.08 1.48 3.82 3.44 4.21a4.22 4.22 0 0 1-1.93.07a4.28 4.28 0 0 0 4 2.98a8.521 8.521 0 0 1-5.33 1.84c-.34 0-.68-.02-1.02-.06C3.44 20.29 5.7 21 8.12 21C16 21 20.33 14.46 20.33 8.79c0-.19 0-.37-.01-.56c.84-.6 1.56-1.36 2.14-2.23Z"
}, null, -1);
const _hoisted_3$1 = [
  _hoisted_2$1
];
function render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$1, _hoisted_3$1);
}
const MdiTwitter = { name: "mdi-twitter", render: render$1 };
const _hoisted_1 = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77Z"
}, null, -1);
const _hoisted_3 = [
  _hoisted_2
];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, _hoisted_3);
}
const MdiLinkedin = { name: "mdi-linkedin", render };
const _sfc_main$3 = {
  __name: "FollowUs",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "bg-sju-500 dark:bg-sjud-100 dark:text-gray-400" }, _attrs))}><div class="container px-2"><div class="flex flex-col md:flex-row gap-8"><div class="md:w-1/2 py-20"><h2 class="text-sju-50 text-3xl mb-2">${ssrInterpolate(_ctx.$translate("Follow us"))}</h2><p class="text-gray-500 px-2">${ssrInterpolate(_ctx.$translate("Follow us on social media"))}</p><div class="flex gap-2 mt-2 px-2">`);
      _push(ssrRenderComponent(_component_nuxt_link, { class: "text-sju-50 text-4xl" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(GgFacebook), { class: "inline" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(GgFacebook), { class: "inline" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "https://twitter.com/sju_ksa",
        target: "_blank",
        class: "text-sju-50 text-4xl"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(MdiTwitter), { class: "inline" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(MdiTwitter), { class: "inline" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, { class: "text-sju-50 text-4xl" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(MdiLinkedin), { class: "inline" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(MdiLinkedin), { class: "inline" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><h2 class="text-sju-50 text-3xl mt-8 mb-2">${ssrInterpolate(_ctx.$translate("Contact us"))}</h2><ul class="px-2 mt-4"><li class="flex gap-2 mb-2"><svg xmlns="http://www.w3.org/2000/svg" width="22.351" height="22.351" viewBox="0 0 22.351 22.351"><g id="email_1_" data-name="email (1)" transform="translate(-0.001 -0.004)"><g id="Group_52" data-name="Group 52" transform="translate(0.001 0.004)"><g id="Group_51" data-name="Group 51" transform="translate(0)"><path id="Path_65" data-name="Path 65" d="M22.348,8.549a.352.352,0,0,0-.015-.076.373.373,0,0,0-.021-.064.334.334,0,0,0-.037-.057.351.351,0,0,0-.05-.058c-.006-.005-.009-.012-.015-.018L18.627,5.495V2.611a1.118,1.118,0,0,0-1.118-1.118H13.472L11.855.238a1.1,1.1,0,0,0-1.359,0L8.88,1.493H4.843A1.118,1.118,0,0,0,3.725,2.611V5.495L.144,8.277c-.006.005-.009.012-.015.018a.349.349,0,0,0-.05.058.333.333,0,0,0-.037.057.368.368,0,0,0-.021.064.353.353,0,0,0-.015.075c0,.008,0,.015,0,.022V21.238A1.105,1.105,0,0,0,.22,21.9s0,.007.005.01l.012.01a1.112,1.112,0,0,0,.881.439H21.235a1.112,1.112,0,0,0,.884-.441s.007,0,.01-.009,0-.007.005-.01a1.105,1.105,0,0,0,.219-.658V8.571C22.352,8.564,22.348,8.557,22.348,8.549ZM10.952.826a.357.357,0,0,1,.444,0l.859.667H10.1ZM1.211,21.61l9.741-7.567a.358.358,0,0,1,.444,0l9.744,7.567Zm20.4-.581-9.752-7.574a1.105,1.105,0,0,0-1.359,0L.745,21.029V9.139l6.1,4.741a.373.373,0,0,0,.457-.589L1.1,8.475,3.725,6.438V9.316a.373.373,0,1,0,.745,0V2.611a.373.373,0,0,1,.373-.373H17.509a.373.373,0,0,1,.373.373V9.316a.373.373,0,1,0,.745,0V6.438l2.621,2.037L15.035,13.3a.373.373,0,1,0,.457.589l6.116-4.749V21.029Z" transform="translate(-0.001 -0.004)" fill="#007c42"></path><path id="Path_66" data-name="Path 66" d="M162.515,74.2v-1.49a4.47,4.47,0,1,0-4.47,4.47.373.373,0,1,0,0-.745,3.725,3.725,0,1,1,3.725-3.725V74.2a.745.745,0,1,1-1.49,0v-1.49a.373.373,0,1,0-.745,0,1.49,1.49,0,1,1-1.49-1.49.373.373,0,1,0,0-.745,2.235,2.235,0,1,0,1.506,3.882,1.486,1.486,0,0,0,2.964-.157Z" transform="translate(-146.869 -65.258)" fill="#007c42"></path></g></g></g></svg><a href="mailto:info@sju.org.sa">info@sju.org.sa</a></li><li class="flex gap-2 mb-2"><svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="22.351" height="22.35" viewBox="0 0 22.35 18.33"><defs></defs><path class="twitter-green" d="M427.82,294.88a9,9,0,0,1-2,2.26.34.34,0,0,0-.15.3,13.26,13.26,0,0,1-2.8,8.26,12.19,12.19,0,0,1-6.59,4.43,13.39,13.39,0,0,1-4.63.42,12.88,12.88,0,0,1-5.86-2,1.73,1.73,0,0,1-.28-.26V308a.62.62,0,0,1,.63-.27,8.48,8.48,0,0,0,4.57-.81l.57-.31-.34-.12a4.82,4.82,0,0,1-3-3.07c-.1-.3.05-.51.44-.6l-.16-.15a4.8,4.8,0,0,1-1.84-3.74c0-.47.29-.66.71-.45l.22.1c-.16-.29-.32-.54-.44-.81a4.82,4.82,0,0,1,.17-4.46.45.45,0,0,1,.77-.07c.6.61,1.21,1.22,1.83,1.8.24.23.54.4.8.61a.36.36,0,0,1,.15.46.46.46,0,0,1-.77.16,12.61,12.61,0,0,1-2.12-1.81l-.14-.2a3.79,3.79,0,0,0-.27,1.52,3.9,3.9,0,0,0,1.62,3.13l.16.12a.43.43,0,0,1,.14.49.38.38,0,0,1-.42.28c-.42-.05-.83-.13-1.25-.19a2.19,2.19,0,0,0-.23-.07,3.91,3.91,0,0,0,.73,1.71,4,4,0,0,0,2.31,1.51c.29.07.43.22.43.44s-.15.39-.45.44-.82.12-1.25.18a3,3,0,0,0,.65.89,4.07,4.07,0,0,0,2.71,1.19.42.42,0,0,1,.44.32.47.47,0,0,1-.22.52,9.45,9.45,0,0,1-4.31,1.82l-.28,0a.62.62,0,0,0-.27.09c.38.14.76.3,1.15.43a11.83,11.83,0,0,0,5.25.51,11.56,11.56,0,0,0,9.35-6.67,11.82,11.82,0,0,0,1.23-5.79.65.65,0,0,1,.28-.56c.34-.27.68-.56,1-.85l0-.05-.84.15-.24,0a.42.42,0,0,1-.48-.28.43.43,0,0,1,.2-.53,3.89,3.89,0,0,0,1.14-1.05l-.38.13c-.4.11-.8.21-1.19.34a.56.56,0,0,1-.63-.18,4,4,0,0,0-1.51-1,4,4,0,0,0-5.2,3.17,7.09,7.09,0,0,0,0,1.38c.05.45-.12.69-.57.63-.84-.11-1.67-.25-2.5-.39a.45.45,0,0,1-.42-.57c.06-.25.29-.36.63-.29l1.73.33h.17v-.57a4.8,4.8,0,0,1,3.76-4.66,4.66,4.66,0,0,1,4.2,1,.48.48,0,0,0,.51.12,8.48,8.48,0,0,0,1.9-.76l.25-.13a.42.42,0,0,1,.51,0,.39.39,0,0,1,.11.51c-.19.42-.41.83-.62,1.24a1.4,1.4,0,0,1-.16.23l.65-.25c.39-.15.51-.13.77.19Zm-9.51,12.33a10,10,0,0,0,2.14-1.68,7.2,7.2,0,0,0,.64-.71.42.42,0,0,0,0-.62.43.43,0,0,0-.61,0,1.1,1.1,0,0,0-.15.16,9.84,9.84,0,0,1-2.33,2,1.61,1.61,0,0,0-.3.21.4.4,0,0,0-.1.48.43.43,0,0,0,.46.26Zm-6.42-10.66a.44.44,0,1,0,0,.88.43.43,0,0,0,.43-.42A.47.47,0,0,0,411.89,296.55Zm9.8,6.27a.41.41,0,0,0-.43.42.45.45,0,0,0,.43.45.43.43,0,0,0,.42-.44A.41.41,0,0,0,421.69,302.82Z" transform="translate(-405.47 -292.27)"></path></svg><a href="https://twitter.com/sju_ksa" target="_blank">sju_ksa</a></li><li class="flex gap-2 mb-2"><svg xmlns="http://www.w3.org/2000/svg" width="22.351" height="22.35" viewBox="0 0 22.351 22.35"><g id="call" transform="translate(-1 -1.018)"><g id="Group_54" data-name="Group 54" transform="translate(1 1.018)"><g id="Group_53" data-name="Group 53" transform="translate(0 0)"><path id="Path_67" data-name="Path 67" d="M22.765,18.26l-4.524-3.017a1.32,1.32,0,0,0-1.768.287l-1.318,1.694a.563.563,0,0,1-.722.152l-.251-.138a15.149,15.149,0,0,1-3.948-3.1,15.211,15.211,0,0,1-3.1-3.948L7,9.939a.564.564,0,0,1,.149-.725L8.838,7.9a1.321,1.321,0,0,0,.288-1.768L6.108,1.6a1.314,1.314,0,0,0-1.771-.4L2.446,2.342A2.669,2.669,0,0,0,1.229,3.921C.548,6.4,1.06,10.687,7.371,17c5.02,5.019,8.757,6.369,11.325,6.369a6.6,6.6,0,0,0,1.751-.229,2.666,2.666,0,0,0,1.579-1.217l1.138-1.891A1.314,1.314,0,0,0,22.765,18.26Zm-.244,1.389-1.135,1.892a1.925,1.925,0,0,1-1.136.881c-2.291.629-6.295.108-12.353-5.95S1.319,6.41,1.948,4.119a1.928,1.928,0,0,1,.882-1.138L4.721,1.846a.57.57,0,0,1,.768.173l1.639,2.46L8.5,6.543a.573.573,0,0,1-.124.767L6.686,8.627A1.3,1.3,0,0,0,6.341,10.3l.134.244A15.8,15.8,0,0,0,9.7,14.664a15.817,15.817,0,0,0,4.119,3.228l.245.135a1.3,1.3,0,0,0,1.673-.345l1.317-1.694a.574.574,0,0,1,.767-.124l4.524,3.017A.569.569,0,0,1,22.521,19.649Z" transform="translate(-1 -1.018)" fill="#007c42"></path><path id="Path_68" data-name="Path 68" d="M283,70.069a6.339,6.339,0,0,1,6.332,6.332.372.372,0,1,0,.745,0A7.085,7.085,0,0,0,283,69.324a.372.372,0,1,0,0,.745Z" transform="translate(-270.335 -66.343)" fill="#007c42"></path><path id="Path_69" data-name="Path 69" d="M283,121.269a4.1,4.1,0,0,1,4.1,4.1.372.372,0,0,0,.745,0A4.848,4.848,0,0,0,283,120.524a.372.372,0,1,0,0,.745Z" transform="translate(-270.335 -115.308)" fill="#007c42"></path><path id="Path_70" data-name="Path 70" d="M283,172.469a1.865,1.865,0,0,1,1.862,1.862.372.372,0,1,0,.745,0A2.61,2.61,0,0,0,283,171.724a.372.372,0,0,0,0,.745Z" transform="translate(-270.335 -164.273)" fill="#007c42"></path></g></g></g></svg> 0114878555 \u2013 0114878855 </li><li class="flex gap-2 mb-2"><svg id="fax" xmlns="http://www.w3.org/2000/svg" width="22.351" height="22.351" viewBox="0 0 22.351 22.351"><path id="Path_71" data-name="Path 71" d="M22.023,13.778a.328.328,0,0,0,.328-.328v-7a1.642,1.642,0,0,0-1.64-1.64h-.263V.328A.328.328,0,0,0,20.12,0H9.423A.328.328,0,0,0,9.1.328V4.81H7.848V4.666a1.2,1.2,0,0,0-1.2-1.2H3.88a1.2,1.2,0,0,0-1.2,1.2V4.81H1.64A1.642,1.642,0,0,0,0,6.45v9.362a.328.328,0,1,0,.656,0V6.45a.985.985,0,0,1,.984-.984H2.677V20.348H1.64a.985.985,0,0,1-.984-.984V17.125a.328.328,0,1,0-.656,0v2.239A1.642,1.642,0,0,0,1.64,21H2.677v.144a1.2,1.2,0,0,0,1.2,1.2H6.645a1.2,1.2,0,0,0,1.2-1.2V21H20.711a1.642,1.642,0,0,0,1.64-1.64v-4.6a.328.328,0,1,0-.656,0v4.6a.985.985,0,0,1-.984.984H7.848V11.131a.328.328,0,0,0-.656,0V21.148a.547.547,0,0,1-.547.547H3.88a.547.547,0,0,1-.547-.547V4.666a.547.547,0,0,1,.547-.547H6.645a.547.547,0,0,1,.547.547V9.819a.328.328,0,1,0,.656,0V5.466H20.711a.985.985,0,0,1,.984.984v7a.328.328,0,0,0,.328.328ZM9.751.656H19.792V4.81H9.751Z" fill="#007c42"></path><path id="Path_72" data-name="Path 72" d="M247.162,158.7v-1.932A.766.766,0,0,0,246.4,156H239.5a.766.766,0,0,0-.765.765V158.7a.766.766,0,0,0,.765.765H246.4A.766.766,0,0,0,247.162,158.7Zm-.656,0a.109.109,0,0,1-.109.109H239.5a.109.109,0,0,1-.109-.109v-1.932a.109.109,0,0,1,.109-.109H246.4a.109.109,0,0,1,.109.109Z" transform="translate(-228.316 -149.188)" fill="#007c42"></path><path id="Path_73" data-name="Path 73" d="M247.938,273.486h-1.274a.328.328,0,0,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-235.582 -261.547)" fill="#007c42"></path><path id="Path_74" data-name="Path 74" d="M314.72,273.528h-1.274a.328.328,0,0,0,0,.656h1.274a.328.328,0,1,0,0-.656Z" transform="translate(-299.449 -261.587)" fill="#007c42"></path><path id="Path_75" data-name="Path 75" d="M381.5,273.486h-1.274a.328.328,0,0,0,0,.656H381.5a.328.328,0,0,0,0-.656Z" transform="translate(-363.317 -261.547)" fill="#007c42"></path><path id="Path_76" data-name="Path 76" d="M247.938,315.609h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-235.582 -301.831)" fill="#007c42"></path><path id="Path_77" data-name="Path 77" d="M314.72,315.651h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-299.449 -301.871)" fill="#007c42"></path><path id="Path_78" data-name="Path 78" d="M381.5,315.609h-1.274a.328.328,0,1,0,0,.656H381.5a.328.328,0,1,0,0-.656Z" transform="translate(-363.317 -301.831)" fill="#007c42"></path><path id="Path_79" data-name="Path 79" d="M247.938,357.732h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-235.582 -342.115)" fill="#007c42"></path><path id="Path_80" data-name="Path 80" d="M314.72,357.773h-1.274a.328.328,0,0,0,0,.656h1.274a.328.328,0,1,0,0-.656Z" transform="translate(-299.449 -342.155)" fill="#007c42"></path><path id="Path_81" data-name="Path 81" d="M381.5,357.732h-1.274a.328.328,0,0,0,0,.656H381.5a.328.328,0,1,0,0-.656Z" transform="translate(-363.317 -342.115)" fill="#007c42"></path><path id="Path_82" data-name="Path 82" d="M247.938,399.854h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,0,0,0-.656Z" transform="translate(-235.582 -382.399)" fill="#007c42"></path><path id="Path_83" data-name="Path 83" d="M314.72,399.895h-1.274a.328.328,0,1,0,0,.656h1.274a.328.328,0,1,0,0-.656Z" transform="translate(-299.449 -382.438)" fill="#007c42"></path><path id="Path_84" data-name="Path 84" d="M381.5,399.854h-1.274a.328.328,0,1,0,0,.656H381.5a.328.328,0,0,0,0-.656Z" transform="translate(-363.317 -382.399)" fill="#007c42"></path></svg> 0114878444 </li></ul></div><div class="md:w-1/2 mb-12 md:mb-0"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1023.7624475266713!2d46.631574088726786!3d24.794504080179525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ee39d45930e57%3A0xb06fc0fbbbe7d2f3!2z2YfZitim2Kkg2KfZhNi12K3ZgdmK2YrZhiDYp9mE2LPYudmI2K_ZitmK2YY!5e0!3m2!1sar!2ssa!4v1542227466291" frameborder="0" style="${ssrRenderStyle({ "border": "0", "min-height": "400px" })}" class="w-full h-full"></iframe></div></div></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/home/FollowUs.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props2, ctx) : void 0;
};
const meta$P = void 0;
const meta$O = {
  middleware: "guest"
};
const meta$N = {
  middleware: "guest"
};
const meta$M = {
  middleware: "guest"
};
const meta$L = {
  middleware: "guest"
};
const meta$K = {
  middleware: "guest"
};
const meta$J = void 0;
const useMemberStore = defineStore("memberStore", {
  state: () => ({
    upcomingEvents: [],
    enrolledEvents: [],
    notifications: []
  }),
  actions: {
    async fetchEvents() {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2, refresh } = await useMyFetch("/members/events", {
        key: "member-events"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.upcomingEvents = data.value.upcomingEvents;
      this.enrolledEvents = data.value.enrolledEvents;
    },
    async fetchNotifications() {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2, refresh } = await useMyFetch("/members/notifications", {
        key: "member-notifications"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.notifications = data.value.notifications;
    },
    updateMember: async (body) => {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/profile", {
        key: "update-member",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.user;
      }
      return { error: error2 };
    },
    updatePassword: async (body) => {
      var _a;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/profile/password", {
        key: "update-password",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
      }
      return { error: error2 };
    },
    updateExperiences: async (experiences, fields, languages) => {
      var _a;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/profile/experiences", {
        key: "update-experiences",
        method: "POST",
        body: { experiences, fields, languages }
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
      }
      return { error: error2 };
    },
    async updatePicture(form) {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/profile/picture", {
        key: "update-picture",
        method: "POST",
        body: form
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData.avatar = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.image;
      }
      return { error: error2 };
    },
    async updateID(form) {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/profile/id", {
        key: "update-id",
        method: "POST",
        body: form
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData.national_image = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.image;
      }
      return { error: error2 };
    },
    async updateStatement(form) {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/profile/statement", {
        key: "update-statement",
        method: "POST",
        body: form
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData.employer_letter = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.image;
      }
      return { error: error2 };
    },
    async updateContract(form) {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/profile/contract", {
        key: "update-contract",
        method: "POST",
        body: form
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData.job_contract = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.image;
      }
      return { error: error2 };
    },
    async updateLicense(form) {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/profile/license", {
        key: "update-license",
        method: "POST",
        body: form
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData.newspaper_license = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.image;
      }
      return { error: error2 };
    },
    async applyMembership() {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/members/membership", {
        key: "request-membership",
        method: "POST"
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData.approved = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.approved;
      }
      return { error: error2 };
    },
    async prepareGateway(type) {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch(`/members/membership/subscribe/${type}`, {
        key: "prepare-gateway",
        method: "POST"
      });
      if (error2 == null ? void 0 : error2.value) {
        const toast = useToast();
        toast.error((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message);
      }
      return { data };
    }
  }
});
const meta$I = {
  middleware: "member"
};
const meta$H = {
  middleware: ["member", "complete"]
};
const meta$G = {
  middleware: ["member", "complete"]
};
const meta$F = {
  middleware: "member"
};
const meta$E = {
  middleware: "member"
};
const _sfc_main$2 = {
  __name: "ProfileNav",
  __ssrInlineRender: true,
  props: ["active"],
  setup(__props) {
    const authStore = useAuthStore();
    const { userData } = storeToRefs(authStore);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<ul${ssrRenderAttrs(mergeProps({ class: "w-full border-b mb-1 shadow-sm" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/profile",
        class: ["cursor-pointer inline-block text-sju-50 text-sm px-4 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: __props.active === "info" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Info"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Info")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/profile/experiences",
        class: ["cursor-pointer inline-block text-sju-50 text-sm px-4 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: __props.active === "experiences" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Exp. & fields"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Exp. & fields")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/profile/picture",
        class: ["cursor-pointer inline-block text-sju-50 text-sm px-4 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: __props.active === "picture" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Profile picture"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Profile picture")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/profile/password",
        class: ["cursor-pointer inline-block text-sju-50 text-sm px-4 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: __props.active === "password" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Password"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Password")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/profile/identification",
        class: ["cursor-pointer inline-block text-sju-50 text-sm px-4 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: __props.active === "identification" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("ID image"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("ID image")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/members/dashboard/profile/statement",
        class: ["cursor-pointer inline-block text-sju-50 text-sm px-4 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: __props.active === "statement" }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Job letter"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Job letter")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      if (((_a = unref(userData).subscription) == null ? void 0 : _a.type) === 3) {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/members/dashboard/profile/contract",
          class: ["cursor-pointer inline-block text-sju-50 text-sm px-4 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: __props.active === "contract" }]
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Job contract"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Job contract")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(userData).newspaper_type === 2) {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/members/dashboard/profile/license",
          class: ["cursor-pointer inline-block text-sju-50 text-sm px-4 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300", { active: __props.active === "license" }]
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Newspaper license"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Newspaper license")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</ul>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/members/ProfileNav.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props2, ctx) : void 0;
};
const meta$D = {
  middleware: "member"
};
const meta$C = {
  middleware: "member"
};
const meta$B = {
  middleware: "member"
};
const meta$A = {
  middleware: "member"
};
const meta$z = {
  middleware: "member"
};
const meta$y = {
  middleware: "member"
};
const meta$x = {
  middleware: "member"
};
const meta$w = {
  middleware: "member"
};
const meta$v = {
  middleware: "member"
};
const useSupportStore = defineStore("supportStore", {
  state: () => ({
    tickets: [],
    chat: {
      title: "",
      messages: []
    }
  }),
  getters: {
    getMessages: (state) => {
      const chatLog = [];
      let msgGroup = [];
      let sender = 1;
      const messages2 = state.chat.messages;
      messages2 == null ? void 0 : messages2.forEach((msg) => {
        if (msg.sender !== sender) {
          sender = msg.sender;
          if (msgGroup.length)
            chatLog.push(msgGroup);
          msgGroup = [];
        }
        msgGroup.push(msg);
      });
      if (msgGroup.length)
        chatLog.push(msgGroup);
      return chatLog;
    }
  },
  actions: {
    async fetchTickets() {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2, refresh } = await useMyFetch("/support", {
        key: "fetch-tickets"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.tickets = data.value.tickets;
    },
    async submitTicket(body) {
      var _a;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/support", {
        key: "create-ticket",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
      }
      return { error: error2 };
    },
    async fetchChat(id) {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2, refresh } = await useMyFetch(`/support/${id}`, {
        key: "fetch-ticket"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.chat.messages = data.value.messages;
      this.chat.title = data.value.title;
    },
    async sendMessage(id, body) {
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch(`/support/${id}`, {
        key: "create-ticket",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        await this.fetchChat(id);
      }
      return { error: error2 };
    }
  }
});
const meta$u = {
  middleware: "member"
};
const meta$t = {
  middleware: "member"
};
const meta$s = {
  middleware: "member"
};
const meta$r = {
  middleware: "redirect"
};
const usePageStore = defineStore("pageStore", {
  state: () => ({
    page: {}
  }),
  actions: {
    async fetchPage(slug) {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch(`/pages/${slug}`, {
        key: "static-page"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.page = data.value.page;
    }
  }
});
const meta$q = {
  key: (route) => route.fullPath,
  validate: async (route) => {
    return false;
  }
};
const usePostStore = defineStore("postStore", {
  state: () => ({
    categories: [],
    category: "all",
    posts: [],
    post: {},
    relatedPosts: [],
    pagination: {
      current_page: 1,
      perPage: 18
    }
  }),
  getters: {
    getCategory: (state) => {
      return () => useRoute().query.category || state.category;
    },
    getPagination: (state) => {
      return () => {
        state.pagination.current_page = useRoute().query.page || 1;
        return state.pagination;
      };
    }
  },
  actions: {
    async fetchCategories() {
      const { useMyFetch } = useApiFetch();
      const {
        data: {
          value: { categories }
        }
      } = await useMyFetch("/blog/categories", {
        key: "categories"
      });
      this.categories = categories;
    },
    async fetchPosts() {
      var _a, _b, _c, _d, _e, _f;
      this.pagination = {
        current_page: 1,
        perPage: 18
      };
      const { useMyFetch } = useApiFetch();
      const { data, error: error2, refresh } = await useMyFetch(
        `/blog/posts?page=${this.pagination.current_page}&perPage=${this.pagination.perPage}&category=${this.getCategory()}`,
        {
          key: "posts"
        }
      );
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.posts = data.value.data;
      this.pagination = { ...this.pagination, ...data.value.meta };
    },
    async fetchPost(id) {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const {
        data = {},
        error: error2,
        refresh
      } = await useMyFetch(`/blog/posts/${id}`, {
        key: "post"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.post = data.value.post;
      this.relatedPosts = data.value.posts;
    }
  }
});
const meta$p = {
  key: (route) => route.fullPath,
  validate: async (route) => {
    return /^\d+$/.test(route.params.id);
  }
};
const meta$o = {
  key: (route) => route.fullPath
};
const meta$n = {
  middleware: "guest"
};
const meta$m = {
  middleware: "guest"
};
const meta$l = {
  middleware: "guest"
};
const meta$k = {
  middleware: "guest"
};
const meta$j = void 0;
const useSubscriberStore = defineStore("subscriberStore", {
  state: () => ({
    upcomingEvents: [],
    enrolledEvents: []
  }),
  actions: {
    async fetchEvents() {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2, refresh } = await useMyFetch("/subscribers/events", {
        key: "subscriber-events"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.upcomingEvents = data.value.upcomingEvents;
      this.enrolledEvents = data.value.enrolledEvents;
    },
    updateSubscriber: async (body) => {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/subscribers/profile", {
        key: "update-subscriber",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.user;
      }
      return { error: error2 };
    },
    updatePassword: async (body) => {
      var _a;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/subscribers/profile/password", {
        key: "update-password",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
      }
      return { error: error2 };
    }
  }
});
const meta$i = {
  middleware: "subscriber"
};
const meta$h = {
  middleware: "subscriber"
};
const meta$g = {
  middleware: "subscriber"
};
const meta$f = {
  middleware: "subscriber"
};
const meta$e = {
  middleware: "subscriber"
};
const meta$d = {
  middleware: "subscriber"
};
const meta$c = {
  middleware: "redirect"
};
const meta$b = {
  middleware: "guest"
};
const meta$a = {
  middleware: "guest"
};
const meta$9 = {
  middleware: "guest"
};
const meta$8 = {
  middleware: "guest"
};
const meta$7 = void 0;
const useVolunteerStore = defineStore("volunteerStore", {
  state: () => ({
    upcomingEvents: [],
    enrolledEvents: []
  }),
  actions: {
    async fetchEvents() {
      var _a, _b, _c, _d, _e, _f;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2, refresh } = await useMyFetch("/volunteers/events", {
        key: "volunteer-events"
      });
      if ((_b = (_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
        throw createError({
          statusCode: (_d = (_c = error2 == null ? void 0 : error2.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
          statusMessage: (_f = (_e = error2 == null ? void 0 : error2.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
        });
      }
      this.upcomingEvents = data.value.upcomingEvents;
      this.enrolledEvents = data.value.enrolledEvents;
    },
    updateVolunteer: async (body) => {
      var _a, _b;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/volunteers/profile", {
        key: "update-volunteer",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
        useAuthStore().userData = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.user;
      }
      return { error: error2 };
    },
    updatePassword: async (body) => {
      var _a;
      const { useMyFetch } = useApiFetch();
      const { data, error: error2 } = await useMyFetch("/volunteers/profile/password", {
        key: "update-password",
        method: "POST",
        body
      });
      if (data == null ? void 0 : data.value) {
        const toast = useToast();
        toast.success((_a = data == null ? void 0 : data.value) == null ? void 0 : _a.message);
      }
      return { error: error2 };
    }
  }
});
const meta$6 = {
  middleware: "volunteer"
};
const meta$5 = {
  middleware: "volunteer"
};
const meta$4 = {
  middleware: "volunteer"
};
const meta$3 = void 0;
const meta$2 = {
  middleware: "volunteer"
};
const meta$1 = {
  middleware: "volunteer"
};
const meta = {
  middleware: "redirect"
};
const _routes = [
  {
    name: "certval",
    path: "/certval",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/certval.vue",
    children: [],
    meta: meta$T,
    alias: [],
    component: () => import('./certval.d72e829f.mjs').then((m) => m.default || m)
  },
  {
    name: "events-id-attend",
    path: "/events/:id/attend",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/events/[id]/attend.vue",
    children: [],
    meta: meta$S,
    alias: (meta$S == null ? void 0 : meta$S.alias) || [],
    component: () => import('./attend.6ccf4866.mjs').then((m) => m.default || m)
  },
  {
    name: "events-id-register",
    path: "/events/:id/register",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/events/[id]/register.vue",
    children: [],
    meta: meta$R,
    alias: (meta$R == null ? void 0 : meta$R.alias) || [],
    component: () => import('./register.51cc39ea.mjs').then((m) => m.default || m)
  },
  {
    name: "events",
    path: "/events",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/events/index.vue",
    children: [],
    meta: meta$Q,
    alias: (meta$Q == null ? void 0 : meta$Q.alias) || [],
    component: () => import('./index.1fc264dc.mjs').then((m) => m.default || m)
  },
  {
    name: "index",
    path: "/",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/index.vue",
    children: [],
    meta: meta$P,
    alias: [],
    component: () => import('./index.53c13234.mjs').then((m) => m.default || m)
  },
  {
    name: "members-auth-forget_password",
    path: "/members/auth/forget_password",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/auth/forget_password.vue",
    children: [],
    meta: meta$O,
    alias: (meta$O == null ? void 0 : meta$O.alias) || [],
    component: () => import('./forget_password.196c1a7d.mjs').then((m) => m.default || m)
  },
  {
    name: "members-auth-login",
    path: "/members/auth/login",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/auth/login.vue",
    children: [],
    meta: meta$N,
    alias: (meta$N == null ? void 0 : meta$N.alias) || [],
    component: () => import('./login.741eda89.mjs').then((m) => m.default || m)
  },
  {
    name: "members-auth-register",
    path: "/members/auth/register",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/auth/register.vue",
    children: [],
    meta: meta$M,
    alias: (meta$M == null ? void 0 : meta$M.alias) || [],
    component: () => import('./register.c6c11e06.mjs').then((m) => m.default || m)
  },
  {
    name: "members-auth-reset_password",
    path: "/members/auth/reset_password",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/auth/reset_password.vue",
    children: [],
    meta: meta$L,
    alias: (meta$L == null ? void 0 : meta$L.alias) || [],
    component: () => import('./reset_password.2537ac93.mjs').then((m) => m.default || m)
  },
  {
    name: "members-auth-verify",
    path: "/members/auth/verify",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/auth/verify.vue",
    children: [],
    meta: meta$K,
    alias: (meta$K == null ? void 0 : meta$K.alias) || [],
    component: () => import('./verify.90e05744.mjs').then((m) => m.default || m)
  },
  {
    path: "/members/dashboard",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard.vue",
    children: [
      {
        name: "members-dashboard",
        path: "",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/index.vue",
        children: [],
        meta: meta$I,
        alias: (meta$I == null ? void 0 : meta$I.alias) || [],
        component: () => import('./index.c5835374.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-membership",
        path: "membership",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/membership/index.vue",
        children: [],
        meta: meta$H,
        alias: (meta$H == null ? void 0 : meta$H.alias) || [],
        component: () => import('./index.7a19efd3.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-membership-pay",
        path: "membership/pay",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/membership/pay.vue",
        children: [],
        meta: meta$G,
        alias: (meta$G == null ? void 0 : meta$G.alias) || [],
        component: () => import('./pay.2234c2e5.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-notifications",
        path: "notifications",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/notifications.vue",
        children: [],
        meta: meta$F,
        alias: (meta$F == null ? void 0 : meta$F.alias) || [],
        component: () => import('./notifications.e9f6a756.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile-complete",
        path: "profile/complete",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/complete.vue",
        children: [],
        meta: meta$E,
        alias: (meta$E == null ? void 0 : meta$E.alias) || [],
        component: () => import('./complete.7e476f73.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile-contract",
        path: "profile/contract",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/contract.vue",
        children: [],
        meta: meta$D,
        alias: (meta$D == null ? void 0 : meta$D.alias) || [],
        component: () => import('./contract.38cd08ec.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile-experiences",
        path: "profile/experiences",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/experiences.vue",
        children: [],
        meta: meta$C,
        alias: (meta$C == null ? void 0 : meta$C.alias) || [],
        component: () => import('./experiences.22d0fc9e.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile-identification",
        path: "profile/identification",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/identification.vue",
        children: [],
        meta: meta$B,
        alias: (meta$B == null ? void 0 : meta$B.alias) || [],
        component: () => import('./identification.3f36b4a7.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile",
        path: "profile",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/index.vue",
        children: [],
        meta: meta$A,
        alias: (meta$A == null ? void 0 : meta$A.alias) || [],
        component: () => import('./index.627fa401.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile-license",
        path: "profile/license",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/license.vue",
        children: [],
        meta: meta$z,
        alias: (meta$z == null ? void 0 : meta$z.alias) || [],
        component: () => import('./license.3eb200ee.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile-password",
        path: "profile/password",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/password.vue",
        children: [],
        meta: meta$y,
        alias: (meta$y == null ? void 0 : meta$y.alias) || [],
        component: () => import('./password.0bccf63f.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile-picture",
        path: "profile/picture",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/picture.vue",
        children: [],
        meta: meta$x,
        alias: (meta$x == null ? void 0 : meta$x.alias) || [],
        component: () => import('./picture.9f8872cf.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-profile-statement",
        path: "profile/statement",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/profile/statement.vue",
        children: [],
        meta: meta$w,
        alias: (meta$w == null ? void 0 : meta$w.alias) || [],
        component: () => import('./statement.190e00f8.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-questionnaire-eventId-questionnaireId",
        path: "questionnaire/:eventId/:questionnaireId",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/questionnaire/[eventId]/[questionnaireId].vue",
        children: [],
        meta: meta$v,
        alias: (meta$v == null ? void 0 : meta$v.alias) || [],
        component: () => import('./_questionnaireId_.cd9df96d.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-support-id",
        path: "support/:id",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/support/[id].vue",
        children: [],
        meta: meta$u,
        alias: (meta$u == null ? void 0 : meta$u.alias) || [],
        component: () => import('./_id_.a086e705.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-support-create",
        path: "support/create",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/support/create.vue",
        children: [],
        meta: meta$t,
        alias: (meta$t == null ? void 0 : meta$t.alias) || [],
        component: () => import('./create.7d4b2065.mjs').then((m) => m.default || m)
      },
      {
        name: "members-dashboard-support",
        path: "support",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/dashboard/support/index.vue",
        children: [],
        meta: meta$s,
        alias: (meta$s == null ? void 0 : meta$s.alias) || [],
        component: () => import('./index.8ff9121c.mjs').then((m) => m.default || m)
      }
    ],
    meta: meta$J,
    alias: [],
    component: () => import('./dashboard.38c84807.mjs').then((m) => m.default || m)
  },
  {
    name: "members",
    path: "/members",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/members/index.vue",
    children: [],
    meta: meta$r,
    alias: (meta$r == null ? void 0 : meta$r.alias) || [],
    component: () => import('./index.ac8ae81a.mjs').then((m) => m.default || m)
  },
  {
    name: "pages-slug",
    path: "/pages/:slug",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/pages/[slug].vue",
    children: [],
    meta: meta$q,
    alias: (meta$q == null ? void 0 : meta$q.alias) || [],
    component: () => import('./_slug_.0f193263.mjs').then((m) => m.default || m)
  },
  {
    name: "posts-id",
    path: "/posts/:id",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/posts/[id].vue",
    children: [],
    meta: meta$p,
    alias: (meta$p == null ? void 0 : meta$p.alias) || [],
    component: () => import('./_id_.72b8a3a2.mjs').then((m) => m.default || m)
  },
  {
    name: "posts",
    path: "/posts",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/posts/index.vue",
    children: [],
    meta: meta$o,
    alias: (meta$o == null ? void 0 : meta$o.alias) || [],
    component: () => import('./index.6047cf4a.mjs').then((m) => m.default || m)
  },
  {
    name: "subscribers-auth-forget_password",
    path: "/subscribers/auth/forget_password",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/auth/forget_password.vue",
    children: [],
    meta: meta$n,
    alias: (meta$n == null ? void 0 : meta$n.alias) || [],
    component: () => import('./forget_password.5edb92d1.mjs').then((m) => m.default || m)
  },
  {
    name: "subscribers-auth-login",
    path: "/subscribers/auth/login",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/auth/login.vue",
    children: [],
    meta: meta$m,
    alias: (meta$m == null ? void 0 : meta$m.alias) || [],
    component: () => import('./login.4daaaa17.mjs').then((m) => m.default || m)
  },
  {
    name: "subscribers-auth-register",
    path: "/subscribers/auth/register",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/auth/register.vue",
    children: [],
    meta: meta$l,
    alias: (meta$l == null ? void 0 : meta$l.alias) || [],
    component: () => import('./register.5de78132.mjs').then((m) => m.default || m)
  },
  {
    name: "subscribers-auth-reset_password",
    path: "/subscribers/auth/reset_password",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/auth/reset_password.vue",
    children: [],
    meta: meta$k,
    alias: (meta$k == null ? void 0 : meta$k.alias) || [],
    component: () => import('./reset_password.4ea606d2.mjs').then((m) => m.default || m)
  },
  {
    path: "/subscribers/dashboard",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/dashboard.vue",
    children: [
      {
        name: "subscribers-dashboard",
        path: "",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/dashboard/index.vue",
        children: [],
        meta: meta$i,
        alias: (meta$i == null ? void 0 : meta$i.alias) || [],
        component: () => import('./index.243384b8.mjs').then((m) => m.default || m)
      },
      {
        name: "subscribers-dashboard-profile",
        path: "profile",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/dashboard/profile.vue",
        children: [],
        meta: meta$h,
        alias: (meta$h == null ? void 0 : meta$h.alias) || [],
        component: () => import('./profile.2540d4e2.mjs').then((m) => m.default || m)
      },
      {
        name: "subscribers-dashboard-questionnaire-eventId-questionnaireId",
        path: "questionnaire/:eventId/:questionnaireId",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/dashboard/questionnaire/[eventId]/[questionnaireId].vue",
        children: [],
        meta: meta$g,
        alias: (meta$g == null ? void 0 : meta$g.alias) || [],
        component: () => import('./_questionnaireId_.90926fce.mjs').then((m) => m.default || m)
      },
      {
        name: "subscribers-dashboard-support-id",
        path: "support/:id",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/dashboard/support/[id].vue",
        children: [],
        meta: meta$f,
        alias: (meta$f == null ? void 0 : meta$f.alias) || [],
        component: () => import('./_id_.5beea3f5.mjs').then((m) => m.default || m)
      },
      {
        name: "subscribers-dashboard-support-create",
        path: "support/create",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/dashboard/support/create.vue",
        children: [],
        meta: meta$e,
        alias: (meta$e == null ? void 0 : meta$e.alias) || [],
        component: () => import('./create.ee07a594.mjs').then((m) => m.default || m)
      },
      {
        name: "subscribers-dashboard-support",
        path: "support",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/dashboard/support/index.vue",
        children: [],
        meta: meta$d,
        alias: (meta$d == null ? void 0 : meta$d.alias) || [],
        component: () => import('./index.11a8f4e1.mjs').then((m) => m.default || m)
      }
    ],
    meta: meta$j,
    alias: [],
    component: () => import('./dashboard.686ea20a.mjs').then((m) => m.default || m)
  },
  {
    name: "subscribers",
    path: "/subscribers",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/subscribers/index.vue",
    children: [],
    meta: meta$c,
    alias: (meta$c == null ? void 0 : meta$c.alias) || [],
    component: () => import('./index.df4dde3d.mjs').then((m) => m.default || m)
  },
  {
    name: "volunteers-auth-forget_password",
    path: "/volunteers/auth/forget_password",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/auth/forget_password.vue",
    children: [],
    meta: meta$b,
    alias: (meta$b == null ? void 0 : meta$b.alias) || [],
    component: () => import('./forget_password.715d62d3.mjs').then((m) => m.default || m)
  },
  {
    name: "volunteers-auth-login",
    path: "/volunteers/auth/login",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/auth/login.vue",
    children: [],
    meta: meta$a,
    alias: (meta$a == null ? void 0 : meta$a.alias) || [],
    component: () => import('./login.d095073d.mjs').then((m) => m.default || m)
  },
  {
    name: "volunteers-auth-register",
    path: "/volunteers/auth/register",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/auth/register.vue",
    children: [],
    meta: meta$9,
    alias: (meta$9 == null ? void 0 : meta$9.alias) || [],
    component: () => import('./register.67a03d2f.mjs').then((m) => m.default || m)
  },
  {
    name: "volunteers-auth-reset_password",
    path: "/volunteers/auth/reset_password",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/auth/reset_password.vue",
    children: [],
    meta: meta$8,
    alias: (meta$8 == null ? void 0 : meta$8.alias) || [],
    component: () => import('./reset_password.34a3d0fc.mjs').then((m) => m.default || m)
  },
  {
    path: "/volunteers/dashboard",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/dashboard.vue",
    children: [
      {
        name: "volunteers-dashboard",
        path: "",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/dashboard/index.vue",
        children: [],
        meta: meta$6,
        alias: (meta$6 == null ? void 0 : meta$6.alias) || [],
        component: () => import('./index.56c1e0f8.mjs').then((m) => m.default || m)
      },
      {
        name: "volunteers-dashboard-profile",
        path: "profile",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/dashboard/profile.vue",
        children: [],
        meta: meta$5,
        alias: (meta$5 == null ? void 0 : meta$5.alias) || [],
        component: () => import('./profile.f1886db2.mjs').then((m) => m.default || m)
      },
      {
        name: "volunteers-dashboard-questionnaire-eventId-questionnaireId",
        path: "questionnaire/:eventId/:questionnaireId",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/dashboard/questionnaire/[eventId]/[questionnaireId].vue",
        children: [],
        meta: meta$4,
        alias: (meta$4 == null ? void 0 : meta$4.alias) || [],
        component: () => import('./_questionnaireId_.590cf3e4.mjs').then((m) => m.default || m)
      },
      {
        name: "volunteers-dashboard-support-id",
        path: "support/:id",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/dashboard/support/[id].vue",
        children: [],
        meta: meta$3,
        alias: [],
        component: () => import('./_id_.eae14f14.mjs').then((m) => m.default || m)
      },
      {
        name: "volunteers-dashboard-support-create",
        path: "support/create",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/dashboard/support/create.vue",
        children: [],
        meta: meta$2,
        alias: (meta$2 == null ? void 0 : meta$2.alias) || [],
        component: () => import('./create.aab87f2f.mjs').then((m) => m.default || m)
      },
      {
        name: "volunteers-dashboard-support",
        path: "support",
        file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/dashboard/support/index.vue",
        children: [],
        meta: meta$1,
        alias: (meta$1 == null ? void 0 : meta$1.alias) || [],
        component: () => import('./index.7ed612a5.mjs').then((m) => m.default || m)
      }
    ],
    meta: meta$7,
    alias: [],
    component: () => import('./dashboard.e0c5c97c.mjs').then((m) => m.default || m)
  },
  {
    name: "volunteers",
    path: "/volunteers",
    file: "C:/wamp64/www/Saudi Journalists V2/users-app/pages/volunteers/index.vue",
    children: [],
    meta,
    alias: (meta == null ? void 0 : meta.alias) || [],
    component: () => import('./index.109fc287.mjs').then((m) => m.default || m)
  }
];
const configRouterOptions = {};
const routerOptions = {
  ...configRouterOptions
};
const globalMiddleware = [];
const namedMiddleware = {
  complete: () => import('./complete.d0d3cb3a.mjs'),
  guest: () => import('./guest.9a06ee50.mjs'),
  member: () => import('./member.c0cefa84.mjs'),
  redirect: () => import('./redirect.fd1dbf1f.mjs'),
  subscriber: () => import('./subscriber.b2e66a4b.mjs'),
  volunteer: () => import('./volunteer.26d752fa.mjs')
};
const node_modules_nuxt_dist_pages_runtime_router_mjs_qNv5Ky2ZmB = defineNuxtPlugin(async (nuxtApp) => {
  var _a, _b, _c, _d;
  let __temp, __restore;
  nuxtApp.vueApp.component("NuxtPage", NuxtPage);
  nuxtApp.vueApp.component("NuxtNestedPage", NuxtPage);
  nuxtApp.vueApp.component("NuxtChild", NuxtPage);
  let routerBase = useRuntimeConfig().app.baseURL;
  if (routerOptions.hashMode && !routerBase.includes("#")) {
    routerBase += "#";
  }
  const history = (_b = (_a = routerOptions.history) == null ? void 0 : _a.call(routerOptions, routerBase)) != null ? _b : createMemoryHistory(routerBase);
  const routes = (_d = (_c = routerOptions.routes) == null ? void 0 : _c.call(routerOptions, _routes)) != null ? _d : _routes;
  const initialURL = nuxtApp.ssrContext.url;
  const router = createRouter({
    ...routerOptions,
    history,
    routes
  });
  nuxtApp.vueApp.use(router);
  const previousRoute = shallowRef(router.currentRoute.value);
  router.afterEach((_to, from) => {
    previousRoute.value = from;
  });
  Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
    get: () => previousRoute.value
  });
  const _route = shallowRef(router.resolve(initialURL));
  const syncCurrentRoute = () => {
    _route.value = router.currentRoute.value;
  };
  nuxtApp.hook("page:finish", syncCurrentRoute);
  router.afterEach((to2, from) => {
    var _a2, _b2, _c2, _d2;
    if (((_b2 = (_a2 = to2.matched[0]) == null ? void 0 : _a2.components) == null ? void 0 : _b2.default) === ((_d2 = (_c2 = from.matched[0]) == null ? void 0 : _c2.components) == null ? void 0 : _d2.default)) {
      syncCurrentRoute();
    }
  });
  const route = {};
  for (const key in _route.value) {
    route[key] = computed(() => _route.value[key]);
  }
  nuxtApp._route = reactive(route);
  nuxtApp._middleware = nuxtApp._middleware || {
    global: [],
    named: {}
  };
  useError();
  try {
    if (true) {
      ;
      [__temp, __restore] = executeAsync(() => router.push(initialURL)), await __temp, __restore();
      ;
    }
    ;
    [__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
    ;
  } catch (error2) {
    callWithNuxt(nuxtApp, showError, [error2]);
  }
  const initialLayout = useState("_layout");
  router.beforeEach(async (to2, from) => {
    var _a2, _b2;
    to2.meta = reactive(to2.meta);
    if (nuxtApp.isHydrating) {
      to2.meta.layout = (_a2 = initialLayout.value) != null ? _a2 : to2.meta.layout;
    }
    nuxtApp._processingMiddleware = true;
    const middlewareEntries = /* @__PURE__ */ new Set([...globalMiddleware, ...nuxtApp._middleware.global]);
    for (const component of to2.matched) {
      const componentMiddleware = component.meta.middleware;
      if (!componentMiddleware) {
        continue;
      }
      if (Array.isArray(componentMiddleware)) {
        for (const entry2 of componentMiddleware) {
          middlewareEntries.add(entry2);
        }
      } else {
        middlewareEntries.add(componentMiddleware);
      }
    }
    for (const entry2 of middlewareEntries) {
      const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_b2 = namedMiddleware[entry2]) == null ? void 0 : _b2.call(namedMiddleware).then((r) => r.default || r)) : entry2;
      if (!middleware) {
        throw new Error(`Unknown route middleware: '${entry2}'.`);
      }
      const result = await callWithNuxt(nuxtApp, middleware, [to2, from]);
      {
        if (result === false || result instanceof Error) {
          const error2 = result || createError$1({
            statusMessage: `Route navigation aborted: ${initialURL}`
          });
          return callWithNuxt(nuxtApp, showError, [error2]);
        }
      }
      if (result || result === false) {
        return result;
      }
    }
  });
  router.afterEach(async (to2) => {
    delete nuxtApp._processingMiddleware;
    if (to2.matched.length === 0) {
      callWithNuxt(nuxtApp, showError, [createError$1({
        statusCode: 404,
        fatal: false,
        statusMessage: `Page not found: ${to2.fullPath}`
      })]);
    } else if (to2.matched[0].name === "404" && nuxtApp.ssrContext) {
      nuxtApp.ssrContext.event.res.statusCode = 404;
    } else {
      const currentURL = to2.fullPath || "/";
      if (!isEqual(currentURL, initialURL)) {
        await callWithNuxt(nuxtApp, navigateTo, [currentURL]);
      }
    }
  });
  nuxtApp.hooks.hookOnce("app:created", async () => {
    try {
      await router.replace({
        ...router.resolve(initialURL),
        name: void 0,
        force: true
      });
    } catch (error2) {
      callWithNuxt(nuxtApp, showError, [error2]);
    }
  });
  return { provide: { router } };
});
const memo = {};
let instanceKey;
const instanceScopes = /* @__PURE__ */ new Map();
const raw = "__raw__";
const isClassProp = /[a-zA-Z0-9\-][cC]lass$/;
function getRef(token, data) {
  const value = ref(null);
  if (token === "get") {
    const nodeRefs = {};
    value.value = get$1.bind(null, nodeRefs);
    return value;
  }
  const path = token.split(".");
  watchEffect(() => value.value = getValue(data, path));
  return value;
}
function getValue(set2, path) {
  if (Array.isArray(set2)) {
    for (const subset of set2) {
      const value = subset !== false && getValue(subset, path);
      if (value !== void 0)
        return value;
    }
    return void 0;
  }
  let foundValue = void 0;
  let obj = set2;
  for (const i2 in path) {
    const key = path[i2];
    if (typeof obj !== "object" || obj === null) {
      foundValue = void 0;
      break;
    }
    const currentValue = obj[key];
    if (Number(i2) === path.length - 1 && currentValue !== void 0) {
      foundValue = currentValue;
      break;
    }
    obj = currentValue;
  }
  return foundValue;
}
function get$1(nodeRefs, id) {
  if (typeof id !== "string")
    return warn(650);
  if (!(id in nodeRefs))
    nodeRefs[id] = ref(void 0);
  if (nodeRefs[id].value === void 0) {
    nodeRefs[id].value = null;
    const root = getNode(id);
    if (root)
      nodeRefs[id].value = root.context;
    watchRegistry(id, ({ payload: node }) => {
      nodeRefs[id].value = isNode(node) ? node.context : node;
    });
  }
  return nodeRefs[id].value;
}
function parseSchema(library, schema) {
  function parseCondition(library2, node) {
    const condition = provider(compile(node.if), { if: true });
    const children = createElements(library2, node.then);
    const alternate = node.else ? createElements(library2, node.else) : null;
    return [condition, children, alternate];
  }
  function parseConditionAttr(attr, _default) {
    var _a, _b;
    const condition = provider(compile(attr.if));
    let b = () => _default;
    let a = () => _default;
    if (typeof attr.then === "object") {
      a = parseAttrs(attr.then, void 0);
    } else if (typeof attr.then === "string" && ((_a = attr.then) === null || _a === void 0 ? void 0 : _a.startsWith("$"))) {
      a = provider(compile(attr.then));
    } else {
      a = () => attr.then;
    }
    if (has(attr, "else")) {
      if (typeof attr.else === "object") {
        b = parseAttrs(attr.else);
      } else if (typeof attr.else === "string" && ((_b = attr.else) === null || _b === void 0 ? void 0 : _b.startsWith("$"))) {
        b = provider(compile(attr.else));
      } else {
        b = () => attr.else;
      }
    }
    return () => condition() ? a() : b();
  }
  function parseAttrs(unparsedAttrs, bindExp, _default = {}) {
    const explicitAttrs = new Set(Object.keys(unparsedAttrs || {}));
    const boundAttrs = bindExp ? provider(compile(bindExp)) : () => ({});
    const setters = [
      (attrs) => {
        const bound = boundAttrs();
        for (const attr in bound) {
          if (!explicitAttrs.has(attr)) {
            attrs[attr] = bound[attr];
          }
        }
      }
    ];
    if (unparsedAttrs) {
      if (isConditional(unparsedAttrs)) {
        const condition = parseConditionAttr(unparsedAttrs, _default);
        return condition;
      }
      for (let attr in unparsedAttrs) {
        const value = unparsedAttrs[attr];
        let getValue2;
        const isStr = typeof value === "string";
        if (attr.startsWith(raw)) {
          attr = attr.substring(7);
          getValue2 = () => value;
        } else if (isStr && value.startsWith("$") && value.length > 1 && !(value.startsWith("$reset") && isClassProp.test(attr))) {
          getValue2 = provider(compile(value));
        } else if (typeof value === "object" && isConditional(value)) {
          getValue2 = parseConditionAttr(value, void 0);
        } else if (typeof value === "object" && isPojo(value)) {
          getValue2 = parseAttrs(value);
        } else {
          getValue2 = () => value;
        }
        setters.push((attrs) => {
          attrs[attr] = getValue2();
        });
      }
    }
    return () => {
      const attrs = Array.isArray(unparsedAttrs) ? [] : {};
      setters.forEach((setter) => setter(attrs));
      return attrs;
    };
  }
  function parseNode(library2, _node) {
    let element = null;
    let attrs = () => null;
    let condition = false;
    let children = null;
    let alternate = null;
    let iterator = null;
    let resolve = false;
    const node = sugar(_node);
    if (isDOM(node)) {
      element = node.$el;
      attrs = node.$el !== "text" ? parseAttrs(node.attrs, node.bind) : () => null;
    } else if (isComponent(node)) {
      if (typeof node.$cmp === "string") {
        if (has(library2, node.$cmp)) {
          element = library2[node.$cmp];
        } else {
          element = node.$cmp;
          resolve = true;
        }
      } else {
        element = node.$cmp;
      }
      attrs = parseAttrs(node.props, node.bind);
    } else if (isConditional(node)) {
      [condition, children, alternate] = parseCondition(library2, node);
    }
    if (!isConditional(node) && "if" in node) {
      condition = provider(compile(node.if));
    } else if (!isConditional(node) && element === null) {
      condition = () => true;
    }
    if ("children" in node && node.children) {
      if (typeof node.children === "string") {
        if (node.children.startsWith("$slots.")) {
          element = element === "text" ? "slot" : element;
          children = provider(compile(node.children));
        } else if (node.children.startsWith("$") && node.children.length > 1) {
          const value = provider(compile(node.children));
          children = () => String(value());
        } else {
          children = () => String(node.children);
        }
      } else if (Array.isArray(node.children)) {
        children = createElements(library2, node.children);
      } else {
        const [childCondition, c, a] = parseCondition(library2, node.children);
        children = (iterationData) => childCondition && childCondition() ? c && c(iterationData) : a && a(iterationData);
      }
    }
    if (isComponent(node)) {
      if (children) {
        const produceChildren = children;
        children = (iterationData) => {
          return {
            default(slotData2, key) {
              var _a, _b, _c, _d;
              const currentKey = instanceKey;
              if (key)
                instanceKey = key;
              if (slotData2)
                (_a = instanceScopes.get(instanceKey)) === null || _a === void 0 ? void 0 : _a.unshift(slotData2);
              if (iterationData)
                (_b = instanceScopes.get(instanceKey)) === null || _b === void 0 ? void 0 : _b.unshift(iterationData);
              const c = produceChildren(iterationData);
              if (slotData2)
                (_c = instanceScopes.get(instanceKey)) === null || _c === void 0 ? void 0 : _c.shift();
              if (iterationData)
                (_d = instanceScopes.get(instanceKey)) === null || _d === void 0 ? void 0 : _d.shift();
              instanceKey = currentKey;
              return c;
            }
          };
        };
        children.slot = true;
      } else {
        children = () => ({});
      }
    }
    if ("for" in node && node.for) {
      const values = node.for.length === 3 ? node.for[2] : node.for[1];
      const getValues = typeof values === "string" && values.startsWith("$") ? provider(compile(values)) : () => values;
      iterator = [
        getValues,
        node.for[0],
        node.for.length === 3 ? String(node.for[1]) : null
      ];
    }
    return [condition, element, attrs, children, alternate, iterator, resolve];
  }
  function createSlots(children, iterationData) {
    const slots = children(iterationData);
    const currentKey = instanceKey;
    return Object.keys(slots).reduce((allSlots, slotName) => {
      const slotFn = slots && slots[slotName];
      allSlots[slotName] = (data) => {
        return slotFn && slotFn(data, currentKey) || null;
      };
      return allSlots;
    }, {});
  }
  function createElement2(library2, node) {
    const [condition, element, attrs, children, alternate, iterator, resolve] = parseNode(library2, node);
    let createNodes = (iterationData) => {
      if (condition && element === null && children) {
        return condition() ? children(iterationData) : alternate && alternate(iterationData);
      }
      if (element && (!condition || condition())) {
        if (element === "text" && children) {
          return createTextVNode(String(children()));
        }
        if (element === "slot" && children)
          return children(iterationData);
        const el = resolve ? resolveComponent(element) : element;
        const slots = (children === null || children === void 0 ? void 0 : children.slot) ? createSlots(children, iterationData) : null;
        return h(el, attrs(), slots || (children ? children(iterationData) : []));
      }
      return typeof alternate === "function" ? alternate(iterationData) : alternate;
    };
    if (iterator) {
      const repeatedNode = createNodes;
      const [getValues, valueName, keyName] = iterator;
      createNodes = () => {
        const _v = getValues();
        const values = !isNaN(_v) ? Array(Number(_v)).fill(0).map((_, i2) => i2) : _v;
        const fragment = [];
        if (typeof values !== "object")
          return null;
        const instanceScope = instanceScopes.get(instanceKey) || [];
        for (const key in values) {
          if (Array.isArray(values) && key === "length")
            continue;
          const iterationData = Object.defineProperty({
            ...instanceScope.reduce((previousIterationData, scopedData) => {
              if (previousIterationData.__idata) {
                return { ...previousIterationData, ...scopedData };
              }
              return scopedData;
            }, {}),
            [valueName]: values[key],
            ...keyName !== null ? { [keyName]: key } : {}
          }, "__idata", { enumerable: false, value: true });
          instanceScope.unshift(iterationData);
          fragment.push(repeatedNode.bind(null, iterationData)());
          instanceScope.shift();
        }
        return fragment;
      };
    }
    return createNodes;
  }
  function createElements(library2, schema2) {
    if (Array.isArray(schema2)) {
      const els = schema2.map(createElement2.bind(null, library2));
      return (iterationData) => els.map((element2) => element2(iterationData));
    }
    const element = createElement2(library2, schema2);
    return (iterationData) => element(iterationData);
  }
  const providers = [];
  function provider(compiled, hints = {}) {
    const compiledFns = {};
    providers.push((callback, key) => {
      compiledFns[key] = compiled.provide((tokens) => callback(tokens, hints));
    });
    return () => compiledFns[instanceKey]();
  }
  return function createInstance(providerCallback, key) {
    const memoKey = JSON.stringify(schema);
    const [render2, compiledProviders] = has(memo, memoKey) ? memo[memoKey] : [createElements(library, schema), providers];
    memo[memoKey] = [render2, compiledProviders];
    compiledProviders.forEach((compiledProvider) => {
      compiledProvider(providerCallback, key);
    });
    return () => {
      instanceKey = key;
      return render2();
    };
  };
}
function useScope(token, defaultValue) {
  const scopedData = instanceScopes.get(instanceKey) || [];
  let scopedValue = void 0;
  if (scopedData.length) {
    scopedValue = getValue(scopedData, token.split("."));
  }
  return scopedValue === void 0 ? defaultValue : scopedValue;
}
function slotData(data, key) {
  return new Proxy(data, {
    get(...args) {
      let data2 = void 0;
      const property = args[1];
      if (typeof property === "string") {
        const prevKey = instanceKey;
        instanceKey = key;
        data2 = useScope(property, void 0);
        instanceKey = prevKey;
      }
      return data2 !== void 0 ? data2 : Reflect.get(...args);
    }
  });
}
function createRenderFn(instanceCreator, data, instanceKey2) {
  return instanceCreator((requirements, hints = {}) => {
    return requirements.reduce((tokens, token) => {
      if (token.startsWith("slots.")) {
        const slot = token.substring(6);
        const hasSlot = data.slots && has(data.slots, slot);
        if (hints.if) {
          tokens[token] = () => hasSlot;
        } else if (data.slots && hasSlot) {
          const scopedData = slotData(data, instanceKey2);
          tokens[token] = () => data.slots[slot](scopedData);
          return tokens;
        }
      }
      const value = getRef(token, data);
      tokens[token] = () => useScope(token, value.value);
      return tokens;
    }, {});
  }, instanceKey2);
}
let i = 0;
const FormKitSchema = defineComponent({
  name: "FormKitSchema",
  props: {
    schema: {
      type: [Array, Object],
      required: true
    },
    data: {
      type: Object,
      default: () => ({})
    },
    library: {
      type: Object,
      default: () => ({})
    }
  },
  setup(props2, context) {
    const instance = getCurrentInstance();
    let instanceKey2 = Symbol(String(i++));
    instanceScopes.set(instanceKey2, []);
    let provider = parseSchema(props2.library, props2.schema);
    let render2;
    let data;
    watch(() => props2.schema, (newSchema, oldSchema) => {
      var _a;
      instanceKey2 = Symbol(String(i++));
      provider = parseSchema(props2.library, props2.schema);
      render2 = createRenderFn(provider, data, instanceKey2);
      if (newSchema === oldSchema) {
        ((_a = instance === null || instance === void 0 ? void 0 : instance.proxy) === null || _a === void 0 ? void 0 : _a.$forceUpdate)();
      }
    }, { deep: true });
    watchEffect(() => {
      data = Object.assign(reactive(props2.data), {
        slots: context.slots
      });
      render2 = createRenderFn(provider, data, instanceKey2);
    });
    return () => render2();
  }
});
const nativeProps = {
  config: {
    type: Object,
    default: {}
  },
  classes: {
    type: Object,
    required: false
  },
  delay: {
    type: Number,
    required: false
  },
  errors: {
    type: Array,
    default: []
  },
  inputErrors: {
    type: Object,
    default: () => ({})
  },
  index: {
    type: Number,
    required: false
  },
  id: {
    type: String,
    required: false
  },
  modelValue: {
    required: false
  },
  name: {
    type: String,
    required: false
  },
  parent: {
    type: Object,
    required: false
  },
  plugins: {
    type: Array,
    default: []
  },
  sectionsSchema: {
    type: Object,
    default: {}
  },
  type: {
    type: [String, Object],
    default: "text"
  },
  validation: {
    type: [String, Array],
    required: false
  },
  validationMessages: {
    type: Object,
    required: false
  },
  validationRules: {
    type: Object,
    required: false
  },
  validationLabel: {
    type: [String, Function],
    required: false
  }
};
const props = nativeProps;
const parentSymbol = Symbol("FormKitParent");
const FormKit = defineComponent({
  props,
  emits: {
    input: (_value, _node) => true,
    inputRaw: (_value, _node) => true,
    "update:modelValue": (_value) => true,
    node: (node) => !!node,
    submit: (_data, _node) => true,
    submitRaw: (_event, _node) => true,
    submitInvalid: (_node) => true
  },
  inheritAttrs: false,
  setup(props2, context) {
    const node = useInput(props2, context);
    if (!node.props.definition)
      error(600, node);
    if (node.props.definition.component) {
      return () => {
        var _a;
        return h((_a = node.props.definition) === null || _a === void 0 ? void 0 : _a.component, {
          context: node.context
        }, { ...context.slots });
      };
    }
    const schema = ref([]);
    const generateSchema = () => {
      var _a, _b;
      const schemaDefinition = (_b = (_a = node.props) === null || _a === void 0 ? void 0 : _a.definition) === null || _b === void 0 ? void 0 : _b.schema;
      if (!schemaDefinition)
        error(601, node);
      schema.value = typeof schemaDefinition === "function" ? schemaDefinition({ ...props2.sectionsSchema }) : schemaDefinition;
    };
    generateSchema();
    node.on("schema", generateSchema);
    context.emit("node", node);
    const library = node.props.definition.library;
    context.expose({ node });
    return () => h(FormKitSchema, { schema: schema.value, data: node.context, library }, { ...context.slots });
  }
});
function createPlugin(app, options2) {
  app.component(options2.alias || "FormKit", FormKit).component(options2.schemaAlias || "FormKitSchema", FormKitSchema);
  return {
    get: getNode,
    setLocale: (locale) => {
      var _a;
      if ((_a = options2.config) === null || _a === void 0 ? void 0 : _a.rootConfig) {
        options2.config.rootConfig.locale = locale;
      }
    },
    clearErrors,
    setErrors,
    submit: submitForm,
    reset
  };
}
const optionsSymbol = Symbol.for("FormKitOptions");
const configSymbol = Symbol.for("FormKitConfig");
const plugin = {
  install(app, _options) {
    const options2 = Object.assign({
      alias: "FormKit",
      schemaAlias: "FormKitSchema"
    }, typeof _options === "function" ? _options() : _options);
    const rootConfig = createConfig(options2.config || {});
    options2.config = { rootConfig };
    app.config.globalProperties.$formkit = createPlugin(app, options2);
    app.provide(optionsSymbol, options2);
    app.provide(configSymbol, rootConfig);
  }
};
const invalidGet = Symbol();
function watchVerbose(obj, callback) {
  const watchers = {};
  const applyWatch = (paths) => {
    for (const path of paths) {
      if (path.__str in watchers)
        watchers[path.__str]();
      watchers[path.__str] = watch(touch.bind(null, obj, path), dispatcher.bind(null, path), { deep: false });
    }
  };
  const clearWatch = (path) => {
    if (!path.length)
      return;
    for (const key in watchers) {
      if (`${key}`.startsWith(`${path.__str}.`)) {
        watchers[key]();
        delete watchers[key];
      }
    }
  };
  const dispatcher = createDispatcher(obj, callback, applyWatch, clearWatch);
  applyWatch(getPaths(obj));
}
function createDispatcher(obj, callback, applyWatch, clearChildWatches) {
  return (path) => {
    const value = get(obj, path);
    if (value === invalidGet)
      return;
    if (path.__deep)
      clearChildWatches(path);
    if (typeof value === "object")
      applyWatch(getPaths(value, [path], ...path));
    callback(path, value, obj);
  };
}
function touch(obj, path) {
  const value = get(obj, path);
  return value && typeof value === "object" ? Object.keys(value) : value;
}
function get(obj, path) {
  if (isRef(obj)) {
    if (path.length === 0)
      return obj.value;
    obj = obj.value;
  }
  return path.reduce((value, segment) => {
    if (value === invalidGet)
      return value;
    if (value === null || typeof value !== "object") {
      return invalidGet;
    }
    return value[segment];
  }, obj);
}
function getPaths(obj, paths = [], ...parents) {
  if (obj === null)
    return paths;
  if (!parents.length) {
    const path = Object.defineProperty([], "__str", {
      value: ""
    });
    obj = isRef(obj) ? obj.value : obj;
    if (obj && typeof obj === "object") {
      Object.defineProperty(path, "__deep", { value: true });
      paths.push(path);
    } else {
      return [path];
    }
  }
  if (obj === null || typeof obj !== "object")
    return paths;
  for (const key in obj) {
    const path = parents.concat(key);
    Object.defineProperty(path, "__str", { value: path.join(".") });
    const value = obj[key];
    if (isPojo(value) || Array.isArray(value)) {
      paths.push(Object.defineProperty(path, "__deep", { value: true }));
      paths = paths.concat(getPaths(value, [], ...path));
    } else {
      paths.push(path);
    }
  }
  return paths;
}
function useRaw(obj) {
  if (obj === null || typeof obj !== "object")
    return obj;
  if (isReactive(obj)) {
    obj = toRaw(obj);
  } else if (isRef(obj)) {
    obj = isReactive(obj.value) ? useRaw(obj.value) : obj.value;
  }
  return obj;
}
const pseudoProps = [
  "help",
  "label",
  "ignore",
  "disabled",
  "preserve",
  /^preserve(-e|E)rrors/,
  /^[a-z]+(?:-visibility|Visibility)$/,
  /^[a-zA-Z-]+(?:-class|Class)$/,
  "prefixIcon",
  "suffixIcon",
  /^[a-zA-Z-]+(?:-icon|Icon)$/
];
function classesToNodeProps(node, props2) {
  if (props2.classes) {
    Object.keys(props2.classes).forEach((key) => {
      if (typeof key === "string") {
        node.props[`_${key}Class`] = props2.classes[key];
        if (isObject(props2.classes[key]) && key === "inner")
          Object.values(props2.classes[key]);
      }
    });
  }
}
function onlyListeners(props2) {
  if (!props2)
    return {};
  const knownListeners = ["Submit", "SubmitRaw", "SubmitInvalid"].reduce((listeners, listener) => {
    const name = `on${listener}`;
    if (name in props2) {
      if (typeof props2[name] === "function") {
        listeners[name] = props2[name];
      }
    }
    return listeners;
  }, {});
  return knownListeners;
}
function useInput(props2, context, options2 = {}) {
  const config2 = Object.assign({}, inject(optionsSymbol) || {}, options2);
  const instance = getCurrentInstance();
  const listeners = onlyListeners(instance === null || instance === void 0 ? void 0 : instance.vnode.props);
  const isVModeled = props2.modelValue !== void 0;
  const value = props2.modelValue !== void 0 ? props2.modelValue : cloneAny(context.attrs.value);
  function createInitialProps() {
    const initialProps2 = {
      ...nodeProps(props2),
      ...listeners
    };
    const attrs = except(nodeProps(context.attrs), pseudoProps);
    initialProps2.attrs = attrs;
    const propValues = only(nodeProps(context.attrs), pseudoProps);
    for (const propName in propValues) {
      initialProps2[camel(propName)] = propValues[propName];
    }
    const classesProps = { props: {} };
    classesToNodeProps(classesProps, props2);
    Object.assign(initialProps2, classesProps.props);
    if (typeof initialProps2.type !== "string") {
      initialProps2.definition = initialProps2.type;
      delete initialProps2.type;
    }
    return initialProps2;
  }
  const initialProps = createInitialProps();
  const parent = initialProps.ignore ? null : props2.parent || inject(parentSymbol, null);
  const node = createNode(extend(config2 || {}, {
    name: props2.name || void 0,
    value,
    parent,
    plugins: (config2.plugins || []).concat(props2.plugins),
    config: props2.config,
    props: initialProps,
    index: props2.index
  }, false, true));
  if (!node.props.definition)
    error(600, node);
  const lateBoundProps = ref(new Set(node.props.definition.props || []));
  node.on("added-props", ({ payload: lateProps }) => {
    if (Array.isArray(lateProps))
      lateProps.forEach((newProp) => lateBoundProps.value.add(newProp));
  });
  const pseudoPropNames = computed(() => pseudoProps.concat([...lateBoundProps.value]).reduce((names, prop) => {
    if (typeof prop === "string") {
      names.push(camel(prop));
      names.push(kebab(prop));
    } else {
      names.push(prop);
    }
    return names;
  }, []));
  watchEffect(() => classesToNodeProps(node, props2));
  const passThrough = nodeProps(props2);
  for (const prop in passThrough) {
    watch(() => props2[prop], () => {
      if (props2[prop] !== void 0) {
        node.props[prop] = props2[prop];
      }
    });
  }
  const attributeWatchers = /* @__PURE__ */ new Set();
  const possibleProps = nodeProps(context.attrs);
  watchEffect(() => {
    watchAttributes(only(possibleProps, pseudoPropNames.value));
  });
  function watchAttributes(attrProps) {
    attributeWatchers.forEach((stop) => {
      stop();
      attributeWatchers.delete(stop);
    });
    for (const prop in attrProps) {
      const camelName = camel(prop);
      attributeWatchers.add(watch(() => context.attrs[prop], () => {
        node.props[camelName] = context.attrs[prop];
      }));
    }
  }
  watchEffect(() => {
    const attrs = except(nodeProps(context.attrs), pseudoPropNames.value);
    node.props.attrs = Object.assign({}, node.props.attrs || {}, attrs);
  });
  watchEffect(() => {
    const messages2 = props2.errors.map((error2) => createMessage({
      key: slugify(error2),
      type: "error",
      value: error2,
      meta: { source: "prop" }
    }));
    node.store.apply(messages2, (message2) => message2.type === "error" && message2.meta.source === "prop");
  });
  if (node.type !== "input") {
    const sourceKey = `${node.name}-prop`;
    watchEffect(() => {
      const keys = Object.keys(props2.inputErrors);
      if (!keys.length)
        node.clearErrors(true, sourceKey);
      const messages2 = keys.reduce((messages3, key) => {
        let value2 = props2.inputErrors[key];
        if (typeof value2 === "string")
          value2 = [value2];
        if (Array.isArray(value2)) {
          messages3[key] = value2.map((error2) => createMessage({
            key: error2,
            type: "error",
            value: error2,
            meta: { source: sourceKey }
          }));
        }
        return messages3;
      }, {});
      node.store.apply(messages2, (message2) => message2.type === "error" && message2.meta.source === sourceKey);
    });
  }
  watchEffect(() => Object.assign(node.config, props2.config));
  if (node.type !== "input") {
    provide(parentSymbol, node);
  }
  let inputTimeout;
  const mutex = /* @__PURE__ */ new WeakSet();
  node.on("modelUpdated", () => {
    var _a, _b;
    context.emit("inputRaw", (_a = node.context) === null || _a === void 0 ? void 0 : _a.value, node);
    clearTimeout(inputTimeout);
    inputTimeout = setTimeout(context.emit, 20, "input", (_b = node.context) === null || _b === void 0 ? void 0 : _b.value, node);
    if (isVModeled && node.context) {
      const newValue = useRaw(node.context.value);
      if (isObject(newValue) && useRaw(props2.modelValue) !== newValue) {
        mutex.add(newValue);
      }
      context.emit("update:modelValue", newValue);
    }
  });
  if (isVModeled) {
    watchVerbose(toRef(props2, "modelValue"), (path, value2) => {
      var _a;
      const rawValue = useRaw(value2);
      if (isObject(rawValue) && mutex.has(rawValue)) {
        return mutex.delete(rawValue);
      }
      if (!path.length)
        node.input(value2, false);
      else
        (_a = node.at(path)) === null || _a === void 0 ? void 0 : _a.input(value2, false);
    });
    if (node.value !== value) {
      node.emit("modelUpdated");
    }
  }
  onUnmounted(() => node.destroy());
  return node;
}
const vueBindings = function vueBindings2(node) {
  node.ledger.count("blocking", (m) => m.blocking);
  const isValid = ref(!node.ledger.value("blocking"));
  node.ledger.count("errors", (m) => m.type === "error");
  const hasErrors = ref(!!node.ledger.value("errors"));
  let hasTicked = false;
  nextTick(() => {
    hasTicked = true;
  });
  const availableMessages = reactive(node.store.reduce((store, message2) => {
    if (message2.visible) {
      store[message2.key] = message2;
    }
    return store;
  }, {}));
  const validationVisibility = ref(node.props.validationVisibility || "blur");
  node.on("prop:validationVisibility", ({ payload }) => {
    validationVisibility.value = payload;
  });
  const hasShownErrors = ref(validationVisibility.value === "live");
  const validationVisible = computed(() => {
    if (context.state.submitted)
      return true;
    if (!hasShownErrors.value && !context.state.settled) {
      return false;
    }
    switch (validationVisibility.value) {
      case "live":
        return true;
      case "blur":
        return context.state.blurred;
      case "dirty":
        return context.state.dirty;
      default:
        return false;
    }
  });
  const isComplete = computed(() => {
    return hasValidation.value ? isValid.value && !hasErrors.value : context.state.dirty && !empty(context.value);
  });
  const hasValidation = ref(Array.isArray(node.props.parsedRules) && node.props.parsedRules.length > 0);
  node.on("prop:parsedRules", ({ payload: rules }) => {
    hasValidation.value = Array.isArray(rules) && rules.length > 0;
  });
  const messages2 = computed(() => {
    const visibleMessages = {};
    for (const key in availableMessages) {
      const message2 = availableMessages[key];
      if (message2.type !== "validation" || validationVisible.value) {
        visibleMessages[key] = message2;
      }
    }
    return visibleMessages;
  });
  const ui = reactive(node.store.reduce((messages3, message2) => {
    if (message2.type === "ui" && message2.visible)
      messages3[message2.key] = message2;
    return messages3;
  }, {}));
  const cachedClasses = reactive({});
  const classes = new Proxy(cachedClasses, {
    get(...args) {
      const [target, property] = args;
      let className = Reflect.get(...args);
      if (!className && typeof property === "string") {
        if (!has(target, property) && !property.startsWith("__v")) {
          const observedNode = createObserver(node);
          observedNode.watch((node2) => {
            const rootClasses = typeof node2.config.rootClasses === "function" ? node2.config.rootClasses(property, node2) : {};
            const globalConfigClasses = node2.config.classes ? createClasses(property, node2, node2.config.classes[property]) : {};
            const classesPropClasses = createClasses(property, node2, node2.props[`_${property}Class`]);
            const sectionPropClasses = createClasses(property, node2, node2.props[`${property}Class`]);
            className = generateClassList(node2, property, rootClasses, globalConfigClasses, classesPropClasses, sectionPropClasses);
            target[property] = className;
          });
        }
      }
      return className;
    }
  });
  const describedBy = computed(() => {
    const describers = [];
    if (context.help) {
      describers.push(`help-${node.props.id}`);
    }
    for (const key in messages2.value) {
      describers.push(`${node.props.id}-${key}`);
    }
    return describers.length ? describers.join(" ") : void 0;
  });
  const value = ref(node.value);
  const _value = ref(node.value);
  const context = reactive({
    _value,
    attrs: node.props.attrs,
    disabled: node.props.disabled,
    describedBy,
    fns: {
      length: (obj) => Object.keys(obj).length,
      number: (value2) => Number(value2),
      string: (value2) => String(value2),
      json: (value2) => JSON.stringify(value2),
      eq
    },
    handlers: {
      blur: (e) => {
        node.store.set(createMessage({ key: "blurred", visible: false, value: true }));
        if (typeof node.props.attrs.onBlur === "function") {
          node.props.attrs.onBlur(e);
        }
      },
      touch: () => {
        node.store.set(createMessage({ key: "dirty", visible: false, value: true }));
      },
      DOMInput: (e) => {
        node.input(e.target.value);
        node.emit("dom-input-event", e);
      }
    },
    help: node.props.help,
    id: node.props.id,
    label: node.props.label,
    messages: messages2,
    node: markRaw(node),
    options: node.props.options,
    state: {
      blurred: false,
      complete: isComplete,
      dirty: false,
      submitted: false,
      settled: node.isSettled,
      valid: isValid,
      errors: hasErrors,
      rules: hasValidation,
      validationVisible
    },
    type: node.props.type,
    family: node.props.family,
    ui,
    value,
    classes
  });
  node.on("created", () => {
    if (!eq(context.value, node.value)) {
      _value.value = node.value;
      value.value = node.value;
      triggerRef(value);
      triggerRef(_value);
    }
    node.props._init = cloneAny(node.value);
  });
  node.on("settled", ({ payload: isSettled }) => {
    context.state.settled = isSettled;
  });
  function observeProps(observe) {
    observe.forEach((prop) => {
      prop = camel(prop);
      if (!has(context, prop) && has(node.props, prop)) {
        context[prop] = node.props[prop];
      }
      node.on(`prop:${prop}`, ({ payload }) => {
        context[prop] = payload;
      });
    });
  }
  const rootProps = () => {
    const props2 = [
      "help",
      "label",
      "disabled",
      "options",
      "type",
      "attrs",
      "preserve",
      "preserveErrors",
      "id"
    ];
    const iconPattern = /^[a-zA-Z-]+(?:-icon|Icon)$/;
    const matchingProps = Object.keys(node.props).filter((prop) => {
      return iconPattern.test(prop);
    });
    return props2.concat(matchingProps);
  };
  observeProps(rootProps());
  function definedAs(definition) {
    if (definition.props)
      observeProps(definition.props);
  }
  node.props.definition && definedAs(node.props.definition);
  node.on("added-props", ({ payload }) => observeProps(payload));
  node.on("input", ({ payload }) => {
    if (node.type !== "input" && !isRef(payload) && !isReactive(payload)) {
      _value.value = shallowClone(payload);
    } else {
      _value.value = payload;
      triggerRef(_value);
    }
  });
  node.on("commit", ({ payload }) => {
    if (node.type !== "input" && !isRef(payload) && !isReactive(payload)) {
      value.value = _value.value = shallowClone(payload);
    } else {
      value.value = _value.value = payload;
      triggerRef(value);
    }
    node.emit("modelUpdated");
    if (!context.state.dirty && node.isCreated && hasTicked && !eq(value.value, node.props._init))
      context.handlers.touch();
    if (isComplete && node.type === "input" && hasErrors.value && !undefine(node.props.preserveErrors)) {
      node.store.filter((message2) => {
        var _a;
        return !(message2.type === "error" && ((_a = message2.meta) === null || _a === void 0 ? void 0 : _a.autoClear) === true);
      });
    }
  });
  const updateState = async (message2) => {
    if (message2.type === "ui" && message2.visible && !message2.meta.showAsMessage) {
      ui[message2.key] = message2;
    } else if (message2.visible) {
      availableMessages[message2.key] = message2;
    } else if (message2.type === "state") {
      context.state[message2.key] = !!message2.value;
    }
  };
  node.on("message-added", (e) => updateState(e.payload));
  node.on("message-updated", (e) => updateState(e.payload));
  node.on("message-removed", ({ payload: message2 }) => {
    delete ui[message2.key];
    delete availableMessages[message2.key];
    delete context.state[message2.key];
  });
  node.on("settled:blocking", () => {
    isValid.value = true;
  });
  node.on("unsettled:blocking", () => {
    isValid.value = false;
  });
  node.on("settled:errors", () => {
    hasErrors.value = false;
  });
  node.on("unsettled:errors", () => {
    hasErrors.value = true;
  });
  watch(validationVisible, (value2) => {
    if (value2) {
      hasShownErrors.value = true;
    }
  });
  node.context = context;
  node.emit("context", node, false);
};
const defaultConfig = (options2 = {}) => {
  const { rules = {}, locales = {}, inputs: inputs$1 = {}, messages: messages2 = {}, locale = void 0, theme: theme2 = void 0, iconLoaderUrl = void 0, iconLoader = void 0, icons = {}, ...nodeOptions } = options2;
  const validation = createValidationPlugin({
    ...defaultRules,
    ...rules || {}
  });
  const i18n = createI18nPlugin(extend({ en: en$1, ...locales || {} }, messages2));
  const library = createLibraryPlugin(inputs, inputs$1);
  const themePlugin = createThemePlugin(theme2, icons, iconLoaderUrl, iconLoader);
  return extend({
    plugins: [library, themePlugin, vueBindings, i18n, validation],
    ...!locale ? {} : { config: { locale } }
  }, nodeOptions || {}, true);
};
defineComponent({
  name: "FormKitIcon",
  props: {
    icon: {
      type: String,
      default: ""
    },
    iconLoader: {
      type: Function,
      default: null
    },
    iconLoaderUrl: {
      type: Function,
      default: null
    }
  },
  setup(props2) {
    var _a, _b;
    const icon2 = ref(void 0);
    const config2 = inject(optionsSymbol, {});
    const parent = inject(parentSymbol, null);
    let iconHandler = void 0;
    if (props2.iconLoader && typeof props2.iconLoader === "function") {
      iconHandler = createIconHandler(props2.iconLoader);
    } else if (parent && ((_a = parent.props) === null || _a === void 0 ? void 0 : _a.iconLoader)) {
      iconHandler = createIconHandler(parent.props.iconLoader);
    } else if (props2.iconLoaderUrl && typeof props2.iconLoaderUrl === "function") {
      iconHandler = createIconHandler(iconHandler, props2.iconLoaderUrl);
    } else {
      const iconPlugin = (_b = config2 === null || config2 === void 0 ? void 0 : config2.plugins) === null || _b === void 0 ? void 0 : _b.find((plugin2) => {
        return typeof plugin2.iconHandler === "function";
      });
      if (iconPlugin) {
        iconHandler = iconPlugin.iconHandler;
      }
    }
    if (iconHandler && typeof iconHandler === "function") {
      const iconOrPromise = iconHandler(props2.icon);
      if (iconOrPromise instanceof Promise) {
        iconOrPromise.then((iconValue) => {
          icon2.value = iconValue;
        });
      } else {
        icon2.value = iconOrPromise;
      }
    }
    return () => {
      if (icon2.value) {
        return h("span", {
          class: "formkit-icon",
          innerHTML: icon2.value
        });
      }
      return null;
    };
  }
});
const myTextInput = {
  schema: outer(textInput(), messages(message("$message.value"))),
  type: "input",
  family: "text",
  props: [],
  forceTypeProp: "text",
  features: []
};
const mySelect = {
  schema: selectInput(
    $if("$slots.default", () => "$slots.default", $if("$slots.option", optionSlot, option("$option.label"))),
    messages(message("$message.value"))
  ),
  type: "input",
  props: ["options", "placeholder", "optionsLoader"],
  forceTypeProp: "select",
  features: [options, selects, defaultIcon("select", "select")]
};
const myRadio = {
  schema: outer(
    $if(
      "$options == undefined",
      boxWrapper(
        inner(prefix(), box(), decorator(icon("decorator")), suffix()),
        $if("$label", boxLabel("$label"))
      ),
      wrapper(
        legend("$label"),
        help("$help"),
        boxOptions(
          boxOption(
            boxWrapper(
              inner(
                prefix(),
                $extend(box(), {
                  bind: "$option.attrs",
                  attrs: {
                    id: "$option.attrs.id",
                    value: "$option.value",
                    checked: "$fns.isChecked($option.value)"
                  }
                }),
                decorator(icon("decorator")),
                suffix()
              ),
              $if("$option.label", boxLabel("$option.label"))
            ),
            boxHelp("$option.help")
          )
        )
      )
    ),
    $if("$options === undefined && $help", help("$help")),
    messages(message("$message.value"))
  ),
  type: "input",
  family: "box",
  props: ["options", "onValue", "offValue", "optionsLoader"],
  forceTypeProp: "radio",
  features: [options, radios, defaultIcon("decorator", "radioDecorator")]
};
const config = {
  locales: { ar: ar$1, en: en$1 },
  locale: "ar",
  inputs: {
    mySelect,
    myTextInput,
    myRadio
  }
};
const _nuxt_formkitPlugin_mjs_pZqjah0RUG = defineNuxtPlugin((nuxtApp) => {
  nuxtApp.hook("app:rendered", () => {
    resetCount();
  });
  nuxtApp.vueApp.use(plugin, defaultConfig(config));
});
const node_modules__64pinia_nuxt_dist_runtime_plugin_vue3_mjs_A0OWXRrUgq = defineNuxtPlugin((nuxtApp) => {
  const pinia = createPinia();
  nuxtApp.vueApp.use(pinia);
  setActivePinia(pinia);
  {
    nuxtApp.payload.pinia = pinia.state.value;
  }
  return {
    provide: {
      pinia
    }
  };
});
const Loading$1 = "\u062C\u0627\u0631\u064A \u0627\u0644\u062A\u062D\u0645\u064A\u0644";
const login$1 = "\u062A\u0633\u062C\u064A\u0644 \u062F\u062E\u0648\u0644";
const logout$1 = "\u062A\u0633\u062C\u064A\u0644 \u062E\u0631\u0648\u062C";
const Subscribers$1 = "\u0627\u0644\u0645\u0634\u062A\u0631\u0643\u064A\u0646";
const Members$1 = "\u0627\u0644\u0623\u0639\u0636\u0627\u0621";
const Volunteers$1 = "\u0627\u0644\u0645\u062A\u0637\u0648\u0639\u064A\u0646";
const Close$1 = "\u0625\u063A\u0644\u0627\u0642";
const Details$1 = "\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644 \u2190";
const Code$1 = "\u0627\u0644\u0631\u0645\u0632";
const Validate$1 = "\u062A\u062D\u0642\u0642";
const about_authority$1 = "\u0639\u0646 \u0627\u0644\u0647\u064A\u0626\u0629";
const about_authority_description$1 = "\u062A\u0623\u0633\u0633\u062A \u0647\u064A\u0626\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646 \u0644\u062E\u062F\u0645\u0629 \u0627\u0644\u0623\u0647\u062F\u0627\u0641 \u0627\u0644\u0645\u0647\u0646\u064A\u0629 \u0644\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0641\u064A \u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u0628\u0645\u0648\u062C\u0628 \u0627\u0644\u0645\u0627\u062F\u0629 \u0631\u0642\u0645 \u201C27\u201D \u0645\u0646 \u0646\u0638\u0627\u0645 \u0627\u0644\u0645\u0624\u0633\u0633\u0627\u062A \u0627\u0644\u0635\u062D\u0641\u064A\u0629 \u0627\u0644\u0635\u0627\u062F\u0631 \u0628\u0627\u0644\u0645\u0631\u0633\u0648\u0645 \u0627\u0644\u0645\u0644\u0643\u064A \u0631\u0642\u0645 (\u0645/20) \u0628\u062A\u0627\u0631\u064A\u062E 08/05/1422\u0647\u0640\u060C \u0648\u062A\u0645 \u0625\u0642\u0631\u0627\u0631 \u0644\u0627\u0626\u062D\u062A\u0647\u0627 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629 \u0641\u064A \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639 \u0627\u0644\u0623\u0648\u0644 \u0644\u0644\u062C\u0645\u0639\u064A\u0629 \u0627\u0644\u0639\u0645\u0648\u0645\u064A\u0629 \u0627\u0644\u0630\u064A \u0627\u0646\u0639\u0642\u062F \u0628\u062A\u0627\u0631\u064A\u062E 19/4/1425\u0647\u0640 \u0627\u0644\u0645\u0648\u0627\u0641\u0642 7/7/2004\u0645\u060C \u0648\u062A\u0645 \u0627\u0639\u062A\u0645\u0627\u062F \u0645\u0639\u0627\u0644\u064A \u0648\u0632\u064A\u0631 \u0627\u0644\u062B\u0642\u0627\u0641\u0629 \u0648\u0627\u0644\u0627\u0639\u0644\u0627\u0645 \u0647\u0630\u0647 \u0627\u0644\u0644\u0627\u0626\u062D\u0629 \u0628\u0645\u0648\u062C\u0628 \u0627\u0644\u0642\u0631\u0627\u0631 \u0631\u0642\u0645 (\u0645/\u0648/383) \u0628\u062A\u0627\u0631\u064A\u062E 11/8/1425\u0647\u0640. \u0648\u064A\u0646\u0637\u0644\u0642 \u062A\u0623\u0633\u064A\u0633 \u0627\u0644\u0647\u064A\u0626\u0629 \u0645\u0646 \u0631\u063A\u0628\u0629 \u062D\u0642\u064A\u0642\u064A\u0629 \u0641\u064A \u062E\u062F\u0645\u0629 \u0627\u0644\u0623\u0647\u062F\u0627\u0641 \u0627\u0644\u0645\u0647\u0646\u064A\u0629 \u0644\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0641\u064A \u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629.";
const More$1 = "\u0627\u0644\u0645\u0632\u064A\u062F";
const Studio$1 = "\u0627\u0644\u0627\u0633\u062A\u062F\u064A\u0648";
const All$1 = "\u0627\u0644\u0643\u0644";
const photo$1 = "\u0635\u0648\u0631\u0629";
const Photos$1 = "\u0627\u0644\u0635\u0648\u0631";
const Videos$1 = "\u0627\u0644\u0641\u064A\u062F\u064A\u0648";
const Events$1 = "\u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0627\u062A";
const Notifications$1 = "\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062A";
const membership_desc$1 = "\u064A\u062D\u0642 \u0644\u0643\u0644 \u0645\u0646 \u064A\u0645\u0627\u0631\u0633 \u0639\u0645\u0644\u0627\u064B \u0635\u062D\u0641\u064A\u0627\u064B \u0627\u0644\u062A\u0642\u062F\u0645 \u0628\u0637\u0644\u0628 \u0627\u0644\u0627\u0646\u062A\u0633\u0627\u0628 \u0625\u0644\u0649 \u0639\u0636\u0648\u064A\u0629 \u0627\u0644\u0647\u064A\u0626\u0629";
const membership_btn$1 = "\u0637\u0644\u0628 \u0639\u0636\u0648\u064A\u0629 \u0647\u064A\u0626\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646";
const membership_conditions$1 = "\u0634\u0631\u0648\u0637 \u0627\u0644\u062A\u0642\u062F\u0645 \u0644\u0644\u0639\u0636\u0648\u064A\u0629";
const fulltime_member$1 = "\u0627\u0644\u0639\u0636\u0648 \u0627\u0644\u0645\u062A\u0641\u0631\u063A";
const fulltime_member_desc1$1 = "\u0643\u0644 \u0635\u062D\u0641\u064A \u0633\u0639\u0648\u062F\u064A \u0645\u062A\u0641\u0631\u063A \u0644\u0644\u0645\u0647\u0646\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u0629";
const fulltime_member_desc2$1 = "\u0643\u0644 \u0635\u062D\u0641\u064A \u0645\u0639\u062A\u0645\u062F \u0648\u0645\u062A\u0641\u0631\u063A \u0644\u0644\u0639\u0645\u0644 \u0645\u0631\u0627\u0633\u0644\u0627\u064B \u0623\u0648 \u0645\u062F\u064A\u0631 \u0645\u0643\u062A\u0628 \u0628\u0645\u0648\u062C\u0628 \u0627\u062A\u0641\u0627\u0642 \u062E\u0637\u064A \u0644\u0623\u064A \u0645\u0646 \u0627\u0644\u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0627\u0644\u0645\u062D\u0644\u064A\u0629 \u0648\u063A\u064A\u0631 \u0627\u0644\u0645\u062D\u0644\u064A\u0629 \u0646\u0638\u064A\u0631 \u0631\u0627\u062A\u0628 \u062B\u0627\u0628\u062A \u0648\u0644\u0627 \u064A\u0645\u0627\u0631\u0633 \u0645\u0647\u0646\u0629 \u0623\u062E\u0631\u0649.";
const fulltime_member_desc3$1 = "\u0623\u0646 \u062A\u062A\u0648\u0627\u0641\u0631 \u0641\u064A \u0627\u0644\u0648\u0633\u064A\u0644\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0627\u0644\u062A\u064A \u064A\u0639\u0645\u0644 \u0628\u0647\u0627 \u062C\u0645\u064A\u0639 \u0634\u0631\u0648\u0637 \u0627\u0644\u0645\u0647\u0646\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u0629 \u0648\u0641\u0646\u0648\u0646 \u0627\u0644\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u0635\u062D\u0641\u064A \u0648\u0639\u0644\u0649 \u0631\u0623\u0633\u0647\u0627 \u0627\u0644\u062E\u0628\u0631.";
const parttime_member$1 = "\u0627\u0644\u0639\u0636\u0648 \u063A\u064A\u0631 \u0627\u0644\u0645\u062A\u0641\u0631\u063A";
const parttime_member_desc1$1 = "\u0643\u0644 \u0635\u062D\u0641\u064A \u0633\u0639\u0648\u062F\u064A \u064A\u0645\u0627\u0631\u0633 \u0627\u0644\u0639\u0645\u0644 \u0627\u0644\u0635\u062D\u0641\u064A \u0628\u0634\u0643\u0644 \u062C\u0632\u0626\u064A";
const parttime_member_desc2$1 = "\u064A\u0634\u0645\u0644 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646 \u0627\u0644\u0630\u064A\u0646 \u064A\u0634\u063A\u0644\u0648\u0646 \u0648\u0638\u0627\u0626\u0641 \u062D\u0643\u0648\u0645\u064A\u0629 \u0623\u0648 \u063A\u064A\u0631 \u062D\u0643\u0648\u0645\u064A\u0629 \u0648\u064A\u0645\u0627\u0631\u0633\u0648\u0646 \u0625\u0644\u0649 \u062C\u0627\u0646\u064A\u0647\u0627 \u0623\u0639\u0645\u0627\u0644\u0627 \u0635\u062D\u0641\u064A\u0629";
const affiliate_member$1 = "\u0627\u0644\u0639\u0636\u0648 \u0627\u0644\u0645\u0646\u062A\u0633\u0628";
const affiliate_member_desc1$1 = "\u0643\u0644 \u0635\u062D\u0641\u064A \u063A\u064A\u0631 \u0633\u0639\u0648\u062F\u064A \u064A\u0642\u064A\u0645 \u0641\u064A \u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0648\u064A\u0639\u0645\u0644 \u0641\u064A \u0627\u0644\u0645\u062C\u0627\u0644 \u0627\u0644\u0635\u062D\u0641\u064A \u0628\u0645\u0648\u062C\u0628 \u0639\u0642\u062F \u0639\u0645\u0644.";
const Statistics$1 = "\u0625\u062D\u0635\u0627\u0626\u064A\u0627\u062A";
const Home$1 = "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629";
const Posts$1 = "\u0627\u0644\u0645\u0642\u0627\u0644\u0627\u062A";
const TermsAgreement$1 = "\u0645\u0648\u0627\u0641\u0642 \u0639\u0644\u0649 \u062C\u0645\u064A\u0639 \u0627\u0644\u0634\u0631\u0648\u0637";
const Registered$1 = "\u0645\u0633\u062C\u0644";
const Attend$1 = "\u062A\u062D\u0636\u064A\u0631";
const Attended$1 = "\u0645\u062D\u0636\u0631";
const to$1 = "\u0625\u0644\u0649";
const Free$1 = "\u0645\u062C\u0627\u0646\u064A";
const Prev$1 = "\u0627\u0644\u0633\u0627\u0628\u0642";
const Next$1 = "\u0627\u0644\u062A\u0627\u0644\u064A";
const Status$1 = "\u0627\u0644\u062D\u0627\u0644\u0629";
const Description$1 = "\u0627\u0644\u0648\u0635\u0641";
const Create$1 = "\u0625\u0646\u0634\u0627\u0621";
const Solved$1 = "\u0645\u062D\u0644\u0648\u0644\u0629";
const Open$1 = "\u0645\u0641\u062A\u0648\u062D\u0629";
const Send$1 = "\u0623\u0631\u0633\u0644";
const Resend$1 = "\u0625\u0639\u0627\u062F\u0629 \u0625\u0631\u0633\u0627\u0644";
const Message$1 = "\u0627\u0644\u0631\u0633\u0627\u0644\u0629";
const fname$1 = "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0623\u0648\u0644";
const sname$1 = "\u0627\u0633\u0645 \u0627\u0644\u0623\u0628";
const tname$1 = "\u0627\u0633\u0645 \u0627\u0644\u062C\u062F";
const lname$1 = "\u0627\u0633\u0645 \u0627\u0644\u0639\u0627\u0626\u0644\u0629";
const Gender$1 = "\u0627\u0644\u062C\u0646\u0633";
const Male$1 = "\u0630\u0643\u0631";
const Female$1 = "\u0623\u0646\u062B\u0649";
const Country$1 = "\u0627\u0644\u062F\u0648\u0644\u0629";
const City$1 = "\u0627\u0644\u0645\u062F\u064A\u0646\u0629";
const Nationality$1 = "\u0627\u0644\u062C\u0646\u0633\u064A\u0629";
const Qualification$1 = "\u0622\u062E\u0631 \u0645\u0624\u0647\u0644 \u062F\u0631\u0627\u0633\u064A";
const Governorate$1 = "\u0627\u0644\u0645\u062D\u0627\u0641\u0638\u0629";
const Address$1 = "\u0645\u0643\u0627\u0646 \u0627\u0644\u0627\u0642\u0627\u0645\u0629";
const Photography$1 = "\u0627\u0644\u062A\u0635\u0648\u064A\u0631 \u0627\u0644\u0641\u0648\u062A\u0648\u063A\u0631\u0627\u0641\u064A";
const Videography$1 = "\u062A\u0635\u0648\u064A\u0631 \u0627\u0644\u0641\u064A\u062F\u064A\u0648";
const Cinematography$1 = "\u0627\u0644\u062A\u0635\u0648\u064A\u0631 \u0627\u0644\u0633\u064A\u0646\u0645\u0627\u0626\u064A";
const Coverings$1 = "\u0627\u0644\u062A\u063A\u0637\u064A\u0627\u062A";
const Presentation$1 = "\u0627\u0644\u062A\u0642\u062F\u064A\u0645";
const Montage$1 = "\u0627\u0644\u0645\u0648\u0646\u062A\u0627\u062C";
const Branch$1 = "\u0627\u0644\u0641\u0631\u0639";
const Mobile$1 = "\u0631\u0642\u0645 \u0627\u0644\u062C\u0648\u0627\u0644";
const Email$1 = "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A";
const Password$1 = "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631";
const TermsAcceptance$1 = "\u0623\u062A\u0639\u0647\u062F \u0628\u0623\u0646 \u062C\u0645\u064A\u0639 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0635\u062D\u064A\u062D\u0629 \u060C \u0648\u0625\u0646 \u0643\u0627\u0646\u062A \u062E\u0644\u0627\u0641 \u0630\u0644\u0643 \u0633\u064A\u062A\u0645 \u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643";
const acceptance$1 = "\u0627\u0644\u062A\u0639\u0647\u062F";
const Register$1 = "\u062A\u0633\u062C\u064A\u0644";
const Login$1 = "\u062F\u062E\u0648\u0644";
const Twitter$1 = "\u062A\u0648\u064A\u062A\u0631";
const Youtube$1 = "\u064A\u0648\u062A\u064A\u0648\u0628";
const Profile$1 = "\u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A";
const Save$1 = "\u062D\u0641\u0638";
const Review$1 = "\u0645\u0631\u0627\u062C\u0639\u0629";
const Registration$1 = "\u0627\u0644\u062A\u0633\u062C\u064A\u0644";
const member_rule1$1 = "\u0623\u0644\u0627 \u064A\u0642\u0644 \u0639\u0645\u0631\u0647 \u0639\u0646 20 \u0639\u0627\u0645\u0627";
const member_rule2$1 = "\u0623\u0646 \u064A\u0645\u0627\u0631\u0633 \u0646\u0634\u0627\u0637\u0647 \u0627\u0644\u0635\u062D\u0641\u064A \u0645\u0645\u0627\u0631\u0633\u0629 \u0641\u0639\u0644\u064A\u0629 \u0648\u0645\u0633\u062A\u0645\u0631\u0629\u060C \u0648\u064A\u0643\u0648\u0646 \u0642\u062F \u0623\u0645\u0636\u064A \u0641\u064A \u0627\u0644\u0645\u0647\u0646\u0629 \u0645\u062A\u0641\u0631\u063A\u0629 \u0645\u062F\u0629 \u0644\u0627 \u062A\u0642\u0644 \u0639\u0646 \u0633\u0646\u0629";
const member_rule3$1 = "\u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0645\u0627\u0631\u0633\u0627 \u0644\u0644\u0646\u0634\u0627\u0637 \u0641\u064A \u0625\u062D\u062F\u0649 \u0627\u0644\u0645\u0624\u0633\u0633\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 \u0627\u0644\u0645\u062D\u0644\u064A\u0629 \u0623\u0648 \u0645\u0639\u062A\u0645\u062F\u0627 \u0643\u0645\u0631\u0627\u0633\u0644 \u0644\u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0645 \u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0623\u0648 \u0627\u0644\u0639\u0645\u0644 \u0627\u0644\u0635\u062D\u0641\u064A \u0644\u0635\u0627\u0644\u062D\u0647\u0627";
const member_rule4$1 = "\u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0645\u0627\u0631\u0633\u0629 \u0644\u0623\u064A \u0645\u0646 \u0627\u0644\u0623\u0639\u0645\u0627\u0644 \u0627\u0644\u0635\u062D\u0641\u064A\u0629 \u0627\u0644\u0648\u0627\u0631\u062F\u0629 \u062A\u0641\u0635\u064A\u0644\u0627 \u0641\u064A \u0627\u0644\u0645\u0627\u062F\u0629 (\u06F4\u06F0) \u0645\u0646 \u0627\u0644\u0644\u0627\u0626\u062D\u0629 \u0648\u0641\u0642\u0627 \u0644\u0645\u0627 \u062D\u062F\u062F\u0647 \u0627\u0644\u062C\u0645\u0639\u064A\u0629 \u0627\u0644\u0639\u0645\u0648\u0645\u064A\u0629 \u0645\u0646 \u0636\u0648\u0627\u0628\u0637";
const member_rule5$1 = "\u0623\u0644\u0627 \u064A\u0643\u0648\u0646 \u0642\u062F \u0635\u062F\u0631 \u0628\u062D\u0642\u0647 \u062D\u0643\u0645 \u0641\u064A \u062C\u0631\u064A\u0645\u0629 \u0645\u062E\u0644\u0629 \u0628\u0627\u0644\u0634\u0631\u0641 \u0623\u0648 \u0627\u0644\u0623\u0645\u0627\u0646\u0629.";
const member_rule6$1 = "\u0623\u0646 \u064A\u0642\u062F\u0645 \u0627\u0644\u0645\u0633\u062A\u0646\u062F\u0627\u062A \u0627\u0644\u062B\u0628\u0648\u062A\u064A\u0629 \u0627\u0644\u0644\u0627\u0632\u0645\u0629 \u0627\u0644\u062A\u064A \u062A\u0637\u0644\u0628\u0647\u0627 \u0627\u0644\u0647\u064A\u0626\u0629.";
const Verify$1 = "\u062A\u0641\u0639\u064A\u0644";
const Amount$1 = "\u0627\u0644\u0645\u0628\u0644\u063A";
const Riyal$1 = "\u0631\u064A\u0627\u0644";
const Annual$1 = "\u0633\u0646\u0648\u064A\u0627\u064B";
const Delivery$1 = "\u0627\u0644\u062A\u0648\u0635\u064A\u0644";
const Hijri$1 = "\u0647\u062C\u0631\u064A";
const Milady$1 = "\u0645\u064A\u0644\u0627\u062F\u064A";
const Major$1 = "\u0627\u0644\u062A\u062E\u0635\u0635";
const Journalist$1 = "\u0627\u0644\u0635\u062D\u0641\u064A";
const Employer$1 = "\u062C\u0647\u0629 \u0627\u0644\u0639\u0645\u0644";
const Fax$1 = "\u0641\u0627\u0643\u0633";
const Ext$1 = "\u062A\u062D\u0648\u064A\u0644\u0629";
const membership_agreement$1 = "\u0648\u0623\u0642\u0631 \u0628\u0627\u0637\u0644\u0627\u0639\u064A \u0648\u0627\u0644\u062A\u0632\u0627\u0645\u064A \u0628\u0643\u0627\u0641\u0629 \u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u0623\u062D\u0643\u0627\u0645 \u060C \u0643\u0645\u0627 \u0648\u0623\u062A\u0639\u0647\u062F \u0628\u0623\u0646 \u062C\u0645\u064A\u0639 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0642\u062F\u0645\u0629 \u0647\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0634\u062E\u0635\u064A\u0629 \u0635\u062D\u064A\u062D\u0629 \u0648\u0623\u062A\u062D\u0645\u0644 \u0643\u0627\u0641\u0629 \u0627\u0644\u0645\u0633\u0626\u0648\u0644\u064A\u0629 \u0625\u062A\u062C\u0627\u0647 \u0630\u0644\u0643";
const Submit$1 = "\u0625\u0631\u0633\u0627\u0644";
const Info$1 = "\u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A";
const Experiences$1 = "\u0627\u0644\u062E\u0628\u0631\u0627\u062A";
const Years = "\u0627\u0644\u0633\u0646\u0648\u0627\u062A";
const Add$1 = "\u0625\u0636\u0627\u0641\u0629";
const Fields$1 = "\u0627\u0644\u0645\u062C\u0627\u0644\u0627\u062A";
const Languages$1 = "\u0627\u0644\u0644\u063A\u0627\u062A";
const Language$1 = "\u0627\u0644\u0644\u063A\u0629";
const Level$1 = "\u0627\u0644\u0645\u0633\u062A\u0648\u0649";
const Fair$1 = "\u0645\u0642\u0628\u0648\u0644";
const Good$1 = "\u062C\u064A\u062F";
const Excellent$1 = "\u0645\u0645\u062A\u0627\u0632";
const Requirement$1 = "\u0627\u0644\u0645\u0637\u0644\u0648\u0628";
const Upload$1 = "\u0631\u0641\u0639";
const Membership$1 = "\u0627\u0644\u0639\u0636\u0648\u064A\u0629";
const Refused$1 = "\u0645\u0631\u0641\u0648\u0636\u0629";
const Pay$1 = "\u0625\u062F\u0641\u0639";
const payment_condition1$1 = "\u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0645\u062F\u0641\u0648\u0639 \u063A\u064A\u0631 \u0645\u0633\u062A\u0631\u062C\u0639";
const payment_condition2$1 = "\u064A\u062D\u0642 \u0644\u0644\u0647\u064A\u0626\u0629 \u0625\u0644\u063A\u0627\u0621 \u0625\u0634\u062A\u0631\u0627\u0643\u0643";
const payment_condition3$1 = "\u062A\u0643\u0648\u0646 \u0645\u062F\u0629 \u0625\u0634\u062A\u0631\u0627\u0643\u0643 \u0625\u0644\u0649 \u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0633\u0646\u0629 \u0627\u0644\u0645\u064A\u0644\u0627\u062F\u064A\u0629";
const Paid$1 = "\u0645\u062F\u0641\u0648\u0639\u0629";
const January$1 = "\u064A\u0646\u0627\u064A\u0631";
const February$1 = "\u0641\u0628\u0631\u0627\u064A\u0631";
const March$1 = "\u0645\u0627\u0631\u0633";
const April$1 = "\u0625\u0628\u0631\u064A\u0644";
const May$1 = "\u0645\u0627\u064A\u0648";
const June$1 = "\u064A\u0648\u0646\u064A\u0648";
const July$1 = "\u064A\u0648\u0644\u064A\u0648";
const August$1 = "\u0623\u063A\u0633\u0637\u0633";
const September$1 = "\u0633\u0628\u062A\u0645\u0628\u0631";
const October$1 = "\u0623\u0643\u062A\u0648\u0628\u0631";
const November$1 = "\u0646\u0648\u0641\u0645\u0628\u0631";
const December$1 = "\u062F\u064A\u0633\u0645\u0628\u0631";
const Diploma$1 = "\u062F\u0628\u0644\u0648\u0645";
const Afghanistan$1 = "\u0623\u0641\u063A\u0627\u0646\u0633\u062A\u0627\u0646";
const Albania$1 = "\u0623\u0644\u0628\u0627\u0646\u064A\u0627";
const Algeria$1 = "\u0627\u0644\u062C\u0632\u0627\u0626\u0631";
const Andorra$1 = "\u0623\u0646\u062F\u0648\u0631\u0627";
const Angola$1 = "\u0623\u0646\u063A\u0648\u0644\u0627";
const Antarctica$1 = "\u0623\u0646\u062A\u0631\u0627\u0643\u062A\u064A\u0643\u0627";
const Argentina$1 = "\u0627\u0644\u0623\u0631\u062C\u0646\u062A\u064A\u0646";
const Armenia$1 = "\u0623\u0631\u0645\u064A\u0646\u064A\u0627";
const Australia$1 = "\u0623\u0633\u062A\u0631\u0627\u0644\u064A\u0627";
const Austria$1 = "\u0627\u0644\u0646\u0645\u0633\u0627";
const Azerbaijan$1 = "\u0623\u0632\u0631\u0628\u064A\u062C\u0627\u0646";
const Bahamas$1 = "\u0627\u0644\u0628\u0627\u0647\u0627\u0645\u0627\u0633";
const Bahrain$1 = "\u0627\u0644\u0628\u062D\u0631\u064A\u0646";
const Bangladesh$1 = "\u0628\u0646\u062C\u0644\u0627\u062F\u064A\u0634";
const Belarus$1 = "\u0628\u064A\u0644\u0627\u0631\u0648\u0633\u064A\u0627";
const Belgium$1 = "\u0628\u0644\u062C\u064A\u0643\u0627";
const Bolivia$1 = "\u0628\u0648\u0644\u064A\u0641\u064A\u0627";
const Botswana$1 = "\u0628\u062A\u0633\u0648\u0627\u0646\u0627";
const Brazil$1 = "\u0627\u0644\u0628\u0631\u0627\u0632\u064A\u0644";
const Bulgaria$1 = "\u0628\u0644\u063A\u0627\u0631\u064A\u0627";
const Burundi$1 = "\u0628\u0648\u0631\u0648\u0646\u062F\u064A";
const Cambodia$1 = "\u0643\u0645\u0628\u0648\u062F\u064A\u0627";
const Cameroon$1 = "\u0627\u0644\u0643\u0627\u0645\u064A\u0631\u0648\u0646";
const Canada$1 = "\u0643\u0646\u062F\u0627";
const Chad$1 = "\u0627\u0644\u062A\u0634\u0627\u062F";
const Chile$1 = "\u062A\u0634\u064A\u0644\u064A";
const China$1 = "\u0627\u0644\u0635\u064A\u0646";
const Colombia$1 = "\u0643\u0648\u0644\u0648\u0645\u0628\u064A\u0627";
const Congo$1 = "\u0627\u0644\u0643\u0648\u0646\u063A\u0648";
const Croatia$1 = "\u0643\u0631\u0648\u0627\u062A\u064A\u0627";
const Cuba$1 = "\u0643\u0648\u0628\u0627";
const Cyprus$1 = "\u0642\u0628\u0631\u0635";
const Denmark$1 = "\u0627\u0644\u062F\u0646\u0645\u0627\u0631\u0643";
const Djibouti$1 = "\u062C\u064A\u0628\u0648\u062A\u064A";
const Ecuador$1 = "\u0627\u0644\u0625\u0643\u0648\u0627\u062F\u0648\u0631";
const Egypt$1 = "\u0645\u0635\u0631";
const Eritrea$1 = "\u0625\u0631\u064A\u062A\u064A\u0631\u064A\u0627";
const Estonia$1 = "\u0625\u0633\u062A\u0648\u0646\u064A\u0627";
const Ethiopia$1 = "\u0625\u062B\u064A\u0648\u0628\u064A\u0627";
const Finland$1 = "\u0641\u064A\u0646\u0644\u0627\u0646\u062F";
const France$1 = "\u0641\u0631\u0646\u0633\u0627";
const Gabon$1 = "\u0627\u0644\u062C\u0627\u0628\u0648\u0646";
const Gambia$1 = "\u062C\u0627\u0645\u0628\u064A\u0627";
const Georgia$1 = "\u062C\u0648\u0631\u062C\u064A\u0627";
const Germany$1 = "\u0623\u0644\u0645\u0627\u0646\u064A\u0627";
const Ghana$1 = "\u063A\u0627\u0646\u0627";
const Gibraltar$1 = "\u062C\u0628\u0644 \u0637\u0627\u0631\u0642";
const Greece$1 = "\u0627\u0644\u064A\u0648\u0646\u0627\u0646";
const Greenland$1 = "\u062C\u0631\u064A\u0646 \u0644\u0627\u0646\u062F";
const Guatemala$1 = "\u062C\u0648\u0627\u062A\u064A\u0645\u0627\u0644\u0627";
const Guinea$1 = "\u063A\u064A\u0646\u064A\u0627";
const Honduras$1 = "\u0627\u0644\u0647\u0646\u062F\u0648\u0631\u0627\u0633";
const Hungary$1 = "\u0627\u0644\u0645\u062C\u0631";
const Iceland$1 = "\u0623\u064A\u0633\u0644\u0627\u0646\u062F";
const India$1 = "\u0627\u0644\u0647\u0646\u062F";
const Indonesia$1 = "\u0625\u0646\u062F\u0648\u0646\u064A\u0633\u064A\u0627";
const Iran$1 = "\u0625\u064A\u0631\u0627\u0646";
const Iraq$1 = "\u0627\u0644\u0639\u0631\u0627\u0642";
const Ireland$1 = "\u0623\u064A\u0631\u0644\u0627\u0646\u062F";
const Italy$1 = "\u0625\u064A\u0637\u0627\u0644\u064A\u0627";
const Jamaica$1 = "\u062C\u0645\u0627\u064A\u0643\u0627";
const Japan$1 = "\u0627\u0644\u064A\u0627\u0628\u0627\u0646";
const Jersey$1 = "\u062C\u064A\u0631\u0633\u064A";
const Jordan$1 = "\u0627\u0644\u0623\u0631\u062F\u0646";
const Kazakhstan$1 = "\u0643\u0627\u0632\u0627\u062E\u0633\u062A\u0627\u0646";
const Kenya$1 = "\u0643\u064A\u0646\u064A\u0627";
const Korea$1 = "\u0643\u0648\u0631\u064A\u0627";
const Kuwait$1 = "\u0627\u0644\u0643\u0648\u064A\u062A";
const Kyrgyzstan$1 = "\u0643\u064A\u0631\u062C\u064A\u0633\u062A\u0627\u0646";
const Latvia$1 = "\u0644\u0627\u062A\u0641\u064A\u0627";
const Lebanon$1 = "\u0644\u0628\u0646\u0627\u0646";
const Libya$1 = "\u0644\u064A\u0628\u064A\u0627";
const Lithuania$1 = "\u0644\u064A\u062B\u0648\u0627\u0646\u064A\u0627";
const Luxembourg$1 = "\u0644\u0643\u0633\u0645\u0628\u0648\u0631\u062C";
const Macao$1 = "\u0645\u0643\u0627\u0648";
const Macedonia$1 = "\u0645\u0642\u062F\u0648\u0646\u064A\u0627";
const Madagascar$1 = "\u0645\u062F\u063A\u0634\u0642\u0631";
const Malawi$1 = "\u0645\u0644\u0627\u0648\u064A";
const Malaysia$1 = "\u0645\u0627\u0644\u064A\u0632\u064A\u0627";
const Maldives$1 = "\u0627\u0644\u0645\u0627\u0644\u062F\u064A\u0641\u0632";
const Mali$1 = "\u0645\u0627\u0644\u064A";
const Malta$1 = "\u0645\u0627\u0644\u0637\u0627";
const Mauritania$1 = "\u0645\u0648\u0631\u064A\u062A\u0627\u0646\u064A\u0627";
const Mexico$1 = "\u0627\u0644\u0645\u0643\u0633\u064A\u0643";
const Mongolia$1 = "\u0645\u0646\u063A\u0648\u0644\u064A\u0627";
const Morocco$1 = "\u0627\u0644\u0645\u063A\u0631\u0628";
const Mozambique$1 = "\u0645\u0648\u0632\u0645\u0628\u064A\u0642";
const Myanmar$1 = "\u0645\u064A\u0627\u0646\u0645\u0627\u0631";
const Namibia$1 = "\u0646\u0627\u0645\u0628\u064A\u0627";
const Nepal$1 = "\u0646\u064A\u0628\u0627\u0644";
const Netherlands$1 = "\u0647\u0648\u0644\u0646\u062F\u0627";
const Nicaragua$1 = "\u0646\u0643\u0627\u0631\u062C\u0648\u0627";
const Niger$1 = "\u0646\u064A\u062C\u0631";
const Nigeria$1 = "\u0646\u064A\u062C\u064A\u0631\u064A\u0627";
const Norway$1 = "\u0627\u0644\u0646\u0631\u0648\u064A\u062C";
const Oman$1 = "\u0639\u0645\u0627\u0646";
const Pakistan$1 = "\u0628\u0627\u0643\u0633\u062A\u0627\u0646";
const Palestine$1 = "\u0641\u0644\u0633\u0637\u064A\u0646 \u0627\u0644\u062D\u0628\u064A\u0628\u0629";
const Panama$1 = "\u0628\u0646\u0645\u0627";
const Paraguay$1 = "\u0628\u0631\u0627\u063A\u0648\u0627\u064A";
const Peru$1 = "\u0628\u064A\u0631\u0648";
const Philippines$1 = "\u0627\u0644\u0641\u0644\u0628\u064A\u0646";
const Poland$1 = "\u0628\u0648\u0644\u0646\u062F\u0627";
const Portugal$1 = "\u0627\u0644\u0628\u0631\u062A\u063A\u0627\u0644";
const Qatar$1 = "\u0642\u0637\u0631";
const Romania$1 = "\u0631\u0648\u0645\u0627\u0646\u064A\u0627";
const Russia$1 = "\u0631\u0648\u0633\u064A\u0627";
const Rwanda$1 = "\u0631\u0648\u0627\u0646\u062F\u0627";
const Senegal$1 = "\u0627\u0644\u0633\u0646\u063A\u0627\u0644";
const Serbia$1 = "\u0635\u0631\u0628\u064A\u0627";
const Singapore$1 = "\u0633\u0646\u063A\u0627\u0641\u0648\u0631\u0629";
const Slovakia$1 = "\u0633\u0644\u0648\u0641\u0627\u0643\u064A\u0627";
const Slovenia$1 = "\u0633\u0644\u0648\u0641\u064A\u0646\u064A\u0627";
const Somalia$1 = "\u0627\u0644\u0635\u0648\u0645\u0627\u0644";
const Spain$1 = "\u0623\u0633\u0628\u0627\u0646\u064A\u0627";
const SriLanka$1 = "\u0633\u0631\u064A\u0644\u0627\u0646\u0643\u0627";
const Sudan$1 = "\u0627\u0644\u0633\u0648\u062F\u0627\u0646";
const Sweden$1 = "\u0627\u0644\u0633\u0648\u064A\u062F";
const Switzerland$1 = "\u0633\u0648\u064A\u0633\u0631\u0627";
const Syria$1 = "\u0633\u0648\u0631\u064A\u0627";
const Taiwan$1 = "\u062A\u064A\u0648\u0627\u0646";
const Tajikistan$1 = "\u0637\u0627\u063A\u0633\u062A\u0627\u0646";
const Tanzania$1 = "\u062A\u0646\u0632\u0627\u0646\u064A\u0627";
const Thailand$1 = "\u062A\u0627\u064A\u0644\u0646\u062F";
const Togo$1 = "\u062A\u0648\u063A\u0648";
const Tunisia$1 = "\u062A\u0648\u0646\u0633";
const Turkey$1 = "\u062A\u0631\u0643\u064A\u0627";
const Turkmenistan$1 = "\u062A\u0631\u0643\u0645\u0646\u0633\u062A\u0627\u0646";
const Uganda$1 = "\u0623\u0648\u063A\u0646\u062F\u0627";
const Ukraine$1 = "\u0623\u0648\u0643\u0631\u0627\u0646\u064A\u0627";
const Uruguay$1 = "\u0623\u0648\u0631\u0648\u063A\u0648\u0627\u064A";
const Uzbekistan$1 = "\u0623\u0648\u0632\u0628\u0627\u0643\u0633\u062A\u0627\u0646";
const Venezuela$1 = "\u0641\u0646\u0632\u0648\u064A\u0644\u0627";
const Vietnam$1 = "\u0641\u064A\u062A\u0646\u0627\u0645";
const Yemen$1 = "\u0627\u0644\u064A\u0645\u0646";
const Zambia$1 = "\u0632\u0627\u0645\u0628\u064A\u0627";
const Zimbabwe$1 = "\u0632\u0645\u0628\u0627\u0628\u0648\u064A";
const Samoa$1 = "\u0633\u0627\u0645\u0648\u0627";
const Benin$1 = "\u0628\u0646\u064A\u0646";
const Aruba$1 = "\u0627\u0631\u0648\u0628\u0627";
const Afghan$1 = "\u0623\u0641\u063A\u0627\u0646\u064A";
const Albanian$1 = "\u0623\u0644\u0628\u0627\u0646\u064A";
const Algerian$1 = "\u062C\u0632\u0627\u0626\u0631\u064A";
const American$1 = "\u0623\u0645\u0631\u064A\u0643\u064A";
const Angolan$1 = "\u0623\u0646\u063A\u0648\u0644\u064A";
const Anguillian$1 = "\u0623\u0646\u063A\u0648\u064A\u0644\u064A";
const Antiguan$1 = "\u0623\u0646\u0637\u064A\u0642\u064A";
const Argentine$1 = "\u0623\u0631\u062C\u0646\u062A\u064A\u0646\u064A";
const Armenian$1 = "\u0623\u0631\u0645\u064A\u0646\u064A";
const Aruban$1 = "\u0623\u0631\u0648\u0628\u064A";
const Australian$1 = "\u0623\u0633\u062A\u0631\u0627\u0644\u064A";
const Austrian$1 = "\u0646\u0645\u0633\u0627\u0648\u064A";
const Azerbaijani$1 = "\u0623\u0632\u0631\u0628\u064A\u062C\u0627\u0646\u064A";
const Bahamian$1 = "\u0628\u0627\u0647\u0627\u0645\u064A";
const Bahraini$1 = "\u0628\u062D\u0631\u064A\u0646\u064A";
const Bangladeshi$1 = "\u0628\u0646\u062C\u0644\u0627\u062F\u064A\u0634\u064A";
const Barbadian$1 = "\u0628\u0631\u0628\u062F\u064A";
const Belarusian$1 = "\u0628\u064A\u0644\u0627\u0631\u0648\u0633\u064A";
const Belgian$1 = "\u0628\u0644\u062C\u064A\u0643\u064A";
const Belizean$1 = "\u0628\u0644\u0632\u064A\u0646\u064A";
const Beninese$1 = "\u0628\u0646\u064A\u0646\u064A";
const Bermudian$1 = "\u0628\u0631\u0645\u0648\u062F\u064A";
const Bhutanese$1 = "\u0628\u0648\u062A\u0627\u0646\u064A";
const Bolivian$1 = "\u0628\u0648\u0644\u064A\u0641\u064A";
const Bosnian$1 = "\u0628\u0648\u0633\u0646\u064A";
const Botswanan$1 = "\u0628\u062A\u0633\u0648\u0627\u0646\u064A";
const Brazilian$1 = "\u0628\u0631\u0627\u0632\u064A\u0644\u064A";
const British$1 = "\u0628\u0631\u064A\u0637\u0627\u0646\u064A";
const Bruneian$1 = "\u0628\u0631\u0648\u0646\u064A";
const Bulgarian$1 = "\u0628\u0644\u063A\u0627\u0631\u064A";
const Burkinabe$1 = "\u0628\u0631\u0643\u064A\u0646\u064A";
const Burundian$1 = "\u0628\u0648\u0631\u0648\u0646\u062F\u064A";
const Cambodian$1 = "\u0643\u0645\u0628\u0648\u062F\u064A";
const Cameroonian$1 = "\u0643\u0627\u0645\u064A\u0631\u0648\u0646\u064A";
const Canadian$1 = "\u0643\u0646\u062F\u064A";
const Caymanian$1 = "\u0643\u064A\u0645\u0627\u0646\u064A";
const Chadian$1 = "\u062A\u0634\u0627\u062F\u064A";
const Chilean$1 = "\u062A\u0634\u064A\u0644\u064A";
const Chinese$1 = "\u0635\u064A\u0646\u064A";
const Colombian$1 = "\u0643\u0648\u0644\u0648\u0645\u0628\u064A";
const Comorian$1 = "\u0643\u0648\u0645\u0648\u0631\u064A";
const Congolese$1 = "\u0643\u0646\u063A\u0648\u0644\u064A";
const Croatian$1 = "\u0643\u0631\u0648\u0627\u062A\u064A";
const Cuban$1 = "\u0643\u0648\u0628\u064A";
const Cypriot$1 = "\u0643\u064A\u0628\u0631\u0648";
const Czech$1 = "\u062A\u0634\u064A\u0643\u064A";
const Danes$1 = "\u062F\u0627\u0646\u064A";
const Djiboutian$1 = "\u062C\u064A\u0628\u0648\u062A\u064A";
const Dominican$1 = "\u062F\u0648\u0645\u064A\u0646\u064A\u0643\u0627\u0646";
const Dutch$1 = "\u0647\u0648\u0644\u0646\u062F\u064A";
const Ecuadorian$1 = "\u0627\u0643\u0648\u0627\u062F\u0648\u0631\u064A";
const Egyptian$1 = "\u0645\u0635\u0631\u064A";
const Emirati$1 = "\u0627\u0645\u0627\u0631\u0627\u062A\u064A";
const Eritrean$1 = "\u0625\u0631\u064A\u062A\u0631\u064A";
const Estonian$1 = "\u0625\u0633\u062A\u0648\u0646\u064A";
const Ethiopian$1 = "\u0625\u062B\u064A\u0648\u0628\u064A";
const Faroese$1 = "\u0641\u0627\u0631\u0648\u0633\u064A";
const Fijian$1 = "\u0641\u064A\u062C\u064A";
const Filipino$1 = "\u0641\u0644\u0628\u064A\u0646\u064A";
const Finnish$1 = "\u0641\u0646\u0644\u0627\u0646\u062F\u064A";
const French$1 = "\u0641\u0631\u0646\u0633\u064A";
const Futunan$1 = "\u0641\u0648\u062A\u0646\u064A";
const Gabonese$1 = "\u062C\u0627\u0628\u0648\u0646\u064A";
const Gambian$1 = "\u062C\u0627\u0645\u0628\u064A\u0627\u0646";
const Georgian$1 = "\u062C\u0648\u0631\u062C\u064A";
const German$1 = "\u0623\u0644\u0645\u0627\u0646\u064A";
const Ghanaian$1 = "\u063A\u0627\u0646\u064A";
const Gibraltarian$1 = "\u062C\u0628\u0644 \u0637\u0627\u0631\u0642";
const Greek$1 = "\u064A\u0648\u0646\u0627\u0646\u064A";
const Grenadian$1 = "\u063A\u0631\u064A\u0646\u0627\u062F\u0627";
const Guadeloupian$1 = "\u062C\u0648\u0627\u062F\u064A\u0644\u0648\u0628\u064A";
const Guamanian$1 = "\u062C\u0648\u0627\u0645\u0627\u0646\u064A";
const Guatemalan$1 = "\u062C\u0648\u0627\u062A\u064A\u0645\u0627\u0644\u064A";
const Guinean$1 = "\u062C\u0648\u064A\u0646\u064A";
const Guyanese$1 = "\u062C\u0648\u0627\u0646\u064A";
const Haitian$1 = "\u0647\u0627\u064A\u062A\u064A";
const Honduran$1 = "\u0647\u0648\u0646\u062F\u0648\u0631\u064A";
const Hungarian$1 = "\u0645\u062C\u0631\u064A";
const Icelander$1 = "\u0627\u064A\u0633\u0644\u0627\u0646\u062F\u064A";
const Indian$1 = "\u0647\u0646\u062F\u064A";
const Indonesian$1 = "\u0627\u0646\u062F\u0648\u0646\u064A\u0633\u064A";
const Iranian$1 = "\u0625\u064A\u0631\u0627\u0646\u064A";
const Iraqi$1 = "\u0639\u0631\u0627\u0636\u064A";
const Irish$1 = "\u0627\u064A\u0631\u0644\u0627\u0646\u062F\u064A";
const Italian$1 = "\u0627\u064A\u0637\u0627\u0644\u064A";
const Ivoirian$1 = "\u0627\u064A\u0641\u0648\u0631\u064A";
const Jamaican$1 = "\u062C\u0627\u0645\u0627\u064A\u0643\u064A";
const Japanese$1 = "\u064A\u0627\u0628\u0627\u0646\u064A";
const Jordanian$1 = "\u0627\u0631\u062F\u0646\u064A";
const Kazakhstani$1 = "\u0643\u0627\u0632\u0627\u062E\u0633\u062A\u0627\u0646\u064A";
const Kenyan$1 = "\u0643\u064A\u0646\u064A";
const Kiribati$1 = "\u0643\u064A\u0631\u064A\u0628\u0627\u062A\u064A";
const Kuwaiti$1 = "\u0643\u0648\u064A\u062A\u064A";
const Kyrgyzstani$1 = "\u0643\u064A\u0631\u062C\u0633\u062A\u0627\u0646\u064A";
const Latvian$1 = "\u0644\u0627\u062A\u064A\u0641\u064A";
const Lebanese$1 = "\u0644\u0628\u0646\u0627\u0646\u064A";
const Liberian$1 = "\u0644\u064A\u0628\u0631\u0627\u0644\u064A";
const Libyan$1 = "\u0644\u064A\u0628\u064A";
const Liechtensteiner$1 = "\u0644\u064A\u062A\u0634\u0646\u0633\u062A\u064A";
const Lithuanian$1 = "\u0644\u064A\u062A\u0648\u0627\u0646\u064A";
const Luxembourger$1 = "\u0644\u0643\u0633\u0645\u0628\u0648\u0631\u062C\u064A";
const Macedonian$1 = "\u0645\u0642\u062F\u0648\u0646\u064A";
const Malagasy$1 = "\u0645\u0644\u0627\u0642\u064A";
const Malawian$1 = "\u0645\u0644\u0648\u0627\u0646\u064A";
const Malaysian$1 = "\u0645\u0627\u0644\u064A\u0632\u064A";
const Maldivian$1 = "\u0645\u0627\u0644\u062F\u064A\u0641\u064A";
const Malian$1 = "\u0645\u0627\u0644\u064A";
const Maltese$1 = "\u0645\u0627\u0644\u062A\u064A";
const Marshallese$1 = "\u0645\u0627\u0631\u0634\u0644\u064A";
const Martiniquai$1 = "\u0645\u0627\u0631\u062A\u064A\u0646\u064A\u0643\u0648\u064A";
const Mauritanian$1 = "\u0645\u0648\u0631\u064A\u062A\u0627\u0646\u064A";
const Mauritian$1 = "\u0645\u0648\u0631\u064A\u062A\u064A";
const Mexican$1 = "\u0645\u0643\u0633\u064A\u0643\u064A";
const Miquelonnais$1 = "\u0645\u064A\u0643\u0648\u0644\u0648\u0646\u064A";
const Moldovan$1 = "\u0645\u0648\u0644\u062F\u0648\u0641\u064A";
const Monacan$1 = "\u0645\u0648\u0646\u0627\u0643\u064A";
const Mongolian$1 = "\u0645\u0648\u0646\u063A\u0648\u0644\u064A";
const Montenegrin$1 = "\u0645\u0648\u0646\u062A\u064A\u0646\u062C\u0631\u064A";
const Montserratian$1 = "\u0645\u0648\u0646\u062A\u0633\u0631\u062A\u064A";
const Moroccan$1 = "\u0645\u063A\u0631\u0628\u064A";
const Mozambican$1 = "\u0645\u0648\u0632\u0645\u0628\u064A\u0642\u064A";
const Myanmarian$1 = "\u0645\u064A\u0627\u0646\u0627\u0645\u0627\u0631\u064A";
const Nauruan$1 = "\u0646\u0648\u0627\u0631\u064A";
const Nepalese$1 = "\u0646\u064A\u0628\u0627\u0644\u064A";
const Nicaraguan$1 = "\u0646\u064A\u0643\u0627\u0631\u0627\u062C\u0648\u064A";
const Nigerian$1 = "\u0646\u064A\u062C\u064A\u0631\u064A";
const Nigerien$1 = "\u0646\u064A\u062C\u064A\u0631\u064A";
const Niuean$1 = "\u0646\u064A\u0648\u064A";
const Norwegian$1 = "\u0646\u0631\u0648\u064A\u062C\u064A";
const Omani$1 = "\u0639\u0645\u0627\u0646\u064A";
const Pakistani$1 = "\u0628\u0627\u0643\u0633\u062A\u0627\u0646\u064A";
const Palauan$1 = "\u0628\u0627\u0644\u0648\u0627\u0646\u064A";
const Palestinian$1 = "\u0641\u0644\u0633\u0637\u064A\u0646\u064A";
const Panamanian$1 = "\u0628\u0646\u0645\u064A";
const Papuans$1 = "\u0628\u0627\u0628\u0648\u0627\u0646\u064A";
const Paraguayan$1 = "\u0628\u0627\u0631\u0627\u063A\u0648\u0627\u064A";
const Peruvian$1 = "\u0628\u064A\u0631\u0648";
const Polish$1 = "\u0628\u0648\u0644\u0646\u062F\u064A";
const Portuguese$1 = "\u0628\u0631\u062A\u063A\u0627\u0644\u064A";
const Qatari$1 = "\u0642\u0637\u0631\u064A";
const Romanian$1 = "\u0631\u0648\u0645\u0627\u0646\u064A";
const Russian$1 = "\u0631\u0648\u0633\u064A";
const Rwandan$1 = "\u0631\u0648\u0627\u0646\u062F\u064A";
const Salvadoran$1 = "\u0633\u0627\u0644\u0641\u0627\u062F\u0648\u0631\u064A";
const Samoan$1 = "\u0633\u0627\u0645\u0648\u064A";
const Santomean$1 = "\u0633\u0627\u0646\u062A\u0648\u0645\u064A";
const Senegalese$1 = "\u0633\u0646\u063A\u0627\u0644\u064A";
const Serbian$1 = "\u0635\u0631\u0628\u064A";
const Seychellois$1 = "\u0635\u0642\u0644\u064A";
const Singaporean$1 = "\u0633\u0646\u063A\u0627\u0641\u0648\u0631\u064A";
const Slovak$1 = "\u0633\u0644\u0648\u0641\u0627\u0643\u064A";
const Slovenian$1 = "\u0633\u0644\u0648\u0641\u064A\u0646\u064A";
const Somali$1 = "\u0635\u0648\u0645\u0627\u0644\u064A";
const Spanish$1 = "\u0623\u0633\u0628\u0627\u0646\u064A";
const Sudanese$1 = "\u0633\u0648\u062F\u0627\u0646\u064A";
const Surinamer$1 = "\u0633\u0648\u0631\u064A\u0646\u0627\u0645\u064A\u0631";
const Swazi$1 = "\u0633\u0648\u0627\u0632\u064A";
const Swede$1 = "\u0633\u0648\u064A\u062F\u064A";
const Swiss$1 = "\u0633\u0648\u064A\u0633\u0631\u064A";
const Syrian$1 = "\u0633\u0648\u0631\u064A";
const Taiwanese$1 = "\u062A\u064A\u0648\u0627\u0646\u064A";
const Tajikistani$1 = "\u0637\u0627\u062C\u0633\u062A\u0627\u0646\u064A";
const Tanzanian$1 = "\u062A\u0646\u0632\u0627\u0646\u064A";
const Thai$1 = "\u062A\u0627\u064A\u0644\u0627\u0646\u062F\u064A";
const Tobagonian$1 = "\u062A\u0627\u0628\u0648\u062C\u0648\u0646\u064A";
const Togolese$1 = "\u062A\u0627\u062C\u0648\u0644\u064A";
const Tokelauan$1 = "\u062A\u0648\u0643\u064A\u0644\u0648\u0627\u0646\u064A";
const Tongan$1 = "\u062A\u0648\u0646\u062C\u0627\u0646\u064A";
const Tunisian$1 = "\u062A\u0648\u0646\u0633\u064A";
const Turk$1 = "\u062A\u0631\u0643\u064A";
const Turkmen$1 = "\u062A\u0631\u0643\u0645\u0627\u0646\u064A";
const Tuvaluan$1 = "\u062A\u0648\u0641\u0644\u0648\u064A";
const Ugandan$1 = "\u0627\u0648\u063A\u0646\u062F\u064A";
const Ukrainian$1 = "\u0627\u0648\u0643\u0631\u0627\u0646\u064A";
const Uruguayan$1 = "\u0627\u0648\u0631\u0648\u063A\u0648\u0627\u064A";
const Uzbek$1 = "\u0627\u0648\u0632\u0628\u0643";
const Vatican$1 = "\u0641\u0627\u062A\u064A\u0643\u064A";
const Venezuelan$1 = "\u0641\u0646\u0632\u0648\u064A\u0644\u064A";
const Vietnamese$1 = "\u0641\u062A\u0646\u0627\u0645\u064A";
const Yemeni$1 = "\u064A\u0645\u0646\u064A";
const Zambian$1 = "\u0632\u0627\u0645\u0628\u064A";
const Zimbabwean$1 = "\u0632\u0645\u0628\u0627\u0628\u0648\u064A";
const Mecca$1 = "\u0645\u0643\u0629";
const Medina$1 = "\u0627\u0644\u0645\u062F\u064A\u0646\u0629";
const Jubail$1 = "\u0627\u0644\u062C\u0628\u064A\u0644";
const Dammam$1 = "\u0627\u0644\u062F\u0645\u0627\u0645";
const Hael$1 = "\u0627\u0644\u062D\u0627\u0626\u0644";
const Riyadh$1 = "\u0627\u0644\u0631\u064A\u0627\u0636";
const Aseer$1 = "\u0639\u0633\u064A\u0631";
const Jazan$1 = "\u062C\u0627\u0632\u0627\u0646";
const Najran$1 = "\u0646\u062C\u0631\u0627\u0646";
const Tabuk$1 = "\u062A\u0628\u0648\u0643";
const Buraidah$1 = "\u0628\u0631\u064A\u062F\u0647";
const Dabaa$1 = "\u0636\u0628\u0627\u0621";
const Khobar$1 = "\u062E\u0628\u0631";
const Sakaka$1 = "\u0633\u0643\u0627\u0643\u0629";
const Jizan$1 = "\u062C\u064A\u0632\u0627\u0646";
const Besha$1 = "\u0628\u064A\u0634\u0629";
const Sehat$1 = "\u0633\u064A\u0647\u0627\u062A";
const Sharora$1 = "\u0634\u0631\u0648\u0631\u0629";
const Bahra$1 = "\u0628\u062D\u0631\u0629";
const Afif$1 = "\u0639\u0641\u064A\u0641";
const Sabia$1 = "\u0635\u0628\u064A\u0627";
const Bariq$1 = "\u0628\u0627\u0631\u0642";
const Abha$1 = "\u0623\u0628\u0647\u0627";
const Aneeza$1 = "\u0639\u0646\u064A\u0632\u0629";
const Jeddah$1 = "\u062C\u062F\u0629";
const ar = {
  "Saudi journalists association": "\u0647\u064A\u0626\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646",
  Loading: Loading$1,
  "Error": "\u062E\u0637\u0623",
  "Sorry, we couldn't find this page.": "\u0646\u0623\u0633\u0641\u060C \u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629",
  "But dont worry, you can find plenty of other things on our homepage.": "\u0644\u0643\u0646 \u0644\u0627 \u062A\u0642\u0644\u0642\u060C \u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0635\u0641\u062D\u0627\u062A \u0623\u062E\u0631\u0649 \u0641\u064A \u0635\u0641\u062D\u062A\u0646\u0627 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
  "Back to homepage": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0644\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
  login: login$1,
  logout: logout$1,
  "Login to sju": "\u062F\u062E\u0648\u0644 \u0644\u0644\u0647\u064A\u0626\u0629",
  "Close modal": "\u063A\u0644\u0642 \u0627\u0644\u0646\u0627\u0641\u0630\u0629",
  Subscribers: Subscribers$1,
  Members: Members$1,
  Volunteers: Volunteers$1,
  Close: Close$1,
  Details: Details$1,
  "/*============================= Certificate validation": "=============================*/",
  "Validate certificate": "\u0627\u0644\u062A\u062D\u0642 \u0645\u0646 \u0627\u0644\u0634\u0647\u0627\u062F\u0629",
  "Please enter the code written on the certificate": "\u0641\u0636\u0644\u0627 \u0642\u0645 \u0628\u0627\u062F\u062E\u0627\u0644 \u0627\u0644\u0631\u0645\u0632 \u0627\u0644\u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0627\u0644\u0634\u0647\u0627\u062F\u0629",
  Code: Code$1,
  Validate: Validate$1,
  "/*================================== HOME PAGE TRANSLATIONS": "==================================*/",
  about_authority: about_authority$1,
  about_authority_description: about_authority_description$1,
  "Read more": "\u0625\u0642\u0631\u0623 \u0627\u0644\u0645\u0632\u064A\u062F",
  More: More$1,
  "Media center": "\u0627\u0644\u0645\u0631\u0643\u0632 \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A",
  Studio: Studio$1,
  All: All$1,
  photo: photo$1,
  Photos: Photos$1,
  Videos: Videos$1,
  "Regulations and events": "\u0627\u0644\u0644\u0648\u0627\u0626\u062D \u0648\u0627\u0644\u0623\u0646\u0638\u0645\u0629",
  Events: Events$1,
  Notifications: Notifications$1,
  "Request type": "\u0646\u0648\u0639 \u0627\u0644\u0637\u0644\u0628",
  "Request date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0637\u0644\u0628",
  "The basic bylaw of the Saudi Journalists Association": "\u0627\u0644\u0644\u0627\u0626\u062D\u0629 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629 \u0644\u0647\u064A\u0626\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646",
  "1.5 Miga bytes": "1.5 \u0645\u064A\u062C\u0627 \u0628\u0627\u064A\u062A",
  "Authority membership": "\u0639\u0636\u0648\u064A\u0629 \u0627\u0644\u0647\u064A\u0626\u0629",
  membership_desc: membership_desc$1,
  membership_btn: membership_btn$1,
  membership_conditions: membership_conditions$1,
  fulltime_member: fulltime_member$1,
  fulltime_member_desc1: fulltime_member_desc1$1,
  fulltime_member_desc2: fulltime_member_desc2$1,
  fulltime_member_desc3: fulltime_member_desc3$1,
  parttime_member: parttime_member$1,
  parttime_member_desc1: parttime_member_desc1$1,
  parttime_member_desc2: parttime_member_desc2$1,
  affiliate_member: affiliate_member$1,
  affiliate_member_desc1: affiliate_member_desc1$1,
  Statistics: Statistics$1,
  "Of members": "\u0639\u062F\u062F \u0627\u0644\u0623\u0639\u0636\u0627\u0621",
  "Of events": "\u0639\u062F\u062F \u0627\u0644\u0645\u0624\u062A\u0645\u0631\u0627\u062A",
  "Of memberships": "\u0639\u062F\u062F \u0627\u0644\u0639\u0636\u0648\u064A\u0627\u062A",
  "Of workshops": "\u0639\u062F\u062F \u0648\u0631\u0634 \u0627\u0644\u0639\u0645\u0644",
  "Follow us": "\u062A\u0627\u0628\u0639\u0646\u0627",
  "Follow us on social media": "\u062A\u0627\u0628\u0639\u0646\u0627 \u0639\u0644\u064A \u0645\u0648\u0627\u0642\u0639 \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u0627\u0644\u0625\u062C\u062A\u0645\u0627\u0639\u064A",
  "Contact us": "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627",
  "/***************** Footer ***************/": "",
  "Important Links": "\u0631\u0648\u0627\u0628\u0637 \u062A\u0647\u0645\u0643:",
  "Ministry of Information": "\u0648\u0632\u0627\u0631\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0645",
  "Audiovisual organization": "\u0647\u064A\u0626\u0629 \u0627\u0644\u0645\u0631\u0626\u064A \u0648\u0627\u0644\u0645\u0633\u0645\u0648\u0639",
  "Saudi press agency": "\u0648\u0643\u0627\u0644\u0629 \u0627\u0644\u0623\u0646\u0628\u0627\u0621 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629",
  "Radio & TV organization": "\u0647\u064A\u0626\u0629 \u0627\u0644\u0625\u0630\u0627\u0639\u0629 \u0648\u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646",
  "Our location": "\u0645\u0648\u0642\u0639\u0646\u0627",
  "Terms of service": "\u0634\u0631\u0648\u0637 \u0627\u0644\u062E\u062F\u0645\u0629",
  "Privacy policy": "\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629",
  "Call us": "\u0627\u062A\u0635\u0644 \u0628\u0646\u0627",
  "All rights reserved to Saudi Journalists Association": "\u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0642\u0648\u0642 \u0645\u062D\u0641\u0648\u0638\u0629 \u0644\u0647\u064A\u0626\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u064A\u0646 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646",
  "Made with \u2764 by:": "\u0635\u0646\u0639 \u0628\u0643\u0644 \u2764 \u0628\u0648\u0627\u0633\u0637\u0629:",
  "/***************************** Posts **********************/": "",
  "Posts list": "\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0642\u0627\u0644\u0627\u062A",
  Home: Home$1,
  Posts: Posts$1,
  "Related posts": "\u0645\u0642\u0627\u0644\u0627\u062A \u0630\u0627\u062A \u0635\u0644\u0629",
  "No posts found": "\u0644\u0627 \u064A\u0648\u062C\u062F \u0645\u0642\u0627\u0644\u0627\u062A",
  "/***************************** Events **********************/": "",
  "No events found": "\u0644\u0627 \u064A\u0648\u062C\u062F \u0641\u0639\u0627\u0644\u064A\u0627\u062A",
  "Additional info": "\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0636\u0627\u0641\u064A\u0629",
  "User info": "\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645",
  "User name": "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645",
  "Upcoming events": "\u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0627\u062A \u0627\u0644\u0642\u0627\u062F\u0645\u0629",
  "Events list": "\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0627\u062A",
  "Events done": "\u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0627\u062A \u0627\u0644\u0645\u0646\u062A\u0647\u064A\u0629",
  "Event name": "\u0627\u0633\u0645 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "Event date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "Event time": "\u0648\u0642\u062A \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "Event type": "\u0646\u0648\u0639 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "Event category": "\u062A\u0635\u0646\u064A\u0641 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "Event gender": "\u0641\u0626\u0629 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "Event location": "\u0645\u0648\u0642\u0639 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "No data found to show": "\u0644\u0627 \u064A\u0648\u062C\u062F \u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0644\u0639\u0631\u0636",
  TermsAgreement: TermsAgreement$1,
  "Already registered in event": "\u0627\u0646\u062A \u0645\u0633\u062C\u0644 \u0641\u064A \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "Already attended in event": "\u0627\u0646\u062A \u0645\u062D\u0636\u0631 \u0641\u064A \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  Registered: Registered$1,
  Attend: Attend$1,
  Attended: Attended$1,
  "Not registered in event": "\u0623\u0646\u062A \u063A\u064A\u0631 \u0645\u0633\u062C\u0644 \u0628\u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  to: to$1,
  Free: Free$1,
  "All paid": "\u0645\u062F\u0641\u0648\u0639 \u0628\u0627\u0644\u0643\u0627\u0645\u0644",
  "Paid certificate": "\u0645\u062F\u0641\u0648\u0639 \u0627\u0644\u0634\u0647\u0627\u062F\u0629",
  "You didn't attend the event": "\u0644\u0645 \u062A\u062D\u0636\u0631 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  "Fill the survey first": "\u0627\u0644\u0645\u0631\u062C\u0648 \u062A\u0642\u064A\u064A\u0645 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629",
  Prev: Prev$1,
  Next: Next$1,
  "Back to events": "\u0627\u0644\u0639\u0648\u062F\u0629 \u0644\u0644\u0641\u0639\u0627\u0644\u064A\u0627\u062A",
  "Please enter a valid phone number. eg: 501234567": "\u0628\u0631\u062C\u0627\u0621 \u0643\u062A\u0627\u0628\u0629 \u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0635\u062D\u064A\u062D. \u0645\u062B\u0627\u0644: 501234567",
  "/************************* Technical support ******************/": "",
  "Ticket title": "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062A\u0630\u0643\u0631\u0629",
  "Creation date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0625\u0646\u0634\u0627\u0621",
  "Modification date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u0639\u062F\u064A\u0644",
  "Last update date": "\u062A\u0627\u0631\u064A\u062E \u0623\u062E\u0631 \u062A\u062D\u062F\u064A\u062B",
  Status: Status$1,
  "New ticket": "\u062A\u0630\u0643\u0631\u0629 \u062C\u062F\u064A\u062F\u0629",
  Description: Description$1,
  "Attach image": "\u0625\u0631\u0641\u0627\u0642 \u0635\u0648\u0631\u0629",
  Create: Create$1,
  Solved: Solved$1,
  Open: Open$1,
  Send: Send$1,
  Resend: Resend$1,
  Message: Message$1,
  "/*************************** Volunteers ********************/": "",
  "Register new volunteer": "\u062A\u0633\u062C\u064A\u0644 \u0645\u062A\u0637\u0648\u0639 \u062C\u062F\u064A\u062F",
  "Profile picture": "\u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u0634\u062E\u0635\u064A\u0629",
  fname: fname$1,
  sname: sname$1,
  tname: tname$1,
  lname: lname$1,
  "In Arabic": "\u0628\u0627\u0644\u0639\u0631\u0628\u064A",
  "In English": "\u0628\u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A",
  Gender: Gender$1,
  Male: Male$1,
  Female: Female$1,
  Country: Country$1,
  City: City$1,
  Nationality: Nationality$1,
  Qualification: Qualification$1,
  "National ID": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0648\u064A\u0629",
  "Martial status": "\u0627\u0644\u062D\u0627\u0644\u0629 \u0627\u0644\u0625\u062C\u062A\u0645\u0627\u0639\u064A\u0629",
  "Adminstrative area": "\u0627\u0644\u0645\u0646\u0637\u0642\u0629 \u0627\u0644\u0625\u062F\u0627\u0631\u064A\u0629",
  Governorate: Governorate$1,
  "National address": "\u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0648\u0637\u0646\u064A",
  "Job title": "\u0627\u0644\u0635\u0641\u0629 \u0627\u0644\u0645\u0647\u0646\u064A\u0629",
  Address: Address$1,
  "Volunteering fields": "\u0645\u062C\u0627\u0644\u0627\u062A \u0627\u0644\u062A\u0637\u0648\u0639",
  Photography: Photography$1,
  Videography: Videography$1,
  Cinematography: Cinematography$1,
  "Editing - Media Platforms - Documentation": "\u0627\u0644\u062A\u062D\u0631\u064A\u0631 - \u0627\u0644\u0645\u0646\u0635\u0627\u062A \u0627\u0644\u0625\u0639\u0644\u0627\u0645\u064A\u0629 -\u0627\u0644\u062A\u0648\u062B\u064A\u0642",
  Coverings: Coverings$1,
  Presentation: Presentation$1,
  "Digital content industry": "\u0635\u0646\u0627\u0639\u0629 \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0627\u0644\u0631\u0642\u0645\u064A",
  Montage: Montage$1,
  "Social media": "\u0627\u0644\u0633\u0648\u0634\u0644 \u0645\u064A\u062F\u064A\u0627",
  "Media marketing": "\u0627\u0644\u062A\u0633\u0648\u064A\u0642 \u0627\u0644\u0627\u0639\u0644\u0627\u0645\u064A",
  "Editorial management": "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u062A\u062D\u0631\u064A\u0631",
  "Field Editorial Leadership": "\u0642\u064A\u0627\u062F\u0629 \u0627\u0644\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u0645\u064A\u062F\u0627\u0646\u064A",
  "Management of meetings and seminars": "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0645\u0644\u062A\u0642\u064A\u0627\u062A \u0648\u0627\u0644\u0646\u062F\u0648\u0627\u062A",
  "Media training": "\u0627\u0644\u062A\u062F\u0631\u064A\u0628 \u0627\u0644\u0627\u0639\u0644\u0627\u0645\u064A",
  "Educational level": "\u0627\u0644\u0645\u0631\u062D\u0644\u0629 \u0627\u0644\u062F\u0631\u0627\u0633\u064A\u0629",
  "Volunteering experiences": "\u0627\u0644\u062E\u0628\u0631\u0627\u062A \u0627\u0644\u062A\u0637\u0648\u0639\u064A\u0629",
  Branch: Branch$1,
  "How do you know the authority?": "\u0643\u064A\u0641 \u062A\u0639\u0631\u0641\u062A \u0639\u0644\u0649 \u0627\u0644\u0647\u064A\u0626\u0629\u061F",
  Mobile: Mobile$1,
  Email: Email$1,
  Password: Password$1,
  "Password confirmation": "\u062A\u0623\u0643\u064A\u062F \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  TermsAcceptance: TermsAcceptance$1,
  acceptance: acceptance$1,
  Register: Register$1,
  Login: Login$1,
  "From a friend": "\u0645\u0646 \u0635\u062F\u064A\u0642",
  Twitter: Twitter$1,
  Youtube: Youtube$1,
  "You can register as a new volunteer from this link": "\u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0643\u0645\u062A\u0637\u0648\u0639 \u062C\u062F\u064A\u062F \u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u062A\u0627\u0644\u064A",
  "Click here to register": "\u0625\u0636\u063A\u0637 \u0647\u0646\u0627 \u0644\u0644\u062A\u0633\u062C\u064A\u0644",
  "Login volunteers": "\u062F\u062E\u0648\u0644 \u0627\u0644\u0645\u062A\u0637\u0648\u0639\u064A\u0646",
  Profile: Profile$1,
  "Technical support": "\u0627\u0644\u062F\u0639\u0645 \u0627\u0644\u0641\u0646\u064A",
  "Edit profile": "\u062A\u062D\u0631\u064A\u0631 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A",
  "Enrolled events": "\u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0627\u062A \u0627\u0644\u0645\u0634\u062A\u0631\u0643 \u0628\u0647\u0627",
  Save: Save$1,
  "Change password": "\u062A\u063A\u064A\u064A\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Current password": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062D\u0627\u0644\u064A\u0629",
  "New password": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629",
  "Please verify your email": "\u064A\u062C\u0628 \u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A.",
  "Email has been verified successfully": "\u062A\u0645 \u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0628\u0646\u062C\u0627\u062D.",
  "Resend verification": "\u0625\u0639\u0627\u062F\u0629 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u062A\u0641\u0639\u064A\u0644",
  "Forgot password": "\u0646\u0633\u064A\u062A \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "Reset password": "\u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
  "/*************************** Subscribers ********************/": "",
  "Login subscribers": "\u062F\u062E\u0648\u0644 \u0627\u0644\u0645\u0634\u062A\u0631\u0643\u064A\u0646",
  "Register new subscriber": "\u062A\u0633\u062C\u064A\u0644 \u0645\u0634\u062A\u0631\u0643 \u062C\u062F\u064A\u062F",
  "You can register as a new subscriber from this link": "\u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0643\u0645\u0634\u062A\u0631\u0643 \u062C\u062F\u064A\u062F \u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u062A\u0627\u0644\u064A",
  "/*************************** Members ********************/": "",
  "Login members": "\u062F\u062E\u0648\u0644 \u0627\u0644\u0623\u0639\u0636\u0627\u0621",
  "Register new member": "\u062A\u0633\u062C\u064A\u0644 \u0639\u0636\u0648 \u062C\u062F\u064A\u062F",
  "You can register as a new member from this link": "\u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 \u0643\u0639\u0636\u0648 \u062C\u062F\u064A\u062F \u0645\u0646 \u062E\u0644\u0627\u0644 \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u062A\u0627\u0644\u064A",
  "Terms and policies": "\u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u0623\u062D\u0643\u0627\u0645",
  "Contact info": "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0648\u0627\u0635\u0644",
  "Membership types": "\u0641\u0626\u0627\u062A \u0627\u0644\u0639\u0636\u0648\u064A\u0629",
  "Membership type": "\u0641\u0626\u0629 \u0627\u0644\u0639\u0636\u0648\u064A\u0629",
  "Member info": "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0639\u0636\u0648",
  "Login info": "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062F\u062E\u0648\u0644",
  Review: Review$1,
  Registration: Registration$1,
  member_rule1: member_rule1$1,
  member_rule2: member_rule2$1,
  member_rule3: member_rule3$1,
  member_rule4: member_rule4$1,
  member_rule5: member_rule5$1,
  member_rule6: member_rule6$1,
  "ID or residence number": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0648\u064A\u0629 \u0623\u0648 \u0627\u0644\u0625\u0642\u0627\u0645\u0629",
  Verify: Verify$1,
  "Send verification code": "\u0625\u0631\u0633\u0627\u0644 \u0643\u0648\u062F \u0627\u0644\u062A\u062D\u0642\u0642",
  "Choose the type that fits you": "\u0641\u0636\u0644\u0627 \u0642\u0645 \u0628\u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0641\u0626\u0629 \u0627\u0644\u062A\u064A \u062A\u0646\u0627\u0633\u0628\u0643",
  Amount: Amount$1,
  Riyal: Riyal$1,
  Annual: Annual$1,
  "Membership branch": "\u0627\u0644\u0641\u0631\u0639 \u0627\u0644\u062A\u0627\u0628\u0639 \u0644\u0644\u0639\u0636\u0648\u064A\u0629",
  "Delivery method": "\u0637\u0631\u064A\u0642\u0629 \u0625\u0633\u062A\u0644\u0627\u0645 \u0627\u0644\u0628\u0637\u0627\u0642\u0629",
  "Receipt from the branch": "\u0627\u0644\u0625\u0633\u062A\u0644\u0627\u0645 \u0645\u0646 \u0627\u0644\u0641\u0631\u0639",
  Delivery: Delivery$1,
  "If you choose delivery, 30 riyals will be added to the invoice value.": "\u0641\u064A \u062D\u0627\u0644\u0629 \u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u062A\u0648\u0635\u064A\u0644 \u064A\u062A\u0645 \u0627\u0636\u0627\u0641\u0629 30 \u0631\u064A\u0627\u0644 \u0644\u0642\u064A\u0645\u0629 \u0627\u0644\u0641\u0627\u062A\u0648\u0631\u0629.",
  "Delivery Address": "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062A\u0648\u0635\u064A\u0644",
  "ID source": "\u0645\u0635\u062F\u0631 \u0627\u0644\u0647\u0648\u064A\u0629",
  Hijri: Hijri$1,
  "ID date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0647\u0648\u064A\u0629",
  "Birth date": "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u064A\u0644\u0627\u062F",
  Milady: Milady$1,
  Major: Major$1,
  Journalist: Journalist$1,
  "Non-Journalist": "\u0627\u0644\u063A\u064A\u0631 \u0635\u062D\u0641\u064A",
  Employer: Employer$1,
  "Newspaper type": "\u0646\u0648\u0639 \u0627\u0644\u0635\u062D\u064A\u0641\u0629",
  "Printed newspaper": "\u0635\u062D\u064A\u0641\u0629 \u0648\u0631\u0642\u064A\u0629",
  "E-newspaper": "\u0635\u062D\u064A\u0641\u0629 \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A\u0629",
  "Work phone": "\u0647\u0627\u062A\u0641 \u0627\u0644\u0639\u0645\u0644",
  Fax: Fax$1,
  Ext: Ext$1,
  "Post box": "\u0635\u0646\u062F\u0648\u0642 \u0628\u0631\u064A\u062F",
  "Post code": "\u0627\u0644\u0631\u0645\u0632 \u0627\u0644\u0628\u0631\u064A\u062F\u064A",
  membership_agreement: membership_agreement$1,
  "Error in one or more fields": "\u062E\u0637\u0623 \u0641\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0623\u062D\u062F \u0627\u0644\u062D\u0642\u0648\u0644",
  "Error in registration": "\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062A\u0633\u062C\u064A\u0644",
  "You have to choose member type": "\u064A\u062C\u0628 \u0627\u062E\u062A\u064A\u0627\u0631 \u0646\u0648\u0639 \u0627\u0644\u0639\u0636\u0648\u064A\u0629",
  "Please verify your mobile": "\u064A\u062C\u0628 \u062A\u0641\u0639\u064A\u0644 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641",
  "Verification code": "\u0643\u0648\u062F \u0627\u0644\u062A\u0641\u0639\u064A\u0644",
  "Resend verification code": "\u0625\u0639\u0627\u062F\u0629 \u0625\u0631\u0633\u0627\u0644 \u0643\u0648\u062F \u0627\u0644\u062A\u0641\u0639\u064A\u0644",
  Submit: Submit$1,
  "Mobile provided is not correct": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D",
  "Mobile verification": "\u062A\u0641\u0639\u064A\u0644 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641",
  Info: Info$1,
  "Exp. & fields": "\u0627\u0644\u062E\u0628\u0631\u0627\u062A \u0648\u0627\u0644\u0645\u062C\u0627\u0644\u0627\u062A",
  "ID image": "\u0635\u0648\u0631\u0629 \u0627\u0644\u0647\u0648\u064A\u0629",
  "Job letter": "\u0625\u0641\u0627\u062F\u0629 \u0627\u0644\u0639\u0645\u0644",
  "Job contract": "\u0639\u0642\u062F \u0639\u0645\u0644",
  "Newspaper license": "\u062A\u0631\u062E\u064A\u0635 \u0627\u0644\u0635\u062D\u064A\u0641\u0629",
  Experiences: Experiences$1,
  Years,
  Add: Add$1,
  "Fields you want to contribute to": "\u0627\u0644\u0645\u062C\u0627\u0644\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0631\u063A\u0628 \u0628\u0627\u0644\u0645\u0633\u0627\u0647\u0645\u0629 \u0641\u064A\u0647\u0627",
  Fields: Fields$1,
  "Languages you good at": "\u0627\u0644\u0644\u063A\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u062C\u064A\u062F\u0647\u0627",
  Languages: Languages$1,
  Language: Language$1,
  Level: Level$1,
  Fair: Fair$1,
  Good: Good$1,
  "Very good": "\u062C\u064A\u062F \u062C\u062F\u0627",
  Excellent: Excellent$1,
  "Change profile picture": "\u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u0634\u062E\u0635\u064A\u0629",
  "Image must have a good quality": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0627\u0644\u0635\u0648\u0631\u0629 \u0628\u062C\u0648\u062F\u0629 \u062C\u064A\u062F\u0629",
  "Only .Jpg, .Gif, .Png images are accepted": "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0627\u0645\u062A\u062F\u0627\u062F \u0627\u0644\u0635\u0648\u0631\u0629 jpg \u0623\u0648 gif \u0623\u0648 png \u0641\u0642\u0637",
  "Image size must not exceed 2 MB": "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u062D\u062C\u0645 \u0627\u0644\u0635\u0648\u0631\u0629 \u0644\u0627 \u064A\u0632\u064A\u062F \u0639\u0646 2 \u0645\u064A\u063A\u0627",
  "A statement from the employer with the title of the current journalistic job": "\u0625\u0641\u0627\u062F\u0629 \u0645\u0646 \u062C\u0647\u0629 \u0627\u0644\u0639\u0645\u0644 \u0628\u0645\u0633\u0645\u0649 \u0627\u0644\u0648\u0638\u064A\u0641\u0629 \u0627\u0644\u0635\u062D\u0641\u064A\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629",
  "Complete profile info": "\u0625\u0633\u062A\u0643\u0645\u0627\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A",
  "To apply for membership, you must complete the required information": "\u0644\u0637\u0644\u0628 \u0627\u0644\u0639\u0636\u0648\u064A\u0629 \u064A\u062C\u0628 \u0627\u0633\u062A\u0643\u0645\u0627\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629",
  "Completion percentage": "\u0646\u0633\u0628\u0629 \u0627\u0644\u0625\u0643\u062A\u0645\u0627\u0644",
  Requirement: Requirement$1,
  Upload: Upload$1,
  Membership: Membership$1,
  "Subscription start": "\u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u0625\u0634\u062A\u0631\u0627\u0643",
  "Subscription end": "\u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u0625\u0634\u062A\u0631\u0627\u0643",
  "Request membership": "\u0637\u0644\u0628 \u0627\u0644\u0639\u0636\u0648\u064A\u0629",
  "Waiting branch approval": "\u0628\u0625\u0646\u062A\u0638\u0627\u0631 \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0641\u0631\u0639",
  "Waiting to pay": "\u0641\u064A \u0625\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062F\u0641\u0639",
  Refused: Refused$1,
  "Unsatisfied conditions": "\u063A\u064A\u0631 \u0645\u0633\u062A\u0648\u0641\u0649 \u0627\u0644\u0634\u0631\u0648\u0637",
  "Waiting admin approval": "\u0628\u0625\u0646\u062A\u0638\u0627\u0631 \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0623\u062F\u0645\u0646",
  "Error occured. Refresh the page and if problem resists contact us!": "\u062D\u062F\u062B \u062E\u0637\u0623\u060C \u0623\u0639\u062F \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0635\u0641\u062D\u0629 \u0648\u0644\u0648 \u0627\u0633\u062A\u0645\u0631 \u0627\u0644\u062E\u0637\u0627 \u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627!",
  Pay: Pay$1,
  "Complete payment process": "\u0625\u062A\u0645\u0627\u0645 \u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u062F\u0641\u0639",
  "Subscribing to membership": "\u0627\u0644\u0625\u0634\u062A\u0631\u0627\u0643 \u0641\u064A \u0627\u0644\u0639\u0636\u0648\u064A\u0629",
  "Card type": "\u0646\u0648\u0639 \u0627\u0644\u0628\u0637\u0627\u0642\u0629",
  payment_condition1: payment_condition1$1,
  payment_condition2: payment_condition2$1,
  payment_condition3: payment_condition3$1,
  "Payment details": "\u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062F\u0641\u0639",
  "for membership": "\u0644\u0639\u0636\u0648\u064A\u0629",
  "card delivery fees": "\u0631\u0633\u0648\u0645 \u062A\u0648\u0635\u064A\u0644 \u0627\u0644\u0628\u0637\u0627\u0642\u0629",
  "Complete payment": "\u0625\u062A\u0645\u0627\u0645 \u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u062F\u0641\u0639",
  "Successful payment": "\u0639\u0645\u0644\u064A\u0629 \u062F\u0641\u0639 \u0646\u0627\u062C\u062D\u0629",
  "Payment is pending": "\u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u062F\u0641\u0639 \u0645\u0639\u0644\u0642\u0629",
  "Payment refused": "\u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u062F\u0641\u0639 \u0645\u0631\u0641\u0648\u0636\u0629",
  Paid: Paid$1,
  "Subscription ended": "\u0627\u0644\u0625\u0634\u062A\u0631\u0627\u0643 \u0645\u0646\u062A\u0647\u064A",
  "Membership card": "\u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0639\u0636\u0648\u064A\u0629",
  "/***************************** Months **********************/": "",
  January: January$1,
  February: February$1,
  March: March$1,
  April: April$1,
  May: May$1,
  June: June$1,
  July: July$1,
  August: August$1,
  September: September$1,
  October: October$1,
  November: November$1,
  December: December$1,
  "/************************* Qualifications *************************/": "",
  "Primary school": "\u0627\u0644\u0625\u0628\u062A\u062F\u0627\u0626\u064A\u0629",
  "Prepatatory school": "\u0627\u0644\u0643\u0641\u0627\u0621\u0629 \u0627\u0644\u0645\u062A\u0648\u0633\u0637\u0629",
  "High school": "\u0627\u0644\u062B\u0627\u0646\u0648\u064A\u0629",
  Diploma: Diploma$1,
  "Bachelor's degree": "\u062F\u0631\u062C\u0629 \u0627\u0644\u0628\u0627\u0643\u0644\u0631\u064A\u0648\u0633",
  "Master's degree": "\u062F\u0631\u062C\u0629 \u0627\u0644\u0645\u0627\u062C\u0633\u062A\u064A\u0631",
  "PHD degree": "\u062F\u0631\u062C\u0629 \u0627\u0644\u062F\u0643\u062A\u0648\u0631\u0627\u0647",
  "/***************** Countries *****************/": "",
  "Saudi Arabia": "\u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629",
  Afghanistan: Afghanistan$1,
  Albania: Albania$1,
  Algeria: Algeria$1,
  Andorra: Andorra$1,
  Angola: Angola$1,
  Antarctica: Antarctica$1,
  Argentina: Argentina$1,
  Armenia: Armenia$1,
  Australia: Australia$1,
  Austria: Austria$1,
  Azerbaijan: Azerbaijan$1,
  Bahamas: Bahamas$1,
  Bahrain: Bahrain$1,
  Bangladesh: Bangladesh$1,
  Belarus: Belarus$1,
  Belgium: Belgium$1,
  Bolivia: Bolivia$1,
  "Bosnia and Herzegovina": "\u0627\u0644\u0628\u0648\u0633\u0646\u0629 \u0648\u0627\u0644\u0647\u0631\u0633\u0643",
  Botswana: Botswana$1,
  Brazil: Brazil$1,
  Bulgaria: Bulgaria$1,
  "Burkina Faso": "\u0628\u0648\u0631\u0643\u064A\u0646\u0627 \u0641\u0627\u0633\u0648",
  Burundi: Burundi$1,
  Cambodia: Cambodia$1,
  Cameroon: Cameroon$1,
  Canada: Canada$1,
  "Central African Republic": "\u0648\u0633\u0637 \u0623\u0641\u0631\u064A\u0642\u064A\u0627",
  Chad: Chad$1,
  Chile: Chile$1,
  China: China$1,
  Colombia: Colombia$1,
  Congo: Congo$1,
  "Costa Rica": "\u0643\u0648\u0633\u062A\u0627\u0631\u064A\u0643\u0627",
  "Cote D'Ivoire": "\u0643\u0648\u062A \u062F\u064A \u0641\u0648\u0627\u0631",
  Croatia: Croatia$1,
  Cuba: Cuba$1,
  Cyprus: Cyprus$1,
  "Czech Republic": "\u062C\u0645\u0647\u0648\u0631\u064A\u0629 \u0627\u0644\u062A\u0634\u064A\u0643",
  Denmark: Denmark$1,
  Djibouti: Djibouti$1,
  "Dominican Republic": "\u062C\u0645\u0647\u0648\u0631\u064A\u0629 \u0627\u0644\u062F\u0648\u0645\u0646\u064A\u0643\u0627\u0646",
  Ecuador: Ecuador$1,
  Egypt: Egypt$1,
  "El Salvador": "\u0627\u0644\u0633\u0644\u0641\u0627\u062F\u0648\u0631",
  Eritrea: Eritrea$1,
  Estonia: Estonia$1,
  Ethiopia: Ethiopia$1,
  Finland: Finland$1,
  France: France$1,
  Gabon: Gabon$1,
  Gambia: Gambia$1,
  Georgia: Georgia$1,
  Germany: Germany$1,
  Ghana: Ghana$1,
  Gibraltar: Gibraltar$1,
  Greece: Greece$1,
  Greenland: Greenland$1,
  Guatemala: Guatemala$1,
  Guinea: Guinea$1,
  Honduras: Honduras$1,
  "Hong Kong": "\u0647\u0648\u0646\u062C \u0643\u0648\u0646\u062C",
  Hungary: Hungary$1,
  Iceland: Iceland$1,
  India: India$1,
  Indonesia: Indonesia$1,
  Iran: Iran$1,
  Iraq: Iraq$1,
  Ireland: Ireland$1,
  Italy: Italy$1,
  Jamaica: Jamaica$1,
  Japan: Japan$1,
  Jersey: Jersey$1,
  Jordan: Jordan$1,
  Kazakhstan: Kazakhstan$1,
  Kenya: Kenya$1,
  Korea: Korea$1,
  Kuwait: Kuwait$1,
  Kyrgyzstan: Kyrgyzstan$1,
  Latvia: Latvia$1,
  Lebanon: Lebanon$1,
  Libya: Libya$1,
  Lithuania: Lithuania$1,
  Luxembourg: Luxembourg$1,
  Macao: Macao$1,
  Macedonia: Macedonia$1,
  Madagascar: Madagascar$1,
  Malawi: Malawi$1,
  Malaysia: Malaysia$1,
  Maldives: Maldives$1,
  Mali: Mali$1,
  Malta: Malta$1,
  Mauritania: Mauritania$1,
  Mexico: Mexico$1,
  Mongolia: Mongolia$1,
  Morocco: Morocco$1,
  Mozambique: Mozambique$1,
  Myanmar: Myanmar$1,
  Namibia: Namibia$1,
  Nepal: Nepal$1,
  Netherlands: Netherlands$1,
  "New Zealand": "\u0646\u064A\u0648\u0632\u064A\u0644\u0627\u0646\u062F",
  Nicaragua: Nicaragua$1,
  Niger: Niger$1,
  Nigeria: Nigeria$1,
  Norway: Norway$1,
  Oman: Oman$1,
  Pakistan: Pakistan$1,
  Palestine: Palestine$1,
  Panama: Panama$1,
  Paraguay: Paraguay$1,
  Peru: Peru$1,
  Philippines: Philippines$1,
  Poland: Poland$1,
  Portugal: Portugal$1,
  Qatar: Qatar$1,
  Romania: Romania$1,
  Russia: Russia$1,
  Rwanda: Rwanda$1,
  Senegal: Senegal$1,
  Serbia: Serbia$1,
  Singapore: Singapore$1,
  Slovakia: Slovakia$1,
  Slovenia: Slovenia$1,
  Somalia: Somalia$1,
  "South Africa": "\u062C\u0646\u0648\u0628 \u0623\u0641\u0631\u064A\u0642\u064A\u0627",
  Spain: Spain$1,
  SriLanka: SriLanka$1,
  Sudan: Sudan$1,
  Sweden: Sweden$1,
  Switzerland: Switzerland$1,
  Syria: Syria$1,
  Taiwan: Taiwan$1,
  Tajikistan: Tajikistan$1,
  Tanzania: Tanzania$1,
  Thailand: Thailand$1,
  Togo: Togo$1,
  Tunisia: Tunisia$1,
  Turkey: Turkey$1,
  Turkmenistan: Turkmenistan$1,
  Uganda: Uganda$1,
  Ukraine: Ukraine$1,
  "United Arab Emirates": "\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0627\u0644\u0645\u062A\u062D\u062F\u0629",
  "United Kingdom": "\u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0645\u062A\u062D\u062F\u0629",
  "United States": "\u0627\u0644\u0648\u0644\u0627\u064A\u0627\u062A \u0627\u0644\u0645\u062A\u062D\u062F\u0629",
  Uruguay: Uruguay$1,
  Uzbekistan: Uzbekistan$1,
  Venezuela: Venezuela$1,
  Vietnam: Vietnam$1,
  "Western Sahara": "\u0627\u0644\u0635\u062D\u0631\u0627\u0621 \u0627\u0644\u063A\u0631\u0628\u064A\u0629",
  Yemen: Yemen$1,
  Zambia: Zambia$1,
  Zimbabwe: Zimbabwe$1,
  "/**************************** Nationalities ****************************/": "",
  Samoa: Samoa$1,
  "North Korea": "\u0643\u0648\u0631\u064A\u0627 \u0627\u0644\u0634\u0645\u0627\u0644\u064A\u0629",
  Benin: Benin$1,
  Aruba: Aruba$1,
  "Saudi Arabian": "\u0633\u0639\u0648\u062F\u064A",
  Afghan: Afghan$1,
  Albanian: Albanian$1,
  Algerian: Algerian$1,
  American: American$1,
  "American Samoan": "\u0633\u0627\u0645\u0648\u064A \u0623\u0645\u0631\u064A\u0643\u064A",
  Angolan: Angolan$1,
  Anguillian: Anguillian$1,
  Antiguan: Antiguan$1,
  Argentine: Argentine$1,
  Armenian: Armenian$1,
  Aruban: Aruban$1,
  Australian: Australian$1,
  Austrian: Austrian$1,
  Azerbaijani: Azerbaijani$1,
  Bahamian: Bahamian$1,
  Bahraini: Bahraini$1,
  Bangladeshi: Bangladeshi$1,
  Barbadian: Barbadian$1,
  Belarusian: Belarusian$1,
  Belgian: Belgian$1,
  Belizean: Belizean$1,
  Beninese: Beninese$1,
  Bermudian: Bermudian$1,
  Bhutanese: Bhutanese$1,
  Bolivian: Bolivian$1,
  Bosnian: Bosnian$1,
  Botswanan: Botswanan$1,
  Brazilian: Brazilian$1,
  British: British$1,
  "British Virgin Islander": "\u062C\u0632\u0631 \u0641\u064A\u0631\u062C\u064A\u0646\u064A\u0627 \u0627\u0644\u0628\u0631\u064A\u0637\u0627\u0646\u064A\u0629",
  Bruneian: Bruneian$1,
  Bulgarian: Bulgarian$1,
  Burkinabe: Burkinabe$1,
  Burundian: Burundian$1,
  Cambodian: Cambodian$1,
  Cameroonian: Cameroonian$1,
  Canadian: Canadian$1,
  "Cape Verdean": "\u0643\u064A\u0628 \u0641\u0631\u062F\u064A\u0646\u064A",
  Caymanian: Caymanian$1,
  "Central African": "\u0648\u0633\u0637 \u0623\u0641\u0631\u064A\u0642\u064A",
  Chadian: Chadian$1,
  Chilean: Chilean$1,
  Chinese: Chinese$1,
  "Christmas Islander": "\u062C\u0632\u0631 \u0627\u0644\u0643\u0631\u064A\u0633\u0645\u0627\u0633",
  Colombian: Colombian$1,
  Comorian: Comorian$1,
  Congolese: Congolese$1,
  "Cook Islander": "\u062C\u0632\u0631 \u0643\u0648\u0643",
  "Costa Rican": "\u0643\u0648\u0633\u062A\u0627 \u0631\u064A\u0643\u0627",
  Croatian: Croatian$1,
  Cuban: Cuban$1,
  Cypriot: Cypriot$1,
  Czech: Czech$1,
  Danes: Danes$1,
  Djiboutian: Djiboutian$1,
  Dominican: Dominican$1,
  Dutch: Dutch$1,
  "Dutch Antillean": "\u0647\u0648\u0644\u0646\u062F\u064A \u0627\u0646\u0637\u064A\u0644\u064A",
  Ecuadorian: Ecuadorian$1,
  Egyptian: Egyptian$1,
  Emirati: Emirati$1,
  "Equatorial Guinean": "\u063A\u064A\u0646\u064A \u0627\u0643\u0648\u0627\u062A\u0648\u0631",
  Eritrean: Eritrean$1,
  Estonian: Estonian$1,
  Ethiopian: Ethiopian$1,
  "Falkland Islander": "\u062C\u0632\u0631 \u0641\u0627\u0644\u0643\u0644\u0627\u062F",
  Faroese: Faroese$1,
  Fijian: Fijian$1,
  Filipino: Filipino$1,
  Finnish: Finnish$1,
  French: French$1,
  "French Guianese": "\u063A\u064A\u0646\u0633\u064A \u0627\u0644\u0641\u0631\u0646\u0633\u064A\u0629",
  "French Polynesian": "\u0628\u0648\u0644\u064A\u0646\u0633\u064A\u0629 \u0627\u0644\u0641\u0631\u0646\u0633\u064A\u0629",
  Futunan: Futunan$1,
  Gabonese: Gabonese$1,
  Gambian: Gambian$1,
  Georgian: Georgian$1,
  German: German$1,
  Ghanaian: Ghanaian$1,
  Gibraltarian: Gibraltarian$1,
  Greek: Greek$1,
  Grenadian: Grenadian$1,
  Guadeloupian: Guadeloupian$1,
  Guamanian: Guamanian$1,
  Guatemalan: Guatemalan$1,
  Guinean: Guinean$1,
  Guyanese: Guyanese$1,
  Haitian: Haitian$1,
  Honduran: Honduran$1,
  Hungarian: Hungarian$1,
  Icelander: Icelander$1,
  Indian: Indian$1,
  Indonesian: Indonesian$1,
  Iranian: Iranian$1,
  Iraqi: Iraqi$1,
  Irish: Irish$1,
  Italian: Italian$1,
  Ivoirian: Ivoirian$1,
  Jamaican: Jamaican$1,
  Japanese: Japanese$1,
  Jordanian: Jordanian$1,
  Kazakhstani: Kazakhstani$1,
  Kenyan: Kenyan$1,
  Kiribati: Kiribati$1,
  Kuwaiti: Kuwaiti$1,
  Kyrgyzstani: Kyrgyzstani$1,
  Latvian: Latvian$1,
  Lebanese: Lebanese$1,
  Liberian: Liberian$1,
  Libyan: Libyan$1,
  Liechtensteiner: Liechtensteiner$1,
  Lithuanian: Lithuanian$1,
  Luxembourger: Luxembourger$1,
  Macedonian: Macedonian$1,
  Malagasy: Malagasy$1,
  Malawian: Malawian$1,
  Malaysian: Malaysian$1,
  Maldivian: Maldivian$1,
  Malian: Malian$1,
  Maltese: Maltese$1,
  Marshallese: Marshallese$1,
  Martiniquai: Martiniquai$1,
  Mauritanian: Mauritanian$1,
  Mauritian: Mauritian$1,
  Mexican: Mexican$1,
  Miquelonnais: Miquelonnais$1,
  Moldovan: Moldovan$1,
  Monacan: Monacan$1,
  Mongolian: Mongolian$1,
  Montenegrin: Montenegrin$1,
  Montserratian: Montserratian$1,
  Moroccan: Moroccan$1,
  Mozambican: Mozambican$1,
  Myanmarian: Myanmarian$1,
  Nauruan: Nauruan$1,
  Nepalese: Nepalese$1,
  "New Caledonian": "\u0646\u064A\u0648 \u0643\u0627\u0644\u064A\u062F\u0648\u0646\u064A",
  "New Zealander": "\u0646\u064A\u0648\u0632\u064A\u0644\u0627\u0646\u062F\u064A",
  "Ni-Vanuatu": "\u0646\u064A \u0641\u0627\u0646\u0648\u0627\u062A\u064A",
  Nicaraguan: Nicaraguan$1,
  Nigerian: Nigerian$1,
  Nigerien: Nigerien$1,
  Niuean: Niuean$1,
  "Norfolk Islander": "\u062C\u0632\u0631 \u0646\u0648\u0631\u0641\u0648\u0644\u0643",
  "North Korean": "\u0643\u0648\u0631\u064A \u0634\u0645\u0627\u0644\u064A",
  "Northern Marianan": "\u0645\u0631\u064A\u0627\u0646\u064A \u0634\u0645\u0627\u0644\u064A",
  Norwegian: Norwegian$1,
  Omani: Omani$1,
  Pakistani: Pakistani$1,
  Palauan: Palauan$1,
  Palestinian: Palestinian$1,
  Panamanian: Panamanian$1,
  Papuans: Papuans$1,
  Paraguayan: Paraguayan$1,
  Peruvian: Peruvian$1,
  Polish: Polish$1,
  Portuguese: Portuguese$1,
  "Puerto Rican": "\u0628\u0648\u0631\u062A\u0648\u0631\u064A\u0643\u0648",
  Qatari: Qatari$1,
  Romanian: Romanian$1,
  Russian: Russian$1,
  Rwandan: Rwandan$1,
  "R\xE9unionese": "\u0625\u062A\u062D\u0627\u062F\u064A",
  "Saint Helenian": "\u0633\u0627\u0646\u062A \u0647\u0627\u0644\u064A\u0646\u0627\u0646",
  "Saint Lucian": "\u0633\u0627\u0646\u062A \u0644\u0648\u0633\u064A\u0627\u0646",
  Salvadoran: Salvadoran$1,
  Samoan: Samoan$1,
  Santomean: Santomean$1,
  Senegalese: Senegalese$1,
  Serbian: Serbian$1,
  Seychellois: Seychellois$1,
  "Sierra Leonean": "\u0633\u064A\u0631\u0627 \u0644\u064A\u0648\u0646\u064A\u0646",
  Singaporean: Singaporean$1,
  Slovak: Slovak$1,
  Slovenian: Slovenian$1,
  "Solomon Islander": "\u062C\u0632\u0631 \u0633\u0644\u0648\u0645\u0648\u0646",
  Somali: Somali$1,
  "South African": "\u062C\u0646\u0648\u0628 \u0627\u0641\u0631\u064A\u0642\u064A\u0627",
  "South Korean": "\u0643\u0648\u0631\u064A\u0627 \u0627\u0644\u062C\u0646\u0648\u0628\u064A",
  Spanish: Spanish$1,
  "Sri Lankan": "\u0633\u0631\u064A\u0644\u0627\u0646\u0643\u064A",
  Sudanese: Sudanese$1,
  Surinamer: Surinamer$1,
  Swazi: Swazi$1,
  Swede: Swede$1,
  Swiss: Swiss$1,
  Syrian: Syrian$1,
  Taiwanese: Taiwanese$1,
  Tajikistani: Tajikistani$1,
  Tanzanian: Tanzanian$1,
  Thai: Thai$1,
  Tobagonian: Tobagonian$1,
  Togolese: Togolese$1,
  Tokelauan: Tokelauan$1,
  Tongan: Tongan$1,
  Tunisian: Tunisian$1,
  Turk: Turk$1,
  Turkmen: Turkmen$1,
  "Turks and Caicos Islander": "\u062C\u0632\u0631 \u062A\u0631\u0643 \u0648\u0643\u0627\u064A\u0643\u0633",
  Tuvaluan: Tuvaluan$1,
  "U.S. Minor Outlying Islander": "\u062C\u0632\u0631 \u0627\u0644\u0648\u0644\u0627\u064A\u0627\u062A \u0627\u0644\u0645\u062A\u062D\u062F\u0629",
  Ugandan: Ugandan$1,
  Ukrainian: Ukrainian$1,
  Uruguayan: Uruguayan$1,
  Uzbek: Uzbek$1,
  Vatican: Vatican$1,
  Venezuelan: Venezuelan$1,
  Vietnamese: Vietnamese$1,
  "Virgin Islander": "\u062C\u0632\u0631 \u0641\u064A\u0631\u062C\u064A\u0646\u064A\u0627",
  Yemeni: Yemeni$1,
  Zambian: Zambian$1,
  Zimbabwean: Zimbabwean$1,
  "/**************************** Branches ****************************/": "",
  Mecca: Mecca$1,
  Medina: Medina$1,
  "Al Ahsaa": "\u0627\u0644\u0623\u062D\u0633\u0627\u0621",
  Jubail: Jubail$1,
  Dammam: Dammam$1,
  Hael: Hael$1,
  "Hafr Al-Baten": "\u062D\u0641\u0631 \u0627\u0644\u0628\u0627\u0637\u0646",
  Riyadh: Riyadh$1,
  "Al-Qusaim": "\u0627\u0644\u0642\u0635\u064A\u0645",
  "Al Bahah": "\u0627\u0644\u0628\u0627\u062D\u0647",
  "Al Jawf": "\u0627\u0644\u062C\u0648\u0641",
  "Northern borders": "\u0627\u0644\u062D\u062F\u0648\u062F \u0627\u0644\u0634\u0645\u0627\u0644\u064A\u0629",
  Aseer: Aseer$1,
  Jazan: Jazan$1,
  Najran: Najran$1,
  Tabuk: Tabuk$1,
  "Al Taeif": "\u0627\u0644\u0637\u0627\u0626\u0641",
  "/**************************** Cities ****************************/": "",
  Buraidah: Buraidah$1,
  "Al Qatif": "\u0627\u0644\u0642\u0637\u064A\u0641",
  "Hafr Albatin": "\u062D\u0641\u0631 \u0627\u0644\u0628\u0627\u0637\u0646",
  Dabaa: Dabaa$1,
  "Al Kharaj": "\u0627\u0644\u062E\u0631\u062C",
  "Yanbu`": "\u064A\u0646\u0628\u0639",
  Khobar: Khobar$1,
  "A'ror": "\u0639\u0631\u0639\u0631",
  Sakaka: Sakaka$1,
  Jizan: Jizan$1,
  "Al Qarrayat": "\u0627\u0644\u0642\u0631\u064A\u0627\u062A",
  "Al Zahran": "\u0627\u0644\u0638\u0647\u0631\u0627\u0646",
  "Al Zelafa": "\u0627\u0644\u0632\u0644\u0641\u0649",
  "Al Rass": "\u0627\u0644\u0631\u0633",
  Besha: Besha$1,
  Sehat: Sehat$1,
  Sharora: Sharora$1,
  Bahra: Bahra$1,
  Afif: Afif$1,
  Sabia: Sabia$1,
  Bariq: Bariq$1,
  "Al Aflaj": "\u0627\u0644\u0623\u0641\u0644\u0627\u062C",
  "Al Bakiria": "\u0627\u0644\u0628\u0643\u064A\u0631\u064A\u0629",
  "Al Moznab": "\u0627\u0644\u0645\u0630\u0646\u0628",
  "Al Bada'e": "\u0627\u0644\u0628\u062F\u0627\u0626\u0639",
  "Riyadh Al Khabraa": "\u0631\u064A\u0627\u0636 \u0627\u0644\u062E\u0628\u0631\u0627\u0621",
  Abha: Abha$1,
  "Khamees Masheet": "\u062E\u0645\u064A\u0633 \u0645\u0634\u064A\u0637",
  "Mahayel Aseer": "\u0645\u062D\u0627\u064A\u0644 \u0639\u0633\u064A\u0631",
  "Al A'laya": "\u0627\u0644\u0639\u0644\u0627\u064A\u0629",
  Aneeza: Aneeza$1,
  "Al Namaas": "\u0627\u0644\u0646\u0645\u0627\u0635",
  Jeddah: Jeddah$1
};
const Loading = "Loading";
const login = "Login";
const logout = "Logout";
const Subscribers = "Subscribers";
const Members = "Members";
const Volunteers = "Volunteers";
const Close = "Close";
const Details = "Read more \u2192";
const Code = "Code";
const Validate = "Validate";
const about_authority = "About authority";
const about_authority_description = "The Saudi Journalists Association for Professional Performance in the Kingdom of Saudi Arabia was established according to Article No. 27 of the Press Institutions Law by Royal Decree No. (M / 20) on 05/08/1422 AH, and its regulations were approved at the first meeting of the Association, which was held on the date corresponding to 4/19 / 1425 AH corresponding to 7/7/2004 Minister of Culture and Information, these regulations are in accordance with Resolution No. (M / F / 383) dated 11/8/1425 AH. The establishment of the foundation stems from a real desire to serve membership in the Kingdom of Saudi Arabia.";
const More = "More";
const Studio = "Studio";
const All = "All";
const photo = "photo";
const Photos = "Photos";
const Videos = "Videos";
const Events = "Events";
const Notifications = "Notifications";
const membership_desc = "Everyone who practices journalistic work has the right to apply for membership in the commission";
const membership_btn = "Apply for a membership";
const membership_conditions = "Conditions for applying for membership";
const fulltime_member = "Full-time member";
const fulltime_member_desc1 = "Every Saudi journalist is dedicated to the profession of journalism";
const fulltime_member_desc2 = "Every accredited and full-time journalist to work as a reporter or office manager according to a written agreement for any of the local and non-local media outlets in exchange for a fixed salary and he does not practice any other profession";
const fulltime_member_desc3 = "That the media in which he works shall fulfill all the conditions for a journalistic profession and the arts of journalistic editing, chiefly news.";
const parttime_member = "Part-time member";
const parttime_member_desc1 = "Every Saudi journalist partially practices journalistic work";
const parttime_member_desc2 = "It includes Saudi journalists who occupy governmental or non-governmental jobs and who work alongside their perpetrators";
const affiliate_member = "Affiliate member";
const affiliate_member_desc1 = "Every non-Saudi journalist residing in the Kingdom and working in the journalistic field under a work contract.";
const Statistics = "Statistics";
const Home = "Home";
const Posts = "Posts";
const TermsAgreement = "I agree to all terms";
const Registered = "Registered";
const Attend = "Attend";
const Attended = "Attended";
const to = "to";
const Free = "Free";
const Prev = "Prev";
const Next = "Next";
const Status = "Status";
const Description = "Description";
const Create = "Create";
const Solved = "Solved";
const Open = "Open";
const Send = "Send";
const Resend = "Resend";
const Message = "Message";
const fname = "First name";
const sname = "Second name";
const tname = "Third name";
const lname = "Last name";
const Gender = "Gender";
const Male = "Male";
const Female = "Female";
const Country = "Country";
const City = "City";
const Nationality = "Nationality";
const Qualification = "Qualification";
const Governorate = "Governorate";
const Address = "Address";
const Photography = "Photography";
const Videography = "Videography";
const Cinematography = "Cinematography";
const Coverings = "Coverings";
const Presentation = "Presentation";
const Montage = "Montage";
const Branch = "Branch";
const Email = "Email";
const Mobile = "Mobile";
const Password = "Password";
const TermsAcceptance = "I accept that all data is correct, and if otherwise, the subscription will be suspended";
const acceptance = "Acceptance";
const Register = "Register";
const Login = "Login";
const Twitter = "Twitter";
const Youtube = "Youtube";
const Profile = "Profile";
const Save = "Save";
const Review = "Review";
const Registration = "Registration";
const member_rule1 = "Not less than 20 years oldtration";
const member_rule2 = "To practice his journalistic activity in an actual and continuous practice, and to have spent in the profession full-time for a period of no less than one year";
const member_rule3 = "To be active in one of the local media institutions or accredited as a reporter for the foreign media or work as a journalist for them";
const member_rule4 = "To practice any of the journalistic activities detailed in Article (40) of the Regulations, in accordance with the controls set by the General Assembly.";
const member_rule5 = "He should not have been convicted of a crime involving moral turpitude or dishonesty.";
const member_rule6 = "To submit the necessary supporting documents required by the Authority.";
const Verify = "Verify";
const Amount = "Amount";
const Riyal = "Riyal";
const Annual = "Annual";
const Delivery = "Delivery";
const Hijri = "Hijri";
const Milady = "Milady";
const Major = "Major";
const Journalist = "Journalist";
const Employer = "Employer";
const Fax = "Fax";
const Ext = "Ext";
const membership_agreement = "I acknowledge that I am aware of all the terms and conditions, and I pledge that all the data provided is correct personal data and I bear all responsibility towards that";
const Submit = "Submit";
const Info = "Info";
const Experiences = "Experiences";
const Add = "Add";
const Fields = "Fields";
const Languages = "Languages";
const Language = "Language";
const Level = "Level";
const Fair = "Fair";
const Good = "Good";
const Excellent = "Excellent";
const Requirement = "Requirement";
const Upload = "Upload";
const Membership = "Membership";
const Refused = "Refused";
const Pay = "Pay";
const payment_condition1 = "The payment is not refundable";
const payment_condition2 = "The Authority has the right to cancel your subscription";
const payment_condition3 = "The subscription period is until the end of the calendar year";
const Paid = "Paid";
const January = "January";
const February = "February";
const March = "March";
const April = "April";
const May = "May";
const June = "June";
const July = "July";
const August = "August";
const September = "September";
const October = "October";
const November = "November";
const December = "December";
const Diploma = "Diploma";
const Samoa = "Samoa";
const Benin = "Benin";
const Aruba = "Aruba";
const Afghanistan = "Afghanistan";
const Albania = "Albania";
const Algeria = "Algeria";
const Andorra = "Andorra";
const Angola = "Angola";
const Antarctica = "Antarctica";
const Argentina = "Argentina";
const Armenia = "Armenia";
const Australia = "Australia";
const Austria = "Austria";
const Azerbaijan = "Azerbaijan";
const Bahamas = "Bahamas";
const Bahrain = "Bahrain";
const Bangladesh = "Bangladesh";
const Belarus = "Belarus";
const Belgium = "Belgium";
const Bolivia = "Bolivia";
const Botswana = "Botswana";
const Brazil = "Brazil";
const Bulgaria = "Bulgaria";
const Burundi = "Burundi";
const Cambodia = "Cambodia";
const Cameroon = "Cameroon";
const Canada = "Canada";
const Chad = "Chad";
const Chile = "Chile";
const China = "China";
const Colombia = "Colombia";
const Congo = "Congo";
const Croatia = "Croatia";
const Cuba = "Cuba";
const Cyprus = "Cyprus";
const Denmark = "Denmark";
const Djibouti = "Djibouti";
const Ecuador = "Ecuador";
const Egypt = "Egypt";
const Eritrea = "Eritrea";
const Estonia = "Estonia";
const Ethiopia = "Ethiopia";
const Finland = "Finland";
const France = "France";
const Gabon = "Gabon";
const Gambia = "Gambia";
const Georgia = "Georgia";
const Germany = "Germany";
const Ghana = "Ghana";
const Gibraltar = "Gibraltar";
const Greece = "Greece";
const Greenland = "Greenland";
const Guatemala = "Guatemala";
const Guinea = "Guinea";
const Honduras = "Honduras";
const Hungary = "Hungary";
const Iceland = "Iceland";
const India = "India";
const Indonesia = "Indonesia";
const Iran = "Iran";
const Iraq = "Iraq";
const Ireland = "Ireland";
const Italy = "Italy";
const Jamaica = "Jamaica";
const Japan = "Japan";
const Jersey = "Jersey";
const Jordan = "Jordan";
const Kazakhstan = "Kazakhstan";
const Kenya = "Kenya";
const Korea = "Korea";
const Kuwait = "Kuwait";
const Kyrgyzstan = "Kyrgyzstan";
const Latvia = "Latvia";
const Lebanon = "Lebanon";
const Libya = "Libya";
const Lithuania = "Lithuania";
const Luxembourg = "Luxembourg";
const Macao = "Macao";
const Macedonia = "Macedonia";
const Madagascar = "Madagascar";
const Malawi = "Malawi";
const Malaysia = "Malaysia";
const Maldives = "Maldives";
const Mali = "Mali";
const Malta = "Malta";
const Mauritania = "Mauritania";
const Mexico = "Mexico";
const Mongolia = "Mongolia";
const Morocco = "Morocco";
const Mozambique = "Mozambique";
const Myanmar = "Myanmar";
const Namibia = "Namibia";
const Nepal = "Nepal";
const Netherlands = "Netherlands";
const Nicaragua = "Nicaragua";
const Niger = "Niger";
const Nigeria = "Nigeria";
const Norway = "Norway";
const Oman = "Oman";
const Pakistan = "Pakistan";
const Palestine = "Palestine";
const Panama = "Panama";
const Paraguay = "Paraguay";
const Peru = "Peru";
const Philippines = "Philippines";
const Poland = "Poland";
const Portugal = "Portugal";
const Qatar = "Qatar";
const Romania = "Romania";
const Russia = "Russia";
const Rwanda = "Rwanda";
const Senegal = "Senegal";
const Serbia = "Serbia";
const Singapore = "Singapore";
const Slovakia = "Slovakia";
const Slovenia = "Slovenia";
const Somalia = "Somalia";
const Spain = "Spain";
const SriLanka = "SriLanka";
const Sudan = "Sudan";
const Sweden = "Sweden";
const Switzerland = "Switzerland";
const Syria = "Syria";
const Taiwan = "Taiwan";
const Tajikistan = "Tajikistan";
const Tanzania = "Tanzania";
const Thailand = "Thailand";
const Togo = "Togo";
const Tunisia = "Tunisia";
const Turkey = "Turkey";
const Turkmenistan = "Turkmenistan";
const Uganda = "Uganda";
const Ukraine = "Ukraine";
const Uruguay = "Uruguay";
const Uzbekistan = "Uzbekistan";
const Venezuela = "Venezuela";
const Vietnam = "Vietnam";
const Yemen = "Yemen";
const Zambia = "Zambia";
const Zimbabwe = "Zimbabwe";
const Afghan = "Afghan";
const Albanian = "Albanian";
const Algerian = "Algerian";
const American = "American";
const Angolan = "Angolan";
const Anguillian = "Anguillian";
const Antiguan = "Antiguan";
const Argentine = "Argentine";
const Armenian = "Armenian";
const Aruban = "Aruban";
const Australian = "Australian";
const Austrian = "Austrian";
const Azerbaijani = "Azerbaijani";
const Bahamian = "Bahamian";
const Bahraini = "Bahraini";
const Bangladeshi = "Bangladeshi";
const Barbadian = "Barbadian";
const Belarusian = "Belarusian";
const Belgian = "Belgian";
const Belizean = "Belizean";
const Beninese = "Beninese";
const Bermudian = "Bermudian";
const Bhutanese = "Bhutanese";
const Bolivian = "Bolivian";
const Bosnian = "Bosnian";
const Botswanan = "Botswanan";
const Brazilian = "Brazilian";
const British = "British";
const Bruneian = "Bruneian";
const Bulgarian = "Bulgarian";
const Burkinabe = "Burkinabe";
const Burundian = "Burundian";
const Cambodian = "Cambodian";
const Cameroonian = "Cameroonian";
const Canadian = "Canadian";
const Caymanian = "Caymanian";
const Chadian = "Chadian";
const Chilean = "Chilean";
const Chinese = "Chinese";
const Colombian = "Colombian";
const Comorian = "Comorian";
const Congolese = "Congolese";
const Croatian = "Croatian";
const Cuban = "Cuban";
const Cypriot = "Cypriot";
const Czech = "Czech";
const Danes = "Danes";
const Djiboutian = "Djiboutian";
const Dominican = "Dominican";
const Dutch = "Dutch";
const Ecuadorian = "Ecuadorian";
const Egyptian = "Egyptian";
const Emirati = "Emirati";
const Eritrean = "Eritrean";
const Estonian = "Estonian";
const Ethiopian = "Ethiopian";
const Faroese = "Faroese";
const Fijian = "Fijian";
const Filipino = "Filipino";
const Finnish = "Finnish";
const French = "French";
const Futunan = "Futunan";
const Gabonese = "Gabonese";
const Gambian = "Gambian";
const Georgian = "Georgian";
const German = "German";
const Ghanaian = "Ghanaian";
const Gibraltarian = "Gibraltarian";
const Greek = "Greek";
const Grenadian = "Grenadian";
const Guadeloupian = "Guadeloupian";
const Guamanian = "Guamanian";
const Guatemalan = "Guatemalan";
const Guinean = "Guinean";
const Guyanese = "Guyanese";
const Haitian = "Haitian";
const Honduran = "Honduran";
const Hungarian = "Hungarian";
const Icelander = "Icelander";
const Indian = "Indian";
const Indonesian = "Indonesian";
const Iranian = "Iranian";
const Iraqi = "Iraqi";
const Irish = "Irish";
const Italian = "Italian";
const Ivoirian = "Ivoirian";
const Jamaican = "Jamaican";
const Japanese = "Japanese";
const Jordanian = "Jordanian";
const Kazakhstani = "Kazakhstani";
const Kenyan = "Kenyan";
const Kiribati = "Kiribati";
const Kuwaiti = "Kuwaiti";
const Kyrgyzstani = "Kyrgyzstani";
const Latvian = "Latvian";
const Lebanese = "Lebanese";
const Liberian = "Liberian";
const Libyan = "Libyan";
const Liechtensteiner = "Liechtensteiner";
const Lithuanian = "Lithuanian";
const Luxembourger = "Luxembourger";
const Macedonian = "Macedonian";
const Malagasy = "Malagasy";
const Malawian = "Malawian";
const Malaysian = "Malaysian";
const Maldivian = "Maldivian";
const Malian = "Malian";
const Maltese = "Maltese";
const Marshallese = "Marshallese";
const Martiniquai = "Martiniquai";
const Mauritanian = "Mauritanian";
const Mauritian = "Mauritian";
const Mexican = "Mexican";
const Miquelonnais = "Miquelonnais";
const Moldovan = "Moldovan";
const Monacan = "Monacan";
const Mongolian = "Mongolian";
const Montenegrin = "Montenegrin";
const Montserratian = "Montserratian";
const Moroccan = "Moroccan";
const Mozambican = "Mozambican";
const Myanmarian = "Myanmarian";
const Nauruan = "Nauruan";
const Nepalese = "Nepalese";
const Nicaraguan = "Nicaraguan";
const Nigerian = "Nigerian";
const Nigerien = "Nigerien";
const Niuean = "Niuean";
const Norwegian = "Norwegian";
const Omani = "Omani";
const Pakistani = "Pakistani";
const Palauan = "Palauan";
const Palestinian = "Palestinian";
const Panamanian = "Panamanian";
const Papuans = "Papuans";
const Paraguayan = "Paraguayan";
const Peruvian = "Peruvian";
const Polish = "Polish";
const Portuguese = "Portuguese";
const Qatari = "Qatari";
const Romanian = "Romanian";
const Russian = "Russian";
const Rwandan = "Rwandan";
const Salvadoran = "Salvadoran";
const Samoan = "Samoan";
const Santomean = "Santomean";
const Senegalese = "Senegalese";
const Serbian = "Serbian";
const Seychellois = "Seychellois";
const Singaporean = "Singaporean";
const Slovak = "Slovak";
const Slovenian = "Slovenian";
const Somali = "Somali";
const Spanish = "Spanish";
const Sudanese = "Sudanese";
const Surinamer = "Surinamer";
const Swazi = "Swazi";
const Swede = "Swede";
const Swiss = "Swiss";
const Syrian = "Syrian";
const Taiwanese = "Taiwanese";
const Tajikistani = "Tajikistani";
const Tanzanian = "Tanzanian";
const Thai = "Thai";
const Tobagonian = "Tobagonian";
const Togolese = "Togolese";
const Tokelauan = "Tokelauan";
const Tongan = "Tongan";
const Tunisian = "Tunisian";
const Turk = "Turk";
const Turkmen = "Turkmen";
const Tuvaluan = "Tuvaluan";
const Ugandan = "Ugandan";
const Ukrainian = "Ukrainian";
const Uruguayan = "Uruguayan";
const Uzbek = "Uzbek";
const Vatican = "Vatican";
const Venezuelan = "Venezuelan";
const Vietnamese = "Vietnamese";
const Yemeni = "Yemeni";
const Zambian = "Zambian";
const Zimbabwean = "Zimbabwean";
const Mecca = "Mecca";
const Medina = "Medina";
const Jubail = "Jubail";
const Dammam = "Dammam";
const Hael = "Hael";
const Riyadh = "Riyadh";
const Aseer = "Aseer";
const Jazan = "Jazan";
const Najran = "Najran";
const Tabuk = "Tabuk";
const Buraidah = "Buraidah";
const Dabaa = "Dabaa";
const Khobar = "Khobar";
const Sakaka = "Sakaka";
const Jizan = "Jizan";
const Besha = "Besha";
const Sehat = "Sehat";
const Sharora = "Sharora";
const Bahra = "Bahra";
const Afif = "Afif";
const Sabia = "Sabia";
const Bariq = "Bariq";
const Abha = "Abha";
const Aneeza = "Aneeza";
const Jeddah = "Jeddah";
const en = {
  "Saudi journalists association": "Saudi journalists association",
  Loading,
  "Error": "Error",
  "Sorry, we couldn't find this page.": "Sorry, we couldn't find this page.",
  "But dont worry, you can find plenty of other things on our homepage.": "But dont worry, you can find plenty of other things on our homepage.",
  "Back to homepage": "Back to homepage",
  login,
  logout,
  "Login to sju": "Login to sju",
  "Close modal": "Close modal",
  Subscribers,
  Members,
  Volunteers,
  Close,
  Details,
  "/*============================= Certificate validation": "=============================*/",
  "Validate certificate": "Validate certificate",
  "Please enter the code written on the certificate": "Please enter the code written on the certificate",
  Code,
  Validate,
  "/*================================== HOME PAGE TRANSLATIONS": "==================================*/",
  about_authority,
  about_authority_description,
  "Read more": "Read more",
  More,
  "Media center": "Media center",
  Studio,
  All,
  photo,
  Photos,
  Videos,
  "Regulations and events": "Regulations and events",
  Events,
  Notifications,
  "Request type": "Request type",
  "Request date": "Request date",
  "The basic bylaw of the Saudi Journalists Association": "The basic bylaw of the Saudi Journalists Association",
  "1.5 Miga bytes": "1.5 Miga bytes",
  "Authority membership": "Authority membership",
  membership_desc,
  membership_btn,
  membership_conditions,
  fulltime_member,
  fulltime_member_desc1,
  fulltime_member_desc2,
  fulltime_member_desc3,
  parttime_member,
  parttime_member_desc1,
  parttime_member_desc2,
  affiliate_member,
  affiliate_member_desc1,
  Statistics,
  "Of members": "Members",
  "Of events": "Events",
  "Of memberships": "Memberships",
  "Of workshops": "Workshops",
  "Follow us": "Follow us",
  "Follow us on social media": "Follow us on social media",
  "Contact us": "Contact us",
  "/***************** Footer ***************/": "",
  "Important Links": "Important Links",
  "Ministry of Information": "Ministry of Information",
  "Audiovisual organization": "Audiovisual organization",
  "Saudi press agency": "Saudi press agency",
  "Radio & TV organization": "Radio & TV organization",
  "Our location": "Our location",
  "Terms of service": "Terms of service",
  "Privacy policy": "Privacy policy",
  "Call us": "Call us",
  "All rights reserved to Saudi Journalists Association": "All rights reserved to Saudi Journalists Association",
  "Made with \u2764 by:": "Made with \u2764 by:",
  "/***************************** Posts **********************/": "",
  "Posts list": "Posts list",
  Home,
  Posts,
  "Related posts": "Related posts",
  "No posts found": "No posts found",
  "/***************************** Events **********************/": "",
  "No events found": "No events found",
  "Additional info": "Additional info",
  "User info": "User info",
  "User name": "User name",
  "Upcoming events": "Upcoming events",
  "Events list": "Events list",
  "Events done": "Events done",
  "Event name": "Event name",
  "Event date": "Event date",
  "Event time": "Event time",
  "Event type": "Event type",
  "Event category": "Event category",
  "Event gender": "Event gender",
  "Event location": "Event location",
  "No data found to show": "No data found",
  TermsAgreement,
  "Already registered in event": "Already registered in event",
  "Already attended in event": "Already attended in event",
  Registered,
  Attend,
  Attended,
  "Not registered in event": "Not registered in event",
  to,
  Free,
  "All paid": "All paid",
  "Paid certificate": "Paid certificate",
  "You didn't attend the event": "You didn't attend the event",
  "Fill the survey first": "Fill the survey first",
  Prev,
  Next,
  "Back to events": "Back to events",
  "Please enter a valid phone number. eg: 501234567": "Please enter a valid phone number. eg: 501234567",
  "/************************* Technical support ******************/": "",
  "Ticket title": "Ticket title",
  "Creation date": "Creation date",
  "Modification date": "Modification date",
  "Last update date": "Last update date",
  Status,
  "New ticket": "New ticket",
  Description,
  "Attach image": "Attach image",
  Create,
  Solved,
  Open,
  Send,
  Resend,
  Message,
  "/*************************** Volunteers ********************/": "",
  "Register new volunteer": "Register new volunteer",
  fname,
  sname,
  tname,
  lname,
  "In Arabic": "In Arabic",
  "In English": "In English",
  Gender,
  Male,
  Female,
  Country,
  City,
  Nationality,
  Qualification,
  "National ID": "National ID",
  "Martial status": "Martial status",
  "Adminstrative area": "Adminstrative area",
  Governorate,
  "National address": "National address",
  "Job title": "Job title",
  Address,
  "Volunteering fields": "Volunteering fields",
  Photography,
  Videography,
  Cinematography,
  "Editing - Media Platforms - Documentation": "Editing - Media Platforms - Documentation",
  Coverings,
  Presentation,
  "Digital content industry": "Digital content industry",
  Montage,
  "Social media": "Social media",
  "Media marketing": "Media marketing",
  "Editorial management": "Editorial management",
  "Field Editorial Leadership": "Field Editorial Leadership",
  "Management of meetings and seminars": "Management of meetings and seminars",
  "Media training": "Media training",
  "Educational level": "Educational level",
  "Volunteering experiences": "Volunteering experiences",
  Branch,
  "How do you know the authority?": "How do you know the authority?",
  Email,
  Mobile,
  Password,
  "Password confirmation": "Password confirmation",
  TermsAcceptance,
  acceptance,
  Register,
  Login,
  "From a friend": "From a friend",
  Twitter,
  Youtube,
  "You can register as a new volunteer from this link": "You can register as a new volunteer from this link",
  "Click here to register": "Click here to register",
  "Login volunteers": "Login volunteers",
  Profile,
  "Technical support": "Technical support",
  "Edit profile": "Edit profile",
  "Enrolled events": "Enrolled events",
  Save,
  "Change password": "Change password",
  "Current password": "Current password",
  "New password": "New password",
  "Please verify your email": "Please verify your email.",
  "Email has been verified successfully": "Email has been verified successfully.",
  "Resend verification": "Resend verification",
  "Forgot password": "Forgot password",
  "Reset password": "Reset password",
  "/*************************** Subscribers ********************/": "",
  "Login subscribers": "Login subscribers",
  "Register new subscriber": "Register new subscriber",
  "You can register as a new subscriber from this link": "You can register as a new subscriber from this link",
  "/*************************** Members ********************/": "",
  "Login members": "Login members",
  "Register new member": "Register new member",
  "You can register as a new member from this link": "You can register as a new member from this link",
  "Terms and policies": "Terms and policies",
  "Contact info": "Contact info",
  "Membership types": "Membership types",
  "Membership type": "Membership type",
  "Member info": "Member info",
  "Login info": "Login info",
  Review,
  Registration,
  member_rule1,
  member_rule2,
  member_rule3,
  member_rule4,
  member_rule5,
  member_rule6,
  "ID or residence number": "ID or residence number",
  Verify,
  "Send verification code": "Send verification code",
  "Choose the type that fits you": "Choose the type that fits you",
  Amount,
  Riyal,
  Annual,
  "Membership branch": "Membership branch",
  "Delivery method": "Delivery method",
  "Receipt from the branch": "Receipt from the branch",
  Delivery,
  "If you choose delivery, 30 riyals will be added to the invoice value.": "If you choose delivery, 30 riyals will be added to the invoice value.",
  "Delivery Address": "Delivery Address",
  "ID source": "ID source",
  Hijri,
  "ID date": "ID date",
  "Birth date": "Birthday",
  Milady,
  Major,
  Journalist,
  "Non-Journalist": "Non-Journalist",
  Employer,
  "Newspaper type": "Newspaper type",
  "Printed newspaper": "Printed newspaper",
  "E-newspaper": "E-newspaper",
  "Work phone": "Work phone",
  Fax,
  Ext,
  "Post box": "Post box",
  "Post code": "Post code",
  membership_agreement,
  "Error in one or more fields": "Error in one or more fields",
  "Error in registration": "Error in registration",
  "You have to choose member type": "You have to choose member type",
  "Please verify your mobile": "Please verify your mobile",
  "Verification code": "Verification code",
  "Resend verification code": "Resend verification code",
  Submit,
  "Mobile provided is not correct": "Mobile provided is not correct",
  "Mobile verification": "Mobile verification",
  Info,
  "Exp. & fields": "Exp. & fields",
  "ID image": "ID image",
  "Job letter": "Job statement",
  "Job contract": "Job contract",
  "Newspaper license": "Newspaper license",
  Experiences,
  Add,
  "Fields you want to contribute to": "Fields you want to contribute to",
  Fields,
  "Languages you good at": "Languages you good at",
  Languages,
  Language,
  Level,
  Fair,
  Good,
  "Very good": "Very good",
  Excellent,
  "Change profile picture": "Change profile picture",
  "Image must have a good quality": "Image must have a good quality",
  "Only .Jpg, .Gif, .Png images are accepted": "Only .Jpg, .Gif, .Png images are accepted",
  "Image size must not exceed 2 MB": "Image size must not exceed 2 MB",
  "A statement from the employer with the title of the current journalistic job": "A statement from the employer with the title of the current journalistic job",
  "Complete profile info": "Complete profile info",
  "To apply for membership, you must complete the required information": "To apply for membership, you must complete the required information",
  "Completion percentage": "Completion percentage",
  Requirement,
  Upload,
  Membership,
  "Subscription start": "Subscription start",
  "Subscription end": "Subscription end",
  "Request membership": "Request membership",
  "Waiting branch approval": "Waiting branch approval",
  "Waiting admin approval": "Waiting admin approval",
  "Waiting to pay": "Waiting to pay",
  Refused,
  "Unsatisfied conditions": "Unsatisfied conditions",
  "Error occured. Refresh the page and if problem resists contact us!": "Error occured. Refresh the page and if problem resists contact us!",
  Pay,
  "Complete payment process": "Complete payment process",
  "Subscribing to membership": "Subscribing to membership",
  "Card type": "Card type",
  payment_condition1,
  payment_condition2,
  payment_condition3,
  "Payment details": "Payment details",
  "for membership": "for membership",
  "card delivery fees": "card delivery fees",
  "Complete payment": "Complete payment",
  "Successful payment": "Successful payment",
  "Payment is pending": "Payment is pending",
  "Payment refused": "Payment refused",
  Paid,
  "Subscription ended": "Subscription ended",
  "Membership card": "Membership card",
  "/***************************** Months **********************/": "",
  January,
  February,
  March,
  April,
  May,
  June,
  July,
  August,
  September,
  October,
  November,
  December,
  "/************************* Qualifications *************************/": "",
  "Primary school": "Primary school",
  "Prepatatory school": "Prepatatory school",
  "High school": "High school",
  Diploma,
  "Bachelor's degree": "Bachelor's degree",
  "Master's degree": "Master's degree",
  "PHD degree": "PHD degree",
  "/**************************** Countries ****************************/": "",
  Samoa,
  "North Korea": "North Korea",
  Benin,
  Aruba,
  "Saudi Arabia": "Saudi Arabia",
  Afghanistan,
  Albania,
  Algeria,
  Andorra,
  Angola,
  Antarctica,
  Argentina,
  Armenia,
  Australia,
  Austria,
  Azerbaijan,
  Bahamas,
  Bahrain,
  Bangladesh,
  Belarus,
  Belgium,
  Bolivia,
  "Bosnia and Herzegovina": "Bosnia and Herzegovina",
  Botswana,
  Brazil,
  Bulgaria,
  "Burkina Faso": "Burkina Faso",
  Burundi,
  Cambodia,
  Cameroon,
  Canada,
  "Central African Republic": "Central African Republic",
  Chad,
  Chile,
  China,
  Colombia,
  Congo,
  "Costa Rica": "Costa Rica",
  "Cote D'Ivoire": "Cote D'Ivoire",
  Croatia,
  Cuba,
  Cyprus,
  "Czech Republic": "Czech Republic",
  Denmark,
  Djibouti,
  "Dominican Republic": "Dominican Republic",
  Ecuador,
  Egypt,
  "El Salvador": "El Salvador",
  Eritrea,
  Estonia,
  Ethiopia,
  Finland,
  France,
  Gabon,
  Gambia,
  Georgia,
  Germany,
  Ghana,
  Gibraltar,
  Greece,
  Greenland,
  Guatemala,
  Guinea,
  Honduras,
  "Hong Kong": "Hong Kong",
  Hungary,
  Iceland,
  India,
  Indonesia,
  Iran,
  Iraq,
  Ireland,
  Italy,
  Jamaica,
  Japan,
  Jersey,
  Jordan,
  Kazakhstan,
  Kenya,
  Korea,
  Kuwait,
  Kyrgyzstan,
  Latvia,
  Lebanon,
  Libya,
  Lithuania,
  Luxembourg,
  Macao,
  Macedonia,
  Madagascar,
  Malawi,
  Malaysia,
  Maldives,
  Mali,
  Malta,
  Mauritania,
  Mexico,
  Mongolia,
  Morocco,
  Mozambique,
  Myanmar,
  Namibia,
  Nepal,
  Netherlands,
  "New Zealand": "New Zealand",
  Nicaragua,
  Niger,
  Nigeria,
  Norway,
  Oman,
  Pakistan,
  Palestine,
  Panama,
  Paraguay,
  Peru,
  Philippines,
  Poland,
  Portugal,
  Qatar,
  Romania,
  Russia,
  Rwanda,
  Senegal,
  Serbia,
  Singapore,
  Slovakia,
  Slovenia,
  Somalia,
  "South Africa": "South Africa",
  Spain,
  SriLanka,
  Sudan,
  Sweden,
  Switzerland,
  Syria,
  Taiwan,
  Tajikistan,
  Tanzania,
  Thailand,
  Togo,
  Tunisia,
  Turkey,
  Turkmenistan,
  Uganda,
  Ukraine,
  "United Arab Emirates": "United Arab Emirates",
  "United Kingdom": "United Kingdom",
  "United States": "United States",
  Uruguay,
  Uzbekistan,
  Venezuela,
  Vietnam,
  "Western Sahara": "Western Sahara",
  Yemen,
  Zambia,
  Zimbabwe,
  "/**************************** Nationalities ****************************/": "",
  "Saudi Arabian": "Saudi Arabian",
  Afghan,
  Albanian,
  Algerian,
  American,
  "American Samoan": "American Samoan",
  Angolan,
  Anguillian,
  Antiguan,
  Argentine,
  Armenian,
  Aruban,
  Australian,
  Austrian,
  Azerbaijani,
  Bahamian,
  Bahraini,
  Bangladeshi,
  Barbadian,
  Belarusian,
  Belgian,
  Belizean,
  Beninese,
  Bermudian,
  Bhutanese,
  Bolivian,
  Bosnian,
  Botswanan,
  Brazilian,
  British,
  "British Virgin Islander": "British Virgin Islander",
  Bruneian,
  Bulgarian,
  Burkinabe,
  Burundian,
  Cambodian,
  Cameroonian,
  Canadian,
  "Cape Verdean": "Cape Verdean",
  Caymanian,
  "Central African": "Central African",
  Chadian,
  Chilean,
  Chinese,
  "Christmas Islander": "Christmas Islander",
  Colombian,
  Comorian,
  Congolese,
  "Cook Islander": "Cook Islander",
  "Costa Rican": "Costa Rican",
  Croatian,
  Cuban,
  Cypriot,
  Czech,
  Danes,
  Djiboutian,
  Dominican,
  Dutch,
  "Dutch Antillean": "Dutch Antillean",
  Ecuadorian,
  Egyptian,
  Emirati,
  "Equatorial Guinean": "Equatorial Guinean",
  Eritrean,
  Estonian,
  Ethiopian,
  "Falkland Islander": "Falkland Islander",
  Faroese,
  Fijian,
  Filipino,
  Finnish,
  French,
  "French Guianese": "French Guianese",
  "French Polynesian": "French Polynesian",
  Futunan,
  Gabonese,
  Gambian,
  Georgian,
  German,
  Ghanaian,
  Gibraltarian,
  Greek,
  Grenadian,
  Guadeloupian,
  Guamanian,
  Guatemalan,
  Guinean,
  Guyanese,
  Haitian,
  Honduran,
  Hungarian,
  Icelander,
  Indian,
  Indonesian,
  Iranian,
  Iraqi,
  Irish,
  Italian,
  Ivoirian,
  Jamaican,
  Japanese,
  Jordanian,
  Kazakhstani,
  Kenyan,
  Kiribati,
  Kuwaiti,
  Kyrgyzstani,
  Latvian,
  Lebanese,
  Liberian,
  Libyan,
  Liechtensteiner,
  Lithuanian,
  Luxembourger,
  Macedonian,
  Malagasy,
  Malawian,
  Malaysian,
  Maldivian,
  Malian,
  Maltese,
  Marshallese,
  Martiniquai,
  Mauritanian,
  Mauritian,
  Mexican,
  Miquelonnais,
  Moldovan,
  Monacan,
  Mongolian,
  Montenegrin,
  Montserratian,
  Moroccan,
  Mozambican,
  Myanmarian,
  Nauruan,
  Nepalese,
  "New Caledonian": "New Caledonian",
  "New Zealander": "New Zealander",
  "Ni-Vanuatu": "Ni-Vanuatu",
  Nicaraguan,
  Nigerian,
  Nigerien,
  Niuean,
  "Norfolk Islander": "Norfolk Islander",
  "North Korean": "North Korean",
  "Northern Marianan": "Northern Marianan",
  Norwegian,
  Omani,
  Pakistani,
  Palauan,
  Palestinian,
  Panamanian,
  Papuans,
  Paraguayan,
  Peruvian,
  Polish,
  Portuguese,
  "Puerto Rican": "Puerto Rican",
  Qatari,
  Romanian,
  Russian,
  Rwandan,
  "R\xE9unionese": "R\xE9unionese",
  "Saint Helenian": "Saint Helenian",
  "Saint Lucian": "Saint Lucian",
  Salvadoran,
  Samoan,
  Santomean,
  Senegalese,
  Serbian,
  Seychellois,
  "Sierra Leonean": "Sierra Leonean",
  Singaporean,
  Slovak,
  Slovenian,
  "Solomon Islander": "Solomon Islander",
  Somali,
  "South African": "South African",
  "South Korean": "South Korean",
  Spanish,
  "Sri Lankan": "Sri Lankan",
  Sudanese,
  Surinamer,
  Swazi,
  Swede,
  Swiss,
  Syrian,
  Taiwanese,
  Tajikistani,
  Tanzanian,
  Thai,
  Tobagonian,
  Togolese,
  Tokelauan,
  Tongan,
  Tunisian,
  Turk,
  Turkmen,
  "Turks and Caicos Islander": "Turks and Caicos Islander",
  Tuvaluan,
  "U.S. Minor Outlying Islander": "U.S. Minor Outlying Islander",
  Ugandan,
  Ukrainian,
  Uruguayan,
  Uzbek,
  Vatican,
  Venezuelan,
  Vietnamese,
  "Virgin Islander": "Virgin Islander",
  Yemeni,
  Zambian,
  Zimbabwean,
  "/**************************** Branches ****************************/": "",
  Mecca,
  Medina,
  "Al Ahsaa": "Al Ahsaa",
  Jubail,
  Dammam,
  Hael,
  "Hafr Al-Baten": "Hafr Al-Baten",
  Riyadh,
  "Al-Qusaim": "Al-Qusaim",
  "Al Bahah": "Al Bahah",
  "Al Jawf": "Al Jawf",
  "Northern borders": "Northern borders",
  Aseer,
  Jazan,
  Najran,
  Tabuk,
  "Al Taeif": "Al Taeif",
  "/**************************** Cities ****************************/": "",
  Buraidah,
  "Al Qatif": "Al Qatif",
  "Hafr Albatin": "Hafr Albatin",
  Dabaa,
  "Al Kharaj": "Al Kharaj",
  "Yanbu`": "Yanbu`",
  Khobar,
  "A'ror": "A'ror",
  Sakaka,
  Jizan,
  "Al Qarrayat": "Al Qarrayat",
  "Al Zahran": "Al Zahran",
  "Al Zelafa": "Al Zelafa",
  "Al Rass": "Al Rass",
  Besha,
  Sehat,
  Sharora,
  Bahra,
  Afif,
  Sabia,
  Bariq,
  "Al Aflaj": "Al Aflaj",
  "Al Bakiria": "Al Bakiria",
  "Al Moznab": "Al Moznab",
  "Al Bada'e": "Al Bada'e",
  "Riyadh Al Khabraa": "Riyadh Al Khabraa",
  Abha,
  "Khamees Masheet": "Khamees Masheet",
  "Mahayel Aseer": "Mahayel Aseer",
  "Al A'laya": "Al A'laya",
  Aneeza,
  "Al Namaas": "Al Namaas",
  Jeddah
};
const plugins_i18n_ts_VfGcjrvSkj = defineNuxtPlugin((nuxtApp) => {
  const i18nPlugin = {
    install(app, options2) {
      app.config.globalProperties.$translate = (key) => {
        return options2.messages[options2.locale][key];
      };
      nuxtApp.provide("i18n", options2);
    }
  };
  const i18n = {
    locale: useCookie("locale").value || "ar",
    messages: {
      ar,
      en
    },
    translate: function(key) {
      return this.messages[this.locale][key];
    }
  };
  nuxtApp.vueApp.use(i18nPlugin, i18n);
});
const plugins_authenticate_js_o3fnjonZxe = defineNuxtPlugin(async () => {
  let __temp, __restore;
  try {
    const authStore = useAuthStore();
    return [__temp, __restore] = executeAsync(() => authStore.initAuth()), __temp = await __temp, __restore(), __temp;
  } catch (e) {
    console.log("Caught err2: ", e);
  }
});
const _plugins = [
  _nuxt_components_plugin_mjs_KR1HBZs4kY,
  node_modules_nuxt_dist_head_runtime_lib_vueuse_head_plugin_mjs_D7WGfuP1A0,
  node_modules_nuxt_dist_head_runtime_plugin_mjs_1QO0gqa6n2,
  node_modules_nuxt_dist_pages_runtime_router_mjs_qNv5Ky2ZmB,
  _nuxt_formkitPlugin_mjs_pZqjah0RUG,
  node_modules__64pinia_nuxt_dist_runtime_plugin_vue3_mjs_A0OWXRrUgq,
  plugins_i18n_ts_VfGcjrvSkj,
  plugins_authenticate_js_o3fnjonZxe
];
const _sfc_main$1 = {
  __name: "nuxt-root",
  __ssrInlineRender: true,
  setup(__props) {
    const ErrorComponent = defineAsyncComponent(() => import('./error-component.5f3ef17f.mjs').then((r) => r.default || r));
    const nuxtApp = useNuxtApp();
    provide("_route", useRoute());
    nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
    const error2 = useError();
    onErrorCaptured((err, target, info) => {
      nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
      {
        callWithNuxt(nuxtApp, showError, [err]);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_App = resolveComponent("App");
      ssrRenderSuspense(_push, {
        default: () => {
          if (unref(error2)) {
            _push(ssrRenderComponent(unref(ErrorComponent), { error: unref(error2) }, null, _parent));
          } else {
            _push(ssrRenderComponent(_component_App, null, null, _parent));
          }
        },
        _: 1
      });
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-root.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props2, ctx) : void 0;
};
const layouts = {
  default: defineAsyncComponent(() => import('./default.eddf521c.mjs').then((m) => m.default || m))
};
const __nuxt_component_0 = defineComponent({
  props: {
    name: {
      type: [String, Boolean, Object],
      default: null
    }
  },
  setup(props2, context) {
    const route = useRoute();
    return () => {
      var _a, _b, _c;
      const layout = (_b = (_a = isRef(props2.name) ? props2.name.value : props2.name) != null ? _a : route.meta.layout) != null ? _b : "default";
      const hasLayout = layout && layout in layouts;
      const transitionProps = (_c = route.meta.layoutTransition) != null ? _c : appLayoutTransition;
      return _wrapIf(Transition, hasLayout && transitionProps, {
        default: () => {
          return _wrapIf(layouts[layout], hasLayout, context.slots).default();
        }
      }).default();
    };
  }
});
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLayout = __nuxt_component_0;
  const _component_NuxtPage = resolveComponent("NuxtPage");
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_NuxtLayout, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_NuxtPage, null, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_NuxtPage)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props2, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("app.vue");
  return _sfc_setup ? _sfc_setup(props2, ctx) : void 0;
};
const AppComponent = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
if (!globalThis.$fetch) {
  globalThis.$fetch = $fetch$1.create({
    baseURL: baseURL()
  });
}
let entry;
const plugins = normalizePlugins(_plugins);
{
  entry = async function createNuxtAppServer(ssrContext) {
    const vueApp = createApp(_sfc_main$1);
    vueApp.component("App", AppComponent);
    const nuxt = createNuxtApp({ vueApp, ssrContext });
    try {
      await applyPlugins(nuxt, plugins);
      await nuxt.hooks.callHook("app:created", vueApp);
    } catch (err) {
      await nuxt.callHook("app:error", err);
      nuxt.payload.error = nuxt.payload.error || err;
    }
    return vueApp;
  };
}
const entry$1 = (ctx) => entry(ctx);

export { useRuntimeConfig as A, _sfc_main$2 as B, useSupportStore as C, usePageStore as D, usePostStore as E, _sfc_main$8 as F, useSubscriberStore as G, useVolunteerStore as H, defineNuxtRouteMiddleware as I, navigateTo as J, GgFacebook as K, MdiLinkedin as L, MdiTwitter as M, __nuxt_component_0 as _, useHead as a, useEventStore as b, clearError as c, useToast as d, entry$1 as default, useAuthStore as e, useLocalization as f, useRoute as g, storeToRefs as h, useFormating as i, _sfc_main$b as j, __nuxt_component_0$1 as k, _sfc_main$a as l, useRouter as m, _sfc_main$9 as n, _export_sfc as o, useHomeStore as p, useApiFetch as q, createError as r, setPageLayout as s, _sfc_main$7 as t, useNuxtApp as u, _sfc_main$6 as v, __nuxt_component_3 as w, _sfc_main$4 as x, _sfc_main$3 as y, useMemberStore as z };
//# sourceMappingURL=server.mjs.map
