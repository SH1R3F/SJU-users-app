import { u as useNuxtApp, a as useHead, g as useRoute, e as useAuthStore, k as __nuxt_component_0$1, d as useToast } from './server.mjs';
import { resolveComponent, withCtx, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "reset_password",
  __ssrInlineRender: true,
  setup(__props) {
    const toast = useToast();
    const submitReset = async (body, node) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const route = useRoute();
      if (route.query.token && route.query.email) {
        const authStore = useAuthStore();
        const { error } = await authStore.resetPassword({ ...body, ...route.query, userType: "member" });
        if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) === 400) {
          node.setErrors((_c = error.value) == null ? void 0 : _c.data);
        } else if (((_e = (_d = error == null ? void 0 : error.value) == null ? void 0 : _d.response) == null ? void 0 : _e.status) === 422) {
          toast.error((_g = (_f = error.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message);
        }
      }
    };
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Reset password");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="container my-20"><div class="card"><h5 class="card-title">${ssrInterpolate(_ctx.$translate("Reset password"))}</h5>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: submitReset
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("New password"),
              type: "password",
              name: "new_password",
              id: "password",
              classes: {
                outer: "mb-3",
                wrapper: {
                  "w-full": true,
                  "formkit-wrapper": false
                },
                inner: "mt-2"
              },
              placeholder: _ctx.$translate("New password"),
              validation: "required:trim|length:6",
              "validation-label": _ctx.$translate("New password")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Password confirmation"),
              type: "password",
              name: "new_password_confirm",
              id: "confirm_password",
              classes: {
                outer: "mb-3",
                wrapper: {
                  "w-full": true,
                  "formkit-wrapper": false
                },
                inner: "mt-2"
              },
              placeholder: _ctx.$translate("Password confirmation"),
              validation: "required:trim|confirm",
              "validation-label": _ctx.$translate("Password confirmation")
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex justify-between mt-8"${_scopeId}><button class="btn-primary" type="submit"${_scopeId}>${ssrInterpolate(_ctx.$translate("Save"))}</button>`);
            _push2(ssrRenderComponent(_component_nuxt_link, {
              to: "/members/auth/login",
              class: "btn"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$translate("login"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$translate("login")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode(_component_FormKit, {
                label: _ctx.$translate("New password"),
                type: "password",
                name: "new_password",
                id: "password",
                classes: {
                  outer: "mb-3",
                  wrapper: {
                    "w-full": true,
                    "formkit-wrapper": false
                  },
                  inner: "mt-2"
                },
                placeholder: _ctx.$translate("New password"),
                validation: "required:trim|length:6",
                "validation-label": _ctx.$translate("New password")
              }, null, 8, ["label", "placeholder", "validation-label"]),
              createVNode(_component_FormKit, {
                label: _ctx.$translate("Password confirmation"),
                type: "password",
                name: "new_password_confirm",
                id: "confirm_password",
                classes: {
                  outer: "mb-3",
                  wrapper: {
                    "w-full": true,
                    "formkit-wrapper": false
                  },
                  inner: "mt-2"
                },
                placeholder: _ctx.$translate("Password confirmation"),
                validation: "required:trim|confirm",
                "validation-label": _ctx.$translate("Password confirmation")
              }, null, 8, ["label", "placeholder", "validation-label"]),
              createVNode("div", { class: "flex justify-between mt-8" }, [
                createVNode("button", {
                  class: "btn-primary",
                  type: "submit"
                }, toDisplayString(_ctx.$translate("Save")), 1),
                createVNode(_component_nuxt_link, {
                  to: "/members/auth/login",
                  class: "btn"
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$translate("login")), 1)
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/subscribers/auth/reset_password.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=reset_password.4ea606d2.mjs.map
