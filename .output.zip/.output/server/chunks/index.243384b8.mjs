import { G as useSubscriberStore, h as storeToRefs, f as useLocalization, i as useFormating, e as useAuthStore, b as useEventStore, u as useNuxtApp, a as useHead, k as __nuxt_component_0$1 } from './server.mjs';
import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { withAsyncContext, computed, unref, withCtx, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { C as CibZoom, a as CiYoutube, M as MdiCertificate, E as EpFailed } from './failed.8c4cb9b5.mjs';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const subscriberStore = useSubscriberStore();
    const { upcomingEvents, enrolledEvents } = storeToRefs(subscriberStore);
    [__temp, __restore] = withAsyncContext(() => subscriberStore.fetchEvents()), await __temp, __restore();
    const { dblocalize } = useLocalization();
    const { formattedDate } = useFormating();
    const { coursePrices } = useSiteConfig();
    const authStore = useAuthStore();
    const upcoming = computed(() => {
      return (dateFrom) => {
        const date = new Date(dateFrom);
        const today = new Date();
        return date >= today;
      };
    });
    useEventStore();
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Events");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="card"><div class="card-title font-semibold">${ssrInterpolate(_ctx.$translate("Upcoming events"))}</div><div class="overflow-x-auto relative shadow-md sm:rounded-lg"><table class="w-full text-sm text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"><tr><th scope="col" class="py-3 px-6">#</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Event name"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Event date"))}</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800"></th></tr></thead><tbody class="text-center">`);
      if ((_a = unref(upcomingEvents)) == null ? void 0 : _a.length) {
        _push(`<!--[-->`);
        ssrRenderList(unref(upcomingEvents), (event, i) => {
          _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(i + 1)}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: `/events/${event.id}/register`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(unref(dblocalize)(event, "name"))}`);
              } else {
                return [
                  createTextVNode(toDisplayString(unref(dblocalize)(event, "name")), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</td><td class="py-4 px-6">${ssrInterpolate(unref(formattedDate)(event.date_from))}</td><td class="py-3 px-6 bg-gray-50 dark:bg-gray-800">`);
          if (event.subscribers.includes(unref(authStore).userData.id)) {
            _push(`<div><b>${ssrInterpolate(_ctx.$translate("Registered"))}</b></div>`);
          } else {
            _push(`<div>`);
            _push(ssrRenderComponent(_component_nuxt_link, {
              to: `/events/${event.id}/register`
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`<button class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Register"))}</button>`);
                } else {
                  return [
                    createVNode("button", { class: "btn-primary" }, toDisplayString(_ctx.$translate("Register")), 1)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</div>`);
          }
          _push(`</td></tr>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6" colspan="5"><b>${ssrInterpolate(_ctx.$translate("No data found to show"))}</b></td></tr>`);
      }
      _push(`</tbody></table></div></div><div class="card"><div class="card-title font-semibold">${ssrInterpolate(_ctx.$translate("Enrolled events"))}</div><div class="overflow-x-auto relative shadow-md sm:rounded-lg"><table class="w-full text-sm text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"><tr><th scope="col" class="py-3 px-6">#</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Event name"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Event date"))}</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Event type"))}</th><th scope="col" class="py-3 px-6"></th></tr></thead><tbody class="text-center">`);
      if ((_b = unref(enrolledEvents)) == null ? void 0 : _b.length) {
        _push(`<!--[-->`);
        ssrRenderList(unref(enrolledEvents), (event, i) => {
          _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(i + 1)}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: `/events/${event.id}/register`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(unref(dblocalize)(event, "name"))}`);
              } else {
                return [
                  createTextVNode(toDisplayString(unref(dblocalize)(event, "name")), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</td><td class="py-4 px-6">${ssrInterpolate(unref(formattedDate)(event.date_from))}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-80">${ssrInterpolate(unref(coursePrices)[event.price].label)}</td><td class="py-4 px-6 flex gap-3 justify-center [&amp;&gt;div]:cursor-pointer">`);
          if (unref(upcoming)(event.date_from) && event.zoom) {
            _push(ssrRenderComponent(_component_nuxt_link, {
              to: event.zoom
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(CibZoom), { class: "text-2xl text-blue-500" }, null, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(CibZoom), { class: "text-2xl text-blue-500" })
                  ];
                }
              }),
              _: 2
            }, _parent));
          } else if (!unref(upcoming)(event.date_from) && event.youtube) {
            _push(ssrRenderComponent(_component_nuxt_link, {
              to: event.youtube
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(CiYoutube), { class: "text-2xl text-red-600" }, null, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(CiYoutube), { class: "text-2xl text-red-600" })
                  ];
                }
              }),
              _: 2
            }, _parent));
          } else {
            _push(`<!---->`);
          }
          if (event.pivot.attendance) {
            _push(`<div>`);
            _push(ssrRenderComponent(unref(MdiCertificate), null, null, _parent));
            _push(`</div>`);
          } else {
            _push(`<div${ssrRenderAttr("title", _ctx.$translate(`You didn't attend the event`))}>`);
            _push(ssrRenderComponent(unref(EpFailed), null, null, _parent));
            _push(`</div>`);
          }
          _push(`</td></tr>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6" colspan="5"><b>${ssrInterpolate(_ctx.$translate("No data found to show"))}</b></td></tr>`);
      }
      _push(`</tbody></table></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/subscribers/dashboard/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.243384b8.mjs.map
