import { o as _export_sfc, p as useHomeStore, f as useLocalization, q as useApiFetch, r as createError, k as __nuxt_component_0$1, t as _sfc_main$7, v as _sfc_main$6, w as __nuxt_component_3, x as _sfc_main$4, y as _sfc_main$3 } from './server.mjs';
import { withAsyncContext, unref, withCtx, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _imports_0 = "" + globalThis.__publicAssetsURL("images/about-organization.jpg");
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d, _e, _f, _g;
    let __temp, __restore;
    const homeStore = useHomeStore();
    homeStore.fetchHomeData();
    const { dblocalize } = useLocalization();
    const { useMyFetch } = useApiFetch();
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useMyFetch("/home", {
      key: "home-posts"
    })), __temp = await __temp, __restore(), __temp);
    if ((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) {
      throw createError({
        statusCode: (_d = (_c = error == null ? void 0 : error.value) == null ? void 0 : _c.response) == null ? void 0 : _d.status,
        statusMessage: (_f = (_e = error == null ? void 0 : error.value) == null ? void 0 : _e.response) == null ? void 0 : _f.statusText
      });
    }
    const posts = (_g = data.value) == null ? void 0 : _g.posts;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_home_media_center = _sfc_main$7;
      const _component_home_regulations = _sfc_main$6;
      const _component_home_membership_details = __nuxt_component_3;
      const _component_home_stats = _sfc_main$4;
      const _component_home_follow_us = _sfc_main$3;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-85d17637><div class="container" data-v-85d17637><div id="default-carousel" class="relative my-16" data-carousel="slide" data-v-85d17637><div class="relative h-[27rem] md:h-96 overflow-hidden rounded-md" data-v-85d17637><!--[-->`);
      ssrRenderList(unref(posts), (post, i) => {
        _push(`<div${ssrRenderAttr("id", `carousel-item-${i + 1}`)} class="duration-700 linear absolute inset-0 transition-all transform translate-x-0 bg-sju-50"${ssrRenderAttr("data-carousel-item", i == 0 ? "active" : "")} data-v-85d17637><div class="flex flex-col md:flex-row-reverse" data-v-85d17637><div class="md:w-2/3 order-lg-last" data-v-85d17637><img class="object-cover h-56 md:h-96 w-full"${ssrRenderAttr("src", post.photos[0] || "/images/noimage.jpg")} onerror="this.src=&#39;/images/noimage.jpg&#39;"${ssrRenderAttr("alt", unref(dblocalize)(post, "title"))} data-v-85d17637></div><div class="md:w-1/3 flex items-center px-5 py-5" data-v-85d17637><div class="text-white pr-3 rtl:pr-0 rtl:pl-3 overflow-hidden" data-v-85d17637><h3 class="mb-2 text-xl md:text-2xl" data-v-85d17637>${ssrInterpolate(unref(dblocalize)(post, "title"))}</h3><p class="my-4" data-v-85d17637></p>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          class: "bg-sju-50 text-xs py-2 px-3 text-sju-400 mt-3",
          to: `/posts/${post.id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$translate("Details"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$translate("Details")), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div></div></div>`);
      });
      _push(`<!--]--></div></div></div><section class="mt-20 px-2 my-16" data-v-85d17637><div class="container" data-v-85d17637><div class="flex flex-col-reverse md:flex-row" data-v-85d17637><div class="md:w-1/2 pr-5 rtl:pr-0 rtl:pl-5" data-v-85d17637><h2 class="text-sju-50 text-4xl py-4 mb-2" data-v-85d17637>${ssrInterpolate(_ctx.$translate("about_authority"))}</h2><p class="text-gray-500 leading-7 text-justify mb-3 pr-5 rtl:pr-0 rtl:pl-5" data-v-85d17637>${ssrInterpolate(_ctx.$translate("about_authority_description"))}</p>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/pages/about-us" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="py-3 px-5 bg-sju-50 text-white hover:bg-white hover:border hover:border-sju-50 hover:text-sju-50 transition" data-v-85d17637${_scopeId}>${ssrInterpolate(_ctx.$translate("Read more"))}</button>`);
          } else {
            return [
              createVNode("button", { class: "py-3 px-5 bg-sju-50 text-white hover:bg-white hover:border hover:border-sju-50 hover:text-sju-50 transition" }, toDisplayString(_ctx.$translate("Read more")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="md:w-1/2" data-v-85d17637><img${ssrRenderAttr("src", _imports_0)} class="w-full object-fit"${ssrRenderAttr("alt", _ctx.$translate("about_authority"))} data-v-85d17637></div></div></div></section>`);
      _push(ssrRenderComponent(_component_home_media_center, {
        posts: unref(homeStore).mediacenter
      }, null, _parent));
      _push(ssrRenderComponent(_component_home_regulations, {
        events: unref(homeStore).events
      }, null, _parent));
      _push(ssrRenderComponent(_component_home_membership_details, null, null, _parent));
      if (unref(homeStore).stats) {
        _push(ssrRenderComponent(_component_home_stats, {
          stats: unref(homeStore).stats
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_home_follow_us, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-85d17637"]]);

export { index as default };
//# sourceMappingURL=index.53c13234.mjs.map
