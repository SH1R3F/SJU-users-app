import { C as useSupportStore, h as storeToRefs, i as useFormating, u as useNuxtApp, a as useHead, k as __nuxt_component_0$1 } from './server.mjs';
import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { withAsyncContext, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const supportStore = useSupportStore();
    const { tickets } = storeToRefs(supportStore);
    [__temp, __restore] = withAsyncContext(() => supportStore.fetchTickets()), await __temp, __restore();
    const { ticketStatus } = useSiteConfig();
    const { formattedDate } = useFormating();
    const { $i18n } = useNuxtApp();
    const title = $i18n.translate("Technical support");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="card"><h5 class="card-title">${ssrInterpolate(_ctx.$translate("Technical support"))}</h5><div class="overflow-x-auto relative shadow-md sm:rounded-lg mb-3"><table class="w-full text-sm text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"><tr><th scope="col" class="py-3 px-6">#</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Ticket title"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Creation date"))}</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Last update date"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Status"))}</th></tr></thead><tbody class="text-center">`);
      if ((_a = unref(tickets)) == null ? void 0 : _a.length) {
        _push(`<!--[-->`);
        ssrRenderList(unref(tickets), (ticket, i) => {
          _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">${ssrInterpolate(i + 1)}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: `/subscribers/dashboard/support/${ticket.id}`,
            class: "text-sju-50"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(ticket.title)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(ticket.title), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</td><td class="py-4 px-6">${ssrInterpolate(unref(formattedDate)(ticket.created_at))}</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-80">${ssrInterpolate(unref(formattedDate)(ticket.updated_at))}</td><td class="py-4 px-6">${ssrInterpolate(unref(ticketStatus)[ticket.status].label)}</td></tr>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6" colspan="5"><b>${ssrInterpolate(_ctx.$translate("No data found to show"))}</b></td></tr>`);
      }
      _push(`</tbody></table></div><div class="text-end">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/subscribers/dashboard/support/create",
        class: "btn-primary inline-block text-sm"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`+ ${ssrInterpolate(_ctx.$translate("New ticket"))}`);
          } else {
            return [
              createTextVNode("+ " + toDisplayString(_ctx.$translate("New ticket")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/subscribers/dashboard/support/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.11a8f4e1.mjs.map
