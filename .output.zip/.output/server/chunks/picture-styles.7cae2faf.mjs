const picture_vue_vue_type_style_index_0_lang = ".formkit-label{font-weight:400!important}";

const pictureStyles_7cae2faf = [picture_vue_vue_type_style_index_0_lang];

export { pictureStyles_7cae2faf as default };
//# sourceMappingURL=picture-styles.7cae2faf.mjs.map
