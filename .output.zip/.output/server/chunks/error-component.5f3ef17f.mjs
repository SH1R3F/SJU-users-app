import { s as setPageLayout, c as clearError, _ as __nuxt_component_0 } from './server.mjs';
import { useSSRContext, withCtx, unref, openBlock, createBlock, createVNode, toDisplayString, createTextVNode } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "error",
  __ssrInlineRender: true,
  props: {
    error: Object
  },
  setup(__props) {
    const { error } = __props;
    const { statusCode, statusMessage } = error;
    setPageLayout("default");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_layout = __nuxt_component_0;
      _push(ssrRenderComponent(_component_nuxt_layout, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(statusCode) == 404) {
              _push2(`<section class="flex items-center h-full p-16 dark:bg-gray-900 dark:text-gray-100 py-16"${_scopeId}><div class="container flex flex-col items-center justify-center px-5 mx-auto my-8"${_scopeId}><div class="max-w-md text-center"${_scopeId}><h2 class="mb-8 font-extrabold text-9xl dark:text-gray-600"${_scopeId}><span class="sr-only"${_scopeId}>${ssrInterpolate(_ctx.$translate("Error"))}</span>404 </h2><p class="text-2xl font-semibold md:text-3xl"${_scopeId}>${ssrInterpolate(_ctx.$translate("Sorry, we couldn't find this page."))}</p><p class="mt-4 mb-8 dark:text-gray-400"${_scopeId}>${ssrInterpolate(_ctx.$translate("But dont worry, you can find plenty of other things on our homepage."))}</p><button class="btn-primary px-8 py-3 font-semibold rounded"${_scopeId}>${ssrInterpolate(_ctx.$translate("Back to homepage"))}</button></div></div></section>`);
            } else {
              _push2(`<div class="container py-20 text-center"${_scopeId}><h1${_scopeId}>Error code ${ssrInterpolate(unref(statusCode))}</h1><h2${_scopeId}>${ssrInterpolate(unref(statusMessage))}</h2></div>`);
            }
          } else {
            return [
              unref(statusCode) == 404 ? (openBlock(), createBlock("section", {
                key: 0,
                class: "flex items-center h-full p-16 dark:bg-gray-900 dark:text-gray-100 py-16"
              }, [
                createVNode("div", { class: "container flex flex-col items-center justify-center px-5 mx-auto my-8" }, [
                  createVNode("div", { class: "max-w-md text-center" }, [
                    createVNode("h2", { class: "mb-8 font-extrabold text-9xl dark:text-gray-600" }, [
                      createVNode("span", { class: "sr-only" }, toDisplayString(_ctx.$translate("Error")), 1),
                      createTextVNode("404 ")
                    ]),
                    createVNode("p", { class: "text-2xl font-semibold md:text-3xl" }, toDisplayString(_ctx.$translate("Sorry, we couldn't find this page.")), 1),
                    createVNode("p", { class: "mt-4 mb-8 dark:text-gray-400" }, toDisplayString(_ctx.$translate("But dont worry, you can find plenty of other things on our homepage.")), 1),
                    createVNode("button", {
                      onClick: ($event) => unref(clearError)({ redirect: "/" }),
                      class: "btn-primary px-8 py-3 font-semibold rounded"
                    }, toDisplayString(_ctx.$translate("Back to homepage")), 9, ["onClick"])
                  ])
                ])
              ])) : (openBlock(), createBlock("div", {
                key: 1,
                class: "container py-20 text-center"
              }, [
                createVNode("h1", null, "Error code " + toDisplayString(unref(statusCode)), 1),
                createVNode("h2", null, toDisplayString(unref(statusMessage)), 1)
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("error.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _sfc_main$1 = _sfc_main;

export { _sfc_main$1 as default };
//# sourceMappingURL=error-component.5f3ef17f.mjs.map
