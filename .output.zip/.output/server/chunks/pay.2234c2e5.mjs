import { u as useNuxtApp, e as useAuthStore, h as storeToRefs, m as useRouter, z as useMemberStore, A as useRuntimeConfig, a as useHead } from './server.mjs';
import { withAsyncContext, computed, ref, resolveComponent, mergeProps, unref, withCtx, openBlock, createBlock, createCommentVNode, createVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useSiteConfig } from './useSiteConfig.b513bb85.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _imports_0 = "" + globalThis.__publicAssetsURL("images/pay-mada.png");
const _imports_1 = "" + globalThis.__publicAssetsURL("images/pay-mastercard.png");
const _imports_2 = "" + globalThis.__publicAssetsURL("images/pay-visa.png");
const _sfc_main = {
  __name: "pay",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { $i18n } = useNuxtApp();
    const authStore = useAuthStore();
    [__temp, __restore] = withAsyncContext(() => authStore.initAuth()), await __temp, __restore();
    const { userData } = storeToRefs(authStore);
    if (userData.value.active !== 1 || userData.value.approved !== 1 || userData.value.subscription.status === 1 && new Date(userData.value.subscription.end_date) > new Date()) {
      useRouter().push("/members/dashboard/membership");
    }
    const memberStore = useMemberStore();
    const { membershipTypes } = useSiteConfig();
    const config = useRuntimeConfig();
    const today = computed(() => {
      return new Date().toISOString().split("T")[0];
    });
    const amount = computed(() => {
      let extra = 0;
      if (userData.value.branch === 8 && userData.value.delivery_method === 2) {
        extra = 30;
      }
      return membershipTypes.find((c) => c.value === userData.value.subscription.type).price + extra;
    });
    const payment_gateway = ref(false);
    const paytype = ref(null);
    const endpoint = config.public.baseURL + "members/membership/payment/response";
    const paymentGatway = async (body, node) => {
      const { data } = await memberStore.prepareGateway(body.card);
      console.log(data.value.id);
      payment_gateway.value = data.value.id;
      paytype.value = body.card;
      useHead({
        script: [
          {
            children: "var wpwlOptions = { style:'plain', locale: 'ar', brandDetection: true }"
          },
          {
            src: `https://test.oppwa.com/v1/paymentWidgets.js?checkoutId=${data.value.id}`,
            body: true
          }
        ]
      });
    };
    const title = $i18n.translate("Subscribing to membership");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "form" }, _attrs))}><h6 class="form-title font-semibold">${ssrInterpolate(_ctx.$translate("Subscribing to membership"))}</h6><div class="w-full md:w-1/2"><div class="flex justify-between mb-2"><span class="text-sm md:text-base font-semibold">${ssrInterpolate(_ctx.$translate("Membership type"))}:</span><span class="text-sm md:text-base font-semibold text-sju-50">${ssrInterpolate(unref(membershipTypes).find((c) => c.value === unref(userData).subscription.type).label)}</span></div><div class="flex justify-between mb-2"><span class="text-sm md:text-base font-semibold">${ssrInterpolate(_ctx.$translate("Subscription start"))}:</span><span class="text-sm md:text-base font-semibold">${ssrInterpolate(unref(today))}</span></div><div class="flex justify-between mb-2"><span class="text-sm md:text-base font-semibold">${ssrInterpolate(_ctx.$translate("Subscription end"))}:</span><span class="text-sm md:text-base font-semibold">${ssrInterpolate(`${new Date().getFullYear()}-12-31`)}</span></div><div class="flex justify-between mb-2"><span class="text-sm md:text-base font-semibold">${ssrInterpolate(_ctx.$translate("Amount"))}:</span><span class="text-sm md:text-base font-semibold text-sju-50">${ssrInterpolate(`${unref(amount)} ${_ctx.$translate("Riyal")}`)}</span></div></div>`);
      if (payment_gateway.value === false) {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_FormKit, {
          type: "form",
          actions: false,
          onSubmit: paymentGatway
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="w-full md:w-1/2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                "outer-class": "mb-2",
                type: "myRadio",
                name: "card",
                label: _ctx.$translate("Card type"),
                options: [
                  {
                    label: "MADA",
                    value: 2
                  },
                  {
                    label: "VISA",
                    value: 1
                  }
                ],
                "validation-label": _ctx.$translate("Card type"),
                validation: "required",
                classes: {
                  options: "flex items-center",
                  option: {
                    "formkit-option": false
                  },
                  inner: "m-3"
                }
              }, {
                label: withCtx((context, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    if (context.option.label === "MADA") {
                      _push3(`<img${ssrRenderAttr("src", _imports_0)} alt="MADA" width="60"${_scopeId2}>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    if (context.option.label === "VISA") {
                      _push3(`<img${ssrRenderAttr("src", _imports_1)} alt="MASTERCARD" width="40"${_scopeId2}>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    if (context.option.label === "VISA") {
                      _push3(`<img${ssrRenderAttr("src", _imports_2)} alt="VISA" width="40"${_scopeId2}>`);
                    } else {
                      _push3(`<!---->`);
                    }
                  } else {
                    return [
                      context.option.label === "MADA" ? (openBlock(), createBlock("img", {
                        key: 0,
                        src: _imports_0,
                        alt: "MADA",
                        width: "60"
                      })) : createCommentVNode("", true),
                      context.option.label === "VISA" ? (openBlock(), createBlock("img", {
                        key: 1,
                        src: _imports_1,
                        alt: "MASTERCARD",
                        width: "40"
                      })) : createCommentVNode("", true),
                      context.option.label === "VISA" ? (openBlock(), createBlock("img", {
                        key: 2,
                        src: _imports_2,
                        alt: "VISA",
                        width: "40"
                      })) : createCommentVNode("", true)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div><hr class="my-5"${_scopeId}><h6 class="form-title font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$translate("Terms and policies"))}</h6><ul class="list-decimal pl-10 rtl:pl-0 rtl:pr-10"${_scopeId}><li class="mb-1"${_scopeId}>${ssrInterpolate(_ctx.$translate("payment_condition1"))}</li><li class="mb-1"${_scopeId}>${ssrInterpolate(_ctx.$translate("payment_condition2"))}</li><li class="mb-1"${_scopeId}>${ssrInterpolate(_ctx.$translate("payment_condition3"))}</li></ul><hr class="my-5"${_scopeId}><h6 class="form-title font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$translate("Payment details"))}</h6><ul class="list-decimal pl-10 rtl:pl-0 rtl:pr-10 mb-5"${_scopeId}><li class="mb-1"${_scopeId}>${ssrInterpolate(`${unref(membershipTypes).find((c) => c.value === unref(userData).subscription.type).price} ${_ctx.$translate(
                "Riyal"
              )} ${_ctx.$translate("for membership")}: ${unref(membershipTypes).find((c) => c.value === unref(userData).subscription.type).label}`)}</li>`);
              if (unref(userData).branch === 8 && unref(userData).delivery_method === 2) {
                _push2(`<li class="mb-1"${_scopeId}>${ssrInterpolate(`30 ${_ctx.$translate("Riyal")} ${_ctx.$translate("card delivery fees")}`)}</li>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</ul>`);
              _push2(ssrRenderComponent(_component_FormKit, {
                type: "checkbox",
                label: _ctx.$translate("TermsAgreement"),
                "validation-label": _ctx.$translate("acceptance"),
                validation: "required|accepted",
                classes: {
                  wrapper: {
                    "formkit-wrapper": false,
                    "w-full flex items-center": true
                  },
                  inner: "mx-3",
                  label: {
                    "formkit-label": false,
                    "font-semibold text-sm text-sju-50": true
                  }
                }
              }, null, _parent2, _scopeId));
              _push2(`<div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Complete payment"))}</button></div>`);
            } else {
              return [
                createVNode("div", { class: "w-full md:w-1/2" }, [
                  createVNode(_component_FormKit, {
                    "outer-class": "mb-2",
                    type: "myRadio",
                    name: "card",
                    label: _ctx.$translate("Card type"),
                    options: [
                      {
                        label: "MADA",
                        value: 2
                      },
                      {
                        label: "VISA",
                        value: 1
                      }
                    ],
                    "validation-label": _ctx.$translate("Card type"),
                    validation: "required",
                    classes: {
                      options: "flex items-center",
                      option: {
                        "formkit-option": false
                      },
                      inner: "m-3"
                    }
                  }, {
                    label: withCtx((context) => [
                      context.option.label === "MADA" ? (openBlock(), createBlock("img", {
                        key: 0,
                        src: _imports_0,
                        alt: "MADA",
                        width: "60"
                      })) : createCommentVNode("", true),
                      context.option.label === "VISA" ? (openBlock(), createBlock("img", {
                        key: 1,
                        src: _imports_1,
                        alt: "MASTERCARD",
                        width: "40"
                      })) : createCommentVNode("", true),
                      context.option.label === "VISA" ? (openBlock(), createBlock("img", {
                        key: 2,
                        src: _imports_2,
                        alt: "VISA",
                        width: "40"
                      })) : createCommentVNode("", true)
                    ]),
                    _: 1
                  }, 8, ["label", "validation-label"])
                ]),
                createVNode("hr", { class: "my-5" }),
                createVNode("h6", { class: "form-title font-semibold" }, toDisplayString(_ctx.$translate("Terms and policies")), 1),
                createVNode("ul", { class: "list-decimal pl-10 rtl:pl-0 rtl:pr-10" }, [
                  createVNode("li", { class: "mb-1" }, toDisplayString(_ctx.$translate("payment_condition1")), 1),
                  createVNode("li", { class: "mb-1" }, toDisplayString(_ctx.$translate("payment_condition2")), 1),
                  createVNode("li", { class: "mb-1" }, toDisplayString(_ctx.$translate("payment_condition3")), 1)
                ]),
                createVNode("hr", { class: "my-5" }),
                createVNode("h6", { class: "form-title font-semibold" }, toDisplayString(_ctx.$translate("Payment details")), 1),
                createVNode("ul", { class: "list-decimal pl-10 rtl:pl-0 rtl:pr-10 mb-5" }, [
                  createVNode("li", { class: "mb-1" }, toDisplayString(`${unref(membershipTypes).find((c) => c.value === unref(userData).subscription.type).price} ${_ctx.$translate(
                    "Riyal"
                  )} ${_ctx.$translate("for membership")}: ${unref(membershipTypes).find((c) => c.value === unref(userData).subscription.type).label}`), 1),
                  unref(userData).branch === 8 && unref(userData).delivery_method === 2 ? (openBlock(), createBlock("li", {
                    key: 0,
                    class: "mb-1"
                  }, toDisplayString(`30 ${_ctx.$translate("Riyal")} ${_ctx.$translate("card delivery fees")}`), 1)) : createCommentVNode("", true)
                ]),
                createVNode(_component_FormKit, {
                  type: "checkbox",
                  label: _ctx.$translate("TermsAgreement"),
                  "validation-label": _ctx.$translate("acceptance"),
                  validation: "required|accepted",
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full flex items-center": true
                    },
                    inner: "mx-3",
                    label: {
                      "formkit-label": false,
                      "font-semibold text-sm text-sju-50": true
                    }
                  }
                }, null, 8, ["label", "validation-label"]),
                createVNode("div", { class: "text-end" }, [
                  createVNode("button", {
                    type: "submit",
                    class: "btn-primary"
                  }, toDisplayString(_ctx.$translate("Complete payment")), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<div class="my-5 shadow-lg border py-10"><form${ssrRenderAttr("action", endpoint)} class="paymentWidgets"${ssrRenderAttr("data-brands", paytype.value === 2 ? "MADA" : "VISA MASTER")}></form></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/dashboard/membership/pay.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=pay.2234c2e5.mjs.map
