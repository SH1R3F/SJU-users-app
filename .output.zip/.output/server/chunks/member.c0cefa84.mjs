import { I as defineNuxtRouteMiddleware, e as useAuthStore, J as navigateTo } from './server.mjs';
import 'vue';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'vue/server-renderer';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const member = defineNuxtRouteMiddleware((to, from) => {
  const authStore = useAuthStore();
  if (authStore.userType != "member")
    return navigateTo("/members/auth/login");
});

export { member as default };
//# sourceMappingURL=member.c0cefa84.mjs.map
