const license_vue_vue_type_style_index_0_lang = ".formkit-label{font-weight:400!important}";

const licenseStyles_4ea7e301 = [license_vue_vue_type_style_index_0_lang];

export { licenseStyles_4ea7e301 as default };
//# sourceMappingURL=license-styles.4ea7e301.mjs.map
