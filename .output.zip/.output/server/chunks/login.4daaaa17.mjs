import { u as useNuxtApp, a as useHead, e as useAuthStore, k as __nuxt_component_0$1, d as useToast } from './server.mjs';
import { ref, resolveComponent, mergeProps, unref, withCtx, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { F as FaSolidUserEdit } from './user-edit.f30b0360.mjs';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    const { $i18n } = useNuxtApp();
    const toast = useToast();
    const resend_verification = ref(null);
    const loginSubscriber = async (body, node) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
      const authStore = useAuthStore();
      const { error } = await authStore.loginSubscriber(body);
      if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) === 400) {
        node.setErrors((_c = error.value) == null ? void 0 : _c.data);
        if ((_e = (_d = error.value) == null ? void 0 : _d.data) == null ? void 0 : _e.resend) {
          resend_verification.value = (_g = (_f = error.value) == null ? void 0 : _f.data) == null ? void 0 : _g.resend;
        }
      } else if (((_i = (_h = error == null ? void 0 : error.value) == null ? void 0 : _h.response) == null ? void 0 : _i.status) === 422) {
        toast.error((_k = (_j = error.value) == null ? void 0 : _j.data) == null ? void 0 : _k.message);
      }
    };
    const resendVerification = async () => {
      const authStore = useAuthStore();
      await authStore.resendVerification(resend_verification.value);
    };
    const title = $i18n.translate("Login subscribers");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "my-20" }, _attrs))}><div class="container"><div class="flex gap-8"><div class="w-full md:w-1/2"><div class="form"><h5 class="form-title">${ssrInterpolate(unref(title))}</h5>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: loginSubscriber
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Email"),
              type: "email",
              name: "email",
              id: "email",
              classes: {
                outer: "mb-3",
                wrapper: {
                  "w-full": true,
                  "formkit-wrapper": false
                }
              },
              placeholder: _ctx.$translate("Email"),
              validation: "required:trim|email",
              "validation-label": _ctx.$translate("Email")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Password"),
              type: "password",
              name: "password",
              id: "password",
              classes: {
                outer: "mb-3",
                wrapper: {
                  "w-full": true,
                  "formkit-wrapper": false
                }
              },
              placeholder: _ctx.$translate("Password"),
              validation: "required:trim|length:6",
              "validation-label": _ctx.$translate("Password")
            }, null, _parent2, _scopeId));
            if (resend_verification.value) {
              _push2(`<span class="text-sju-50 text-sm cursor-pointer"${_scopeId}>${ssrInterpolate(_ctx.$translate("Resend verification email"))}</span>`);
            } else {
              _push2(ssrRenderComponent(_component_nuxt_link, {
                to: "/subscribers/auth/forget_password",
                class: "text-sju-50 text-sm cursor-pointer"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(_ctx.$translate("Forgot password"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$translate("Forgot password")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            }
            _push2(`<div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Login"))}</button></div>`);
          } else {
            return [
              createVNode(_component_FormKit, {
                label: _ctx.$translate("Email"),
                type: "email",
                name: "email",
                id: "email",
                classes: {
                  outer: "mb-3",
                  wrapper: {
                    "w-full": true,
                    "formkit-wrapper": false
                  }
                },
                placeholder: _ctx.$translate("Email"),
                validation: "required:trim|email",
                "validation-label": _ctx.$translate("Email")
              }, null, 8, ["label", "placeholder", "validation-label"]),
              createVNode(_component_FormKit, {
                label: _ctx.$translate("Password"),
                type: "password",
                name: "password",
                id: "password",
                classes: {
                  outer: "mb-3",
                  wrapper: {
                    "w-full": true,
                    "formkit-wrapper": false
                  }
                },
                placeholder: _ctx.$translate("Password"),
                validation: "required:trim|length:6",
                "validation-label": _ctx.$translate("Password")
              }, null, 8, ["label", "placeholder", "validation-label"]),
              resend_verification.value ? (openBlock(), createBlock("span", {
                key: 0,
                class: "text-sju-50 text-sm cursor-pointer",
                onClick: resendVerification
              }, toDisplayString(_ctx.$translate("Resend verification email")), 1)) : (openBlock(), createBlock(_component_nuxt_link, {
                key: 1,
                to: "/subscribers/auth/forget_password",
                class: "text-sju-50 text-sm cursor-pointer"
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(_ctx.$translate("Forgot password")), 1)
                ]),
                _: 1
              })),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  type: "submit",
                  class: "btn-primary"
                }, toDisplayString(_ctx.$translate("Login")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="w-1/2 hidden md:flex items-center justify-center"><div class="text-center">`);
      _push(ssrRenderComponent(unref(FaSolidUserEdit), { class: "text-5xl mb-7 text-sju-100 m-auto" }, null, _parent));
      _push(`<h4 class="text-sju-200 mb-2">${ssrInterpolate(_ctx.$translate("Register new subscriber"))}</h4><p class="mb-4">${ssrInterpolate(_ctx.$translate("You can register as a new subscriber from this link"))}</p>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/subscribers/auth/register",
        class: "text-sju-50"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Click here to register"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Click here to register")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/subscribers/auth/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=login.4daaaa17.mjs.map
