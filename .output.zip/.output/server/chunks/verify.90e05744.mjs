import { g as useRoute, m as useRouter, u as useNuxtApp, a as useHead, d as useToast, p as useHomeStore, e as useAuthStore, k as __nuxt_component_0$1 } from './server.mjs';
import { resolveComponent, unref, withCtx, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "verify",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const { $i18n } = useNuxtApp();
    const toast = useToast();
    const mobile = route.query.mobile;
    const pattern = /^(5)\d{8}$/;
    if (!pattern.test(mobile)) {
      router.push("/members/auth/login");
      toast.error($i18n.translate("Mobile provided is not correct"));
    }
    const resendVerification = async () => {
      var _a;
      useHomeStore().loading = true;
      const authStore = useAuthStore();
      const { error } = await authStore.resendMobileVerification(mobile);
      if (error.value) {
        toast.error((_a = error.value.data) == null ? void 0 : _a.message);
      }
      useHomeStore().loading = false;
    };
    const verify = async (body, node) => {
      var _a;
      useHomeStore().loading = true;
      const authStore = useAuthStore();
      const { error } = await authStore.verifyMobile(mobile, body.code);
      if (error.value) {
        toast.error((_a = error.value.data) == null ? void 0 : _a.message);
      }
      useHomeStore().loading = false;
    };
    const title = $i18n.translate("Mobile verification");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="container my-20"><div class="card"><h5 class="card-title">${ssrInterpolate(_ctx.$translate("Mobile verification"))}</h5><div class="my-4"><label class="font-bold">${ssrInterpolate(_ctx.$translate("Mobile"))}</label><h5 class="font-bold inline mx-10 text-sju-200 underline">966${ssrInterpolate(unref(mobile))}</h5></div>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: verify
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Verification code"),
              type: "text",
              name: "code",
              id: "code",
              classes: {
                outer: "mb-3",
                inner: "mt-2"
              },
              placeholder: _ctx.$translate("Verification code"),
              validation: "required:trim|number|length:4,4",
              "validation-label": _ctx.$translate("Verification code")
            }, null, _parent2, _scopeId));
            _push2(`<span class="text-sju-50 text-sm cursor-pointer"${_scopeId}>${ssrInterpolate(_ctx.$translate("Resend verification code"))}</span><div class="flex justify-between mt-8"${_scopeId}><button class="btn-primary" type="submit"${_scopeId}>${ssrInterpolate(_ctx.$translate("Send"))}</button>`);
            _push2(ssrRenderComponent(_component_nuxt_link, {
              to: "/members/auth/login",
              class: "btn"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.$translate("login"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.$translate("login")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode(_component_FormKit, {
                label: _ctx.$translate("Verification code"),
                type: "text",
                name: "code",
                id: "code",
                classes: {
                  outer: "mb-3",
                  inner: "mt-2"
                },
                placeholder: _ctx.$translate("Verification code"),
                validation: "required:trim|number|length:4,4",
                "validation-label": _ctx.$translate("Verification code")
              }, null, 8, ["label", "placeholder", "validation-label"]),
              createVNode("span", {
                class: "text-sju-50 text-sm cursor-pointer",
                onClick: resendVerification
              }, toDisplayString(_ctx.$translate("Resend verification code")), 1),
              createVNode("div", { class: "flex justify-between mt-8" }, [
                createVNode("button", {
                  class: "btn-primary",
                  type: "submit"
                }, toDisplayString(_ctx.$translate("Send")), 1),
                createVNode(_component_nuxt_link, {
                  to: "/members/auth/login",
                  class: "btn"
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$translate("login")), 1)
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/members/auth/verify.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=verify.90e05744.mjs.map
