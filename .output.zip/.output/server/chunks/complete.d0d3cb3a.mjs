import { I as defineNuxtRouteMiddleware, e as useAuthStore, J as navigateTo } from './server.mjs';
import 'vue';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'vue/server-renderer';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const complete = defineNuxtRouteMiddleware((to, from) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  const authStore = useAuthStore();
  if (authStore.userType != "member") {
    return navigateTo("/members/auth/login");
  }
  let complete2 = true;
  complete2 = complete2 && authStore.userData.avatar;
  complete2 = complete2 && authStore.userData.national_image;
  complete2 = complete2 && authStore.userData.employer_letter;
  if (((_a = authStore.userData) == null ? void 0 : _a.newspaper_type) == 2) {
    complete2 = complete2 && authStore.userData.newspaper_license;
  }
  if (((_c = (_b = authStore.userData) == null ? void 0 : _b.subscription) == null ? void 0 : _c.type) == 3) {
    complete2 = complete2 && authStore.userData.job_contract;
  }
  complete2 = complete2 && ((_e = (_d = authStore.userData.experiences_and_fields) == null ? void 0 : _d.fields) == null ? void 0 : _e.length);
  complete2 = complete2 && ((_g = (_f = authStore.userData.experiences_and_fields) == null ? void 0 : _f.experiences) == null ? void 0 : _g.length);
  complete2 = complete2 && ((_i = (_h = authStore.userData.experiences_and_fields) == null ? void 0 : _h.languages) == null ? void 0 : _i.length);
  if (!complete2) {
    return navigateTo("/members/dashboard/profile/complete");
  }
});

export { complete as default };
//# sourceMappingURL=complete.d0d3cb3a.mjs.map
