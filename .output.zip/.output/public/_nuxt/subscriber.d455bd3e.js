import{a0 as e,k as r,a1 as t}from"./entry.1f559288.js";const i=e((s,a)=>{if(r().userType!="subscriber")return t("/subscribers/auth/login")});export{i as default};
