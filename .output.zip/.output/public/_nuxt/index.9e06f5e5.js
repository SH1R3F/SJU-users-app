import{o as e,a as t}from"./entry.1f559288.js";const n={__name:"index",setup(a){return(o,r)=>(e(),t("div"))}};export{n as default};
