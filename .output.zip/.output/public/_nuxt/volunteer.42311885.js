import{a0 as e,k as t,a1 as o}from"./entry.1f559288.js";const s=e((r,a)=>{if(t().userType!="volunteer")return o("/volunteers/auth/login")});export{s as default};
