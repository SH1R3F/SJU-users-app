import{a0 as e,k as t,a1 as r}from"./entry.1f559288.js";const s=e((a,o)=>{if(t().userType!="member")return r("/members/auth/login")});export{s as default};
