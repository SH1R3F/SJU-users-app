<script setup></script>

<template>
	<div>
		<div class="card">
			<div class="card-title font-semibold">{{ $translate("Edit profile") }}</div>
			a
		</div>
	</div>
</template>
