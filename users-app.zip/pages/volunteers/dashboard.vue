<script setup></script>

<template>
	<div class="dashboard my-16">
		<div class="container">
			<div class="flex gap-5 flex-col sm:flex-row">
				<div class="w-full sm:w-3/12">
					<img
						src="http://127.0.0.1:8000/storage/volunteers/18/images/1667396869.jpg"
						class="rounded-full mx-auto mb-5 h-40 w-40 lg:h-52 lg:w-52 object-cover object-top shadow-lg"
					/>
					<h6 class="text-sju-50 text-center font-bold">تجربة تجربة تجربة تجربة</h6>
					<ul class="mt-4">
						<nuxt-link
							to="/volunteers/dashboard"
							class="block active p-2 hover:bg-sju-500 transition-all [&.router-link-active]:text-sju-50 [&.router-link-active]:font-bold [&.router-link-active]:bg-sju-500 dark:[&.router-link-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
						>
							{{ $translate("Events") }}
						</nuxt-link>
						<nuxt-link
							to="/volunteers/dashboard/profile"
							class="block p-2 hover:bg-sju-500 transition-all [&.router-link-active]:text-sju-50 [&.router-link-active]:font-bold [&.router-link-active]:bg-sju-500 dark:[&.router-link-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
						>
							{{ $translate("Profile") }}
						</nuxt-link>
						<nuxt-link
							class="block p-2 hover:bg-sju-500 transition-all [&.router-link-active]:text-sju-50 [&.router-link-active]:font-bold [&.router-link-active]:bg-sju-500 dark:[&.router-link-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
						>
							{{ $translate("Technical support") }}
						</nuxt-link>
					</ul>
				</div>
				<div class="w-full sm:w-9/12">
					<NuxtChild />
				</div>
			</div>
		</div>
	</div>
</template>
