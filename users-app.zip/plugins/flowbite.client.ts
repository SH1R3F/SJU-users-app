import * as flowbite from "flowbite"

export default defineNuxtPlugin(({ vueApp }) => {
	vueApp.use(flowbite)
})
