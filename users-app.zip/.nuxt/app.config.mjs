
import { defuFn } from 'defu'

const inlineConfig = {}

import cfg0 from "C:/wamp64/www/Saudi Journalists V2/users-app/app.config.ts"

export default defuFn(cfg0, inlineConfig)
