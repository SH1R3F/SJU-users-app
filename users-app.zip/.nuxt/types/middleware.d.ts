import type { NavigationGuard } from 'vue-router'
export type MiddlewareKey = "guest"
declare module "C:/wamp64/www/Saudi Journalists V2/users-app/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    middleware?: MiddlewareKey | NavigationGuard | Array<MiddlewareKey | NavigationGuard>
  }
}