<template>
	<div class="fixed inset-0 bg-gray-100 transition-opacity z-30 flex items-center justify-center">
		<div class="text-center">
			<img src="/images/logo.png" alt="هيئة الصحفيين السعوديين" class="h-20 mx-auto" />
			<span class="mt-1 text-sm text-gray-500">{{ $translate("Loading") }}...</span>
		</div>
	</div>
</template>
