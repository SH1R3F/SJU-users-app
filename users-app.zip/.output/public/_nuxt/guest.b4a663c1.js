import{N as e,O as t}from"./entry.b63c5213.js";const s=e((o,a)=>{if(localStorage.getItem("accessToken"))return t("/")});export{s as default};
