import{x as a}from"./entry.b63c5213.js";const c=()=>{const{$i18n:r}=a();return{dblocalize:(e,t)=>{const n=r.locale;return n==="en"&&!e[`${t}_${n}`]?e[`${t}_ar`]:e[`${t}_${n}`]}}};export{c as u};
