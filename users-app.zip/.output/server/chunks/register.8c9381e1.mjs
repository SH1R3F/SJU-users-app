import { o as useNuxtApp, x as useAuthStore, p as useHead } from './server.mjs';
import { ref, resolveComponent, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'vue-toastification/dist/index.mjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const useSiteConfig = () => {
  const { $i18n } = useNuxtApp();
  return {
    qualifications: [
      { label: $i18n.translate("Primary school"), value: 0 },
      { label: $i18n.translate("Prepatatory school"), value: 1 },
      { label: $i18n.translate("High school"), value: 2 },
      { label: $i18n.translate("Diploma"), value: 3 },
      { label: $i18n.translate("Bachelor's degree"), value: 4 },
      { label: $i18n.translate("Master's degree"), value: 5 },
      { label: $i18n.translate("PHD degree"), value: 6 }
    ],
    howKnewUs: [
      { label: $i18n.translate("From a friend"), value: 0 },
      { label: $i18n.translate("Twitter"), value: 1 },
      { label: $i18n.translate("Youtube"), value: 2 }
    ],
    countries: [
      { label: $i18n.translate("Saudi Arabia"), value: 0 },
      { label: $i18n.translate("Afghanistan"), value: 1 },
      { label: $i18n.translate("Albania"), value: 2 },
      { label: $i18n.translate("Algeria"), value: 3 },
      { label: $i18n.translate("Andorra"), value: 4 },
      { label: $i18n.translate("Angola"), value: 5 },
      { label: $i18n.translate("Armenia"), value: 6 },
      { label: $i18n.translate("Azerbaijan"), value: 7 },
      { label: $i18n.translate("Bahamas"), value: 8 },
      { label: $i18n.translate("Bahrain"), value: 9 },
      { label: $i18n.translate("Bangladesh"), value: 10 },
      { label: $i18n.translate("Belarus"), value: 11 },
      { label: $i18n.translate("Bolivia"), value: 12 },
      { label: $i18n.translate("Botswana"), value: 13 },
      { label: $i18n.translate("Cameroon"), value: 14 },
      { label: $i18n.translate("Congo"), value: 15 },
      { label: $i18n.translate("Cuba"), value: 16 },
      { label: $i18n.translate("Cyprus"), value: 17 },
      { label: $i18n.translate("Egypt"), value: 18 },
      { label: $i18n.translate("Gabon"), value: 19 },
      { label: $i18n.translate("Gambia"), value: 20 },
      { label: $i18n.translate("Georgia"), value: 21 },
      { label: $i18n.translate("Ghana"), value: 22 },
      { label: $i18n.translate("Greenland"), value: 23 },
      { label: $i18n.translate("Guinea"), value: 24 },
      { label: $i18n.translate("Honduras"), value: 25 },
      { label: $i18n.translate("Iraq"), value: 26 },
      { label: $i18n.translate("Jamaica"), value: 27 },
      { label: $i18n.translate("Kuwait"), value: 28 },
      { label: $i18n.translate("Lebanon"), value: 29 },
      { label: $i18n.translate("Libya"), value: 30 },
      { label: $i18n.translate("Morocco"), value: 31 },
      { label: $i18n.translate("Mozambique"), value: 32 },
      { label: $i18n.translate("Myanmar"), value: 33 },
      { label: $i18n.translate("Namibia"), value: 34 },
      { label: $i18n.translate("Nepal"), value: 35 },
      { label: $i18n.translate("Nicaragua"), value: 36 },
      { label: $i18n.translate("Oman"), value: 37 },
      { label: $i18n.translate("Palestine"), value: 38 },
      { label: $i18n.translate("Senegal"), value: 39 },
      { label: $i18n.translate("Sudan"), value: 40 },
      { label: $i18n.translate("Tunisia"), value: 41 },
      { label: $i18n.translate("United Arab Emirates"), value: 42 }
    ],
    cities: [
      { label: $i18n.translate("Jubail"), value: 0 },
      { label: $i18n.translate("Buraidah"), value: 1 },
      { label: $i18n.translate("Riyadh"), value: 2 },
      { label: $i18n.translate("Mecca"), value: 3 },
      { label: $i18n.translate("Medina"), value: 4 },
      { label: $i18n.translate("Tabuk"), value: 5 },
      { label: $i18n.translate("Dammam"), value: 6 },
      { label: $i18n.translate("Al Taeif"), value: 7 },
      { label: $i18n.translate("Al Ahsaa"), value: 8 },
      { label: $i18n.translate("Al Qatif"), value: 9 },
      { label: $i18n.translate("Najran"), value: 10 },
      { label: $i18n.translate("Hafr Albatin"), value: 11 },
      { label: $i18n.translate("Dabaa"), value: 12 },
      { label: $i18n.translate("Al Kharaj"), value: 13 },
      { label: $i18n.translate("Yanbu`"), value: 14 },
      { label: $i18n.translate("Khobar"), value: 15 },
      { label: $i18n.translate("A'ror"), value: 16 },
      { label: $i18n.translate("Sakaka"), value: 17 },
      { label: $i18n.translate("Jizan"), value: 18 },
      { label: $i18n.translate("Al Qarrayat"), value: 19 },
      { label: $i18n.translate("Al Zahran"), value: 20 },
      { label: $i18n.translate("Al Zelafa"), value: 21 },
      { label: $i18n.translate("Al Bahah"), value: 22 },
      { label: $i18n.translate("Al Rass"), value: 23 },
      { label: $i18n.translate("Besha"), value: 24 },
      { label: $i18n.translate("Sehat"), value: 25 },
      { label: $i18n.translate("Sharora"), value: 26 },
      { label: $i18n.translate("Bahra"), value: 27 },
      { label: $i18n.translate("Afif"), value: 28 },
      { label: $i18n.translate("Sabia"), value: 29 },
      { label: $i18n.translate("Bariq"), value: 30 },
      { label: $i18n.translate("Al Aflaj"), value: 31 },
      { label: $i18n.translate("Al Bakiria"), value: 32 },
      { label: $i18n.translate("Al Moznab"), value: 33 },
      { label: $i18n.translate("Al Bada'e"), value: 34 },
      { label: $i18n.translate("Riyadh Al Khabraa"), value: 35 },
      { label: $i18n.translate("Abha"), value: 36 },
      { label: $i18n.translate("Khamees Masheet"), value: 37 },
      { label: $i18n.translate("Mahayel Aseer"), value: 38 },
      { label: $i18n.translate("Al A'laya"), value: 39 },
      { label: $i18n.translate("Aneeza"), value: 40 },
      { label: $i18n.translate("Al Namaas"), value: 41 },
      { label: $i18n.translate("Jeddah"), value: 42 }
    ],
    branches: [
      { label: $i18n.translate("Mecca"), value: 0 },
      { label: $i18n.translate("Medina"), value: 1 },
      { label: $i18n.translate("Al Ahsaa"), value: 2 },
      { label: $i18n.translate("Jubail"), value: 3 },
      { label: $i18n.translate("Dammam"), value: 4 },
      { label: $i18n.translate("Hael"), value: 5 },
      { label: $i18n.translate("Hafr Al-Baten"), value: 6 },
      { label: $i18n.translate("Riyadh"), value: 7 },
      { label: $i18n.translate("Al-Qusaim"), value: 8 },
      { label: $i18n.translate("Al Bahah"), value: 9 },
      { label: $i18n.translate("Al Jawf"), value: 10 },
      { label: $i18n.translate("Northern borders"), value: 11 },
      { label: $i18n.translate("Aseer"), value: 12 },
      { label: $i18n.translate("Jazan"), value: 13 },
      { label: $i18n.translate("Najran"), value: 14 },
      { label: $i18n.translate("Tabuk"), value: 15 },
      { label: $i18n.translate("Al Taeif"), value: 16 }
    ],
    mobileCodes: [
      { label: "+93", value: "93" },
      { label: "+358", value: "358" },
      { label: "+355", value: "355" },
      { label: "+213", value: "213" },
      { label: "+1684", value: "1684" },
      { label: "+376", value: "376" },
      { label: "+244", value: "244" },
      { label: "+1264", value: "1264" },
      { label: "+1268", value: "1268" },
      { label: "+54", value: "54" },
      { label: "+374", value: "374" },
      { label: "+297", value: "297" },
      { label: "+43", value: "43" },
      { label: "+994", value: "994" },
      { label: "+1242", value: "1242" },
      { label: "+973", value: "973" },
      { label: "+880", value: "880" },
      { label: "+1246", value: "1246" },
      { label: "+375", value: "375" },
      { label: "+32", value: "32" },
      { label: "+501", value: "501" },
      { label: "+229", value: "229" },
      { label: "+1441", value: "1441" },
      { label: "+975", value: "975" },
      { label: "+591", value: "591" },
      { label: "+387", value: "387" },
      { label: "+267", value: "267" },
      { label: "+55", value: "55" },
      { label: "+246", value: "246" },
      { label: "+673", value: "673" },
      { label: "+359", value: "359" },
      { label: "+226", value: "226" },
      { label: "+257", value: "257" },
      { label: "+855", value: "855" },
      { label: "+237", value: "237" },
      { label: "+1", value: "1" },
      { label: "+238", value: "238" },
      { label: "+ 345", value: " 345" },
      { label: "+236", value: "236" },
      { label: "+235", value: "235" },
      { label: "+56", value: "56" },
      { label: "+86", value: "86" },
      { label: "+61", value: "61" },
      { label: "+57", value: "57" },
      { label: "+269", value: "269" },
      { label: "+242", value: "242" },
      { label: "+243", value: "243" },
      { label: "+682", value: "682" },
      { label: "+506", value: "506" },
      { label: "+225", value: "225" },
      { label: "+385", value: "385" },
      { label: "+53", value: "53" },
      { label: "+357", value: "357" },
      { label: "+420", value: "420" },
      { label: "+45", value: "45" },
      { label: "+253", value: "253" },
      { label: "+1767", value: "1767" },
      { label: "+1849", value: "1849" },
      { label: "+593", value: "593" },
      { label: "+20", value: "20" },
      { label: "+503", value: "503" },
      { label: "+240", value: "240" },
      { label: "+291", value: "291" },
      { label: "+372", value: "372" },
      { label: "+251", value: "251" },
      { label: "+500", value: "500" },
      { label: "+298", value: "298" },
      { label: "+679", value: "679" },
      { label: "+33", value: "33" },
      { label: "+594", value: "594" },
      { label: "+689", value: "689" },
      { label: "+241", value: "241" },
      { label: "+220", value: "220" },
      { label: "+995", value: "995" },
      { label: "+49", value: "49" },
      { label: "+233", value: "233" },
      { label: "+350", value: "350" },
      { label: "+30", value: "30" },
      { label: "+299", value: "299" },
      { label: "+1473", value: "1473" },
      { label: "+590", value: "590" },
      { label: "+1671", value: "1671" },
      { label: "+502", value: "502" },
      { label: "+224", value: "224" },
      { label: "+245", value: "245" },
      { label: "+509", value: "509" },
      { label: "+379", value: "379" },
      { label: "+504", value: "504" },
      { label: "+852", value: "852" },
      { label: "+36", value: "36" },
      { label: "+354", value: "354" },
      { label: "+91", value: "91" },
      { label: "+62", value: "62" },
      { label: "+98", value: "98" },
      { label: "+964", value: "964" },
      { label: "+353", value: "353" },
      { label: "+972", value: "972" },
      { label: "+39", value: "39" },
      { label: "+1876", value: "1876" },
      { label: "+81", value: "81" },
      { label: "+962", value: "962" },
      { label: "+77", value: "77" },
      { label: "+254", value: "254" },
      { label: "+686", value: "686" },
      { label: "+850", value: "850" },
      { label: "+82", value: "82" },
      { label: "+965", value: "965" },
      { label: "+996", value: "996" },
      { label: "+856", value: "856" },
      { label: "+371", value: "371" },
      { label: "+961", value: "961" },
      { label: "+266", value: "266" },
      { label: "+231", value: "231" },
      { label: "+218", value: "218" },
      { label: "+423", value: "423" },
      { label: "+370", value: "370" },
      { label: "+352", value: "352" },
      { label: "+853", value: "853" },
      { label: "+389", value: "389" },
      { label: "+261", value: "261" },
      { label: "+265", value: "265" },
      { label: "+60", value: "60" },
      { label: "+960", value: "960" },
      { label: "+223", value: "223" },
      { label: "+356", value: "356" },
      { label: "+692", value: "692" },
      { label: "+596", value: "596" },
      { label: "+222", value: "222" },
      { label: "+230", value: "230" },
      { label: "+52", value: "52" },
      { label: "+691", value: "691" },
      { label: "+373", value: "373" },
      { label: "+377", value: "377" },
      { label: "+976", value: "976" },
      { label: "+382", value: "382" },
      { label: "+1664", value: "1664" },
      { label: "+212", value: "212" },
      { label: "+258", value: "258" },
      { label: "+95", value: "95" },
      { label: "+264", value: "264" },
      { label: "+674", value: "674" },
      { label: "+977", value: "977" },
      { label: "+31", value: "31" },
      { label: "+599", value: "599" },
      { label: "+687", value: "687" },
      { label: "+64", value: "64" },
      { label: "+505", value: "505" },
      { label: "+227", value: "227" },
      { label: "+234", value: "234" },
      { label: "+683", value: "683" },
      { label: "+672", value: "672" },
      { label: "+1670", value: "1670" },
      { label: "+968", value: "968" },
      { label: "+92", value: "92" },
      { label: "+680", value: "680" },
      { label: "+970", value: "970" },
      { label: "+507", value: "507" },
      { label: "+675", value: "675" },
      { label: "+595", value: "595" },
      { label: "+51", value: "51" },
      { label: "+63", value: "63" },
      { label: "+872", value: "872" },
      { label: "+48", value: "48" },
      { label: "+351", value: "351" },
      { label: "+1939", value: "1939" },
      { label: "+974", value: "974" },
      { label: "+40", value: "40" },
      { label: "+7", value: "7" },
      { label: "+250", value: "250" },
      { label: "+262", value: "262" },
      { label: "+290", value: "290" },
      { label: "+1869", value: "1869" },
      { label: "+1758", value: "1758" },
      { label: "+508", value: "508" },
      { label: "+1784", value: "1784" },
      { label: "+685", value: "685" },
      { label: "+378", value: "378" },
      { label: "+239", value: "239" },
      { label: "+966", value: "966" },
      { label: "+221", value: "221" },
      { label: "+381", value: "381" },
      { label: "+248", value: "248" },
      { label: "+232", value: "232" },
      { label: "+65", value: "65" },
      { label: "+421", value: "421" },
      { label: "+386", value: "386" },
      { label: "+677", value: "677" },
      { label: "+252", value: "252" },
      { label: "+27", value: "27" },
      { label: "+211", value: "211" },
      { label: "+34", value: "34" },
      { label: "+94", value: "94" },
      { label: "+249", value: "249" },
      { label: "+597", value: "597" },
      { label: "+47", value: "47" },
      { label: "+268", value: "268" },
      { label: "+46", value: "46" },
      { label: "+41", value: "41" },
      { label: "+963", value: "963" },
      { label: "+886", value: "886" },
      { label: "+992", value: "992" },
      { label: "+255", value: "255" },
      { label: "+66", value: "66" },
      { label: "+670", value: "670" },
      { label: "+228", value: "228" },
      { label: "+690", value: "690" },
      { label: "+676", value: "676" },
      { label: "+1868", value: "1868" },
      { label: "+216", value: "216" },
      { label: "+90", value: "90" },
      { label: "+993", value: "993" },
      { label: "+1649", value: "1649" },
      { label: "+688", value: "688" },
      { label: "+256", value: "256" },
      { label: "+380", value: "380" },
      { label: "+971", value: "971" },
      { label: "+44", value: "44" },
      { label: "+598", value: "598" },
      { label: "+998", value: "998" },
      { label: "+678", value: "678" },
      { label: "+58", value: "58" },
      { label: "+84", value: "84" },
      { label: "+1284", value: "1284" },
      { label: "+1340", value: "1340" },
      { label: "+681", value: "681" },
      { label: "+967", value: "967" },
      { label: "+260", value: "260" },
      { label: "+263", value: "263" }
    ]
  };
};
const _sfc_main = {
  __name: "register",
  __ssrInlineRender: true,
  setup(__props) {
    const { $i18n } = useNuxtApp();
    const { countries, cities, branches, qualifications, howKnewUs, mobileCodes } = useSiteConfig();
    const volunteerData = ref({});
    const authStore = useAuthStore();
    const createVolunteer = async (volunteer, node) => {
      var _a, _b, _c, _d;
      const body = new FormData();
      Object.keys(volunteer).forEach((key) => {
        let value = volunteer[key];
        body.append(key, value);
      });
      body.append("image", (_a = volunteer.image[0]) == null ? void 0 : _a.file);
      const { data, error } = await authStore.registerVolunteer(body);
      if (((_c = (_b = error == null ? void 0 : error.value) == null ? void 0 : _b.response) == null ? void 0 : _c.status) === 400) {
        node.setErrors((_d = error.value) == null ? void 0 : _d.data);
      }
      if (data == null ? void 0 : data.value) {
        authStore.authenticated = true;
        authStore.userData = data.value.userData;
        authStore.userType = "volunteer";
        authStore.accessToken = data.value.accessToken;
        localStorage.setItem("userData", JSON.stringify(data.value.userData));
        localStorage.setItem("userType", "volunteer");
        localStorage.setItem("accessToken", data.value.accessToken);
      }
    };
    const title = $i18n.translate("Register new volunteer");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "my-20" }, _attrs))}><div class="container"><div class="form"><h5 class="form-title">${ssrInterpolate(unref(title))}</h5>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: createVolunteer,
        modelValue: volunteerData.value,
        "onUpdate:modelValue": ($event) => volunteerData.value = $event,
        enctype: "multipart/form-data"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "file",
              name: "image",
              label: _ctx.$translate("Profile picture"),
              accept: "image/*",
              classes: {
                input: "block px-3 w-full",
                outer: "mb-5",
                wrapper: {
                  "formkit-wrapper": false
                }
              }
            }, null, _parent2, _scopeId));
            _push2(`<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: `${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`,
              type: "text",
              name: "fname_ar",
              id: "fname_ar",
              "outer-class": "mb-3",
              placeholder: _ctx.$translate("fname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("fname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: `${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`,
              type: "text",
              name: "sname_ar",
              id: "sname_ar",
              "outer-class": "mb-3",
              placeholder: _ctx.$translate("sname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("sname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: `${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`,
              type: "text",
              name: "tname_ar",
              id: "tname_ar",
              "outer-class": "mb-3",
              placeholder: _ctx.$translate("tname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("tname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: `${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`,
              type: "text",
              name: "lname_ar",
              id: "lname_ar",
              "outer-class": "mb-3",
              placeholder: _ctx.$translate("lname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("lname")
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              "outer-class": "mb-3",
              type: "text",
              label: `${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`,
              name: "fname_en",
              id: "fname_en",
              placeholder: _ctx.$translate("fname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("fname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              "outer-class": "mb-3",
              type: "text",
              label: `${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`,
              name: "sname_en",
              id: "sname_en",
              placeholder: _ctx.$translate("sname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("sname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              "outer-class": "mb-3",
              type: "text",
              label: `${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`,
              name: "tname_en",
              id: "tname_en",
              placeholder: _ctx.$translate("tname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("tname")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              "outer-class": "mb-3",
              type: "text",
              label: `${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`,
              name: "lname_en",
              id: "lname_en",
              placeholder: _ctx.$translate("lname"),
              validation: "required:trim|length:3,50",
              "validation-label": _ctx.$translate("lname")
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              "outer-class": "mb-3",
              type: "myRadio",
              name: "gender",
              label: _ctx.$translate("Gender"),
              options: [
                {
                  label: _ctx.$translate("Male"),
                  value: 0
                },
                {
                  label: _ctx.$translate("Female"),
                  value: 1
                }
              ],
              "validation-label": _ctx.$translate("Gender"),
              validation: "required",
              classes: {
                options: "flex items-center",
                option: {
                  "formkit-option": false
                },
                inner: "m-3"
              }
            }, null, _parent2, _scopeId));
            _push2(`<div class="${ssrRenderClass([{
              "md:grid-cols-4": volunteerData.value.country === 0,
              "md:grid-cols-3": volunteerData.value.country !== 0
            }, "grid grid-cols-1 gap-2 md:gap-4"])}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Country"),
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              options: unref(countries),
              name: "country",
              "validation-label": _ctx.$translate("Country"),
              validation: "required",
              "outer-class": "mb-3"
            }, null, _parent2, _scopeId));
            if (volunteerData.value.country === 0) {
              _push2(ssrRenderComponent(_component_FormKit, {
                label: _ctx.$translate("City"),
                type: "select",
                "sections-schema": {
                  selectIcon: { $el: null }
                },
                options: unref(cities),
                name: "city",
                "validation-label": _ctx.$translate("City"),
                validation: "required",
                "outer-class": "mb-3"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Nationality"),
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              "outer-class": "mb-3",
              options: unref(countries),
              name: "nationality",
              "validation-label": _ctx.$translate("Nationality"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Qualification"),
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              "outer-class": "mb-3",
              options: unref(qualifications),
              name: "qualification",
              "validation-label": _ctx.$translate("Qualification"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("National ID"),
              "outer-class": "mb-3",
              type: "number",
              placeholder: _ctx.$translate("National ID"),
              name: "national_id",
              "validation-label": _ctx.$translate("National ID"),
              validation: "required:trim|number|length:10"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Martial status"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Martial status"),
              name: "marital_status",
              "validation-label": _ctx.$translate("Martial status"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Adminstrative area"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Adminstrative area"),
              name: "adminstrative_area",
              "validation-label": _ctx.$translate("Adminstrative area"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Governorate"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Governorate"),
              name: "governorate",
              "validation-label": _ctx.$translate("Governorate"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("National address"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("National address"),
              name: "national_address",
              id: "national_address",
              "validation-label": _ctx.$translate("National address"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Job title"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Job title"),
              name: "job_title",
              "validation-label": _ctx.$translate("Job title"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Address"),
              "outer-class": "mb-3",
              type: "text",
              placeholder: _ctx.$translate("Address"),
              name: "address",
              "validation-label": _ctx.$translate("Address"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              classes: {
                outer: "my-4",
                options: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4",
                option: {
                  "formkit-option": false
                },
                fieldset: { "formkit-fieldset": false },
                wrapper: "flex justify-between items-center p-2 border-l border-b"
              },
              name: "fields",
              type: "checkbox",
              label: _ctx.$translate("Volunteering fields"),
              options: [
                {
                  label: _ctx.$translate("Photography"),
                  value: 1
                },
                {
                  label: _ctx.$translate("Videography"),
                  value: 2
                },
                {
                  label: _ctx.$translate("Cinematography"),
                  value: 3
                },
                {
                  label: _ctx.$translate("Editing - Media Platforms - Documentation"),
                  value: 4
                },
                {
                  label: _ctx.$translate("Coverings"),
                  value: 5
                },
                {
                  label: _ctx.$translate("Presentation"),
                  value: 6
                },
                {
                  label: _ctx.$translate("Digital content industry"),
                  value: 7
                },
                {
                  label: _ctx.$translate("Montage"),
                  value: 8
                },
                {
                  label: _ctx.$translate("Social media"),
                  value: 9
                },
                {
                  label: _ctx.$translate("Media marketing"),
                  value: 10
                },
                {
                  label: _ctx.$translate("Editorial management"),
                  value: 11
                },
                {
                  label: _ctx.$translate("Field Editorial Leadership"),
                  value: 12
                },
                {
                  label: _ctx.$translate("Management of meetings and seminars"),
                  value: 13
                },
                {
                  label: _ctx.$translate("Media training"),
                  value: 14
                }
              ],
              "validation-label": _ctx.$translate("Volunteering fields"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(`<div class="row-of-two"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Educational level"),
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              type: "text",
              placeholder: _ctx.$translate("Educational level"),
              name: "education",
              "validation-label": _ctx.$translate("Educational level"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "text",
              placeholder: _ctx.$translate("Volunteering experiences"),
              name: "experiences",
              label: _ctx.$translate("Volunteering experiences"),
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                },
                outer: "mb-3"
              },
              "validation-label": _ctx.$translate("Volunteering experiences"),
              validation: "required:trim"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="row-of-two"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Branch"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              options: unref(branches),
              name: "branch",
              "validation-label": _ctx.$translate("Branch"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("How do you know the authority?"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "select",
              "sections-schema": {
                selectIcon: { $el: null }
              },
              options: unref(howKnewUs),
              name: "hearabout",
              "validation-label": _ctx.$translate("How do you know the authority?"),
              validation: "required"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="row-of-two"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Email"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "email",
              placeholder: _ctx.$translate("Email"),
              id: "email",
              name: "email",
              "validation-label": _ctx.$translate("Email"),
              validation: "required:trim|email"
            }, null, _parent2, _scopeId));
            _push2(`<div class="formkit-outer mb-3" data-family="text" data-type="email"${_scopeId}><label for="mobile" class="formkit-label"${_scopeId}>${ssrInterpolate(_ctx.$translate("Mobile"))}</label><div class="input-group [&amp;&gt;.formkit-outer]:mb-0 h-9" style="${ssrRenderStyle({ "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" })}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "myTextInput",
              "outer-class": "w-full border border-y-0 m-0",
              id: "mobile",
              name: "mobile",
              placeholder: _ctx.$translate("Mobile"),
              validation: "required:trim|number",
              "validation-label": _ctx.$translate("Mobile")
            }, null, _parent2, _scopeId));
            _push2(`<span class="prepend"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "mySelect",
              name: "mobile_key",
              options: unref(mobileCodes),
              style: { "box-shadow": "none" }
            }, null, _parent2, _scopeId));
            _push2(`</span></div></div></div><div class="row-of-two"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Password"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("Password"),
              id: "password",
              name: "password",
              "validation-label": _ctx.$translate("Password"),
              validation: "required:trim|length:6"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Password confirmation"),
              classes: {
                outer: "mb-3",
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full": true
                }
              },
              type: "password",
              placeholder: _ctx.$translate("Password confirmation"),
              id: "password_confirm",
              name: "password_confirm",
              "validation-label": _ctx.$translate("Password confirmation"),
              validation: "required:trim|confirm"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mb-7"${_scopeId}></div><div class="mb-7"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormKit, {
              type: "checkbox",
              label: _ctx.$translate("TermsAcceptance"),
              "validation-label": _ctx.$translate("acceptance"),
              validation: "required",
              classes: {
                wrapper: {
                  "formkit-wrapper": false,
                  "w-full flex items-center": true
                },
                inner: "mx-3"
              }
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Register"))}</button></div>`);
          } else {
            return [
              createVNode(_component_FormKit, {
                type: "file",
                name: "image",
                label: _ctx.$translate("Profile picture"),
                accept: "image/*",
                classes: {
                  input: "block px-3 w-full",
                  outer: "mb-5",
                  wrapper: {
                    "formkit-wrapper": false
                  }
                }
              }, null, 8, ["label"]),
              createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                createVNode(_component_FormKit, {
                  label: `${_ctx.$translate("fname")} (${_ctx.$translate("In Arabic")})`,
                  type: "text",
                  name: "fname_ar",
                  id: "fname_ar",
                  "outer-class": "mb-3",
                  placeholder: _ctx.$translate("fname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("fname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: `${_ctx.$translate("sname")} (${_ctx.$translate("In Arabic")})`,
                  type: "text",
                  name: "sname_ar",
                  id: "sname_ar",
                  "outer-class": "mb-3",
                  placeholder: _ctx.$translate("sname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("sname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: `${_ctx.$translate("tname")} (${_ctx.$translate("In Arabic")})`,
                  type: "text",
                  name: "tname_ar",
                  id: "tname_ar",
                  "outer-class": "mb-3",
                  placeholder: _ctx.$translate("tname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("tname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: `${_ctx.$translate("lname")} (${_ctx.$translate("In Arabic")})`,
                  type: "text",
                  name: "lname_ar",
                  id: "lname_ar",
                  "outer-class": "mb-3",
                  placeholder: _ctx.$translate("lname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("lname")
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                createVNode(_component_FormKit, {
                  "outer-class": "mb-3",
                  type: "text",
                  label: `${_ctx.$translate("fname")} (${_ctx.$translate("In English")})`,
                  name: "fname_en",
                  id: "fname_en",
                  placeholder: _ctx.$translate("fname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("fname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  "outer-class": "mb-3",
                  type: "text",
                  label: `${_ctx.$translate("sname")} (${_ctx.$translate("In English")})`,
                  name: "sname_en",
                  id: "sname_en",
                  placeholder: _ctx.$translate("sname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("sname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  "outer-class": "mb-3",
                  type: "text",
                  label: `${_ctx.$translate("tname")} (${_ctx.$translate("In English")})`,
                  name: "tname_en",
                  id: "tname_en",
                  placeholder: _ctx.$translate("tname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("tname")
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  "outer-class": "mb-3",
                  type: "text",
                  label: `${_ctx.$translate("lname")} (${_ctx.$translate("In English")})`,
                  name: "lname_en",
                  id: "lname_en",
                  placeholder: _ctx.$translate("lname"),
                  validation: "required:trim|length:3,50",
                  "validation-label": _ctx.$translate("lname")
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode(_component_FormKit, {
                "outer-class": "mb-3",
                type: "myRadio",
                name: "gender",
                label: _ctx.$translate("Gender"),
                options: [
                  {
                    label: _ctx.$translate("Male"),
                    value: 0
                  },
                  {
                    label: _ctx.$translate("Female"),
                    value: 1
                  }
                ],
                "validation-label": _ctx.$translate("Gender"),
                validation: "required",
                classes: {
                  options: "flex items-center",
                  option: {
                    "formkit-option": false
                  },
                  inner: "m-3"
                }
              }, null, 8, ["label", "options", "validation-label"]),
              createVNode("div", {
                class: ["grid grid-cols-1 gap-2 md:gap-4", {
                  "md:grid-cols-4": volunteerData.value.country === 0,
                  "md:grid-cols-3": volunteerData.value.country !== 0
                }]
              }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Country"),
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(countries),
                  name: "country",
                  "validation-label": _ctx.$translate("Country"),
                  validation: "required",
                  "outer-class": "mb-3"
                }, null, 8, ["label", "options", "validation-label"]),
                volunteerData.value.country === 0 ? (openBlock(), createBlock(_component_FormKit, {
                  key: 0,
                  label: _ctx.$translate("City"),
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(cities),
                  name: "city",
                  "validation-label": _ctx.$translate("City"),
                  validation: "required",
                  "outer-class": "mb-3"
                }, null, 8, ["label", "options", "validation-label"])) : createCommentVNode("", true),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Nationality"),
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  "outer-class": "mb-3",
                  options: unref(countries),
                  name: "nationality",
                  "validation-label": _ctx.$translate("Nationality"),
                  validation: "required"
                }, null, 8, ["label", "options", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Qualification"),
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  "outer-class": "mb-3",
                  options: unref(qualifications),
                  name: "qualification",
                  "validation-label": _ctx.$translate("Qualification"),
                  validation: "required"
                }, null, 8, ["label", "options", "validation-label"])
              ], 2),
              createVNode("div", { class: "grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("National ID"),
                  "outer-class": "mb-3",
                  type: "number",
                  placeholder: _ctx.$translate("National ID"),
                  name: "national_id",
                  "validation-label": _ctx.$translate("National ID"),
                  validation: "required:trim|number|length:10"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Martial status"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Martial status"),
                  name: "marital_status",
                  "validation-label": _ctx.$translate("Martial status"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Adminstrative area"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Adminstrative area"),
                  name: "adminstrative_area",
                  "validation-label": _ctx.$translate("Adminstrative area"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Governorate"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Governorate"),
                  name: "governorate",
                  "validation-label": _ctx.$translate("Governorate"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("National address"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("National address"),
                  name: "national_address",
                  id: "national_address",
                  "validation-label": _ctx.$translate("National address"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Job title"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Job title"),
                  name: "job_title",
                  "validation-label": _ctx.$translate("Job title"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Address"),
                  "outer-class": "mb-3",
                  type: "text",
                  placeholder: _ctx.$translate("Address"),
                  name: "address",
                  "validation-label": _ctx.$translate("Address"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode(_component_FormKit, {
                classes: {
                  outer: "my-4",
                  options: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4",
                  option: {
                    "formkit-option": false
                  },
                  fieldset: { "formkit-fieldset": false },
                  wrapper: "flex justify-between items-center p-2 border-l border-b"
                },
                name: "fields",
                type: "checkbox",
                label: _ctx.$translate("Volunteering fields"),
                options: [
                  {
                    label: _ctx.$translate("Photography"),
                    value: 1
                  },
                  {
                    label: _ctx.$translate("Videography"),
                    value: 2
                  },
                  {
                    label: _ctx.$translate("Cinematography"),
                    value: 3
                  },
                  {
                    label: _ctx.$translate("Editing - Media Platforms - Documentation"),
                    value: 4
                  },
                  {
                    label: _ctx.$translate("Coverings"),
                    value: 5
                  },
                  {
                    label: _ctx.$translate("Presentation"),
                    value: 6
                  },
                  {
                    label: _ctx.$translate("Digital content industry"),
                    value: 7
                  },
                  {
                    label: _ctx.$translate("Montage"),
                    value: 8
                  },
                  {
                    label: _ctx.$translate("Social media"),
                    value: 9
                  },
                  {
                    label: _ctx.$translate("Media marketing"),
                    value: 10
                  },
                  {
                    label: _ctx.$translate("Editorial management"),
                    value: 11
                  },
                  {
                    label: _ctx.$translate("Field Editorial Leadership"),
                    value: 12
                  },
                  {
                    label: _ctx.$translate("Management of meetings and seminars"),
                    value: 13
                  },
                  {
                    label: _ctx.$translate("Media training"),
                    value: 14
                  }
                ],
                "validation-label": _ctx.$translate("Volunteering fields"),
                validation: "required"
              }, null, 8, ["label", "options", "validation-label"]),
              createVNode("div", { class: "row-of-two" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Educational level"),
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  type: "text",
                  placeholder: _ctx.$translate("Educational level"),
                  name: "education",
                  "validation-label": _ctx.$translate("Educational level"),
                  validation: "required:trim"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  type: "text",
                  placeholder: _ctx.$translate("Volunteering experiences"),
                  name: "experiences",
                  label: _ctx.$translate("Volunteering experiences"),
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    },
                    outer: "mb-3"
                  },
                  "validation-label": _ctx.$translate("Volunteering experiences"),
                  validation: "required:trim"
                }, null, 8, ["placeholder", "label", "validation-label"])
              ]),
              createVNode("div", { class: "row-of-two" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Branch"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(branches),
                  name: "branch",
                  "validation-label": _ctx.$translate("Branch"),
                  validation: "required"
                }, null, 8, ["label", "options", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("How do you know the authority?"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "select",
                  "sections-schema": {
                    selectIcon: { $el: null }
                  },
                  options: unref(howKnewUs),
                  name: "hearabout",
                  "validation-label": _ctx.$translate("How do you know the authority?"),
                  validation: "required"
                }, null, 8, ["label", "options", "validation-label"])
              ]),
              createVNode("div", { class: "row-of-two" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Email"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "email",
                  placeholder: _ctx.$translate("Email"),
                  id: "email",
                  name: "email",
                  "validation-label": _ctx.$translate("Email"),
                  validation: "required:trim|email"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode("div", {
                  class: "formkit-outer mb-3",
                  "data-family": "text",
                  "data-type": "email"
                }, [
                  createVNode("label", {
                    for: "mobile",
                    class: "formkit-label"
                  }, toDisplayString(_ctx.$translate("Mobile")), 1),
                  createVNode("div", {
                    class: "input-group [&>.formkit-outer]:mb-0 h-9",
                    style: { "border-radius": "5px", "box-shadow": "0 0 0 1px #94929c" }
                  }, [
                    createVNode(_component_FormKit, {
                      type: "myTextInput",
                      "outer-class": "w-full border border-y-0 m-0",
                      id: "mobile",
                      name: "mobile",
                      placeholder: _ctx.$translate("Mobile"),
                      validation: "required:trim|number",
                      "validation-label": _ctx.$translate("Mobile")
                    }, null, 8, ["placeholder", "validation-label"]),
                    createVNode("span", { class: "prepend" }, [
                      createVNode(_component_FormKit, {
                        type: "mySelect",
                        name: "mobile_key",
                        options: unref(mobileCodes),
                        style: { "box-shadow": "none" }
                      }, null, 8, ["options"])
                    ])
                  ])
                ])
              ]),
              createVNode("div", { class: "row-of-two" }, [
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Password"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("Password"),
                  id: "password",
                  name: "password",
                  "validation-label": _ctx.$translate("Password"),
                  validation: "required:trim|length:6"
                }, null, 8, ["label", "placeholder", "validation-label"]),
                createVNode(_component_FormKit, {
                  label: _ctx.$translate("Password confirmation"),
                  classes: {
                    outer: "mb-3",
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full": true
                    }
                  },
                  type: "password",
                  placeholder: _ctx.$translate("Password confirmation"),
                  id: "password_confirm",
                  name: "password_confirm",
                  "validation-label": _ctx.$translate("Password confirmation"),
                  validation: "required:trim|confirm"
                }, null, 8, ["label", "placeholder", "validation-label"])
              ]),
              createVNode("div", { class: "mb-7" }),
              createVNode("div", { class: "mb-7" }, [
                createVNode(_component_FormKit, {
                  type: "checkbox",
                  label: _ctx.$translate("TermsAcceptance"),
                  "validation-label": _ctx.$translate("acceptance"),
                  validation: "required",
                  classes: {
                    wrapper: {
                      "formkit-wrapper": false,
                      "w-full flex items-center": true
                    },
                    inner: "mx-3"
                  }
                }, null, 8, ["label", "validation-label"])
              ]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  type: "submit",
                  class: "btn-primary"
                }, toDisplayString(_ctx.$translate("Register")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/volunteers/auth/register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=register.8c9381e1.mjs.map
