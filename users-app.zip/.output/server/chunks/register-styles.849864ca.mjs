const register_vue_vue_type_style_index_0_lang = "[data-type=checkbox] .formkit-input,[data-type=radio] .formkit-input{left:auto}";

const registerStyles_849864ca = [register_vue_vue_type_style_index_0_lang];

export { registerStyles_849864ca as default };
//# sourceMappingURL=register-styles.849864ca.mjs.map
