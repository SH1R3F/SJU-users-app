import { i as index } from './styles.mjs';

const toastStyles_e8a963e0 = [index];

export { toastStyles_e8a963e0 as default };
//# sourceMappingURL=toast-styles.e8a963e0.mjs.map
