import { o as useNuxtApp, p as useHead, x as useAuthStore, f as __nuxt_component_0$1 } from './server.mjs';
import { resolveComponent, mergeProps, unref, withCtx, createVNode, toDisplayString, createTextVNode, useSSRContext, openBlock, createElementBlock, createElementVNode } from 'vue';
import { useToast as useToast$1 } from 'vue-toastification';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'vue-toastification/dist/index.mjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const useToast = () => {
  return useToast$1();
};
const _hoisted_1 = {
  viewBox: "0 0 640 512",
  width: "1.2em",
  height: "1.2em"
};
const _hoisted_2 = /* @__PURE__ */ createElementVNode("path", {
  fill: "currentColor",
  d: "M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0S96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h274.9c-2.4-6.8-3.4-14-2.6-21.3l6.8-60.9l1.2-11.1l7.9-7.9l77.3-77.3c-24.5-27.7-60-45.5-99.9-45.5zm45.3 145.3l-6.8 61c-1.1 10.2 7.5 18.8 17.6 17.6l60.9-6.8l137.9-137.9l-71.7-71.7l-137.9 137.8zM633 268.9L595.1 231c-9.3-9.3-24.5-9.3-33.8 0l-37.8 37.8l-4.1 4.1l71.8 71.7l41.8-41.8c9.3-9.4 9.3-24.5 0-33.9z"
}, null, -1);
const _hoisted_3 = [
  _hoisted_2
];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, _hoisted_3);
}
const FaSolidUserEdit = { name: "fa-solid-user-edit", render };
const _sfc_main = {
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    const { $i18n } = useNuxtApp();
    const toast = useToast();
    const loginVolunteer = async (body, node) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const authStore = useAuthStore();
      const { data, error } = await authStore.loginVolunteer(body);
      if (((_b = (_a = error == null ? void 0 : error.value) == null ? void 0 : _a.response) == null ? void 0 : _b.status) === 400) {
        node.setErrors((_c = error.value) == null ? void 0 : _c.data);
      } else if (((_e = (_d = error == null ? void 0 : error.value) == null ? void 0 : _d.response) == null ? void 0 : _e.status) === 422) {
        toast.error((_g = (_f = error.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message);
      }
      if (data == null ? void 0 : data.value) {
        authStore.authenticated = true;
        authStore.userData = data.value.userData;
        authStore.userType = "volunteer";
        authStore.accessToken = data.value.accessToken;
        localStorage.setItem("userData", JSON.stringify(data.value.userData));
        localStorage.setItem("userType", "volunteer");
        localStorage.setItem("accessToken", data.value.accessToken);
      }
    };
    const title = $i18n.translate("Login volunteers");
    useHead({
      title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormKit = resolveComponent("FormKit");
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "my-20" }, _attrs))}><div class="container"><div class="flex gap-8"><div class="w-full md:w-1/2"><div class="form"><h5 class="form-title">${ssrInterpolate(unref(title))}</h5>`);
      _push(ssrRenderComponent(_component_FormKit, {
        type: "form",
        actions: false,
        onSubmit: loginVolunteer
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Email"),
              type: "email",
              name: "email",
              id: "email",
              classes: {
                outer: "mb-3",
                wrapper: {
                  "w-full": true,
                  "formkit-wrapper": false
                }
              },
              placeholder: _ctx.$translate("Email"),
              validation: "required:trim|email",
              "validation-label": _ctx.$translate("Email")
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormKit, {
              label: _ctx.$translate("Password"),
              type: "password",
              name: "password",
              id: "password",
              classes: {
                outer: "mb-3",
                wrapper: {
                  "w-full": true,
                  "formkit-wrapper": false
                }
              },
              placeholder: _ctx.$translate("Password"),
              validation: "required:trim|length:6",
              "validation-label": _ctx.$translate("Password")
            }, null, _parent2, _scopeId));
            _push2(`<div class="text-end"${_scopeId}><button type="submit" class="btn-primary"${_scopeId}>${ssrInterpolate(_ctx.$translate("Login"))}</button></div>`);
          } else {
            return [
              createVNode(_component_FormKit, {
                label: _ctx.$translate("Email"),
                type: "email",
                name: "email",
                id: "email",
                classes: {
                  outer: "mb-3",
                  wrapper: {
                    "w-full": true,
                    "formkit-wrapper": false
                  }
                },
                placeholder: _ctx.$translate("Email"),
                validation: "required:trim|email",
                "validation-label": _ctx.$translate("Email")
              }, null, 8, ["label", "placeholder", "validation-label"]),
              createVNode(_component_FormKit, {
                label: _ctx.$translate("Password"),
                type: "password",
                name: "password",
                id: "password",
                classes: {
                  outer: "mb-3",
                  wrapper: {
                    "w-full": true,
                    "formkit-wrapper": false
                  }
                },
                placeholder: _ctx.$translate("Password"),
                validation: "required:trim|length:6",
                "validation-label": _ctx.$translate("Password")
              }, null, 8, ["label", "placeholder", "validation-label"]),
              createVNode("div", { class: "text-end" }, [
                createVNode("button", {
                  type: "submit",
                  class: "btn-primary"
                }, toDisplayString(_ctx.$translate("Login")), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="w-1/2 hidden md:flex items-center justify-center"><div class="text-center">`);
      _push(ssrRenderComponent(unref(FaSolidUserEdit), { class: "text-5xl mb-7 text-sju-100 m-auto" }, null, _parent));
      _push(`<h4 class="text-sju-200 mb-2">${ssrInterpolate(_ctx.$translate("Register new volunteer"))}</h4><p class="mb-4">${ssrInterpolate(_ctx.$translate("You can register as a new volunteer from this link"))}</p>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "volunteers/register",
        class: "text-sju-50"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$translate("Click here to register"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$translate("Click here to register")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/volunteers/auth/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=login.dfae9419.mjs.map
