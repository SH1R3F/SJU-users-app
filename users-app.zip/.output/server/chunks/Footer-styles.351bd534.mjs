const Footer_vue_vue_type_style_index_0_scoped_aba2e56a_lang = ".twitter-white[data-v-aba2e56a]{fill:#fff}";

const FooterStyles_351bd534 = [Footer_vue_vue_type_style_index_0_scoped_aba2e56a_lang];

export { FooterStyles_351bd534 as default };
//# sourceMappingURL=Footer-styles.351bd534.mjs.map
