const index_vue_vue_type_style_index_0_scoped_87c044d6_lang = ".twitter-green[data-v-87c044d6]{fill:#007d41}";

const indexStyles_22cc77e7 = [index_vue_vue_type_style_index_0_scoped_87c044d6_lang];

export { indexStyles_22cc77e7 as default };
//# sourceMappingURL=index-styles.22cc77e7.mjs.map
