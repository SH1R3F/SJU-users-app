const default_vue_vue_type_style_index_0_lang = "body{font-family:Droid Arabic Kufi,sans-serif!important}";

const defaultStyles_7948269c = [default_vue_vue_type_style_index_0_lang];

export { defaultStyles_7948269c as default };
//# sourceMappingURL=default-styles.7948269c.mjs.map
