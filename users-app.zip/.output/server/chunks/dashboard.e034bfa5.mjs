import { a as _export_sfc, f as __nuxt_component_0$1 } from './server.mjs';
import { resolveComponent, mergeProps, withCtx, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'vue-toastification/dist/index.mjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_nuxt_link = __nuxt_component_0$1;
  const _component_NuxtChild = resolveComponent("NuxtChild");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "dashboard my-16" }, _attrs))}><div class="container"><div class="flex gap-5 flex-col sm:flex-row"><div class="w-full sm:w-3/12"><img src="http://127.0.0.1:8000/storage/volunteers/18/images/1667396869.jpg" class="rounded-full mx-auto mb-5 h-40 w-40 lg:h-52 lg:w-52 object-cover object-top shadow-lg"><h6 class="text-sju-50 text-center font-bold">\u062A\u062C\u0631\u0628\u0629 \u062A\u062C\u0631\u0628\u0629 \u062A\u062C\u0631\u0628\u0629 \u062A\u062C\u0631\u0628\u0629</h6><ul class="mt-4">`);
  _push(ssrRenderComponent(_component_nuxt_link, {
    to: "/volunteers/dashboard",
    class: "block active p-2 hover:bg-sju-500 transition-all [&.router-link-active]:text-sju-50 [&.router-link-active]:font-bold [&.router-link-active]:bg-sju-500 dark:[&.router-link-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`${ssrInterpolate(_ctx.$translate("Events"))}`);
      } else {
        return [
          createTextVNode(toDisplayString(_ctx.$translate("Events")), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_nuxt_link, {
    to: "/volunteers/dashboard/profile",
    class: "block p-2 hover:bg-sju-500 transition-all [&.router-link-active]:text-sju-50 [&.router-link-active]:font-bold [&.router-link-active]:bg-sju-500 dark:[&.router-link-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`${ssrInterpolate(_ctx.$translate("Profile"))}`);
      } else {
        return [
          createTextVNode(toDisplayString(_ctx.$translate("Profile")), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_nuxt_link, { class: "block p-2 hover:bg-sju-500 transition-all [&.router-link-active]:text-sju-50 [&.router-link-active]:font-bold [&.router-link-active]:bg-sju-500 dark:[&.router-link-active]:bg-sjud-200 dark:hover:bg-sjud-200 dark:text-sjud-400" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`${ssrInterpolate(_ctx.$translate("Technical support"))}`);
      } else {
        return [
          createTextVNode(toDisplayString(_ctx.$translate("Technical support")), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</ul></div><div class="w-full sm:w-9/12">`);
  _push(ssrRenderComponent(_component_NuxtChild, null, null, _parent));
  _push(`</div></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/volunteers/dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const dashboard = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { dashboard as default };
//# sourceMappingURL=dashboard.e034bfa5.mjs.map
