import { b as useLocalization, m as useRoute, r as usePostStore, n as storeToRefs, o as useNuxtApp, p as useHead, q as _sfc_main$3, t as _sfc_main$9 } from './server.mjs';
import { withAsyncContext, ref, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'vue-toastification/dist/index.mjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { dblocalize } = useLocalization();
    const route = useRoute();
    const postStore = usePostStore();
    const { post, relatedPosts } = storeToRefs(postStore);
    [__temp, __restore] = withAsyncContext(() => postStore.fetchPost(route.params.id)), await __temp, __restore();
    const { $i18n } = useNuxtApp();
    const meta = ref({
      title: dblocalize(post.value, "title"),
      breadcrumb: [
        {
          link: "/",
          title: $i18n.translate("Home")
        },
        {
          link: "/posts",
          title: $i18n.translate("Posts list")
        }
      ]
    });
    useHead({
      title: meta.value.title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_page_header = _sfc_main$3;
      const _component_post_preview = _sfc_main$9;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_page_header, {
        title: meta.value.title,
        breadcrumb: meta.value.breadcrumb,
        date: unref(post).postDate
      }, null, _parent));
      _push(`<div class="page-content py-11 dark:bg-sjud-100"><div class="container"><div class="flex flex-col md:flex-row gap-6"><div class="md:w-8/12 text-center text-gray-600">`);
      if (unref(post).photos) {
        _push(`<!--[-->`);
        ssrRenderList(unref(post).photos, (photo) => {
          _push(`<img${ssrRenderAttr("src", photo)}${ssrRenderAttr("alt", unref(dblocalize)(unref(post), "title"))} class="my-1 max-w-full mx-auto">`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="text-start border-b py-5 content">${unref(dblocalize)(unref(post), "content")}</div></div><div class="md:w-4/12"><h3 class="mb-3 text-sju-50">${ssrInterpolate(_ctx.$translate("Related posts"))}</h3><!--[-->`);
      ssrRenderList(unref(postStore).relatedPosts, (post2) => {
        _push(ssrRenderComponent(_component_post_preview, {
          post: post2,
          class: "mb-5"
        }, null, _parent));
      });
      _push(`<!--]--></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_.d65d6aff.mjs.map
