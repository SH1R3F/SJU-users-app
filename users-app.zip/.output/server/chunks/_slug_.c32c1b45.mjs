import { b as useLocalization, l as usePageStore, m as useRoute, n as storeToRefs, o as useNuxtApp, p as useHead, q as _sfc_main$3 } from './server.mjs';
import { withAsyncContext, ref, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'vue-toastification/dist/index.mjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { dblocalize } = useLocalization();
    const pageStore = usePageStore();
    const route = useRoute();
    [__temp, __restore] = withAsyncContext(() => pageStore.fetchPage(route.params.slug)), await __temp, __restore();
    const { page } = storeToRefs(pageStore);
    const { $i18n } = useNuxtApp();
    const meta = ref({
      title: dblocalize(page.value, "title"),
      breadcrumb: [
        {
          link: "/",
          title: $i18n.translate("Home")
        }
      ]
    });
    useHead({
      title: meta.value.title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_page_header = _sfc_main$3;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_page_header, {
        title: meta.value.title,
        breadcrumb: meta.value.breadcrumb
      }, null, _parent));
      _push(`<div class="page-content py-11 dark:bg-sjud-100"><div class="container"><div class="text-start border-b py-5 content">${unref(dblocalize)(unref(page), "content")}</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/pages/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_.c32c1b45.mjs.map
