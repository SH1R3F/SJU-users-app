import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { a as _export_sfc } from './server.mjs';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'vue-toastification/dist/index.mjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "my-20" }, _attrs))}><div class="container"><div class="form"><h5 class="text-sju-50 mb-5 border-b border-b-sju-400 pt-0 px-1 pb-2 inline-block">\u062A\u0633\u062C\u064A\u0644 \u0645\u0634\u062A\u0631\u0643 \u062C\u062F\u064A\u062F</h5> \`\` <form action="https://sju.org.sa/volunteers/login" method="post"><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 md:gap-4"><div class="mb-3"><label for="fname">\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0623\u0648\u0644</label><input type="text" name="fname" id="fname" placeholder="\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0623\u0648\u0644" required></div><div class="mb-3"><label for="sname">\u0627\u0633\u0645 \u0627\u0644\u0623\u0628</label><input type="text" name="sname" id="sname" placeholder="\u0627\u0633\u0645 \u0627\u0644\u0623\u0628" required></div><div class="mb-3"><label for="tname">\u0627\u0633\u0645 \u0627\u0644\u062C\u062F</label><input type="text" name="tname" id="tname" placeholder="\u0627\u0633\u0645 \u0627\u0644\u062C\u062F" required></div><div class="mb-3"><label for="lname">\u0627\u0633\u0645 \u0627\u0644\u0639\u0627\u0626\u0644\u0629</label><input type="text" name="lname" id="lname" placeholder="\u0627\u0633\u0645 \u0627\u0644\u0639\u0627\u0626\u0644\u0629" required></div></div><div class="mb-3"><label>\u0627\u0644\u062C\u0646\u0633</label><div class="px-2"><label for="male" class="mx-3"><input type="radio" name="gender" id="male" class="mx-1"> \u0630\u0643\u0631 </label><label for="female" class="mx-3"><input type="radio" name="gender" id="female" class="mx-1"> \u0623\u0646\u062B\u0649 </label></div></div><div class="row-of-two"><div class="mb-3"><label for="address">\u0645\u0643\u0627\u0646 \u0627\u0644\u0625\u0642\u0627\u0645\u0629</label><select name="address" id="address"><option value="1">\u0645\u0648\u0632\u0645\u0628\u064A\u0642</option><option value="2">\u0627\u0644\u063A\u0631\u062F\u0642\u0629</option></select></div><div class="mb-3"><label for="nationality">\u0627\u0644\u062C\u0646\u0633\u064A\u0629</label><select name="nationality" id="nationality"><option value="1">\u0645\u0648\u0632\u0645\u0628\u064A\u0642</option><option value="2">\u0627\u0644\u063A\u0631\u062F\u0642\u0629</option></select></div></div><div class="row-of-two"><div class="mb-3"><label for="qualification">\u0622\u062E\u0631 \u0645\u0624\u0647\u0644 \u062F\u0631\u0627\u0633\u064A</label><select name="qualification" id="qualification"><option value="1">\u0645\u0648\u0632\u0645\u0628\u064A\u0642</option><option value="2">\u0627\u0644\u063A\u0631\u062F\u0642\u0629</option></select></div><div class="mb-3"><label for="HowKnew">\u0643\u064A\u0641 \u062A\u0639\u0631\u0641\u062A \u0639\u0644\u0649 \u0627\u0644\u0647\u064A\u0626\u0629</label><select name="HowKnew" id="HowKnew"><option value="1">\u0645\u0648\u0632\u0645\u0628\u064A\u0642</option><option value="2">\u0627\u0644\u063A\u0631\u062F\u0642\u0629</option></select></div></div><div class="row-of-two"><div class="mb-3"><label for="email">\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A</label><input type="email" name="email" id="email" placeholder="\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0627\u0644\u0643\u062A\u0631\u0648\u0646\u064A" required></div><div class="mb-3"><label for="mobile">\u0631\u0642\u0645 \u0627\u0644\u062C\u0648\u0627\u0644</label><div class="input-group"><input type="number" name="mobile" id="mobile" placeholder="\u0631\u0642\u0645 \u0627\u0644\u062C\u0648\u0627\u0644" required><span class="prepend"> 966 </span></div></div></div><div class="row-of-two"><div class="mb-3"><label for="password">\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631</label><input type="password" name="password" id="password" placeholder="\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" required></div><div class="mb-3"><label for="password_confirmation">\u062A\u0623\u0643\u064A\u062F \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631</label><input type="password" name="password_confirmation" id="password_confirmation" placeholder="\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" required></div></div><div class="mb-7"><label for="userPassword">\u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642</label><input type="password" name="password" class="form-control" id="userPassword" placeholder="\u0631\u0645\u0632 \u0627\u0644\u062A\u062D\u0642\u0642" autocompleted=""></div><div class="mb-7"><input type="checkbox" name="terms" id="terms"><label for="terms">\u0623\u062A\u0639\u0647\u062F \u0628\u0623\u0646 \u062C\u0645\u064A\u0639 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0635\u062D\u064A\u062D\u0629 \u060C \u0648\u0625\u0646 \u0643\u0627\u0646\u062A \u062E\u0644\u0627\u0641 \u0630\u0644\u0643 \u0633\u064A\u062A\u0645 \u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643</label></div><div class="text-end"><button type="submit" class="btn-primary">\u062A\u0633\u062C\u064A\u0644</button></div></form></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/subscribers/register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const register = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { register as default };
//# sourceMappingURL=register.2cbf964a.mjs.map
