import { ssrInterpolate } from 'vue/server-renderer';
import { useSSRContext } from 'vue';
import { a as _export_sfc } from './server.mjs';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'vue-toastification/dist/index.mjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<!--[--><div class="card"><div class="card-title font-semibold">${ssrInterpolate(_ctx.$translate("Upcoming events"))}</div><div class="overflow-x-auto relative shadow-md sm:rounded-lg"><table class="w-full text-sm text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"><tr><th scope="col" class="py-3 px-6">#</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Event name"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Event date"))}</th></tr></thead><tbody class="text-center"><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">1</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">\u062A\u062C\u0631\u0628\u0629 \u0627\u0633\u0645 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629</td><td class="py-4 px-6">11 \u0633\u0628\u062A\u0645\u0628\u0631 2022</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">2</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">\u062A\u062C\u0631\u0628\u0629 \u0627\u0633\u0645 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629</td><td class="py-4 px-6">11 \u0633\u0628\u062A\u0645\u0628\u0631 2022</td></tr></tbody></table></div></div><div class="card"><div class="card-title font-semibold">${ssrInterpolate(_ctx.$translate("Enrolled events"))}</div><div class="overflow-x-auto relative shadow-md sm:rounded-lg"><table class="w-full text-sm text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase dark:text-gray-400"><tr><th scope="col" class="py-3 px-6">#</th><th scope="col" class="py-3 px-6 bg-gray-50 dark:bg-gray-800">${ssrInterpolate(_ctx.$translate("Event name"))}</th><th scope="col" class="py-3 px-6">${ssrInterpolate(_ctx.$translate("Event date"))}</th></tr></thead><tbody class="text-center"><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">1</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">\u062A\u062C\u0631\u0628\u0629 \u0627\u0633\u0645 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629</td><td class="py-4 px-6">11 \u0633\u0628\u062A\u0645\u0628\u0631 2022</td></tr><tr class="border-b border-gray-200 dark:border-gray-700"><td class="py-4 px-6">2</td><td class="py-4 px-6 bg-gray-50 dark:bg-gray-800">\u062A\u062C\u0631\u0628\u0629 \u0627\u0633\u0645 \u0627\u0644\u0641\u0639\u0627\u0644\u064A\u0629</td><td class="py-4 px-6">11 \u0633\u0628\u062A\u0645\u0628\u0631 2022</td></tr></tbody></table></div></div><!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/volunteers/dashboard/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index.15abc9f8.mjs.map
