const client_manifest = {
  "assets/fonts/droidkufi/DroidKufi-Bold.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "DroidKufi-Bold.827c40bb.eot",
    "src": "assets/fonts/droidkufi/DroidKufi-Bold.eot"
  },
  "assets/fonts/droidkufi/DroidKufi-Regular.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "DroidKufi-Regular.1fe42158.eot",
    "src": "assets/fonts/droidkufi/DroidKufi-Regular.eot"
  },
  "assets/fonts/droidkufi/DroidKufi-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "DroidKufi-Bold.31f02fb9.woff2",
    "src": "assets/fonts/droidkufi/DroidKufi-Bold.woff2"
  },
  "assets/fonts/droidkufi/DroidKufi-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "DroidKufi-Regular.a7b09bb9.woff2",
    "src": "assets/fonts/droidkufi/DroidKufi-Regular.woff2"
  },
  "assets/fonts/droidkufi/DroidKufi-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "DroidKufi-Regular.1a4abb4b.woff",
    "src": "assets/fonts/droidkufi/DroidKufi-Regular.woff"
  },
  "assets/fonts/droidkufi/DroidKufi-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "DroidKufi-Bold.91862e14.woff",
    "src": "assets/fonts/droidkufi/DroidKufi-Bold.woff"
  },
  "assets/fonts/droidkufi/DroidKufi-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "DroidKufi-Regular.ae57aea1.ttf",
    "src": "assets/fonts/droidkufi/DroidKufi-Regular.ttf"
  },
  "assets/fonts/droidkufi/DroidKufi-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "DroidKufi-Bold.b9699e2c.ttf",
    "src": "assets/fonts/droidkufi/DroidKufi-Bold.ttf"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.b63c5213.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "middleware/guest.js",
      "virtual:nuxt:C:/wamp64/www/Saudi Journalists V2/users-app/.nuxt/error-component.mjs",
      "layouts/default.vue",
      "node_modules/nuxt/dist/app/entry.mjs-css"
    ],
    "css": [],
    "assets": [
      "DroidKufi-Regular.1fe42158.eot",
      "DroidKufi-Regular.a7b09bb9.woff2",
      "DroidKufi-Regular.1a4abb4b.woff",
      "DroidKufi-Regular.ae57aea1.ttf",
      "DroidKufi-Bold.827c40bb.eot",
      "DroidKufi-Bold.31f02fb9.woff2",
      "DroidKufi-Bold.91862e14.woff",
      "DroidKufi-Bold.b9699e2c.ttf"
    ]
  },
  "entry.6eee7992.css": {
    "file": "entry.6eee7992.css",
    "resourceType": "style"
  },
  "DroidKufi-Regular.1fe42158.eot": {
    "file": "DroidKufi-Regular.1fe42158.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "DroidKufi-Regular.a7b09bb9.woff2": {
    "file": "DroidKufi-Regular.a7b09bb9.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "DroidKufi-Regular.1a4abb4b.woff": {
    "file": "DroidKufi-Regular.1a4abb4b.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "DroidKufi-Regular.ae57aea1.ttf": {
    "file": "DroidKufi-Regular.ae57aea1.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "DroidKufi-Bold.827c40bb.eot": {
    "file": "DroidKufi-Bold.827c40bb.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "DroidKufi-Bold.31f02fb9.woff2": {
    "file": "DroidKufi-Bold.31f02fb9.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "DroidKufi-Bold.91862e14.woff": {
    "file": "DroidKufi-Bold.91862e14.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "DroidKufi-Bold.b9699e2c.ttf": {
    "file": "DroidKufi-Bold.b9699e2c.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "virtual:nuxt:C:/wamp64/www/Saudi Journalists V2/users-app/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.fd113d53.js",
    "src": "virtual:nuxt:C:/wamp64/www/Saudi Journalists V2/users-app/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.373e30df.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_PostPreview.a4e7f2b5.js",
      "_useLocalization.0bdf635d.js",
      "_linkedin.96d40af5.js"
    ],
    "css": []
  },
  "index.0f5d9e50.css": {
    "file": "index.0f5d9e50.css",
    "resourceType": "style"
  },
  "_useLocalization.0bdf635d.js": {
    "resourceType": "script",
    "module": true,
    "file": "useLocalization.0bdf635d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_PostPreview.a4e7f2b5.js": {
    "resourceType": "script",
    "module": true,
    "file": "PostPreview.a4e7f2b5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.0bdf635d.js"
    ]
  },
  "_linkedin.96d40af5.js": {
    "resourceType": "script",
    "module": true,
    "file": "linkedin.96d40af5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/pages/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_slug_.551d53c3.js",
    "src": "pages/pages/[slug].vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.805fc1ea.js",
      "_useLocalization.0bdf635d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_PageHeader.805fc1ea.js": {
    "resourceType": "script",
    "module": true,
    "file": "PageHeader.805fc1ea.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/posts/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.4433c9f4.js",
    "src": "pages/posts/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.805fc1ea.js",
      "_PostPreview.a4e7f2b5.js",
      "_useLocalization.0bdf635d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/posts/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.9f491568.js",
    "src": "pages/posts/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_PageHeader.805fc1ea.js",
      "_PostPreview.a4e7f2b5.js",
      "node_modules/nuxt/dist/app/entry.mjs",
      "_useLocalization.0bdf635d.js"
    ]
  },
  "pages/subscribers/register.vue": {
    "resourceType": "script",
    "module": true,
    "file": "register.9fb77a53.js",
    "src": "pages/subscribers/register.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/auth/login.vue": {
    "resourceType": "script",
    "module": true,
    "file": "login.958470f7.js",
    "src": "pages/volunteers/auth/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/auth/register.vue": {
    "resourceType": "script",
    "module": true,
    "file": "register.48db4be3.js",
    "src": "pages/volunteers/auth/register.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "register.d6af9369.css": {
    "file": "register.d6af9369.css",
    "resourceType": "style"
  },
  "pages/volunteers/dashboard/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.0f534e59.js",
    "src": "pages/volunteers/dashboard/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/dashboard/profile.vue": {
    "resourceType": "script",
    "module": true,
    "file": "profile.9cd4dc4d.js",
    "src": "pages/volunteers/dashboard/profile.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/volunteers/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "file": "dashboard.fbf50c07.js",
    "src": "pages/volunteers/dashboard.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "middleware/guest.js": {
    "resourceType": "script",
    "module": true,
    "file": "guest.b4a663c1.js",
    "src": "middleware/guest.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.39639ef3.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_linkedin.96d40af5.js",
      "_useLocalization.0bdf635d.js"
    ],
    "css": []
  },
  "default.779cc3f3.css": {
    "file": "default.779cc3f3.css",
    "resourceType": "style"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.779cc3f3.css",
    "src": "layouts/default.css"
  },
  "pages/volunteers/auth/register.css": {
    "resourceType": "style",
    "file": "register.d6af9369.css",
    "src": "pages/volunteers/auth/register.css"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.0f5d9e50.css",
    "src": "pages/index.css"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.6eee7992.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.mjs-css": {
    "file": "",
    "css": [
      "entry.6eee7992.css"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
