import { b as useLocalization, v as useRouter, m as useRoute, r as usePostStore, n as storeToRefs, o as useNuxtApp, p as useHead, q as _sfc_main$3, t as _sfc_main$9, w as _sfc_main$2 } from './server.mjs';
import { withAsyncContext, watch, ref, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'vue-toastification/dist/index.mjs';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { dblocalize } = useLocalization();
    const router = useRouter();
    const route = useRoute();
    const postStore = usePostStore();
    const { posts, categories, getCategory, getPagination } = storeToRefs(postStore);
    [__temp, __restore] = withAsyncContext(() => postStore.fetchCategories()), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => postStore.fetchPosts()), await __temp, __restore();
    const setPage = (page) => {
      router.push({
        path: route.fullPath,
        query: {
          page,
          category: route.query.category
        }
      });
    };
    watch(
      () => route.query,
      async () => {
        postStore.category = route.query.category;
        postStore.pagination.current_page = route.query.page;
        await postStore.fetchPosts();
      }
    );
    const { $i18n } = useNuxtApp();
    const meta = ref({
      title: $i18n.translate("Posts list"),
      breadcrumb: [
        {
          link: "/",
          title: $i18n.translate("Home")
        }
      ]
    });
    useHead({
      title: meta.value.title
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_page_header = _sfc_main$3;
      const _component_post_preview = _sfc_main$9;
      const _component_simple_pagination = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_page_header, {
        title: meta.value.title,
        breadcrumb: meta.value.breadcrumb
      }, null, _parent));
      _push(`<div class="page-content py-11 dark:bg-sjud-100"><div class="container"><ul class="w-full border-b"><li class="${ssrRenderClass([{ active: unref(getCategory)() == "all" }, "cursor-pointer inline-block text-sju-50 text-sm px-5 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300"])}">${ssrInterpolate(_ctx.$translate("All"))}</li><!--[-->`);
      ssrRenderList(unref(categories), (category) => {
        _push(`<li class="${ssrRenderClass([{ active: unref(getCategory)() == category.id }, "cursor-pointer inline-block text-sju-50 text-sm px-5 py-3 hover:bg-gray-200 hover:text-sju-50 [&.active]:text-white [&.active]:bg-sju-50 transition dark:text-white dark:hover:bg-sjud-300"])}">${ssrInterpolate(unref(dblocalize)(category, "title"))}</li>`);
      });
      _push(`<!--]--></ul>`);
      if (unref(posts)) {
        _push(`<div class="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 my-10"><!--[-->`);
        ssrRenderList(unref(posts), (post) => {
          _push(`<div>`);
          _push(ssrRenderComponent(_component_post_preview, { post }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<div class="my-5 p-5 bg-sju-50 rounded-sm text-white">${ssrInterpolate(_ctx.$translate("No posts found"))}</div>`);
      }
      if (unref(getPagination)().last_page) {
        _push(ssrRenderComponent(_component_simple_pagination, {
          pagination: unref(getPagination)(),
          onPaginate: setPage
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.1f905bce.mjs.map
