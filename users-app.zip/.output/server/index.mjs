globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
export { n as default } from './chunks/node-server.mjs';
import 'h3';
import 'ohmyfetch';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';
//# sourceMappingURL=index.mjs.map
