// Public variables that can be determined at build time.
export default defineAppConfig({
	title: "Saudi journalists association",
})
